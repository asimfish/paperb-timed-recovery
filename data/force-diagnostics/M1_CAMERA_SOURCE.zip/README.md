# Bounded M1 secondary camera encoder source

This archive contains the fixed post-result encoder and its protocol/release. It is not a prospective auditor, a full native simulator source release, or a full RAW dataset. The force audit remains RED; only the already accepted base camera partition is used.

Run with Python/Pillow plus ffmpeg/ffprobe and the private, already audited runtime JPEG/metadata and frozen audit directory:

    python -B encode_native_camera.py --runtime-root <bound-runtime> --audit-dir <frozen-audit-directory> --output <existing-empty-output-directory>

The public MP4 is a168-frame recorded task window, not the whole episode. No artificial final repeat, interpolation, old ARIS frames, force numerical parsing or physics rerun is used. Native absolute clocks and video display PTS are separately indexed. Source JPEG hashes cannot reconstruct pre-JPEG raw RGB digests.
