"""Encode only M1's already audited camera partition; keep full force RED unchanged."""
import argparse,hashlib,io,json,math,shutil,subprocess
from pathlib import Path
from PIL import Image
HERE=Path(__file__).resolve().parent
CASE='dev_seen_force_channel_diagnostics_002'
PROTOCOL=HERE/'ENCODER_PROTOCOL.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())

def main():
 p=argparse.ArgumentParser();p.add_argument('--runtime-root',type=Path,required=True);p.add_argument('--audit-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 cfg=read(PROTOCOL);audit_path=a.audit_dir/'NATIVE_RAW_AUDIT.json';public_path=a.audit_dir/'PUBLIC_AUDIT.json';first_path=a.audit_dir/'FIRST_REJECTED_FORCE_RECORD_ID.json'
 assert sha(audit_path.read_bytes())==cfg['original_raw_audit_sha256']
 assert sha(public_path.read_bytes())==cfg['public_audit_sha256']
 audit=read(audit_path);public=read(public_path);first=read(first_path)
 assert audit['status']==cfg['required_original_force_audit_status'] and audit['case_id']==public['case_id']==CASE
 assert audit['auditor_release_sha256']==cfg['prospective_reader_release_sha256']
 assert public['force_scientific_qualification']['training_admitted']==0 and public['current_learning_scope']['weights']==0
 camera=audit['inherited_native_physical_FIFO_capture_and_mechanical_audit']['captures']
 assert camera['status']==cfg['required_camera_partition_status'] and camera['RGBD_count']==177 and camera['video_frames']==168
 assert public['accepted_base_integrity_counts']['RGBD']==177 and public['accepted_base_integrity_counts']['source_video_frames']==168
 members=audit['all_case_regular_RAW_members'];assert len(members)==425
 task=a.runtime_root/'cases'/CASE/'task'
 def bound_bytes(path):
  assert path.is_file() and not path.is_symlink()
  rel=str(path.relative_to(a.runtime_root));b=path.read_bytes();pin=members[rel]
  assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],rel
  return b
 video_bytes=bound_bytes(task/'video_frames.json');capture_bytes=bound_bytes(task/'capture_index.json')
 video=json.loads(video_bytes);captures=json.loads(capture_bytes);frames=video['frames']
 assert video['fps']==6 and len(frames)==168 and len(captures)==177
 assert [f['command_index'] for f in frames]==list(range(2160,8841,40))
 capture_by_index={x['command_index']:x for x in captures};assert len(capture_by_index)==177
 audited_by_index={x['command_index']:x for x in camera['captures']};assert len(audited_by_index)==177
 assert len({x['image'] for x in frames})==168
 epoch=public['native_epoch'];prev=-math.inf;image_bytes=[];index=[]
 for ordinal,f in enumerate(frames):
  assert f['native_epoch']==epoch and f['observation_mode']=='OFFLINE_CAPTURE'
  assert f['native_time_s']==f['rendered_state_native_time_s'] and math.isfinite(f['native_time_s']) and f['native_time_s']>prev
  assert f['policy_delivery_time_s'] is None and f['physics_callbacks_during_render']==0 and f['physical_state_changed'] is False and f['sensor_clock_is_native_clock'] is False
  idx=f['command_index'];assert capture_by_index[idx]==f
  audited=audited_by_index[idx];assert audited['native_time_s']==f['native_time_s'] and audited['JPEG_sha256']==f['image_sha256']
  relative=Path(f['image']);assert not relative.is_absolute() and '..' not in relative.parts and relative.parent==Path('images')
  raw=bound_bytes(task/relative);assert sha(raw)==f['image_sha256']
  with Image.open(io.BytesIO(raw)) as im:
   im.load();assert im.format=='JPEG' and im.size==(640,400) and im.mode=='RGB'
  image_bytes.append(raw);index.append({'source_ordinal':ordinal,'source_command_index':idx,'source_image':str(relative),'source_JPEG_sha256':sha(raw),'source_JPEG_bytes':len(raw),'native_epoch':epoch,'absolute_native_time_s':f['native_time_s'],'rendered_state_native_time_s':f['rendered_state_native_time_s'],'source_camera_frame':f['camera_frame'],'video_display_PTS_s':ordinal/6,'source_RGB_raw_digest_not_reconstructed':True});prev=f['native_time_s']
 assert a.output.is_dir() and not any(a.output.iterdir()),'Output directory must already exist and be empty.'
 input_binding={'schema':'SecondaryM1CameraInputBinding/1','status':'SOURCE_JPEG_AND_METADATA_HASHES_MATCH_ORIGINAL_RED_AUDIT_CAMERA_PARTITION','original_raw_audit_sha256':sha(audit_path.read_bytes()),'public_audit_sha256':sha(public_path.read_bytes()),'encoder_protocol_sha256':sha(PROTOCOL.read_bytes()),'encoder_source_sha256':sha(Path(__file__).read_bytes()),'video_metadata_sha256':sha(video_bytes),'capture_index_sha256':sha(capture_bytes),'source_JPEG_members_checked':168,'all_case_regular_member_count_in_original_audit':425,'force_numeric_stream_read':False}
 (a.output/'INPUT_BINDING.json').write_text(json.dumps(input_binding,indent=2)+'\n')
 ffmpeg=shutil.which('ffmpeg');ffprobe=shutil.which('ffprobe');assert ffmpeg and ffprobe
 mp4=a.output/'M1_native_camera_force_rejected.mp4'
 command=[ffmpeg,'-hide_banner','-loglevel','warning','-f','image2pipe','-vcodec','mjpeg','-framerate','6','-i','pipe:0','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart','-frames:v','168','-y',str(mp4)]
 with (a.output/'ENCODER.log').open('wb') as log:
  process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=log)
  try:
   for raw in image_bytes:process.stdin.write(raw)
   process.stdin.close();code=process.wait(timeout=120)
  except BaseException:
   if process.poll() is None:process.kill();process.wait(timeout=5)
   raise
 assert code==0
 poster=a.output/'M1_native_camera_poster.jpg';poster.write_bytes(image_bytes[0])
 probe_cmd=[ffprobe,'-v','error','-select_streams','v:0','-count_frames','-show_frames','-show_streams','-show_format','-of','json',str(mp4)]
 probe_bytes=subprocess.check_output(probe_cmd,timeout=120);(a.output/'FFPROBE_FULL_FRAME_DECODE.json').write_bytes(probe_bytes)
 probe=json.loads(probe_bytes);stream=probe['streams'][0];decoded=probe['frames']
 assert len(probe['streams'])==1 and stream['codec_type']=='video' and stream['codec_name']=='h264'
 assert stream['width']==640 and stream['height']==400 and stream['avg_frame_rate']=='6/1'
 assert int(stream['nb_read_frames'])==int(stream['nb_frames'])==len(decoded)==168
 assert float(stream['duration'])==float(probe['format']['duration'])==28
 for ordinal,frame in enumerate(decoded):
  assert frame['width']==640 and frame['height']==400 and abs(float(frame['best_effort_timestamp_time'])-ordinal/6)<=0.000001
 first_clock=first['actual_native_clock'];assert first_clock['native_epoch']==epoch
 t=first_clock['time_s'];lower=max((f for f in index if f['absolute_native_time_s']<=t),key=lambda f:f['absolute_native_time_s']);upper=min((f for f in index if f['absolute_native_time_s']>=t),key=lambda f:f['absolute_native_time_s'])
 rejection_bracket={'source':'original frozen FIRST_REJECTED_FORCE_RECORD_ID.json; no force value parsed','record_sha256':sha(first_path.read_bytes()),'rejected_record_native_time_s':t,'lower_source_ordinal':lower['source_ordinal'],'lower_source_command_index':lower['source_command_index'],'lower_native_time_s':lower['absolute_native_time_s'],'lower_minus_rejection_s':lower['absolute_native_time_s']-t,'upper_source_ordinal':upper['source_ordinal'],'upper_source_command_index':upper['source_command_index'],'upper_native_time_s':upper['absolute_native_time_s'],'upper_minus_rejection_s':upper['absolute_native_time_s']-t,'same_clock_video_frame_exists':any(f['absolute_native_time_s']==t for f in index),'not_claimed_exact_rejected_snapshot':True}
 frame_index={'schema':'M1SecondaryNativeCameraFrameIndex/1','case_id':CASE,'source_qualification':'accepted base camera partition of original force RED audit','native_epoch':epoch,'native_clock_scope':'absolute SDK clock including warmup/transient origin, not certified exposure time','video_clock_scope':'fixed 6Hz display PTS, not physics or host time','source_frame_count':168,'encoded_frame_count':168,'artificial_duplicate_final_frame':False,'synthetic_frames':False,'old_ARIS_frames':False,'source_native_first_s':index[0]['absolute_native_time_s'],'source_native_last_s':index[-1]['absolute_native_time_s'],'source_native_capture_span_s':index[-1]['absolute_native_time_s']-index[0]['absolute_native_time_s'],'display_duration_s':28,'frames':index,'first_force_rejection_frame_bracket':rejection_bracket}
 (a.output/'M1_CAMERA_FRAME_INDEX.json').write_text(json.dumps(frame_index,ensure_ascii=False,indent=2)+'\n')
 receipt={'schema':'PostResultSecondaryM1PartialCameraAcceptance/1','status':'PASS_SECONDARY_CAMERA_ENCODING_NOT_FULL_FORCE_ACCEPTANCE','post_result_encoder_not_prospective_auditor':True,'original_force_RAW_audit_status':audit['status'],'original_force_RAW_audit_sha256':sha(audit_path.read_bytes()),'accepted_base_camera_partition_status':camera['status'],'case_id':CASE,'case_role':'DEVELOPMENT_SEEN_DIAGNOSTICS','existing_native_attempt_denominator_M0_M1':2,'new_native_attempts':0,'new_GPU_simulation_or_reintegration':0,'force_values_read':0,'source_JPEG_hashes_verified_again':168,'source_metadata_files_verified_again':2,'encoded_frames_decoded':168,'fps':'6/1','dimensions':[640,400],'duration_s':28,'MP4_display_time_not_physical_clock':True,'artificial_frames_or_final_repeat':0,'source_order_unchanged':True,'poster_source_ordinal':0,'poster_bytes_match_source':poster.read_bytes()==image_bytes[0],'first_force_rejection_frame_bracket':rejection_bracket,'force_gate_pass':0,'strict_sampled_hold':False,'training_admitted':0,'new_weights':0,'load_ready':'UNKNOWN','robot_unloaded':'UNKNOWN','real_robot_or_chemical_success_claimed':False,'input_binding_sha256':sha((a.output/'INPUT_BINDING.json').read_bytes()),'frame_index_sha256':sha((a.output/'M1_CAMERA_FRAME_INDEX.json').read_bytes()),'MP4_sha256':sha(mp4.read_bytes()),'MP4_bytes':mp4.stat().st_size,'poster_sha256':sha(poster.read_bytes()),'encoder_command':command[:-1]+['M1_native_camera_force_rejected.mp4'],'ffmpeg_version':subprocess.check_output([ffmpeg,'-version'],text=True).splitlines()[0],'ffprobe_full_frame_decode_sha256':sha(probe_bytes),'scientific_acceptance':'MAJOR_OPEN'}
 (a.output/'PARTIAL_CAMERA_ACCEPTANCE.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
 (a.output/'REPORT_cn.md').write_text('M1相机二级报告（结果后编码，非前瞻独立force审计）\n\n使用原始f8a读器RED结果中已接受的base camera分项，重新核对168源JPEG及2份metadata的425成员摘要绑定。只编码原video_frames顺序的168实际原生帧，6Hz/640×400/28秒，完整解码168帧；无插帧、假帧、旧ARIS拼接或追加尾帧。poster精确复制源ordinal0。\n\n本视频属于dev_seen_force_channel_diagnostics_002，原生采集完整但force RED和strict hold FALSE保留。新增native0/训练准入0/新权重0，不是硬件、化学或学习成功。视频PTS仅用于展示；源时钟为同epoch绝对SDK时间，包含warmup/transient，非曝光时钟认证。原JPEG有损，不能反向证明pre-JPEG RGB摘要。\n\n首次拒绝native时刻没有同clock视频帧；前后最近源帧与准确差值列于frame index和partial-camera receipt，不称为exact受力快照。编码器不读取force数值、大force RAW或vendor SDK。\n')
 print(json.dumps({'status':receipt['status'],'source_frames':168,'decoded_frames':168,'duration_s':28,'MP4_sha256':receipt['MP4_sha256'],'poster_sha256':receipt['poster_sha256'],'first_reject_frame_bracket':rejection_bracket},ensure_ascii=False))

if __name__=='__main__':main()
