# ADR: Outcome前缀与明确标签类型

授权范围为新v0.3和CPU验证。旧v0.2、19metadata、currentA/paired32及所有native源不编辑。

| 候选 | 边界 | 判定 |
|---|---|---|
| 仅最终检查outcome.time≥max(apply_time) | 仍可能利用晚记录的旧时间application、错误chunk或未来mask | 不足，拒绝 |
| 明确label类型、不可变required slots、outcome的ns+seq前缀 | 防future submit/apply、同时间反序、错request/chunk及future mask | 采用 |

EXECUTION_OUTCOME成功须标签前真实submit及该request APPLIED；REJECTED/DROPPED/TIMEOUT不能成功。明确失败和合法next-state/reward可用于失败RL。STATE/PROPOSAL无执行资格；其TRUE不改成任务执行成功。optional尾部可明确mask，缺失/未来mask不提高过去行资格。

偏序用同epoch(time_ns,seq)；同时间仅允许source-order已发生的actualapplication。晚记录的application即使自报更早apply_time，也不能回填标签前证据。ACK/effect区分不变。跨chunk完整任务仍由独立referee验证，单chunk标签不能外推全任务。

两因果模式、privileged teacher BC、teacher/audit隔离、学生state OPD、原role/split保持。没有新增用户训练审批；production0/fit0是证据状态。来源依赖可信typed collector，hash/黑名单不是拍摄真实性证明或敌手沙箱。

append只做单事件检查；close/readback重建跨事件语义。已知过早执行标签close失败、无CLOSE；UNKNOWN可留但不借以后动作升级。此producer CPU修复不能替代root/第三独立源码复核或真实学习实验。
