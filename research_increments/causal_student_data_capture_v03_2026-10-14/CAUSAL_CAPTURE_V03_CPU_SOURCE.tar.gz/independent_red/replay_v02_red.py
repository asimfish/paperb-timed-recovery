"""Byte-pinned original independent counterexample; no producer fixtures."""
import copy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "original_v02_snapshot/code"))
from causal_capture import derive


def main():
    h = json.loads((ROOT / "independent_red/HEADER_v02.json").read_text())
    original = json.loads((ROOT / "independent_red/DRAFT_CPU_RESULTS.json").read_text())["early_outcome_probe"]["events"]
    assert [e["payload"]["time_ns"] for e in original] == [0, 10, 20, 40, 50]
    early = derive(h, original, ROOT)["rows"][0]["bc_success"]
    late = copy.deepcopy(original)
    o = late.pop(2); o["payload"]["time_ns"] = 60; late.append(o)
    for i, e in enumerate(late): e["seq"] = i
    late_result = derive(h, late, ROOT)["rows"][0]["bc_success"]
    no_apply = copy.deepcopy(original[:-1])
    missing_apply = derive(h, no_apply, ROOT)["rows"][0]["bc_success"]
    no_submit = copy.deepcopy(original[:3])
    missing_submit = derive(h, no_submit, ROOT)["rows"][0]["bc_success"]
    result = {"status": "REPRODUCED_FROZEN_V02_INDEPENDENT_RED",
              "original_exact_times_ns": [0, 10, 20, 40, 50],
              "early_action_success_before_submit_apply": early,
              "only_outcome_moved_after_effects": late_result,
              "future_application_removed": missing_apply,
              "future_submission_removed": missing_submit,
              "source": "byte-exact original_v02_snapshot/code/",
              "no_producer_fixtures_imported": True, "native_epochs": 0,
              "GPU_work": 0, "parameter_updates": 0}
    assert early["eligible_by_contract"] == "TRUE"
    assert late_result["eligible_by_contract"] == "TRUE"
    assert missing_apply["eligible_by_contract"] == "TRUE"
    assert missing_submit["eligible_by_contract"] == "UNKNOWN"
    path = ROOT / "independent_red/V02_REPRODUCTION.json"
    with path.open("x") as f: json.dump(result, f, indent=2, sort_keys=True); f.write("\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__": main()
