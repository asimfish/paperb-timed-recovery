"""Third-party data-only checks, deliberately not importing producer fixtures."""
from datetime import datetime, timezone
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile

HERE = Path(__file__).resolve().parent
BASE = HERE.parent.parent
PHYSICAL = BASE / "supported_handoff_collector_design_2026-10-14/code"
CAUSAL = BASE / "causal_student_data_capture_2026-10-14/code"
sys.path[:0] = [str(PHYSICAL), str(CAUSAL)]
from physical_capture import capture_snapshot, digest as physical_digest
from physical_validate import validate_snapshot
from causal_capture import derive, validate_header, JsonlCaptureWriter, JsonlCaptureReader, state_digest


def header(mode="OFFLINE_CAPTURE", actor_kind="PRIVILEGED_TEACHER"):
    return {"schema": "CausalStudentCapture/0.2", "episode_id": "INDEPENDENT_CPU_ONLY",
        "actor_epoch": "fake_epoch_no_physics", "clock_id": "INDEPENDENT_CPU_ONLY:fake_epoch_no_physics",
        "dataset_kind": "CPU_FIXTURE", "actor": {"actor_id": "review_actor", "kind": actor_kind, "source_sha256": "1" * 64},
        "original_role": "development", "split": {"pool": "DEVELOPMENT_SEEN", "group_id": "review_group", "prospectively_frozen": True, "original_role_training_use": None},
        "seen_before_protocol": True, "pins": {"protocol_sha256": "2" * 64, "collector_source_sha256": "3" * 64, "split_plan_sha256": "4" * 64},
        "supervision_sources": {"audit_sha256": ["5" * 64], "teacher_sha256": ["6" * 64]},
        "observation_mode": mode, "offline_capture_rule": "CAPTURE_BEFORE_FUTURE_SUBMISSION" if mode == "OFFLINE_CAPTURE" else None,
        "physical_effect_not_assumed_from_ack": True}


def event(h, seq, kind, payload):
    return {"schema": "CausalStudentEvent/0.2", "seq": seq, "kind": kind, "payload": payload,
        **{k: h[k] for k in ("episode_id", "actor_epoch", "clock_id")}}


def observation(h, obs_id, t):
    features = {"instruction": "Independent synthetic CPU boundary only", "proprioception": [.2]}
    return {"time_ns": t, "obs_id": obs_id, "source_channel": "CPU_FIXTURE", "source_sha256": h["pins"]["collector_source_sha256"],
        "immutable_snapshot": True, "features": features, "assets": [], "state_sha256": state_digest(features, [])}


def trace(h, outcome_time=70, early_outcome=False):
    a = observation(h, "before", 0)
    chunk = {"time_ns": 10, "chunk_id": "proposal", "obs_id": "before", "actor_id": "review_actor", "semantic": "FUTURE_SUBMITTED_CONTROL",
             "slots": [{"slot_id": "slot", "requested_submit_time_ns": 40, "target": [.7]}]}
    submit = {"time_ns": 40, "chunk_id": "proposal", "slot_id": "slot", "request_id": "request", "actor_id": "review_actor", "target": [.7]}
    channel = {"time_ns": 50, "request_id": "request", "status": "APPLIED", "application_time_ns": 50, "effect_status": "SEPARATE_AUDIT_REQUIRED"}
    outcome = {"time_ns": outcome_time, "row_id": "scoped_row", "obs_id": "before", "next_obs_id": None if early_outcome else "after", "chunk_id": "proposal",
        "objective_name": "SYNTHETIC_ACTION_DEPENDENT_OBJECTIVE", "objective": "TRUE", "failure_vector": [], "reward": None, "reward_status": "UNKNOWN",
        "terminal": True, "audit_source_sha256": "5" * 64, "recovery": None}
    items = [("capture", a), ("chunk", chunk)]
    if early_outcome:
        items += [("outcome", outcome), ("submit", submit), ("channel_result", channel)]
    else:
        items += [("submit", submit), ("channel_result", channel), ("capture", observation(h, "after", 60)), ("outcome", outcome)]
    return [event(h, i, kind, payload) for i, (kind, payload) in enumerate(items)]


class Body:
    def get_transforms(self): return [[0., 0., 1., 0., 0., 0., 1.]]
    def get_velocities(self): return [[0.] * 6]
    def get_accelerations(self): return [[0.] * 6]
    def get_masses(self): return [[.2]]
    def get_inv_masses(self): return [[5.]]
    def get_coms(self): return [[0., 0., 0., 0., 0., 0., 1.]]
    def get_inertias(self): return [[1., 0., 0., 0., 1., 0., 0., 0., 1.]]
    def get_disable_gravities(self): return [[0]]
    def get_disable_simulations(self): return [[0]]


class Sim:
    def get_gravity(self): return [0., 0., -9.81]


class Composer:
    active = False
    composed_force_as_torch = [[[0., 0., 0.]]]
    composed_torque_as_torch = [[[0., 0., 0.]]]


class Rigid:
    instantaneous_wrench_composer = Composer()
    permanent_wrench_composer = Composer()


def physical(body=None, simulation=None, clock=None):
    return capture_snapshot(body_view=Body() if body is None else body, simulation_view=Sim() if simulation is None else simulation, rigid_object=Rigid(),
        clock_read=(lambda: {"native_epoch": "FAKE_CPU_NO_PHYSICS", "time_s": 1., "callback_count": 1}) if clock is None else clock,
        tick=0, phase="PRE_WRITE", body_path="/World/IndependentFake")


def main():
    checks = []
    def check(name, action):
        try:
            value = action()
            if value is not True:
                raise AssertionError("predicate did not return True")
            checks.append({"name": name, "status": "PASS"})
        except Exception as exc:
            checks.append({"name": name, "status": "FAIL_RETAINED", "error": {"type": type(exc).__name__, "message": str(exc)}})
    def rejected(action):
        try:
            action()
        except (ValueError, TypeError):
            return True
        return False
    check("known_installed_uint8_1x1_flag_shape", lambda: validate_snapshot(physical())["structure_pass"])
    class MissingBody(Body):
        def get_velocities(self): return None
        def get_accelerations(self): raise RuntimeError("independent_missing_getter")
    check("none_and_exception_retained_UNKNOWN_not_zero", lambda: (lambda r: r["rigid_body"]["velocity_world_com_linear_angular"]["status"] == "UNKNOWN" and r["rigid_body"]["acceleration_world_com_linear_angular"]["status"] == "UNKNOWN" and validate_snapshot(r)["structure_pass"])(physical(MissingBody())))
    def bad_flag():
        r = physical(); r["rigid_body"]["gravity_disabled_flag"]["value"] = [[2]]
        r["record_sha256"] = physical_digest({k: v for k, v in r.items() if k != "record_sha256"})
        return not validate_snapshot(r)["structure_pass"]
    check("invalid_disabled_flag_2_rejected", bad_flag)
    def advancing_clock():
        counter = [0]
        def clock():
            counter[0] += 1
            return {"native_epoch": "FAKE_CPU", "time_s": counter[0] / 240., "callback_count": counter[0]}
        r = physical(clock=clock)
        return not r["no_native_step_during_getters"] and not validate_snapshot(r)["structure_pass"]
    check("getter_clock_change_rejected", advancing_clock)
    def no_load_true():
        r = physical(); r["load_bearing_verdict"] = "TRUE"
        r["record_sha256"] = physical_digest({k: v for k, v in r.items() if k != "record_sha256"})
        return not validate_snapshot(r)["structure_pass"]
    check("self_asserted_loadbearing_TRUE_rejected", no_load_true)
    with tempfile.TemporaryDirectory(prefix="independent_handoff_cpu_") as temporary:
        assets = Path(temporary)
        h = header()
        check("offline_capture_future_submission_privileged_teacher_BC_allowed", lambda: derive(h, trace(h), assets)["rows"][0]["bc_success"]["eligible_by_contract"] == "TRUE")
        check("missing_online_delivery_kept_UNKNOWN", lambda: derive(header("ONLINE_DELIVERED"), trace(header("ONLINE_DELIVERED")), assets)["rows"][0]["bc_success"]["eligible_by_contract"] == "UNKNOWN")
        def private_feature():
            e = trace(h); p = e[0]["payload"]; p["features"]["history"] = [{"teacher_label": [.8]}]; p["state_sha256"] = state_digest(p["features"], [])
            return rejected(lambda: derive(h, e, assets))
        check("nested_teacher_label_cannot_enter_student_features", private_feature)
        def cross_epoch():
            e = trace(h); e[2]["actor_epoch"] = "OTHER"
            return rejected(lambda: derive(h, e, assets))
        check("cross_epoch_control_rejected", cross_epoch)
        def heldout_seen():
            x = copy.deepcopy(h); x["split"]["pool"] = "FUTURE_HELDOUT"
            return rejected(lambda: validate_header(x))
        check("seen_task_cannot_be_future_heldout", heldout_seen)
        def preserve_test_train():
            x = copy.deepcopy(h); x["original_role"] = "test"; x["split"]["pool"] = "LEGACY_SEEN_TRAIN"; x["split"]["original_role_training_use"] = "EXPLICIT_PRESERVE_ORIGINAL_ROLE"
            validate_header(x)
            return x["original_role"] == "test"
        check("explicit_legacy_seen_train_preserves_original_test_role", preserve_test_train)
        def early_submit():
            e = trace(h); e[2]["payload"]["time_ns"] = 39
            return rejected(lambda: derive(h, e, assets))
        check("submission_before_declared_future_time_rejected", early_submit)
        def incomplete_log():
            w = JsonlCaptureWriter(assets / "incomplete", h, assets)
            w.append("capture", observation(h, "only", 0))
            return rejected(lambda: JsonlCaptureReader(assets / "incomplete", assets).readback())
        check("incomplete_log_not_admitted", incomplete_log)
        def expert_not_opd():
            e = trace(h)
            p = e[0]["payload"]
            q = {"time_ns": 80, "query_id": "q", "obs_id": "before", "student_actor_id": "review_actor", "state_sha256": p["state_sha256"], "teacher_id": "teacher",
                "teacher_source": "PRIVILEGED", "teacher_source_sha256": "6" * 64, "teacher_privileged_input": {"private_state": [9]}, "target_time_ns": 90, "target": [.3]}
            e.append(event(h, len(e), "teacher_query", q))
            return derive(h, e, assets)["teacher_queries"][0]["opd_student_state_label"]["eligible_by_contract"] == "UNKNOWN"
        check("expert_replay_query_without_student_visit_is_not_OPD", expert_not_opd)
        early = trace(h, outcome_time=20, early_outcome=True)
        try:
            early_result = derive(h, early, assets)
            eligible = early_result["rows"][0]["bc_success"]["eligible_by_contract"]
            early_evidence = {"status": "COUNTEREXAMPLE_ACCEPTED" if eligible == "TRUE" else "SAFE_NOT_ADMITTED", "bc_success": eligible, "events": early,
                "description": "Action-dependent success outcome is logged before its actual future submission/application; close later sees all actions."}
        except Exception as exc:
            early_evidence = {"status": "SAFE_REJECTED", "type": type(exc).__name__, "message": str(exc), "events": early}
    output = {"schema": "IndependentHandoffDraftCPUReview/0.1", "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "DRAFT_REVIEW_NOT_FINAL_NATIVE_ADMISSION", "checks": checks, "pass": sum(x["status"] == "PASS" for x in checks), "fail": sum(x["status"] != "PASS" for x in checks),
        "early_outcome_probe": early_evidence, "production_or_native_or_GPU_or_training": 0,
        "producer_fixtures_or_checks_imported": False,
        "sources": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [PHYSICAL / "physical_capture.py", PHYSICAL / "physical_validate.py", CAUSAL / "causal_capture.py", CAUSAL / "schema_definition.py"]}}
    (HERE / "DRAFT_CPU_RESULTS.json").write_text(json.dumps(output, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"checks_pass": output["pass"], "checks_fail": output["fail"], "early_outcome_probe": early_evidence["status"], "source_stage": "DRAFT"}))


if __name__ == "__main__":
    main()
