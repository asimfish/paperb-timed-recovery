# 前瞻学生数据记录接口

提供可运行 writer、三条隔离 JSONL、全局哈希索引、严格 schema、readback 和用途限定资格检查。允许 privileged teacher 提供离线 BC 标签；ONLINE_DELIVERED 与明确声明的 OFFLINE_CAPTURE 是两种不同的因果接口。教师是否看过图像不是 BC 的一般禁用条件。OPD 另外要求学生实际访问状态和教师查询的匹配证据。

只实施 CPU 接口实验。tiny synthetic JSON fixtures 不伪装机器人图像；actual production 合格行=0、当前入训行=0、θ 更新=0、native/GPU=0。这些是实际证据状态，不是等待用户另授权。失败数据按目的保留：不能充当目标成功 BC，但可以满足 offline RL 或已验证局部恢复 BC；UNKNOWN 不补零。

- [ADR](ADR_cn.md)、[collector 挂点](COLLECTOR_INTEGRATION_cn.md)、[测试合同](TEST_CONTRACT.md)。
- `code/causal_capture.py`：write-once writer/readback、资产摘要校验、未来提交 chunk、teacher/audit 隔离和 eligibility。
- `code/legacy_allowlist.py`：旧元数据显式字段转换与显式 versioned legacy train 用途，原 role 不改、delivery 不补造。
- `schemas/`：独立机器可读 header/event/recovery contract；`PROTOCOL_TEMPLATE.json` 仅前瞻模板，生产必须填实际冻结 pins 和角色/split。
- `cpu_acceptance_v2/`：最终实际 CPU receipt、六条 synthetic 完整 logs、完整读回及一条留存 partial red log；旧 19 metadata 只读兼容检查。`cpu_acceptance_v1/` 与 source snapshot 保留首轮 PASS；v2 改为线性 append、close/readback 完整语义验证，不声称实际 native 实时性能。
- `development_history/`：开发时 unpack 初始化错误及实际红/绿日志保留，未被当作物理失败或生产源码。

从此目录运行（只写指定的新输出目录）：

```bash
PYTHONDONTWRITEBYTECODE=1 python3 code/run_cpu_acceptance.py \
  --output cpu_acceptance_local \
  --legacy-root ../stateful_controller_expansion_2026-10-13/learning_data_design
```

writer 不 resume/覆盖原 episode。发生异常留下的部分目录不能读取为完整数据。reader 要验证 asset root 内不可变原件；生产必须同时传 collector 外部 expected pins。student observation catalogue 不是所有时刻输入，每行只有合法 available-history IDs。raw feature provenance 仍依赖可信 collector 源审；有限私有键检测不是 hostile-process sandbox。

下一步在全新 supported-handoff/source closure 接入单个 native development capture，分别验证 capture→未来 submission 和真实 delivery 模式。保留旧源/旧 strict 负结果与原分母；新支持资格另验 object v、effective gravity、contact force 语义与 native-time span。本增量不启动该采集，也不宣称已 VLA、化学效果、OPD 学习或算法收益。
