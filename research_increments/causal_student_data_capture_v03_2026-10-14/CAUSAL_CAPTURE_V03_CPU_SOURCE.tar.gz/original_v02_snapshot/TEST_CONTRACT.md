# CPU acceptance contract

The oracle is the prospective data contract, not a controller success flag. This increment must perform zero native integration, GPU imports, model fitting, parameter updates and old-image copies. CPU fixtures are explicitly synthetic JSON references, never robot or RGB evidence.

Behavioral checks cover online delivered observation and explicit offline capture; privileged teacher BC; rejected future/cross-epoch/identity leakage; proposal versus submitted/applied timing; typed/nested private data; matching student-state OPD; failed offline-RL and verified recovery; unknown reward and original anchor preservation; masked unsubmitted chunk tails; write-once and incomplete records; byte/hash/index tampering; root-relative immutable references; grouped split consistency; legacy allowlist conversion without fabricated delivery.

The gate must run actual unittest cases, persist complete output, independently re-open each tiny fixture log, inspect source dependencies, and hash source/schema/protocol/tests before final write-once release. No synthetic eligibility count may be reported as an actual production row. Gate failures remain visible in their original artifacts.
