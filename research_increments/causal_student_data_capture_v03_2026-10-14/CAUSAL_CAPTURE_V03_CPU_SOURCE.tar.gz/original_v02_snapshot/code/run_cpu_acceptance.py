"""Write-once CPU gate. Synthetic fixtures and legacy metadata only."""
import argparse
import ast
from datetime import datetime, timezone
import importlib.metadata
import io
import json
import os
from pathlib import Path
import platform
import sys
import unittest

from jsonschema import Draft7Validator
from schema_definition import SCHEMA
from causal_capture import canonical, file_sha, JsonlCaptureReader, JsonlCaptureWriter
from cpu_fixtures import header, make_asset, base_events, recovery_events, teacher_query, capture, write_fixture
from legacy_allowlist import convert_episode, convert_candidate

HERE = Path(__file__).resolve().parents[1]
FORBIDDEN_IMPORTS = {"mujoco", "torch", "tensorflow", "isaacsim", "omni", "gymnasium", "jax"}


def put(path, value):
    with Path(path).open("xb") as f:
        f.write(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode() + b"\n")


def legacy_receipt(root):
    root = Path(root)
    manifest_path = root / "ARTIFACT_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text())
    before = {name: file_sha(root / name) for name in manifest["files"]}
    if any(before[n] != entry["sha256"] for n, entry in manifest["files"].items()):
        raise ValueError("OLD_METADATA_CLOSURE_MISMATCH")
    episodes = [json.loads(x) for x in (root / "metadata_v1/EPISODE_RECORDS.jsonl").read_text().splitlines()]
    candidates = [json.loads(x) for x in (root / "metadata_v1/CAUSAL_CANDIDATES.jsonl").read_text().splitlines()]
    converted_e, converted_c = [convert_episode(e) for e in episodes], [convert_candidate(c) for c in candidates]
    assert all(a["original_role"] == b["original_role"] and a["clock"] == {k: b["clock"][k] for k in a["clock"]}
               for a, b in zip(converted_e, episodes))
    assert all(a["observation"]["policy_delivery_time"] == b["observation"]["policy_delivery_time"]
               and a["observation"]["capture_time"] == b["observation"]["capture_time"]
               and ((a["action_label"] is None) == (b["action_label"] is None))
               and (b["action_label"] is None or
                    all(a["action_label"][k] == b["action_label"][k] for k in
                        ["command_id", "submission_time", "submission_tick", "semantic"]))
               for a, b in zip(converted_c, candidates))
    after = {name: file_sha(root / name) for name in manifest["files"]}
    assert before == after
    return {"status": "PASS_READONLY_ALLOWLIST_COMPATIBILITY", "legacy_manifest_sha256": file_sha(manifest_path),
            "old_closure_member_count_including_manifest": len(before) + 1, "old_member_hashes_unchanged": True,
            "episodes_projected_in_memory": len(converted_e), "causal_candidates_projected_in_memory": len(converted_c),
            "policy_delivery_missing_retained": sum(c["observation"]["policy_delivery_time"] is None for c in converted_c),
            "no_future_submission_retained": sum(c["action_label"] is None for c in converted_c),
            "original_roles": {role: sum(e["original_role"] == role for e in converted_e) for role in sorted({e["original_role"] for e in converted_e})},
            "actual_production_rows": 0, "old_frame_files_opened_or_copied": 0,
            "student_features_materialized": 0, "prospective_contract_not_backdated": True,
            "representative_episode_projection": converted_e[0], "representative_causal_projection": converted_c[0]}


def gate(output, legacy_root):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    before_native = sorted(FORBIDDEN_IMPORTS.intersection(sys.modules))
    Draft7Validator.check_schema(SCHEMA)
    suite = unittest.defaultTestLoader.discover(str(HERE / "tests"))
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    (output / "UNITTEST.log").write_text(log.getvalue())
    imports = {}
    for path in sorted((HERE / "code").glob("*.py")):
        tree = ast.parse(path.read_text())
        names = []
        for n in ast.walk(tree):
            if isinstance(n, ast.Import):
                names.extend(a.name.split(".")[0] for a in n.names)
            elif isinstance(n, ast.ImportFrom):
                names.append((n.module or "").split(".")[0])
        imports[path.name] = sorted(set(names))
        assert not FORBIDDEN_IMPORTS.intersection(names)
    asset_root = output / "synthetic_assets"
    asset = make_asset(asset_root)
    specs = []
    h = header(); specs.append(("online_privileged_BC", h, base_events(asset, h)))
    h = header("OFFLINE_CAPTURE"); specs.append(("offline_capture_privileged_BC", h, base_events(asset, h, deliver=False)))
    h = header(); specs.append(("definite_failure_RL", h, base_events(asset, h, objective="FALSE", reward=-1.0)))
    h = header(); specs.append(("global_failure_local_recovery", h, recovery_events(asset, h)))
    h = header(actor="STUDENT"); e = base_events(asset, h, visit=True); e.append(("teacher_query", teacher_query(e[0][1])))
    specs.append(("student_visited_state_OPD", h, e))
    h = header(); specs.append(("masked_unsubmitted_chunk_tail", h, base_events(asset, h, tail=True)))
    readbacks = {}
    for name, h, events in specs:
        out = output / name
        write_fixture(out, asset_root, h, events)
        readbacks[name] = JsonlCaptureReader(out, asset_root).readback()
        assert readbacks[name]["actual_production_rows"] == readbacks[name]["admitted_for_current_training_rows"] == 0
    # Persist an actual partial log and its rejection rather than deleting it.
    partial = output / "negative_incomplete_log"
    w = JsonlCaptureWriter(partial, header(), asset_root)
    w.append("capture", capture("o", 0, asset))
    try:
        JsonlCaptureReader(partial, asset_root).readback()
    except ValueError as exc:
        partial_rejection = str(exc)
    else:
        raise AssertionError("PARTIAL_LOG_INCORRECTLY_ADMITTED")
    put(output / "FIXTURE_READBACKS.json", readbacks)
    put(output / "LEGACY_COMPATIBILITY.json", legacy_receipt(legacy_root))
    source_names = [p.relative_to(HERE).as_posix() for directory in ["code", "tests", "schemas"]
                    for p in sorted((HERE / directory).rglob("*")) if p.is_file() and p.suffix != ".pyc"]
    source_pin = {name: file_sha(HERE / name) for name in source_names}
    receipt = {"status": "PASS_CPU_CAPTURE_CONTRACT" if result.wasSuccessful() else "FAIL_CPU_CAPTURE_CONTRACT",
               "created_at_utc": datetime.now(timezone.utc).isoformat(),
               "actual_tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
               "synthetic_complete_fixture_logs": len(specs), "retained_incomplete_fixture_logs": 1,
               "retained_incomplete_rejection": partial_rejection,
               "each_complete_fixture_independently_reopened": True,
               "schema_static_validation": "PASS", "source_imports": imports,
               "native_modules_loaded_before": before_native, "native_modules_loaded_after": sorted(FORBIDDEN_IMPORTS.intersection(sys.modules)),
               "environment": {"python": platform.python_version(), "jsonschema": importlib.metadata.version("jsonschema")},
               "source_file_sha256": source_pin, "actual_production_rows": 0,
               "admitted_for_current_training_rows": 0, "native_epochs": 0,
               "GPU_work": 0, "parameter_updates": 0, "real_image_files_copied": 0,
               "scope": "SYNTHETIC_CPU_INTERFACE_AND_LEGACY_METADATA_CONVERSION_ONLY"}
    assert not receipt["native_modules_loaded_before"] and not receipt["native_modules_loaded_after"]
    put(output / "CPU_ACCEPTANCE.json", receipt)
    print(json.dumps({k: receipt[k] for k in ["status", "actual_tests_run", "failures", "errors", "synthetic_complete_fixture_logs", "actual_production_rows", "native_epochs"]}))
    if not result.wasSuccessful():
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--legacy-root", required=True)
    args = parser.parse_args()
    gate(args.output, args.legacy_root)
