# ADR: 前瞻学生数据与分用途因果准入

这是独立 CPU 接口增量，不改旧 VerifiedReplay/0.1、19 文件元数据包或已发布论文。协议模板必须在生产采集前绑定实际 source/protocol/split；本次测试只用明确标为 CPU_FIXTURE 的小型 JSON 特征，没有图片、物理 rollout、张量或参数更新。

| 候选 | 因果及权限边界 | 兼容性与代价 |
|---|---|---|
| 给旧 causal candidate 填缺失 delivery、共用单一 success 标志 | 无法补证旧策略交付；容易改写历史身份与失败用途 | 字段较少，但会制造并不存在的证据，拒绝 |
| 新事件日志、独立公共输入/控制/监督文件、目的限定 readback | 在线交付和离线 capture 分开；实际提交与教师目标分开；目标、奖励、恢复不进入学生特征 | 多个显式事件和哈希索引；采用 |

接口仅接收 data-only 精确 dict/list/原生标量，拒绝 getter、非有限值、未知字段、嵌套显式特权键及路径逃逸。它是可信 collector 的类型与来源检查，不是 hostile Python sandbox；被重命名的私有数值不能靠键名检测，需要 collector 信息流审计。

append 做单事件类型、身份/时间及当前 capture 资产检查；完整跨事件语义在 close 与独立 readback 检查。错误可以留作 partial 原件，但没有合格 CLOSE。避免每次 append 重算全部 prefix 的二次复杂度；flush/fsync 和 asset I/O 的实际墙钟尚未在 native collector 测量，不能声称实时性能。

`CaptureLogger` 的 Protocol 是 write-once `append(kind,payload)`、`close()`；运行实现是 `JsonlCaptureWriter`。三条 JSONL 分别保存 student、control、supervision；全局索引以单调序号、内容 SHA、上一索引 SHA 绑定次序。关闭后生成完成 receipt；异常或缺失 close 的部分记录保持在原目录但不能成为完整合格数据。reader 独立重读原件、验证索引/流/asset bytes，再重建 causal rows。不读取 SDK、机器人、GPU 或模型。

两种模式：ONLINE_DELIVERED 要求 capture≤delivery≤decision≤future submit；OFFLINE_CAPTURE 要求前瞻声明 CAPTURE_BEFORE_FUTURE_SUBMISSION、immutable snapshot 与 capture 的 source-order，decision/submit 不早于 capture。后者不声称 teacher 看过图，也不声称已在线交付。离线 BC 允许 privileged teacher 提供标签。所有模式不能把 apply/ACK/物理终点当成未来提交；chunk 未提交尾部只作明确 mask，不可补造动作。

学生 `state_sha256` 覆盖合法 observation 的公开 features 和 asset 引用。teacher query 与 audit event 放 supervision。OPD 需要 STUDENT actor、同 epoch 的访问证据、匹配 state digest 与查询、合法 target time；教师可特权访问但其 observation 不能成为 student 输入。无学生访问的 expert trajectory 可用于 BC，不自动成为 OPD。

目的限定：成功 BC 只接受已验证指定 objective；恢复 BC 接受原失败、反馈观测、不可替换原 anchor、独立已验证恢复；offline RL 可使用 definite failure 和恢复，需同 epoch 的下一观察、已知 reward 与动作 channel terminal 状态；UNKNOWN 奖励保留而不制造 scalar。全局失败不永久排除局部恢复 BC 或 RL。eligibility 不是本轮实际训练行：CPU fixtures 可以验证接口，但 actual_production_rows 与 admitted_for_current_training 均为 0。这是当前证据状态，不是新增用户权限流程。

旧格式转换只映射显式 allowlist，并继续输出 METADATA_ONLY、原 split/role、缺失 delivery 和 training materialization=0；它不下载帧、不发明 capture provenance、不改变 heldout 身份。后续生产 collector 应在 capture 完成、合法 delivery、decision/chunk、真实 submit、实际 channel application 及独立 audit 各位置分别调用，而不能仅在 episode 末尾凭成功位回填。
