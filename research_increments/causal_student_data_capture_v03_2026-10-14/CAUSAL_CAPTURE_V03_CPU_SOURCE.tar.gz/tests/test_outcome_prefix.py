"""Temporal regressions from the independent counterexample, no CPU fixtures."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

from causal_capture import derive

ROOT = Path(__file__).resolve().parents[1]


def example(*, early=False, label_kind="EXECUTION_OUTCOME"):
    h = json.loads((ROOT / "independent_red/HEADER_v02.json").read_text())
    h["schema"] = "CausalStudentCapture/0.3"
    events = json.loads((ROOT / "independent_red/DRAFT_CPU_RESULTS.json").read_text())["early_outcome_probe"]["events"]
    for e in events:
        e["schema"] = "CausalStudentEvent/0.3"
        if e["kind"] == "chunk":
            for slot in e["payload"]["slots"]:
                slot["required_for_execution"] = True
        if e["kind"] == "outcome":
            e["payload"]["label_kind"] = label_kind
    if not early:
        o = events.pop(2); o["payload"]["time_ns"] = 70; events.append(o)
    return h, sequence(events)


def sequence(events):
    for i, e in enumerate(events): e["seq"] = i
    return events


def make_event(h, kind, payload):
    return {"schema": "CausalStudentEvent/0.3", "seq": 0, "kind": kind, "payload": payload,
            **{k: h[k] for k in ["episode_id", "actor_epoch", "clock_id"]}}


class OutcomePrefixTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="v03_independent_red_")

    def tearDown(self): self.tmp.cleanup()

    def run_example(self, h, events): return derive(h, sequence(events), self.tmp.name)

    def reject(self, h, events, message):
        with self.assertRaisesRegex(ValueError, message): self.run_example(h, events)

    def test_original_independent_red_not_schema_only_rejection(self):
        h, e = example(early=True)
        self.assertEqual([x["payload"]["time_ns"] for x in e], [0, 10, 20, 40, 50])
        self.reject(h, e, "EXECUTION_LABEL_BEFORE_REQUIRED_SUBMISSION")

    def test_only_outcome_moved_after_related_effects_passes(self):
        h, e = example()
        self.assertEqual(self.run_example(h, e)["rows"][0]["bc_success"]["eligible_by_contract"], "TRUE")

    def test_after_submission_before_application_rejected(self):
        h, e = example(); o = e.pop(); o["payload"]["time_ns"] = 45; e.insert(3, o)
        self.reject(h, e, "EXECUTION_LABEL_BEFORE_REQUIRED_CHANNEL_RESULT")

    def test_application_timestamp_past_but_record_arrives_future_rejected(self):
        h, e = example(); app = e.pop(3); app["payload"]["time_ns"] = 80; e.append(app)
        self.reject(h, e, "EXECUTION_LABEL_BEFORE_REQUIRED_CHANNEL_RESULT")

    def test_missing_application_cannot_support_known_success(self):
        h, e = example(); e.pop(3)
        self.reject(h, e, "EXECUTION_LABEL_BEFORE_REQUIRED_CHANNEL_RESULT")

    def test_unknown_early_outcome_not_backfilled(self):
        h, e = example(early=True); e[2]["payload"]["objective"] = "UNKNOWN"
        r = self.run_example(h, e)["rows"][0]
        self.assertEqual(r["bc_success"]["eligible_by_contract"], "UNKNOWN")
        self.assertEqual(r["submitted_label_mask"], [None])
        self.assertIn("CONTROL_NOT_OCCURRED_BY_LABEL", r["bc_success"]["reasons"])

    def test_early_state_label_not_execution_success(self):
        h, e = example(early=True, label_kind="STATE_LABEL")
        r = self.run_example(h, e)["rows"][0]
        self.assertEqual(r["objective"], "TRUE")
        self.assertEqual(r["bc_success"]["eligible_by_contract"], "FALSE")
        self.assertEqual(r["offline_rl"]["eligible_by_contract"], "FALSE")

    def test_early_proposal_label_not_execution_success(self):
        h, e = example(early=True, label_kind="PROPOSAL_LABEL")
        self.assertEqual(self.run_example(h, e)["rows"][0]["bc_success"]["eligible_by_contract"], "FALSE")

    def test_rejected_control_cannot_be_success(self):
        h, e = example(); e[3]["payload"].update(status="REJECTED", application_time_ns=None)
        self.reject(h, e, "NONAPPLIED_CONTROL_CANNOT_SUPPORT_EXECUTION_SUCCESS")

    def test_timeout_control_cannot_be_success(self):
        h, e = example(); e[3]["payload"].update(status="TIMEOUT", application_time_ns=None)
        self.reject(h, e, "NONAPPLIED_CONTROL_CANNOT_SUPPORT_EXECUTION_SUCCESS")

    def test_dropped_control_cannot_be_success(self):
        h, e = example(); e[3]["payload"].update(status="DROPPED", application_time_ns=None)
        self.reject(h, e, "NONAPPLIED_CONTROL_CANNOT_SUPPORT_EXECUTION_SUCCESS")

    def test_complete_failure_before_future_submission_also_rejected(self):
        h, e = example(early=True); e[2]["payload"]["objective"] = "FALSE"
        self.reject(h, e, "EXECUTION_LABEL_BEFORE_REQUIRED_SUBMISSION")

    def test_two_required_slots_cannot_use_first_only_success(self):
        h, e = example()
        e[1]["payload"]["slots"].append({"slot_id": "second", "requested_submit_time_ns": 80, "target": [.9], "required_for_execution": True})
        e.append(make_event(h, "submit", {"time_ns": 80, "chunk_id": "proposal", "slot_id": "second", "request_id": "second_req", "actor_id": "review_actor", "target": [.9]}))
        e.append(make_event(h, "channel_result", {"time_ns": 90, "request_id": "second_req", "status": "APPLIED", "application_time_ns": 90, "effect_status": "UNKNOWN"}))
        self.reject(h, e, "EXECUTION_LABEL_BEFORE_REQUIRED_SUBMISSION")

    def test_two_required_slots_second_application_future_rejected(self):
        h, e = example(); o = e.pop()
        e[1]["payload"]["slots"].append({"slot_id": "second", "requested_submit_time_ns": 60, "target": [.9], "required_for_execution": True})
        e.append(make_event(h, "submit", {"time_ns": 60, "chunk_id": "proposal", "slot_id": "second", "request_id": "second_req", "actor_id": "review_actor", "target": [.9]}))
        e.append(o)
        e.append(make_event(h, "channel_result", {"time_ns": 90, "request_id": "second_req", "status": "APPLIED", "application_time_ns": 90, "effect_status": "UNKNOWN"}))
        self.reject(h, e, "EXECUTION_LABEL_BEFORE_REQUIRED_CHANNEL_RESULT")

    def test_two_required_slots_both_applied_before_label_passes(self):
        h, e = example(); o = e.pop(); o["payload"]["time_ns"] = 95
        e[1]["payload"]["slots"].append({"slot_id": "second", "requested_submit_time_ns": 60, "target": [.9], "required_for_execution": True})
        e.append(make_event(h, "submit", {"time_ns": 60, "chunk_id": "proposal", "slot_id": "second", "request_id": "second_req", "actor_id": "review_actor", "target": [.9]}))
        e.append(make_event(h, "channel_result", {"time_ns": 90, "request_id": "second_req", "status": "APPLIED", "application_time_ns": 90, "effect_status": "UNKNOWN"}))
        e.append(o)
        self.assertEqual(self.run_example(h, e)["rows"][0]["bc_success"]["eligible_by_contract"], "TRUE")

    def test_other_chunk_application_cannot_fulfil_this_chunk(self):
        h, e = example(); e.pop(3)
        other = copy.deepcopy(e[1]); other["payload"].update(time_ns=15, chunk_id="other")
        e.insert(2, other)
        e.insert(4, make_event(h, "submit", {"time_ns": 45, "chunk_id": "other", "slot_id": "slot", "request_id": "other_req", "actor_id": "review_actor", "target": [.7]}))
        e.insert(5, make_event(h, "channel_result", {"time_ns": 50, "request_id": "other_req", "status": "APPLIED", "application_time_ns": 50, "effect_status": "UNKNOWN"}))
        self.reject(h, e, "EXECUTION_LABEL_BEFORE_REQUIRED_CHANNEL_RESULT")

    def test_later_unrelated_chunk_does_not_invalidate_earlier_success(self):
        h, e = example()
        other = copy.deepcopy(e[1]); other["payload"].update(time_ns=80, chunk_id="other")
        other["payload"]["slots"][0]["requested_submit_time_ns"] = 90
        e.append(other)
        e.append(make_event(h, "submit", {"time_ns": 90, "chunk_id": "other", "slot_id": "slot", "request_id": "other_req", "actor_id": "review_actor", "target": [.7]}))
        e.append(make_event(h, "channel_result", {"time_ns": 100, "request_id": "other_req", "status": "APPLIED", "application_time_ns": 100, "effect_status": "UNKNOWN"}))
        self.assertEqual(self.run_example(h, e)["rows"][0]["bc_success"]["eligible_by_contract"], "TRUE")

    def test_cross_request_application_time_rollback_rejected(self):
        h, e = example(); e[3]["payload"]["application_time_ns"] = 39
        self.reject(h, e, "APPLICATION_PRECEDES_SUBMISSION")

    def test_application_in_future_of_its_own_record_rejected(self):
        h, e = example(); e[3]["payload"]["application_time_ns"] = 51
        self.reject(h, e, "APPLICATION_PRECEDES_SUBMISSION_OR_FUTURE")

    def test_required_unsubmitted_control_cannot_support_success(self):
        h, e = example(); e.pop(3); e.pop(2)
        e.insert(2, make_event(h, "unsubmitted", {"time_ns": 55, "chunk_id": "proposal", "slot_id": "slot", "reason": "REFUSED"}))
        self.reject(h, e, "EXECUTION_SUCCESS_WITH_UNSUBMITTED_REQUIRED_CONTROL")

    def test_optional_tail_before_label_stays_masked(self):
        h, e = example()
        e[1]["payload"]["slots"].append({"slot_id": "tail", "requested_submit_time_ns": 60, "target": [.9], "required_for_execution": False})
        e.insert(4, make_event(h, "unsubmitted", {"time_ns": 65, "chunk_id": "proposal", "slot_id": "tail", "reason": "TERMINAL_TAIL"}))
        r = self.run_example(h, e)["rows"][0]
        self.assertEqual(r["bc_success"]["eligible_by_contract"], "TRUE")
        self.assertEqual(r["submitted_label_mask"], [True, False])

    def test_future_optional_mask_is_not_backfilled(self):
        h, e = example()
        e[1]["payload"]["slots"].append({"slot_id": "tail", "requested_submit_time_ns": 60, "target": [.9], "required_for_execution": False})
        e.append(make_event(h, "unsubmitted", {"time_ns": 80, "chunk_id": "proposal", "slot_id": "tail", "reason": "TERMINAL_TAIL"}))
        r = self.run_example(h, e)["rows"][0]
        self.assertEqual(r["bc_success"]["eligible_by_contract"], "UNKNOWN")
        self.assertEqual(r["submitted_label_mask"], [True, None])

    def test_future_optional_submitted_action_not_backfilled(self):
        h, e = example()
        e[1]["payload"]["slots"].append({"slot_id": "tail", "requested_submit_time_ns": 80, "target": [.9], "required_for_execution": False})
        e.append(make_event(h, "submit", {"time_ns": 80, "chunk_id": "proposal", "slot_id": "tail", "request_id": "tail_req", "actor_id": "review_actor", "target": [.9]}))
        e.append(make_event(h, "channel_result", {"time_ns": 90, "request_id": "tail_req", "status": "APPLIED", "application_time_ns": 90, "effect_status": "UNKNOWN"}))
        r = self.run_example(h, e)["rows"][0]
        self.assertEqual(r["bc_success"]["eligible_by_contract"], "UNKNOWN")
        self.assertEqual(r["submitted_label_mask"], [True, None])

    def test_same_timestamp_channel_before_label_order_is_proven(self):
        h, e = example(); e[-1]["payload"]["time_ns"] = 50
        self.assertEqual(self.run_example(h, e)["rows"][0]["bc_success"]["eligible_by_contract"], "TRUE")

    def test_same_timestamp_label_before_channel_order_rejected(self):
        h, e = example(); o = e.pop(); o["payload"]["time_ns"] = 50; e.insert(3, o)
        self.reject(h, e, "EXECUTION_LABEL_BEFORE_REQUIRED_CHANNEL_RESULT")

    def test_timeout_failure_retained_for_offline_rl(self):
        h, e = example(); e[3]["payload"].update(status="TIMEOUT", application_time_ns=None)
        o = e[-1]["payload"]; o.update(objective="FALSE", reward=-1.0, reward_status="KNOWN", next_obs_id="after")
        cap = copy.deepcopy(e[0]); cap["payload"].update(time_ns=60, obs_id="after")
        e.insert(4, cap)
        r = self.run_example(h, e)["rows"][0]
        self.assertEqual(r["bc_success"]["eligible_by_contract"], "FALSE")
        self.assertEqual(r["offline_rl"]["eligible_by_contract"], "TRUE")


if __name__ == "__main__": unittest.main(verbosity=2)
