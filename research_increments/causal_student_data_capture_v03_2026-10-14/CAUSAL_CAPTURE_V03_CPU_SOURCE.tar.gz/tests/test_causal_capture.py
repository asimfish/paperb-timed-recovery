import copy
import json
from pathlib import Path
import tempfile
import unittest

from causal_capture import (JsonlCaptureWriter, JsonlCaptureReader, canonical, derive,
                            state_digest, validate_header, check_split_groups)
from cpu_fixtures import header, make_asset, capture, base_events, recovery_events, teacher_query, write_fixture
from legacy_allowlist import convert_episode, convert_candidate, declare_legacy_training


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="causal_capture_cpu_")
        self.root = Path(self.tmp.name)
        self.asset_root = self.root / "assets"
        self.asset = make_asset(self.asset_root)
        self.h = header()

    def tearDown(self):
        self.tmp.cleanup()

    def run_events(self, events=None, h=None, name="log"):
        h = self.h if h is None else h
        events = base_events(self.asset, h) if events is None else events
        output = self.root / name
        write_fixture(output, self.asset_root, h, events)
        return JsonlCaptureReader(output, self.asset_root).readback()

    def reject_events(self, events, text=None, h=None):
        with self.assertRaises(ValueError) as cm:
            self.run_events(events, h)
        if text:
            self.assertIn(text, str(cm.exception))

    def test_privileged_teacher_online_bc(self):
        r = self.run_events()
        self.assertEqual(r["rows"][0]["bc_success"]["eligible_by_contract"], "TRUE")
        self.assertEqual(r["actual_production_rows"], 0)
        self.assertEqual(r["admitted_for_current_training_rows"], 0)

    def test_privileged_teacher_offline_capture_without_delivery(self):
        h = header("OFFLINE_CAPTURE")
        r = self.run_events(base_events(self.asset, h, deliver=False), h)
        self.assertEqual(r["rows"][0]["bc_success"]["eligible_by_contract"], "TRUE")

    def test_missing_online_delivery_is_unknown_not_eligible(self):
        r = self.run_events(base_events(self.asset, deliver=False))
        self.assertEqual(r["rows"][0]["bc_success"]["eligible_by_contract"], "UNKNOWN")
        self.assertIn("MISSING_STUDENT_DELIVERY", r["rows"][0]["bc_success"]["reasons"])

    def test_delivery_after_decision_never_backfilled(self):
        e = base_events(self.asset, deliver=False)
        e.insert(2, ("delivery", {"time_ns": 35, "obs_id": "obs0", "actor_id": "fixture_actor"}))
        r = self.run_events(e)
        self.assertIn("DELIVERY_AFTER_DECISION", r["rows"][0]["bc_success"]["reasons"])

    def test_same_time_order_capture_before_chunk_and_submit(self):
        e = base_events(self.asset, header("OFFLINE_CAPTURE"), deliver=False)
        for kind, p in e:
            if kind in {"chunk", "submit"}:
                p["time_ns"] = 0
            if kind == "chunk":
                p["slots"][0]["requested_submit_time_ns"] = 0
        r = self.run_events(e, header("OFFLINE_CAPTURE"))
        self.assertEqual(r["rows"][0]["bc_success"]["eligible_by_contract"], "TRUE")

    def test_chunk_before_capture_rejected(self):
        e = base_events(self.asset)
        e[0], e[2] = e[2], e[0]
        self.reject_events(e, "UNKNOWN_CHUNK")

    def test_future_time_rollback_rejected(self):
        e = base_events(self.asset)
        e[0][1]["time_ns"] = 100
        self.reject_events(e, "LOG_TIME_ROLLBACK")

    def test_cross_epoch_event_rejected(self):
        from causal_capture import validate_event
        event = {"schema": "CausalStudentEvent/0.3", "seq": 0, "episode_id": self.h["episode_id"],
                 "actor_epoch": "other", "clock_id": self.h["clock_id"], "kind": "capture", "payload": capture("o", 0, self.asset)}
        with self.assertRaisesRegex(ValueError, "CROSS_EPOCH"):
            validate_event(self.h, event)

    def test_nested_privileged_student_feature_rejected(self):
        e = base_events(self.asset)
        e[0][1]["features"]["public_packet"] = {"nested": [{"private_state": [1]}]}
        e[0][1]["state_sha256"] = state_digest(e[0][1]["features"], e[0][1]["assets"])
        self.reject_events(e, "PRIVILEGED_STUDENT_FEATURE")

    def test_unknown_student_key_rejected(self):
        e = base_events(self.asset)
        e[0][1]["features"]["hidden_pose"] = [3.0]
        e[0][1]["state_sha256"] = state_digest(e[0][1]["features"], e[0][1]["assets"])
        self.reject_events(e, "UNKNOWN_STUDENT_FEATURE")

    def test_getter_never_invoked(self):
        called = []
        class Getter:
            def __float__(self):
                called.append("called")
                return 1.0
        e = base_events(self.asset)
        e[0][1]["features"]["proprioception"] = [Getter()]
        self.reject_events(e, "NON_PLAIN_VALUE")
        self.assertEqual(called, [])

    def test_nonfinite_value_rejected(self):
        e = base_events(self.asset)
        e[0][1]["features"]["proprioception"] = [float("nan")]
        self.reject_events(e, "NONFINITE_VALUE")

    def test_asset_mutation_readback_rejected(self):
        self.run_events()
        (self.asset_root / self.asset["relative_path"]).write_text("mutated")
        with self.assertRaisesRegex(ValueError, "ASSET_BYTES_MISMATCH"):
            JsonlCaptureReader(self.root / "log", self.asset_root).readback()

    def test_asset_path_escape_rejected(self):
        e = base_events(self.asset)
        e[0][1]["assets"][0]["relative_path"] = "../outside.json"
        e[0][1]["state_sha256"] = state_digest(e[0][1]["features"], e[0][1]["assets"])
        self.reject_events(e, "ASSET_PATH_ESCAPE")

    def test_asset_symlink_escape_rejected(self):
        outside = self.root / "outside.json"
        outside.write_text("outside")
        (self.asset_root / "escape.json").symlink_to(outside)
        e = base_events(self.asset)
        e[0][1]["assets"][0]["relative_path"] = "escape.json"
        e[0][1]["state_sha256"] = state_digest(e[0][1]["features"], e[0][1]["assets"])
        self.reject_events(e, "ASSET_PATH_ESCAPE")

    def test_fixture_cannot_be_declared_production(self):
        h = header()
        h["dataset_kind"] = "PRODUCTION"
        w = JsonlCaptureWriter(self.root / "production_negative", h, self.asset_root, expected_pins=h["pins"])
        with self.assertRaisesRegex(ValueError, "FIXTURE_NOT_PRODUCTION"):
            w.append("capture", capture("o", 0, self.asset, h))

    def test_production_requires_expected_protocol_pins(self):
        h = header()
        h["dataset_kind"] = "PRODUCTION"
        with self.assertRaisesRegex(ValueError, "EXPECTED_PINS"):
            JsonlCaptureWriter(self.root / "bad", h, self.asset_root)

    def test_expected_protocol_mismatch_rejected(self):
        with self.assertRaisesRegex(ValueError, "EXPECTED_PROTOCOL_PINS_MISMATCH"):
            JsonlCaptureWriter(self.root / "bad", self.h, self.asset_root, expected_pins={})

    def test_missing_offline_contract_rejected(self):
        h = header("OFFLINE_CAPTURE")
        h["offline_capture_rule"] = None
        with self.assertRaisesRegex(ValueError, "OFFLINE_CAPTURE_RULE"):
            validate_header(h)

    def test_failed_transition_is_eligible_offline_rl(self):
        r = self.run_events(base_events(self.asset, objective="FALSE", reward=-1.0))
        row = r["rows"][0]
        self.assertEqual(row["bc_success"]["eligible_by_contract"], "FALSE")
        self.assertEqual(row["offline_rl"]["eligible_by_contract"], "TRUE")

    def test_unknown_reward_is_not_filled_zero(self):
        r = self.run_events(base_events(self.asset, objective="UNKNOWN", reward=None))
        self.assertIn("REWARD_UNKNOWN_NOT_ZERO", r["rows"][0]["offline_rl"]["reasons"])
        self.assertEqual(r["rows"][0]["offline_rl"]["eligible_by_contract"], "UNKNOWN")

    def test_application_before_submission_rejected(self):
        e = base_events(self.asset)
        e[4][1]["application_time_ns"] = 39
        self.reject_events(e, "APPLICATION_PRECEDES_SUBMISSION")

    def test_ack_or_application_is_not_effect_success(self):
        e = base_events(self.asset, objective="UNKNOWN", reward=None)
        r = self.run_events(e)
        self.assertEqual(r["rows"][0]["bc_success"]["eligible_by_contract"], "UNKNOWN")

    def test_next_state_before_channel_terminal_is_unknown_rl(self):
        e = base_events(self.asset)
        e[4], e[5] = e[5], e[4]
        e[4][1]["time_ns"] = 45
        r = self.run_events(e)
        self.assertIn("NEXT_OBSERVATION_PRECEDES_CHANNEL_TERMINAL_RESULT", r["rows"][0]["offline_rl"]["reasons"])

    def test_masked_tail_does_not_invent_submission(self):
        r = self.run_events(base_events(self.asset, tail=True))
        self.assertEqual(r["rows"][0]["submitted_label_mask"], [True, False])

    def test_missing_tail_mask_is_unknown(self):
        e = [(k, p) for k, p in base_events(self.asset, tail=True) if k != "unsubmitted"]
        r = self.run_events(e)
        self.assertIn("MISSING_SUBMISSION_OR_EXPLICIT_TAIL_MASK", r["rows"][0]["bc_success"]["reasons"])

    def test_proposal_without_submission_is_not_bc_label(self):
        e = [(k, p) for k, p in base_events(self.asset) if k not in {"submit", "channel_result"}]
        # 0.3 fails closed: a known execution-success label cannot precede or
        # omit its required actual submission. Proposal labels are separate.
        self.reject_events(e, "EXECUTION_LABEL_BEFORE_REQUIRED_SUBMISSION")

    def test_actual_submitted_target_mismatch_rejected(self):
        e = base_events(self.asset)
        e[3][1]["target"] = [0.6]
        self.reject_events(e, "SUBMITTED_TARGET_OR_ACTOR_MISMATCH")

    def test_duplicate_request_or_slot_rejected(self):
        e = base_events(self.asset)
        e.insert(4, copy.deepcopy(e[3]))
        self.reject_events(e, "UNKNOWN_OR_REUSED_SLOT")

    def test_recovery_label_survives_global_failure(self):
        r = self.run_events(recovery_events(self.asset))
        self.assertEqual(r["rows"][1]["bc_success"]["eligible_by_contract"], "FALSE")
        self.assertEqual(r["rows"][1]["bc_recovery"]["eligible_by_contract"], "TRUE")
        self.assertEqual(r["rows"][1]["offline_rl"]["eligible_by_contract"], "TRUE")

    def test_recovery_cannot_replace_original_anchor(self):
        e = recovery_events(self.asset)
        e[-1][1]["recovery"]["original_anchor_event_ids"] = [self.h["clock_id"] + ":new_fake_anchor"]
        self.reject_events(e, "RECOVERY_ORIGINAL_ANCHOR_MISSING")

    def test_recovery_before_feedback_is_rejected(self):
        e = recovery_events(self.asset)
        e[-1][1]["recovery"]["feedback_obs_id"] = "obs2"
        self.reject_events(e, "RECOVERY_FEEDBACK_AFTER_RECOVERY_DECISION")

    def test_reused_original_event_identity_rejected(self):
        e = recovery_events(self.asset)
        e.insert(8, copy.deepcopy(e[7]))
        self.reject_events(e, "ORIGINAL_EVENT_ID_REUSED")

    def test_student_visited_state_privileged_opd_label(self):
        h = header(actor="STUDENT")
        e = base_events(self.asset, h, visit=True)
        e.append(("teacher_query", teacher_query(e[0][1])))
        r = self.run_events(e, h)
        self.assertEqual(r["teacher_queries"][0]["opd_student_state_label"]["eligible_by_contract"], "TRUE")
        projected = json.dumps(r["student_observation_catalogue"])
        self.assertNotIn("private_state", projected)
        self.assertNotIn("reward", projected)

    def test_teacher_expert_state_is_not_student_opd(self):
        e = base_events(self.asset)
        e.append(("teacher_query", teacher_query(e[0][1])))
        r = self.run_events(e)
        self.assertEqual(r["teacher_queries"][0]["opd_student_state_label"]["eligible_by_contract"], "UNKNOWN")

    def test_teacher_visited_state_digest_mismatch_rejected(self):
        h = header(actor="STUDENT")
        e = base_events(self.asset, h, visit=True)
        q = teacher_query(e[0][1]); q["state_sha256"] = "0" * 64
        e.append(("teacher_query", q))
        self.reject_events(e, "TEACHER_STATE_MISMATCH", h)

    def test_teacher_target_past_rejected(self):
        e = base_events(self.asset)
        q = teacher_query(e[0][1]); q["target_time_ns"] = 89
        e.append(("teacher_query", q))
        self.reject_events(e, "TEACHER_TARGET_IN_PAST")

    def test_unpinned_teacher_and_audit_rejected(self):
        e = base_events(self.asset)
        e[-1][1]["audit_source_sha256"] = "0" * 64
        self.reject_events(e, "AUDIT_SOURCE_NOT_PROTOCOL_PINNED")

    def test_input_history_excludes_future_observation(self):
        r = self.run_events()
        self.assertEqual(r["rows"][0]["student_available_history_ids"], ["obs0"])
        self.assertNotIn("obs1", r["rows"][0]["student_available_history_ids"])

    def test_writeonce_and_closed_writer(self):
        w = JsonlCaptureWriter(self.root / "log", self.h, self.asset_root)
        w.close()
        with self.assertRaisesRegex(ValueError, "CLOSED_LOG"):
            w.append("capture", capture("o", 0, self.asset))
        with self.assertRaises(FileExistsError):
            JsonlCaptureWriter(self.root / "log", self.h, self.asset_root)

    def test_incomplete_log_remains_but_not_admitted(self):
        w = JsonlCaptureWriter(self.root / "partial", self.h, self.asset_root)
        w.append("capture", capture("o", 0, self.asset))
        with self.assertRaisesRegex(ValueError, "INCOMPLETE_LOG_NOT_ADMITTED"):
            JsonlCaptureReader(self.root / "partial", self.asset_root).readback()
        self.assertTrue((self.root / "partial" / "student.jsonl").is_file())

    def test_stream_tampering_detected(self):
        self.run_events()
        with (self.root / "log" / "student.jsonl").open("ab") as f:
            f.write(b"{}\n")
        with self.assertRaisesRegex(ValueError, "LOG_BYTES_MISMATCH"):
            JsonlCaptureReader(self.root / "log", self.asset_root).readback()

    def test_index_tampering_detected_even_rehashed_close(self):
        from causal_capture import file_sha
        self.run_events()
        p = self.root / "log" / "index.jsonl"
        lines = p.read_text().splitlines(); item = json.loads(lines[0]); item["previous_index_sha256"] = "1" * 64
        lines[0] = canonical(item).decode(); p.write_text("\n".join(lines) + "\n")
        close = self.root / "log" / "CLOSE.json"
        c = json.loads(close.read_text()); c["files"]["index.jsonl"] = file_sha(p); close.write_bytes(canonical(c))
        with self.assertRaisesRegex(ValueError, "INDEX_CHAIN_MISMATCH"):
            JsonlCaptureReader(self.root / "log", self.asset_root).readback()

    def test_input_mutation_after_append_does_not_change_log(self):
        w = JsonlCaptureWriter(self.root / "log", self.h, self.asset_root)
        p = capture("o", 0, self.asset); w.append("capture", p)
        p["features"]["proprioception"][0] = 100.0
        w.close()
        r = JsonlCaptureReader(self.root / "log", self.asset_root).readback()
        self.assertEqual(r["student_observation_catalogue"][0]["features"]["proprioception"], [0.25])

    def test_seen_cannot_be_heldout(self):
        h = header(); h["split"]["pool"] = "FUTURE_HELDOUT"
        with self.assertRaisesRegex(ValueError, "SEEN_OR_UNFROZEN_HELDOUT"):
            validate_header(h)

    def test_seen_new_collection_can_be_train(self):
        h = header(); h["split"]["pool"] = "FUTURE_TRAIN"
        validate_header(h)

    def test_explicit_legacy_test_training_preserves_original_role(self):
        h = header(); h["original_role"] = "test"; h["split"]["pool"] = "LEGACY_SEEN_TRAIN"
        h["split"]["original_role_training_use"] = "EXPLICIT_PRESERVE_ORIGINAL_ROLE"
        validate_header(h)
        self.assertEqual(h["original_role"], "test")

    def test_undeclared_original_role_training_use_rejected(self):
        h = header(); h["original_role"] = "calibration"; h["split"]["pool"] = "LEGACY_SEEN_TRAIN"
        with self.assertRaisesRegex(ValueError, "TRAIN_USE_NOT_DECLARED"):
            validate_header(h)

    def test_group_cross_split_rejected(self):
        h1, h2 = header(), header(); h2["episode_id"] = "CPU_ONLY_002"; h2["clock_id"] = h2["episode_id"] + ":" + h2["actor_epoch"]
        h2["split"]["pool"] = "FUTURE_TRAIN"
        with self.assertRaisesRegex(ValueError, "RELATED_GROUP_CROSSES_SPLITS"):
            check_split_groups([h1, h2])


class LegacyTests(unittest.TestCase):
    def legacy(self):
        return {"schema": "VerifiedReplayEpisode/0.1", "episode_id": "legacy001", "dataset_kind": "robot_timing_legacy", "original_role": "test",
                "origin": {"seen_before_design": True, "actor_kind": "SCRIPTED", "neural_expert": False, "student_rollout": False, "audit_sha256": "d" * 64},
                "split": {"original_role": "test", "pool": "LEGACY_SEEN_METADATA", "duplicate_or_scenario_group": "g", "future_heldout_eligible": False, "prospective_split_frozen": False},
                "clock": {"clock_id": "legacy_epoch", "original_epoch": "legacy_epoch", "unit": "s", "samples": 1},
                "labels": {"contracts": {}, "objectives": {}}, "student_input": {"private_state": [99]}, "extra": "not copied"}

    def test_legacy_episode_allowlist_keeps_roles_and_no_features(self):
        r = convert_episode(self.legacy())
        self.assertEqual(r["original_role"], "test")
        self.assertEqual(r["student_features"], {})
        self.assertNotIn("extra", r)
        self.assertNotIn("private_state", json.dumps(r))

    def test_explicit_versioned_legacy_training_use(self):
        r = convert_episode(self.legacy())
        d = {"new_dataset_version": "v_future", "source_episode_id": "legacy001", "original_role": "test", "pool": "LEGACY_SEEN_TRAIN"}
        converted = declare_legacy_training(r, d)
        self.assertEqual(converted["original_role"], "test")
        self.assertEqual(converted["status"], "METADATA_ONLY")
        self.assertEqual(converted["actual_production_rows"], 0)

    def test_legacy_silent_role_rewrite_rejected(self):
        d = {"new_dataset_version": "v_future", "source_episode_id": "legacy001", "original_role": "train", "pool": "LEGACY_SEEN_TRAIN"}
        with self.assertRaisesRegex(ValueError, "ROLE_ID_OR_POOL_REWRITE"):
            declare_legacy_training(convert_episode(self.legacy()), d)

    def test_legacy_missing_schema_field_rejected(self):
        old = self.legacy(); del old["clock"]["clock_id"]
        with self.assertRaisesRegex(ValueError, "REQUIRED_FIELD_MISSING"):
            convert_episode(old)

    def test_legacy_candidate_does_not_invent_delivery_or_offline_contract(self):
        old = {"schema": "VerifiedReplayCausalCandidate/0.1", "episode_id": "legacy001",
               "observation": {"capture_index": 0, "camera_frame": 1, "capture_phase": "TASK_ORIGIN_PRE_FIRST_SUBMISSION",
                   "capture_time": 1.0, "clock_id": "legacy_epoch", "unit": "s", "next_submission_tick": 0,
                   "policy_delivery_time": None, "policy_delivery_clock_id": None, "JPEG_sha256": "a" * 64, "depth_sha256": "b" * 64},
               "action_label": None, "same_time_source_order": "CAPTURE_BEFORE_SUBMISSION",
               "source_order_evidence": "legacy source binding", "source_dispatch_sha256": "c" * 64,
               "scripted_actor_observed_image": False, "extra": "ignored"}
        r = convert_candidate(old)
        self.assertIsNone(r["observation"]["policy_delivery_time"])
        self.assertEqual(r["offline_capture_contract"], "NOT_RETROACTIVELY_CREATED")
        self.assertEqual(r["actual_production_rows"], 0)
        self.assertNotIn("extra", r)


if __name__ == "__main__":
    unittest.main(verbosity=2)
