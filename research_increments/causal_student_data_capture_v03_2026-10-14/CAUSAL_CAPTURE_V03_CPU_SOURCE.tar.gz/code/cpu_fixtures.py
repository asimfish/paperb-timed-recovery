"""Tiny synthetic data fixtures. No JPEG, renderer, native episode or robot data."""
from pathlib import Path
from causal_capture import canonical, file_sha, state_digest, JsonlCaptureWriter


def header(mode="ONLINE_DELIVERED", actor="PRIVILEGED_TEACHER"):
    return {"schema": "CausalStudentCapture/0.3", "episode_id": "CPU_ONLY_001",
            "actor_epoch": "synthetic_epoch_0", "clock_id": "CPU_ONLY_001:synthetic_epoch_0",
            "dataset_kind": "CPU_FIXTURE", "actor": {"actor_id": "fixture_actor", "kind": actor, "source_sha256": "f" * 64},
            "original_role": "development", "split": {"pool": "DEVELOPMENT_SEEN", "group_id": "synthetic_group", "prospectively_frozen": True, "original_role_training_use": None},
            "seen_before_protocol": True, "pins": {"protocol_sha256": "a" * 64, "collector_source_sha256": "b" * 64, "split_plan_sha256": "c" * 64},
            "supervision_sources": {"audit_sha256": ["d" * 64], "teacher_sha256": ["e" * 64]},
            "observation_mode": mode,
            "offline_capture_rule": "CAPTURE_BEFORE_FUTURE_SUBMISSION" if mode == "OFFLINE_CAPTURE" else None,
            "physical_effect_not_assumed_from_ack": True}


def make_asset(root):
    Path(root).mkdir(parents=True, exist_ok=True)
    p = Path(root) / "synthetic_public_features.json"
    p.write_bytes(canonical({"synthetic_not_robot": True, "public_sensor": 0.25}))
    return {"relative_path": p.name, "sha256": file_sha(p), "byte_count": p.stat().st_size,
            "encoding": "JSON_FIXTURE", "modality": "SYNTHETIC_JSON", "shape": []}


def capture(obs_id, t, asset, h=None):
    h = header() if h is None else h
    features = {"instruction": "SYNTHETIC CPU contract check", "proprioception": [0.25], "clock": {"capture_time_ns": t}}
    assets = [asset]
    return {"time_ns": t, "obs_id": obs_id, "source_channel": "CPU_FIXTURE",
            "source_sha256": h["pins"]["collector_source_sha256"], "immutable_snapshot": True,
            "features": features, "assets": assets, "state_sha256": state_digest(features, assets)}


def outcome(t=80, row_id="row0", obs_id="obs0", next_obs_id="obs1", chunk_id="chunk0", objective="TRUE", reward=1.0, recovery=None):
    return {"time_ns": t, "row_id": row_id, "obs_id": obs_id, "next_obs_id": next_obs_id,
            "label_kind": "EXECUTION_OUTCOME",
            "chunk_id": chunk_id, "objective_name": "synthetic_scoped_objective", "objective": objective,
            "failure_vector": [] if objective == "TRUE" else ["synthetic_failure_or_unknown"],
            "reward": reward, "reward_status": "KNOWN" if reward is not None else "UNKNOWN",
            "terminal": True, "audit_source_sha256": "d" * 64, "recovery": recovery}


def base_events(asset, h=None, *, objective="TRUE", reward=1.0, deliver=True, tail=False, visit=False):
    h = header() if h is None else h
    events = [("capture", capture("obs0", 0, asset, h))]
    if deliver:
        events.append(("delivery", {"time_ns": 10, "obs_id": "obs0", "actor_id": "fixture_actor"}))
    if visit:
        events.append(("visit", {"time_ns": 20, "obs_id": "obs0", "actor_id": "fixture_actor", "state_sha256": events[0][1]["state_sha256"]}))
    intended = [{"slot_id": "s0", "requested_submit_time_ns": 40, "target": [0.5], "required_for_execution": True}]
    if tail:
        intended.append({"slot_id": "tail", "requested_submit_time_ns": 45, "target": [0.7], "required_for_execution": False})
    events += [("chunk", {"time_ns": 30, "chunk_id": "chunk0", "obs_id": "obs0", "actor_id": "fixture_actor",
                           "semantic": "FUTURE_SUBMITTED_CONTROL", "slots": intended}),
               ("submit", {"time_ns": 40, "chunk_id": "chunk0", "slot_id": "s0", "request_id": "request0", "actor_id": "fixture_actor", "target": [0.5]}),
               ("channel_result", {"time_ns": 50, "request_id": "request0", "status": "APPLIED", "application_time_ns": 50, "effect_status": "UNKNOWN"})]
    if tail:
        events.append(("unsubmitted", {"time_ns": 55, "chunk_id": "chunk0", "slot_id": "tail", "reason": "TERMINAL_TAIL"}))
    events += [("capture", capture("obs1", 60, asset, h)),
               ("outcome", outcome(objective=objective, reward=reward))]
    return events


def recovery_events(asset, h=None):
    h = header() if h is None else h
    events = base_events(asset, h, objective="FALSE", reward=-1.0)
    anchor = h["clock_id"] + ":original_external_event"
    events += [("audit_event", {"time_ns": 90, "event_id": anchor, "kind": "SYNTHETIC_EXTERNAL_EVENT",
                                "onset_interval_ns": [40, 50], "audit_source_sha256": "d" * 64}),
               ("capture", capture("feedback", 100, asset, h)),
               ("delivery", {"time_ns": 110, "obs_id": "feedback", "actor_id": "fixture_actor"}),
               ("chunk", {"time_ns": 120, "chunk_id": "recovery_chunk", "obs_id": "feedback", "actor_id": "fixture_actor", "semantic": "FUTURE_SUBMITTED_CONTROL",
                           "slots": [{"slot_id": "r0", "requested_submit_time_ns": 130, "target": [0.2], "required_for_execution": True}]}),
               ("submit", {"time_ns": 130, "chunk_id": "recovery_chunk", "slot_id": "r0", "request_id": "recovery_req", "actor_id": "fixture_actor", "target": [0.2]}),
               ("channel_result", {"time_ns": 140, "request_id": "recovery_req", "status": "APPLIED", "application_time_ns": 140, "effect_status": "SEPARATE_AUDIT_REQUIRED"}),
               ("capture", capture("obs2", 150, asset, h)),
               ("outcome", outcome(t=160, row_id="recovery_row", obs_id="feedback", next_obs_id="obs2", chunk_id="recovery_chunk", objective="FALSE", reward=0.5,
                   recovery={"failure_row_id": "row0", "feedback_obs_id": "feedback", "original_anchor_event_ids": [anchor],
                             "verified": "TRUE", "recovered_objective": "TRUE", "audit_source_sha256": "d" * 64}))]
    return events


def teacher_query(capture_payload, t=90):
    return {"time_ns": t, "query_id": "query0", "obs_id": capture_payload["obs_id"], "student_actor_id": "fixture_actor",
            "state_sha256": capture_payload["state_sha256"], "teacher_id": "synthetic_privileged_teacher",
            "teacher_source": "PRIVILEGED", "teacher_source_sha256": "e" * 64,
            "teacher_privileged_input": {"private_state": [9.0], "reward": 1.0},
            "target_time_ns": t + 10, "target": [0.3]}


def write_fixture(output, asset_root, h, events):
    writer = JsonlCaptureWriter(output, h, asset_root)
    for kind, payload in events:
        writer.append(kind, payload)
    return writer.close()
