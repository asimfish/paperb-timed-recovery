"""Metadata-only explicit projection from legacy 0.1, not retroactive admission."""
import copy
from causal_capture import plain


def _select(value, keys):
    plain(value)
    if type(value) is not dict or any(k not in value for k in keys):
        raise ValueError("LEGACY_ALLOWLIST_REQUIRED_FIELD_MISSING")
    return {k: copy.deepcopy(value[k]) for k in keys}


def convert_episode(old):
    plain(old)
    if old.get("schema") != "VerifiedReplayEpisode/0.1":
        raise ValueError("UNSUPPORTED_LEGACY_SCHEMA")
    return {"schema": "LegacyEpisodeImport/0.3", "status": "METADATA_ONLY",
            **_select(old, ["episode_id", "dataset_kind", "original_role"]),
            "origin": _select(old["origin"], ["seen_before_design", "actor_kind", "neural_expert", "student_rollout", "audit_sha256"]),
            "split": _select(old["split"], ["original_role", "pool", "duplicate_or_scenario_group", "future_heldout_eligible", "prospective_split_frozen"]),
            "clock": _select(old["clock"], ["clock_id", "original_epoch", "unit", "samples"]),
            "labels": _select(old["labels"], ["contracts", "objectives"]),
            "student_features": {}, "capture_interface_evidence": "NOT_ESTABLISHED_BY_CONVERSION",
            "actual_production_rows": 0, "admitted_for_current_training_rows": 0,
            "teacher_privilege_not_a_blanket_BC_disqualification": True}


def convert_candidate(old):
    plain(old)
    if old.get("schema") != "VerifiedReplayCausalCandidate/0.1":
        raise ValueError("UNSUPPORTED_LEGACY_SCHEMA")
    observation = _select(old["observation"], ["capture_index", "camera_frame", "capture_phase", "capture_time",
        "clock_id", "unit", "next_submission_tick", "policy_delivery_time", "policy_delivery_clock_id", "JPEG_sha256", "depth_sha256"])
    action = old["action_label"]
    if action is not None:
        action = _select(action, ["command_id", "source_index", "submission_tick", "submission_time", "clock_id", "unit",
                                 "semantic", "arm_target", "grip_target", "actual_application", "physical_effect_time"])
        if action["actual_application"] is not None:
            action["actual_application"] = _select(action["actual_application"], ["apply_tick", "apply_time", "clock_id", "semantic"])
    return {"schema": "LegacyCausalImport/0.3", "status": "METADATA_ONLY", "episode_id": old["episode_id"],
            "observation": observation, "action_label": action,
            **_select(old, ["same_time_source_order", "source_order_evidence", "source_dispatch_sha256"]),
            "student_features": {}, "offline_capture_contract": "NOT_RETROACTIVELY_CREATED",
            "actual_production_rows": 0, "admitted_for_current_training_rows": 0,
            "scripted_actor_observed_image": old["scripted_actor_observed_image"],
            "teacher_observed_image_not_required_for_offline_BC": True,
            "missing_provenance_not_filled": True}


def declare_legacy_training(record, declaration):
    """Explicit versioned use, preserving old roles; still metadata-only."""
    keys = {"new_dataset_version", "source_episode_id", "original_role", "pool"}
    plain(record)
    plain(declaration)
    if type(declaration) is not dict or set(declaration) != keys or not declaration["new_dataset_version"]:
        raise ValueError("EXPLICIT_VERSIONED_LEGACY_TRAIN_DECLARATION_REQUIRED")
    if record.get("schema") != "LegacyEpisodeImport/0.3" or declaration["source_episode_id"] != record["episode_id"] or declaration["original_role"] != record["original_role"] or declaration["pool"] != "LEGACY_SEEN_TRAIN":
        raise ValueError("LEGACY_ROLE_ID_OR_POOL_REWRITE_REJECTED")
    result = copy.deepcopy(record)
    result["training_use_declaration"] = copy.deepcopy(declaration)
    result["split"]["source_pool_preserved"] = result["split"]["pool"]
    result["split"]["pool"] = "LEGACY_SEEN_TRAIN"
    result["split"]["future_heldout_eligible"] = False
    return result
