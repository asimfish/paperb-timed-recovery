"""Data-only prospective recorder boundary; no native/hardware implementation."""
from typing import Protocol


class CaptureLogger(Protocol):
    def append(self, kind: str, payload: dict) -> int: ...
    def close(self) -> dict: ...


class CaptureReader(Protocol):
    def readback(self) -> dict: ...

# Implementations accept externally supplied expected protocol pins for
# production. CPU fixture fake pins are never evidence of source attestation.
