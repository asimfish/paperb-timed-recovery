# Causal student capture 0.3

修复独立审计发现的真实时序漏洞。v0.2的 outcome20→submit40→apply50 在close时读取整段日志的动作，错误得到bc_success=TRUE；缺少application仍可TRUE。原frozen20 source、89,084B源码包及54PASS逐字保留在original_v02_snapshot，旧目录不修改。

v0.3只使用outcome当时的(native ns, source seq)前缀。EXECUTION_OUTCOME的已知成功须有相关chunk前声明required controls的真实提交及已发生APPLIED；未发生channel终态或REJECTED/DROPPED/TIMEOUT不能执行成功。物理成功仍需要独立固定源objective标签，应用本身不证明效果。UNKNOWN不向未来借证据。STATE_LABEL/PROPOSAL_LABEL可保留TRUE，但不能成为执行成功BC、恢复或RL transition。

required_for_execution在原chunk中不可变。optional尾部可在标签前明确unsubmitted/mask；之后才提交或mask的未来slot不回填，BC资格UNKNOWN。不同chunk/request不能互相替代application。跨多个chunk的完整task由独立全任务合同验证，不把本接口单chunk row称整个任务成功。

- ROOT_CAUSE_cn.md、ADR_cn.md、COLLECTOR_INTEGRATION_cn.md解释根因/协议/挂点。
- independent_red保留第三方原反例与实际v0.2复现。
- tests保留原54项（新类型声明），另26项时序回归。无提交proposal的已知执行成功范围加强为拒绝；另有显式proposal-label正例。
- cpu_acceptance_v03保存实际80测试、synthetic writer/readback、early-execution失败原件无CLOSE。
- schemas是0.3合同；0.2不能静默升为合格0.3记录。

生产、入训、native/GPU/θ均0。synthetic JSON不是图片或真实机器人数据。特权教师BC仍允许；失败RL与恢复按用途保留。旧19 allowlist只读转换，不补delivery或改role/heldout。已见任务可显式训练。

运行：PYTHONDONTWRITEBYTECODE=1 python3 code/run_cpu_acceptance.py --output cpu_acceptance_local --legacy-root ../stateful_controller_expansion_2026-10-13/learning_data_design

writer单owner/write-once，close失败留原件；reader fail closed。source pin/有限键检测依赖可信collector，不是敌手沙箱。用独立进程或模块路径避免混用0.2/0.3同名模块缓存；native I/O墙钟未测。

这是producer CPU通过的修复候选，root/独立审计再复核后才用于production learning。并行native单例只采原件、标签UNKNOWN、入训0，不依赖旧BCgate；本owner不启动native。
