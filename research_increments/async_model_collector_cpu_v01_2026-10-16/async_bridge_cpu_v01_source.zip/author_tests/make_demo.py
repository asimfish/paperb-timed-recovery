"""Retain one complete deterministic CPU fixture journal and its external header."""
import copy,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from async_bridge import AsyncBridge,fixture_header,fixture_state,canonical,sha256
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
h=fixture_header();(out/'expected_header.json').write_bytes(canonical(h)+b'\n')
b=AsyncBridge(out/'journal.jsonl',h,expected_header=copy.deepcopy(h));wall=1
b.observe_state(fixture_state(h,0),wall_ns=wall);wall+=1
b.publish_packet('rgb-proprio-cpu-public',b'CPU_SYNTHETIC_PUBLIC_NO_RGB_MODEL',wall_ns=wall);wall+=1
start=b.start_inference('ticket-0',actor_id='student',actual_input_bytes=b'CPU_SYNTHETIC_PUBLIC_NO_RGB_MODEL',desired_ticks=list(range(8)),declared_end_tick=7,purpose='ORIGINAL_GOAL',wall_ns=wall);wall+=1
b.observe_state(fixture_state(h,3),wall_ns=wall);wall+=1
b.accept_return('ticket-0',snapshot_sha256=start['body']['snapshot_sha256'],output_8x9=[[i/10.0]*9 for i in range(8)],current_state_id='state-3',wall_ns=wall);wall+=1
for i in range(8):
 p=b.prepare_slot('ticket-0',i,current_state_id=b.snapshot()['state']['state_id'],queue_sha256=b.queue_snapshot()['sha256'],purpose='ORIGINAL_GOAL')
 b.commit_slot(p,current_state_id=p['current_state_id'],queue_sha256=p['queue_sha256'],wall_ns=wall);wall+=1
for tick in (4,5,6):
 b.observe_state(fixture_state(h,tick),wall_ns=wall);wall+=1
 cmd=b.queue_snapshot()['commands'][0]
 b.record_channel_result(cmd['command_id'],status='APPLIED',current_state_id='state-'+str(tick),actual_target_9d=cmd['target_9d'],claimed_owner=cmd['owner'],wall_ns=wall);wall+=1
b.close(reason='CPU_DEMO_COMPLETE_NOT_NATIVE_NOT_SFR',wall_ns=wall)
r=AsyncBridge.replay(out/'journal.jsonl',expected_header=h)
assert r.snapshot()==b.snapshot()
(out/'final_snapshot.json').write_bytes(canonical(b.snapshot())+b'\n')
(out/'receipt.json').write_text(json.dumps({'scope':'CPU_FIXTURE_ONLY_NOT_MODEL_NOT_NATIVE_NOT_SFR','executed_source_sha256':sha256((Path(__file__).resolve().parents[1]/'code'/'async_bridge.py').read_bytes()),'events':b.snapshot()['events'],'slots':{k:v['disposition'] for k,v in b.snapshot()['tickets']['ticket-0']['slots'].items()},'replay_exact':True,'journal_sha256':sha256((out/'journal.jsonl').read_bytes()),'header_sha256':sha256((out/'expected_header.json').read_bytes())},indent=2)+'\n')
print(json.dumps({'out':str(out),'events':b.snapshot()['events'],'replay_exact':True}))
