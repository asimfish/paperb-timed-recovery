"""Independent public-API contract tests. CPU fixtures only; no author reducer oracle."""
from __future__ import annotations
import argparse, base64, copy, hashlib, importlib.util, json, math, os, pathlib, tempfile, traceback

HERE=pathlib.Path(__file__).resolve().parents[1]
def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False,ensure_ascii=True).encode('ascii')
def h(x): return hashlib.sha256(x).hexdigest()
def dg(x): return h(canon(x))
KINDS=['CASE_BEGIN','OBSERVED_STATE','PUBLIC_PACKET','INFERENCE_START','INFERENCE_RETURN','SLOT_DISPOSITION','CHANNEL_RESULT','ACTOR_TRANSITION','FULL_TASK_FAILURE','CAPACITY_REFUSAL','CASE_END']
def header(**cap_changes):
    actors=[{'actor_id':r.lower(),'role':r,'actor_source_sha256':h((r+'source').encode()),'weights_sha256':h((r+'weights').encode()),'input_adapter_sha256':h((r+'adapter').encode())} for r in ['STUDENT','TEACHER']]
    caps={'events':100000,'tickets':2000,'inflight':64,'packet_archive':3000,'asset_bytes':20000000,'commands':16000,'history_window':512,'end_reserve':1,'refusal_reserve':8,'max_line_bytes':4000000,'journal_bytes':512000000,'kinds':{k:100000 for k in KINDS}}
    caps.update(cap_changes)
    return {'schema':'AsyncCollectorHeader/0.1','mode':'CPU_FIXTURE','attempt_id':'reader-attempt','failure_root_id':'reader-original-root','native_epoch':'reader-synthetic-epoch','original_deadline_ns':1000000000,'deadline_clock_id':'reader-synthetic-clock','clock_mapping_sha256':h(b'reader-map'),'collector_source_sha256':h(b'reader-collector'),'source_pins':{'independent_fixture':h(b'independent-fixture-not-native')},'graph_id':'reader-cpu-graph','split':'TRAIN','actors':actors,'initial_actor_id':'student','horizon':8,'action_dimension':9,'guard_source_sha256':h(b'reader-guard'),'authorization_source_sha256':h(b'reader-authority'),'channel':{'source_sha256':h(b'reader-fifo'),'latency_ticks':1,'semantics':'FIFO_NONCANCELLABLE'},'caps':caps}
def state(hd,tick,**extra):
    d={'attempt_id':hd['attempt_id'],'native_epoch':hd['native_epoch'],'state_id':'s'+str(tick),'physical_state_sha256':dg({'reader_synthetic_tick':tick}),'tick':tick,'time_ns':tick*1000000,'deadline_clock_id':hd['deadline_clock_id'],'deadline_time_ns':tick*1000000,'collector_source_sha256':hd['collector_source_sha256'],'lawful_state':True}
    d.update(extra); return d
OUT=[[i+j/100 for j in range(9)] for i in range(8)]
class Fixture:
    def __init__(self,mod,name,hd=None,hook=None):
        self.h=copy.deepcopy(hd or header());self.expected=copy.deepcopy(self.h);self.path=ROOT/(name+'.jsonl');self.a=mod.AsyncBridge(self.path,self.h,expected_header=self.expected,persist_hook=hook);self.wall=0
    def w(self): self.wall+=1;return self.wall
    def obs(self,tick,**kw):return self.a.observe_state(state(self.h,tick,**kw),wall_ns=self.w())
    def sid(self):return self.a.snapshot()['state']['state_id']
    def packet(self,b=b'public synthetic RGBD/proprio/offsets/mask',name='p0'):return self.a.publish_packet(name,b,wall_ns=self.w())
    def start(self,name='t0',ticks=None,end=100,purpose='ORIGINAL_GOAL',data=None):
        ss=self.a.snapshot(); tick=ss['state']['tick']; raw=base64.b64decode(ss['packets'][-1]['public_bytes_b64']) if data is None else data
        return self.a.start_inference(name,actor_id=ss['actor_id'],actual_input_bytes=raw,desired_ticks=list(range(tick,tick+8)) if ticks is None else ticks,declared_end_tick=end,purpose=purpose,wall_ns=self.w())
    def ret(self,name='t0',output=OUT,**kw):
        sha=self.a.snapshot()['tickets'][name]['snapshot_sha256'];return self.a.accept_return(name,snapshot_sha256=sha,output_8x9=copy.deepcopy(output),current_state_id=self.sid(),wall_ns=self.w(),**kw)
    def prep(self,i,name='t0',purpose=None,auth=None):
        if purpose is None:purpose=self.a.snapshot()['tickets'][name]['snapshot']['purpose']
        return self.a.prepare_slot(name,i,current_state_id=self.sid(),queue_sha256=self.a.queue_snapshot()['sha256'],purpose=purpose,authorization=auth)
    def commit(self,p):return self.a.commit_slot(p,current_state_id=self.sid(),queue_sha256=self.a.queue_snapshot()['sha256'],wall_ns=self.w())
    def transition(self,actor):return self.a.transition_actor(actor,reason='independent fixture takeover',current_state_id=self.sid(),wall_ns=self.w())
    def failure(self,known,full):return self.a.record_failure(known_original_failure=known,original_full_failure=full,evidence_sha256=h(b'synthetic-independent-failure-record'),current_state_id=self.sid(),wall_ns=self.w())
    def result(self,cid,status='APPLIED',owner=None,target=None):
        cmd=self.a.snapshot()['commands'][cid];return self.a.record_channel_result(cid,status=status,current_state_id=self.sid(),actual_target_9d=cmd['target_9d'] if target is None else target,claimed_owner=cmd['owner'] if owner is None else owner,wall_ns=self.w())
    def closed(self):return self.a.close(reason='reader fixture ended',wall_ns=self.w())
    def auth(self,i,name='t0',purpose=None,**kw):
        t=self.a.snapshot()['tickets'][name];d={'state_id':self.sid(),'purpose':purpose or t['snapshot']['purpose'],'target_sha256':dg(t['return']['output_8x9'][i]),'source_sha256':self.h['authorization_source_sha256']};d.update(kw);return d

def reject_unchanged(f,fn,contains=None):
    before=canon(f.a.snapshot());raw=f.path.read_bytes();broken=f.a.broken
    try:fn()
    except Exception as e:
        if contains:assert contains in str(e),(contains,type(e).__name__,str(e))
    else:raise AssertionError('INVALID_REQUEST_ACCEPTED')
    assert canon(f.a.snapshot())==before,'REJECTION_MUTATED_ACCEPTED_STATE'
    assert f.path.read_bytes()==raw,'REJECTION_MUTATED_JOURNAL_BYTES'
    assert f.a.broken==broken,'VALIDATION_REJECTION_CHANGED_BROKEN'

def basic(mod,name,**kw):
    f=Fixture(mod,name,**kw);f.obs(0);f.packet();return f

def T01_input_snapshot_vs_current_guard(mod):
    f=basic(mod,'T01');e=f.start();frozen=copy.deepcopy(e['body']['snapshot']);sha=e['body']['snapshot_sha256'];assert frozen['input_prefix']['as_of_time_ns']==0
    e['body']['snapshot']['input_prefix']['packet_ids'][0]='MUTATED';e['body']['snapshot']['actor']['actor_generation']=500
    assert f.a.snapshot()['tickets']['t0']['snapshot']==frozen
    f.obs(3);f.packet(b'new tick 3 image bytes','p3');f.ret();assert f.a.snapshot()['tickets']['t0']['snapshot_sha256']==sha
    for i in range(4):assert f.prep(i)['disposition']=='STALE'
    p=f.prep(4);assert p['disposition']=='SUBMIT' and p['desired_tick']==4 and p['slot_index']==4 and p['target_9d']==OUT[4]
    assert p['input_snapshot_sha256']==sha and p['current_state_id']=='s3'
    f.commit(p);assert f.a.snapshot()['commands']['t0:4']['owner']==frozen['actor'];f.obs(4);f.result('t0:4');f.closed()

def T02_causal_input_mismatch_and_assets(mod):
    f=basic(mod,'T02');reject_unchanged(f,lambda:f.start(data=b'future or unsupplied input'),'ACTUAL_INPUT_MUST_EQUAL')
    reject_unchanged(f,lambda:f.a.start_inference('assets',actor_id='student',actual_input_bytes=b'public synthetic RGBD/proprio/offsets/mask',actual_asset_bytes=(b'unbound asset',),desired_ticks=list(range(8)),declared_end_tick=9,wall_ns=f.w()),'ASSET_BINDINGS_UNSUPPORTED')
    reject_unchanged(f,lambda:f.start(data=bytearray(b'public synthetic RGBD/proprio/offsets/mask')),'IMMUTABLE_BYTES_REQUIRED')
    f.start();reject_unchanged(f,lambda:f.start(),'TICKET_ID_INVALID_OR_DUPLICATE')
    f.obs(2);reject_unchanged(f,lambda:f.a.accept_return('t0',snapshot_sha256='f'*64,output_8x9=OUT,current_state_id=f.sid(),wall_ns=f.w()),'RETURN_START_SNAPSHOT_MISMATCH')
    reject_unchanged(f,lambda:f.a.accept_return('t0',snapshot_sha256=f.a.snapshot()['tickets']['t0']['snapshot_sha256'],output_8x9=OUT,current_state_id='s0',wall_ns=f.w()),'LATEST_CURRENT_STATE_REQUIRED')
    f.ret();reject_unchanged(f,lambda:f.ret(),'DUPLICATE_RETURN');f.closed()

def T03_shape_finiteness_rejections(mod):
    f=basic(mod,'T03');f.start()
    malformed=[list(range(72)),[[1.0]*8 for _ in range(8)],[[True]*9 for _ in range(8)],[[float('inf')]*9 for _ in range(8)],[[float('nan')]*9 for _ in range(8)]]
    for bad in malformed:reject_unchanged(f,lambda bad=bad:f.ret(output=bad))
    f.ret();f.closed()

def T04_reverse_arrival_order(mod):
    f=basic(mod,'T04');f.start('older');f.obs(1);f.packet(b'next start inputs','p1');f.start('newer');f.obs(3);f.ret('newer');f.ret('older')
    s=f.a.snapshot();assert s['tickets']['older']['snapshot']['start_state']['tick']==0 and s['tickets']['newer']['snapshot']['start_state']['tick']==1
    assert s['tickets']['older']['return']['current_state_id']=='s3';f.closed()

def T05_actor_ABA_revocation(mod):
    f=basic(mod,'T05');f.start();f.transition('teacher');f.transition('student');f.obs(2);f.ret();p=f.prep(5)
    assert p['disposition']=='ACTOR_REVOKED' and p['owner']['actor_generation']==0 and f.a.snapshot()['actor_generation']==2;f.commit(p);assert not f.a.snapshot()['commands'];f.closed()

def T06_FIFO_original_owner_and_result_validation(mod):
    f=basic(mod,'T06');f.start();f.ret();p1=f.prep(1);f.commit(p1);p2=f.prep(2);f.commit(p2)
    before=copy.deepcopy(f.a.queue_snapshot());f.transition('teacher');assert f.a.queue_snapshot()==before
    f.obs(1);reject_unchanged(f,lambda:f.result('t0:2'),'FIFO_HEAD_REQUIRED')
    wrong=copy.deepcopy(p1['owner']);wrong['actor_generation']=2;reject_unchanged(f,lambda:f.result('t0:1',owner=wrong),'CHANNEL_OWNER_TARGET_MISMATCH')
    f.result('t0:1');assert f.a.snapshot()['commands']['t0:1']['owner']['actor_id']=='student'
    reject_unchanged(f,lambda:f.result('t0:2'),'APPLIED_ORIGINAL_TICK_OR_READY_MISMATCH');f.obs(2);f.result('t0:2');reject_unchanged(f,lambda:f.result('t0:2'),'SUBMITTED_PENDING_COMMAND_REQUIRED');f.closed()

def T07_prepared_staleness(mod):
    f=basic(mod,'T07');f.start();f.ret();p=f.prep(4);f.obs(1);reject_unchanged(f,lambda:f.commit(p))
    p3=f.prep(3);p4=f.prep(4);f.commit(p3);reject_unchanged(f,lambda:f.commit(p4),'PREPARED_EXPECTATION_MISMATCH')
    p=f.prep(5);f.transition('teacher');reject_unchanged(f,lambda:f.commit(p),'PREPARED_STALE_OR_TAMPERED')
    f.transition('student');f.closed()

def T08_deadline_failure_and_frozen_purpose(mod):
    hd=header();hd['original_deadline_ns']=2000000;f=basic(mod,'T08',hd=hd);f.start(ticks=list(range(10,18)),end=20);f.obs(3);f.ret()
    reject_unchanged(f,lambda:f.prep(1,purpose='SAFE_LOCAL_RECOVERY'),'FROZEN_PURPOSE_MISMATCH')
    p=f.prep(1);assert p['disposition']=='GUARD_REJECTED';f.commit(p);assert not f.a.snapshot()['commands']
    f.failure(True,True);reject_unchanged(f,lambda:f.failure(False,False),'HARD_FAILURE_ABSORBING');f.closed()

def T09_recovery_current_target_authorization(mod):
    hd=header();hd['original_deadline_ns']=2000000;f=basic(mod,'T09',hd=hd);f.start(ticks=list(range(10,18)),end=20,purpose='SAFE_LOCAL_RECOVERY');f.obs(3);f.ret()
    reject_unchanged(f,lambda:f.prep(1,auth=f.auth(1)),'RECOVERY_REQUIRES_KNOWN_FAILURE');f.failure(True,False)
    reject_unchanged(f,lambda:f.prep(1,auth=f.auth(1)),'POST_DEADLINE_RECOVERY_REQUIRES_FULL_FALSE');f.failure(True,True)
    for kw in [{'state_id':'s0'},{'purpose':'SAFETY_ABORT'},{'target_sha256':'f'*64},{'source_sha256':'e'*64}]:reject_unchanged(f,lambda kw=kw:f.prep(1,auth=f.auth(1,**kw)),'CURRENT_TARGET_AUTHORIZATION_REQUIRED')
    p=f.prep(1,auth=f.auth(1));assert p['disposition']=='SUBMIT';f.commit(p);assert f.a.snapshot()['original_full_failure'];f.closed()

def T10_abort_under_unknown_no_invented_failure(mod):
    f=basic(mod,'T10');f.start(purpose='SAFETY_ABORT');f.ret();p=f.prep(2,auth=f.auth(2));f.commit(p);s=f.a.snapshot();assert not s['original_full_failure'] and not s['known_original_failure'];f.closed()

def T11_error_return_tail_and_duplicate_slot(mod):
    f=basic(mod,'T11');f.start(end=4);f.ret(output=None,status='ERROR');p=f.prep(2);assert p['disposition']=='ERROR_NO_OUTPUT';f.commit(p);reject_unchanged(f,lambda:f.prep(2),'DUPLICATE_SLOT');f.closed()
    g=basic(mod,'T11tail');g.start(end=4);g.ret();assert g.prep(4)['disposition']=='PADDING','DECLARED_END_MUST_BE_EXCLUSIVE';g.closed()

def T12_absorbing_failure_rechecks_prepared(mod):
    f=basic(mod,'T12');f.start();f.ret();p=f.prep(4);f.failure(True,True);reject_unchanged(f,lambda:f.commit(p),'PREPARED_STALE_OR_TAMPERED');assert f.prep(4)['disposition']=='GUARD_REJECTED';f.closed()

def T13_clock_header_and_public_export_boundaries(mod):
    hd=header();wrong=copy.deepcopy(hd);wrong['actors'][0]['weights_sha256']='f'*64
    p=ROOT/'T13header.jsonl'
    try:mod.AsyncBridge(p,wrong,expected_header=hd)
    except Exception as e:assert 'EXTERNAL_FULL_HEADER_MISMATCH' in str(e)
    else:raise AssertionError('REHASHED_HEADER_ACCEPTED')
    assert not p.exists()
    f=basic(mod,'T13');f.start();f.obs(3);reject_unchanged(f,lambda:f.obs(2),'ACCEPTED_CLOCK_ROLLBACK')
    oldwall=f.wall-2;reject_unchanged(f,lambda:f.a.transition_actor('teacher',reason='rollback',current_state_id=f.sid(),wall_ns=oldwall),'ACCEPTED_CLOCK_ROLLBACK')
    assert not hasattr(f.a,'teacher_private_inputs') and not hasattr(f.a,'admit_verified_label');assert f.a.snapshot()['header']['mode']=='CPU_FIXTURE';f.closed()

def T14_pending_crash_and_readonly_recovery(mod):
    f=basic(mod,'T14');f.start();f.ret();f.commit(f.prep(2));before=f.a.snapshot();raw=f.path.read_bytes();r=mod.AsyncBridge.replay(f.path,expected_header=f.expected)
    assert r.snapshot()==before and r.snapshot()['queue']==['t0:2'] and r.snapshot()['commands']['t0:2']['status']=='SUBMITTED'
    try:r.observe_state(state(f.h,1),wall_ns=100)
    except Exception as e:assert 'READ_ONLY_REPLAY' in str(e)
    else:raise AssertionError('READONLY_REPLAY_MUTATED')
    assert f.path.read_bytes()==raw;f.closed();assert f.a.snapshot()['commands']['t0:2']['status']=='SUBMITTED'
    assert json.loads(f.path.read_text().splitlines()[-1])['body']['censored']['unresolved_outcomes']=='UNKNOWN_NO_AUTOMATIC_RESEND'

def T15_WAL_each_phase_failure_and_prefix_readback(mod):
    for phase in ['before_write','after_write','after_flush','after_fsync']:
        enabled={'value':False}
        def hook(at,event,file,phase=phase):
            if enabled['value'] and at==phase:raise OSError('reader injected '+phase)
        f=basic(mod,'T15_'+phase,hook=hook);f.start();before=f.a.snapshot();old=f.path.read_bytes();enabled['value']=True
        try:f.ret()
        except OSError:pass
        else:raise AssertionError('PERSISTENCE_FAULT_IGNORED')
        assert f.a.broken and f.a.snapshot()==before
        reject_unchanged(f,lambda:f.ret(),'JOURNAL_BROKEN')
        retained=f.path.read_bytes();r=mod.AsyncBridge.replay(f.path,expected_header=f.expected)
        if phase=='before_write':assert retained==old and r.snapshot()==before
        else:assert r.snapshot()['tickets']['t0']['return'] is not None and r.snapshot()['events']==before['events']+1
        # A fsync uncertainty can leave a valid durable line while live indices stay unchanged.
        # This proves safe read-only prefix handling, not physical exactly-once.

def T16_capacity_reservation_refusal_and_close(mod):
    hd=header(events=30,tickets=2,inflight=1,commands=16,packet_archive=3,history_window=2)
    f=basic(mod,'T16',hd=hd);f.start()
    reject_unchanged(f,lambda:f.start('second'),'TICKET_OR_INFLIGHT_CAPACITY_REFUSED')
    f.a.record_capacity_refusal('INFERENCE_START','inflight reservation refused',wall_ns=f.w());assert f.a.snapshot()['refusals']==1
    f.ret();reject_unchanged(f,lambda:f.start('second'),'EVENT_CAPACITY_REFUSED');f.closed()
    g=basic(mod,'T16asset',hd=header(asset_bytes=45));reject_unchanged(g,lambda:g.start(),'ASSET_CAPACITY_REFUSED');g.closed()

def T17_archive_window_lifetime_and_long_trace(mod):
    hd=header(events=5000,tickets=70,inflight=2,packet_archive=520,history_window=3,asset_bytes=2000000,commands=600)
    f=basic(mod,'T17',hd=hd)
    for i in range(1,514):f.packet(('public'+str(i)).encode(),'p'+str(i))
    p=f.a.prefix();assert p['start']==511 and p['end']==514 and p['length']==3 and p['packet_ids']==['p511','p512','p513']
    for k in range(66):
        f.start('long'+str(k));f.ret('long'+str(k),output=None,status='ERROR')
        for i in range(8):f.commit(f.prep(i,'long'+str(k)))
    s=f.a.snapshot();assert len(s['tickets'])==66 and len(s['packets'])==514 and s['reserved_commands']==0 and s['reserved_events']==0 and not s['commands']
    f.closed();r=mod.AsyncBridge.replay(f.path,expected_header=f.expected);assert r.snapshot()==f.a.snapshot()
    (ROOT/'LONG_TRACE_COUNTS.json').write_text(json.dumps({'events':r.snapshot()['events'],'packets':514,'history_window':3,'tickets':66,'slots':528,'native_model_physical_commands':0,'full_1750_ticket_case':'NOT_RUN'},indent=2)+'\n')

def T18_unsubmitted_slot_not_channel_result(mod):
    f=basic(mod,'T18');f.start();f.obs(3);f.ret();f.commit(f.prep(0));reject_unchanged(f,lambda:f.a.record_channel_result('t0:0',status='DROPPED',current_state_id=f.sid(),actual_target_9d=OUT[0],claimed_owner=f.a.snapshot()['tickets']['t0']['snapshot']['actor'],wall_ns=f.w()),'SUBMITTED_PENDING_COMMAND_REQUIRED');f.closed()

def T19_actor_and_output_deepcopy(mod):
    f=basic(mod,'T19');f.start();out=copy.deepcopy(OUT);f.ret(output=out);out[2][0]=999;p=f.prep(2);assert p['target_9d']==OUT[2]
    forged=copy.deepcopy(p);forged['target_9d'][0]=999;unsigned={k:v for k,v in forged.items() if k!='prepared_sha256'};forged['prepared_sha256']=dg(unsigned)
    reject_unchanged(f,lambda:f.commit(forged),'PREPARED_STALE_OR_TAMPERED');f.closed()

def T20_replay_wrong_header_truncation_and_hash_tamper(mod):
    f=basic(mod,'T20');f.start();f.ret();f.closed();raw=f.path.read_bytes();wrong=copy.deepcopy(f.expected);wrong['graph_id']='changed'
    try:mod.AsyncBridge.replay(f.path,expected_header=wrong)
    except Exception as e:assert 'EXTERNAL_FULL_HEADER_MISMATCH' in str(e)
    else:raise AssertionError('WRONG_EXTERNAL_REPLAY_HEADER_ACCEPTED')
    for name,data in [('truncated',raw[:-1]),('corrupt',raw.replace(b'public',b'PUBLIC',1))]:
        p=ROOT/('T20_'+name+'.jsonl');p.write_bytes(data)
        try:mod.AsyncBridge.replay(p,expected_header=f.expected)
        except Exception:pass
        else:raise AssertionError(name+' replay accepted')


def T21_unsafe_authorized_abort_recovery_and_goal(mod):
    f=basic(mod,'T21abort');f.start(purpose='SAFETY_ABORT');f.ret();f.obs(1,lawful_state=False)
    for kw in [{'state_id':'s0'},{'purpose':'SAFE_LOCAL_RECOVERY'},{'target_sha256':'f'*64},{'source_sha256':'e'*64}]:reject_unchanged(f,lambda kw=kw:f.prep(5,auth=f.auth(5,**kw)),'CURRENT_TARGET_AUTHORIZATION_REQUIRED')
    p=f.prep(5,auth=f.auth(5));assert p['disposition']=='SUBMIT','UNSAFE_CURRENT_STATE_CANNOT_BLOCK_CURRENT_AUTHORIZED_ABORT'
    f.commit(p);assert not f.a.snapshot()['known_original_failure'] and not f.a.snapshot()['original_full_failure'];f.closed()
    g=basic(mod,'T21recovery');g.start(purpose='SAFE_LOCAL_RECOVERY');g.ret();g.obs(1,lawful_state=False)
    reject_unchanged(g,lambda:g.prep(5,auth=g.auth(5)),'RECOVERY_REQUIRES_KNOWN_FAILURE');g.failure(True,False)
    reject_unchanged(g,lambda:g.prep(5,auth=None),'CURRENT_TARGET_AUTHORIZATION_REQUIRED');p=g.prep(5,auth=g.auth(5))
    assert p['disposition']=='SUBMIT','UNSAFE_CURRENT_STATE_CANNOT_BLOCK_CURRENT_AUTHORIZED_RECOVERY';g.commit(p);g.closed()
    q=basic(mod,'T21goal');q.start();q.ret();q.obs(1,lawful_state=False);p=q.prep(5);assert p['disposition']=='GUARD_REJECTED';q.commit(p);assert not q.a.snapshot()['commands'];q.closed()

TESTS=[v for k,v in globals().copy().items() if k.startswith('T') and k[1:3].isdigit() and callable(v)]
def main():
    global ROOT
    ap=argparse.ArgumentParser();ap.add_argument('--source',required=True);ap.add_argument('--out',required=True);ap.add_argument('--only');ap.add_argument('--skip-long',action='store_true');args=ap.parse_args()
    ROOT=pathlib.Path(args.out);ROOT.mkdir(parents=True,exist_ok=False)
    source_before=h(pathlib.Path(args.source).read_bytes())
    spec=importlib.util.spec_from_file_location('reader_candidate_async_bridge',args.source);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    results=[]
    for test in TESTS:
        if args.only and args.only not in test.__name__:continue
        if args.skip_long and test.__name__.startswith('T17'):continue
        try:test(mod);status='PASS';error=None
        except Exception:status='FAIL';error=traceback.format_exc()
        row={'id':test.__name__,'status':status,'error':error};results.append(row);print(json.dumps(row),flush=True)
    report={'schema':'PaperBIndependentAsyncPublicAPITests/1','candidate_path':args.source,'candidate_sha256':h(pathlib.Path(args.source).read_bytes()),'candidate_sha256_before':source_before,'candidate_stable_during_run':source_before==h(pathlib.Path(args.source).read_bytes()),'reader_sha256':h(pathlib.Path(__file__).read_bytes()),'tests':results,'pass_count':sum(x['status']=='PASS' for x in results),'fail_count':sum(x['status']=='FAIL' for x in results),'scope':'CPU synthetic public API only; no author reducer oracle; no native/model/hardware/SFR proof'}
    (ROOT/'RESULTS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['candidate_sha256','pass_count','fail_count']}),flush=True)
    return bool(report['fail_count'])
if __name__=='__main__':raise SystemExit(main())
