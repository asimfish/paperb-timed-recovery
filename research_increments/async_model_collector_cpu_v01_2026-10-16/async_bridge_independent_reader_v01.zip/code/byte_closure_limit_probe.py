"""Independent bounded counterexample: event reservations are not byte reservations."""
import importlib.util,json,pathlib,sys
from independent_tests import header,Fixture
import independent_tests
p=pathlib.Path('/data/liyufeng/paperb_g1_async_bridge_20261016_v1/code/async_bridge.py');s=importlib.util.spec_from_file_location('candidate',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
out=pathlib.Path(sys.argv[1]);out.mkdir(exist_ok=False);independent_tests.ROOT=out
f=Fixture(m,'sizing');f.obs(0);f.packet();f.start();sized=f.path.stat().st_size
limit=sized-5+100 # 512000000 -> four-digit budget shortens header by five bytes.
hd=header(journal_bytes=limit);g=Fixture(m,'bounded',hd);g.obs(0);g.packet();g.start();before=g.a.snapshot();raw=g.path.read_bytes()
try:g.closed()
except Exception as e:failure=type(e).__name__+': '+str(e)
else:raise AssertionError('fixture unexpectedly closed; inspect sizing')
assert 'JOURNAL_TOTAL_BYTE_CAPACITY_REFUSED' in failure and g.a.snapshot()==before and g.path.read_bytes()==raw
r={'schema':'PaperBAsyncReaderByteReservationLimit/1','status':'KNOWN_LIMIT_REPRODUCED_NOT_AN_UNSAFE_WRITE','source_sha256':__import__('hashlib').sha256(p.read_bytes()).hexdigest(),'sizing_bytes':sized,'accepted_start_bytes':len(raw),'declared_journal_bytes':limit,'close_failure':failure,'live_state_unchanged':True,'broken':g.a.broken,'meaning':'Whole-ticket event/kind/command reservations do not reserve future serialized line/journal bytes; end event can be refused by byte cap. Partial prefix remains read-only replayable, no automatic send or resume is justified.'}
(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
