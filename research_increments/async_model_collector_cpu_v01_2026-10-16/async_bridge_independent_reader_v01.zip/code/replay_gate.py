from __future__ import annotations
import argparse,copy,hashlib,importlib.util,json,pathlib,sys,traceback
from independent_replay import audit,C,D,H
from independent_tests import header

def load(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def expected(name):
 h=header()
 if name.startswith('T08') or name.startswith('T09'):h['original_deadline_ns']=2000000
 if name=='T16':h=header(events=30,tickets=2,inflight=1,commands=16,packet_archive=3,history_window=2)
 if name=='T16asset':h=header(asset_bytes=45)
 if name=='T17':h=header(events=5000,tickets=70,inflight=2,packet_archive=520,history_window=3,asset_bytes=2000000,commands=600)
 return h

def rechain(events):
 prev='0'*64
 for i,e in enumerate(events):
  e['seq']=i;e['prev_sha256']=prev;e['sha256']=D({k:v for k,v in e.items() if k!='sha256'});prev=e['sha256']
 return b''.join(C(e)+b'\n' for e in events)

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--out',required=True);args=p.parse_args();out=pathlib.Path(args.out);out.mkdir(exist_ok=False)
 base=pathlib.Path(__file__).resolve().parents[1];m=load(args.source,'producer_replay_for_comparison_only');results=[]
 def check(name,fn):
  try:detail=fn();row={'id':name,'status':'PASS','detail':detail}
  except Exception:row={'id':name,'status':'FAIL','error':traceback.format_exc()}
  results.append(row);print(json.dumps(row),flush=True)
 def one(path,hd):
  ours=audit(path,hd);producer=m.AsyncBridge.replay(path,expected_header=hd).snapshot()
  pairs={'events':'events','chain':'chain','commands':'commands','queue':'queue','actor_id':'actor_id','actor_generation':'actor_generation','known_original_failure':'known_original_failure','original_full_failure':'original_full_failure','closed':'closed','kind_counts':'kind_counts'}
  for a,b in pairs.items():assert ours[a]==producer[b],(a,ours[a],producer[b])
  assert ours['packets']==len(producer['packets']) and ours['tickets']==len(producer['tickets'])
  return {'events':ours['events'],'packets':ours['packets'],'tickets':ours['tickets'],'slots':ours['slots'],'journal_sha256':H(path.read_bytes()),'independent_summary':ours}
 for dirname in ['first_candidate_all','second_candidate_short','unsafe_scope_regression_green_d044']:
  for path in sorted((base/'results'/dirname).glob('*.jsonl')):
   if path.name.startswith('T20_'):continue
   check(dirname+'/'+path.stem,lambda path=path:one(path,expected(path.stem)))
 root=pathlib.Path('/data/liyufeng/paperb_async_runtime_20261016_v1/wiring_smoke_actual_v1');check('root_real_process_wiring_OLD_SOURCE_CPU_ONLY',lambda:one(root/'ASYNC_JOURNAL.jsonl',json.loads((root/'EXPECTED_HEADER.json').read_text())))
 # Retain a small valid journal as immutable ancestor, then rehash all modified descendants.
 source=base/'results'/'second_candidate_short'/'T01.jsonl';events=[json.loads(x) for x in source.read_text().splitlines()];hd=header()
 def bad(name,mut):
  altered=copy.deepcopy(events);mut(altered);path=out/(name+'.jsonl');path.write_bytes(rechain(altered));rejections={}
  for reader,call in [('independent',lambda:audit(path,hd)),('producer_public_replay',lambda:m.AsyncBridge.replay(path,expected_header=hd))]:
   try:call()
   except Exception as e:rejections[reader]=type(e).__name__+': '+str(e)
   else:raise AssertionError(reader+' accepted fully rehashed semantic tamper '+name)
  return {'sha256':H(path.read_bytes()),'rejections':rejections}
 def mutate_start(ev,key,value):
  row=next(e for e in ev if e['kind']=='INFERENCE_START');row['body']['snapshot'][key]=value;row['body']['snapshot_sha256']=D(row['body']['snapshot'])
 check('tamper_future_prefix_rehashed',lambda:bad('tamper_future_prefix',lambda ev:mutate_start(ev,'input_prefix',dict(next(e for e in ev if e['kind']=='INFERENCE_START')['body']['snapshot']['input_prefix'],as_of_time_ns=3000000))))
 check('tamper_actual_bytes_rehashed',lambda:bad('tamper_actual_bytes',lambda ev:mutate_start(ev,'input_bytes_b64','RlVUVVJF')))
 def changedesired(ev):
  row=next(e for e in ev if e['kind']=='SLOT_DISPOSITION');p=row['body']['prepared'];p['desired_tick']+=1;p['prepared_sha256']=D({k:v for k,v in p.items() if k!='prepared_sha256'})
 check('tamper_slot_retime_rehashed',lambda:bad('tamper_slot_retime',changedesired))
 def owner(ev):
  row=next(e for e in ev if e['kind']=='SLOT_DISPOSITION');p=row['body']['prepared'];p['owner']['actor_generation']+=1;p['prepared_sha256']=D({k:v for k,v in p.items() if k!='prepared_sha256'})
 check('tamper_owner_relabel_rehashed',lambda:bad('tamper_owner_relabel',owner))
 def guard(ev):
  row=next(e for e in ev if e['kind']=='SLOT_DISPOSITION');p=row['body']['prepared'];p['current_state_id']='s0';p['prepared_sha256']=D({k:v for k,v in p.items() if k!='prepared_sha256'})
 check('tamper_guard_rollback_rehashed',lambda:bad('tamper_guard_rollback',guard))
 def extra(ev):next(e for e in ev if e['kind']=='INFERENCE_RETURN')['body']['private_payload']='unauthorized-extra'
 check('tamper_extra_body_field_rehashed',lambda:bad('tamper_extra_body',extra))
 def changedheader(ev):ev[0]['body']['header']['graph_id']='other-graph';ev[0]['body']['header_sha256']=D(ev[0]['body']['header'])
 check('tamper_rehashed_header_externalpin',lambda:bad('tamper_header',changedheader))
 # Explicit bounded read gates at the earliest byte boundary; malformed bytes are never JSON parsed.
 for kind in ['line','file']:
  def gate(kind=kind):
   ext=header();path=out/('over_'+kind+'.jsonl')
   if kind=='line':ext['caps']['max_line_bytes']=1024;path.write_bytes(b'X'*1025+b'\n');code='READER_LINE_BYTE_CAPACITY_REFUSED'
   else:ext['caps']['journal_bytes']=3000;path.write_bytes(b'X'*3001);code='READER_FILE_BYTE_CAPACITY_REFUSED'
   try:m.AsyncBridge.replay(path,expected_header=ext)
   except Exception as e:assert code in str(e),(code,str(e));return {'rejection':str(e),'bytes':path.stat().st_size}
   raise AssertionError('oversize accepted')
  check('resource_'+kind+'_gate_before_parse',gate)
 report={'schema':'PaperBIndependentAsyncReplayGate/1','candidate_sha256':H(pathlib.Path(args.source).read_bytes()),'reader_sha256':H(pathlib.Path(__file__).read_bytes()),'independent_replay_sha256':H((base/'code'/'independent_replay.py').read_bytes()),'checks':results,'pass_count':sum(r['status']=='PASS' for r in results),'fail_count':sum(r['status']=='FAIL' for r in results),'scope':'Independent property checker has no producer imports; producer replay only a separately compared observable. CPU synthetic/wiring journals; not native, authentication, training, SFR, or hardware exactly-once.'}
 (out/'REPLAY_GATE.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['candidate_sha256','pass_count','fail_count']}));return bool(report['fail_count'])
if __name__=='__main__':raise SystemExit(main())
