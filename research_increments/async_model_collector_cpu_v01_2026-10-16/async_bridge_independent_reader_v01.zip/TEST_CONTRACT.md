# Independent async collector reader: prospective CPU contract

Scope: single-writer, CPU synthetic inputs and simulated channel records. This is neither native integration nor physical authentication, model performance, S/F/R admission, security isolation, or hardware exactly-once evidence. The reader imports the public API but does not call the author reducer to decide replay validity.

The author may revise an unsealed candidate after independent failures. Every execution retains candidate source SHA and complete output. No original failed execution is overwritten; focused reruns retain the same case identity and expected assertion.

| Boundary | Observable oracle | Adversarial / recovery requirement |
| --- | --- | --- |
| Header | Constructor and replay match externally pinned full canonical bytes and SHA | Rehashing an altered actor, weight, deadline, source, graph/split or channel cannot bypass expected header |
| Input start | Worker-visible immutable bytes and assets equal the actually supplied, digest-bound copy; prefix is exactly the start-time selected packets | Buffer mutation, future prefix replacement, unknown packet, asset digest, private/student routing cannot change accepted state |
| Inference return | Ticket links original actor generation, snapshot and prefix while current receive time advances | Duplicate/wrong snapshot/epoch, malformed 8x9 and clock rollback reject atomically; valid reverse arrival order remains possible |
| Current action guard | Per-slot original indices/ticks and target are preserved; state, queue and version are current at commit | Stale state/queue, actor ABA and purpose mutation refuse; late return remains observable but goal actuation refuses |
| Channel | One 9D command has immutable submitting owner and original ready tick; FIFO and at most one APPLIED per tick | Actor changes retain outstanding queue; pending/stale slots cannot become fake channel drops; truthful post-deadline results are retained |
| Failure / authorization | Original deadline and absorbing failure remain immutable; current authorization binds source, state, purpose and target | Null original-goal auth, post-D recovery known FALSE, abort under UNKNOWN, independent known failure are distinguished |
| Transactions | Invalid API leaves entire exported state, journal bytes, event highwater, ticket/command/reservation membership unchanged | Injected append/fsync failure marks broken without live half state; recovery reads only durable committed prefix |
| Crash reconciliation | Persist-before-send SUBMITTED intent survives restart; pending outcome remains UNKNOWN | Recovery does not manufacture APPLIED or send again; explicit channel result may reconcile command ID |
| Capacity | Explicit finite caps are checked before start / dispatch and slots remain individually terminal or censored | Window <= history cap and archive > history cap are distinct; overlapping / lifetime tickets and prospective long trace retain all rows |
| Teacher | Student export never receives teacher payload; teacher target is supervision, not application/success | Capability/split/actual student visit references enforced only to the extent implemented; opaque private bytes are not process isolation |
| Independent journal replay | Hash chain, external header, monotone observed clock, input/return/submit linkage, owner generation, original slot, FIFO/unique result and capacity checked by reader code | Tamper record data and recompute descendant hashes: semantic violation must still reject |

Before API exists, this document fixes behavior-level tests, not implementation-specific key names. The design's 37 proposed cases are input to risk selection; no claim that the number itself proves readiness. Long trace is a declared CPU fixture, not performance/native budget admission.
