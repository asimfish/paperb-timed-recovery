# Reproduce in a fresh owned output directory

The source snapshots in `fixtures/` preserve exactly which candidate was tested. Tests are CPU synthetic fixtures; do not interpret this as authorization for native dispatch.

```sh
python3 -B code/independent_tests.py --source fixtures/candidate_third_d04472.py --out /tmp/paperb-reader-new-short --skip-long
python3 -B code/independent_tests.py --source fixtures/candidate_second_550bc8.py --out /tmp/paperb-reader-old-unsafe-red --only T21
```

The second command intentionally fails T21 for the root-discovered unsafe authorization defect. Existing output directories are refused; choose new names on every execution. The complete first long trace is retained as `results/first_candidate_all/T17.jsonl`; it was built once and replayed with later source. Main test IDs and exact first outputs are in `results/*/RESULTS.json` and the matching `.log` files.

`code/independent_replay.py` imports no producer code and accepts a journal plus an externally frozen expected-header file. `code/replay_gate.py` reconstructs expected headers from independent fixture definitions, checks the retained fixtures and root wiring journal, compares selected producer-replay observables, and writes fully rehashed semantic tamper files. Root wiring paths are recorded; relocation requires explicitly remapping those provenance inputs, not modifying preserved records. The producer source was loaded only for the separate public replay comparison, never as the independent semantic oracle.

`code/byte_closure_limit_probe.py` preserves the concrete byte reservation limitation. It references the recorded original source path; use a controlled copy and record the changed source pin if relocating it. That negative evidence remains OPEN in the reviewed final descendant and must not be silently rewritten as a passing lifecycle test.
