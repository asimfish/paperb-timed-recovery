"""Plot every retained owner tick and every CPU command from one actual case."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def main():
    p=argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--case',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
    raw=[json.loads(l) for l in (a.case/'RAW_PROCESS_CHANNEL.jsonl').read_bytes().splitlines()]
    events=[json.loads(l) for l in (a.case/'ASYNC_JOURNAL.jsonl').read_bytes().splitlines()]
    result=json.loads((a.case/'RESULT.json').read_text())
    ticks=json.loads((a.case/'OWNER_TICK_WALL_RECORDS.json').read_text())
    returned=next(r['body'] for r in raw if r['kind']=='WORKER_MESSAGE' and r['body']['kind']=='RETURN')
    dispatch=next(r for r in raw if r['kind']=='WORKER_DISPATCH')['wall_ns']
    owner_return=next(e for e in events if e['kind']=='INFERENCE_RETURN')
    slots=[e for e in events if e['kind']=='SLOT_DISPOSITION']
    acks={r['body']['command_id']:r for r in raw if r['kind']=='CPU_CHANNEL_RAW_ACK'}
    ms=lambda ns:(ns-dispatch)/1e6
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#254454','text.color':'#254454','xtick.color':'#4c6570','ytick.color':'#4c6570','svg.fonttype':'none','pdf.fonttype':42})
    fig,(ax,bx)=plt.subplots(2,1,figsize=(10,6.7),gridspec_kw={'height_ratios':[1,2.1]})
    fig.subplots_adjust(left=.14,right=.97,bottom=.17,top=.79,hspace=1.05)
    ax.set_title('A  Worker computation and continuing owner observations',loc='left',fontweight='bold',pad=30)
    ax.broken_barh([(ms(returned['compute_start_ns']),(returned['compute_end_ns']-returned['compute_start_ns'])/1e6)],(.15,.27),facecolors='#24766a',label='Actual P0 CPU denoising')
    ax.scatter([ms(t['owner_wall_ns']) for t in ticks],[.75]*len(ticks),s=9,color='#3b78a4',marker='|',label='Every owner observation')
    ax.axvline(ms(owner_return['wall_ns']),ls='--',lw=1,color='#b97839',label='Return recorded by owner')
    ax.set_yticks([.28,.75],['P0 worker','Owner loop']);ax.set_ylim(0,1)
    ax.set_xlabel('Measured wall time since dispatch (ms)')
    # The overview includes the complete fixed case; inset is unnecessary and
    # no outcome-dependent subwindow is selected.
    ax.set_xlim(min(0,ms(returned['compute_start_ns'])),ms(ticks[-1]['owner_wall_ns'])+4)
    ax.legend(loc='upper left',bbox_to_anchor=(0,1.72),fontsize=8,frameon=False,ncol=3)
    bx.set_title('B  Original slots, durable submissions and CPU acknowledgments',loc='left',fontweight='bold',pad=30)
    for event in slots:
        s=event['body']['prepared'];i=s['slot_index'];start=ms(event['wall_ns'])
        if s['disposition']=='SUBMIT':
            end=ms(acks[s['command_id']]['wall_ns'])
            bx.plot([start,end],[i,i],color='#bad0d8',lw=4,zorder=1)
            bx.scatter(start,i,s=24,color='#b97839',zorder=3)
            bx.scatter(end,i,s=29,color='#24766a',zorder=3)
            bx.annotate('tick '+str(s['desired_tick']),(end,i),xytext=(6,0),textcoords='offset points',va='center',fontsize=8)
        else:
            bx.scatter(start,i,marker='x',color='#a55545',s=30)
            bx.annotate(s['disposition'],(start,i),xytext=(6,0),textcoords='offset points',va='center',fontsize=8)
    bx.set_yticks(range(8),['Slot '+str(i) for i in range(8)])
    bx.invert_yaxis();bx.set_xlabel('Measured wall time since dispatch (ms)');bx.grid(axis='x',color='#e5ebee',lw=.7)
    bx.margins(x=.17,y=.15)
    bx.scatter([],[],s=24,color='#b97839',label='Durable CPU submission')
    bx.scatter([],[],s=29,color='#24766a',label='CPU FIFO acknowledgment')
    bx.legend(frameon=False,loc='upper left',bbox_to_anchor=(0,1.30),ncol=2,fontsize=8)
    fig.suptitle('One cross-process engineering-model integration run',x=.14,y=.98,ha='left',fontsize=15,fontweight='bold')
    fig.text(.14,.065,'Synthetic CPU state clock and FIFO fixture; no physics, robot actuation, new training or S/F/R admission.',fontsize=9,color='#5e7075')
    fig.text(.14,.035,'All 121 owner observations and all eight original slots retained. One prior P0 checkpoint; no policy-success claim.',fontsize=9,color='#5e7075')
    for ext in ('svg','pdf','png'):fig.savefig(a.out/('async_cpu_timeline.'+ext),dpi=180,metadata={'Creator':'PaperB root audited runtime plot'})
    plt.close(fig)
    sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
    receipt={'schema':'PaperBAsyncCPUFigureReceipt/1','status':'ACTUAL_WALL_AND_CPU_CHANNEL_ONLY','input_files':{n:sha(a.case/n) for n in ['RAW_PROCESS_CHANNEL.jsonl','ASYNC_JOURNAL.jsonl','RESULT.json','OWNER_TICK_WALL_RECORDS.json']},'figure_files':{f.name:sha(f) for f in sorted(a.out.iterdir()) if f.is_file()},'owner_observations_plotted':len(ticks),'original_slots_plotted':len(slots),'epoch_replicates':1,'smoothing':False,'window_search':False,'actual_P0_inferences':result['actual_engineering_inferences'],'model_compute_ms':result['compute_ms'],'physics_or_qualified_SFR':0}
    (a.out/'FIGURE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))


if __name__=='__main__':main()
