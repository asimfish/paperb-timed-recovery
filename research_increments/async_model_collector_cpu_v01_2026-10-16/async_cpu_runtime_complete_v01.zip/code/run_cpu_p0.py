"""Single predeclared P0 inference across a real process boundary, CPU fixture.

No simulator is running. Synthetic state ticks and real wall times are separate.
The frozen P0 model is an inaccurate prior engineering checkpoint, not a VLA.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.util
import io
import json
import multiprocessing as mp
import os
from pathlib import Path
import time
import traceback

from cpu_channel import CPUFIFO
from p0_worker import worker_main, canonical

ROOT = Path(__file__).resolve().parents[1]
SHA = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--bridge", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--fixture-worker", action="store_true", help="Pre-model IPC/queue wiring fixture, no neural inference")
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    pins = json.loads((ROOT / "INPUT_PINS.json").read_text())["inputs"]
    for name, pin in pins.items():
        file = ROOT / "inputs" / name
        if SHA(file) != pin["sha256"] or file.stat().st_size != pin["bytes"]:
            raise ValueError("ROOT_FROZEN_INPUT_CHANGED:" + name)
    spec = importlib.util.spec_from_file_location("runtime_bridge", args.bridge)
    bridge_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bridge_module)
    import numpy as np

    # Build public inputs from one fixed prior episode sample. Never send actions,
    # future APPLIED timestamps, outcome labels, or data-derived target masks.
    with np.load(ROOT / "inputs/p0_dataset.npz", allow_pickle=False) as data:
        image = data["images"][0].copy()
        proprio = data["proprio"][0].copy()
        offsets = data["nominal_offsets"][0].copy()
    buffer = io.BytesIO()
    np.savez(buffer, image=image, proprio=proprio, nominal_offsets=offsets,
             mask=np.ones(8, dtype=np.bool_))
    public_input = buffer.getvalue()
    (out / "PUBLIC_MODEL_INPUT.npz").write_bytes(public_input)
    header = bridge_module.fixture_header()
    header["attempt_id"] = "cpu-p0-cross-process-v1"
    header["failure_root_id"] = "cpu-runtime-only-no-scientific-attempt"
    header["native_epoch"] = "CPU_SYNTHETIC_CLOCK_NOT_ISAAC"
    header["original_deadline_ns"] = 200_000_000
    header["graph_id"] = "transport-fixture-no-chemical-task"
    selected_worker_file = ROOT / ("code/fixture_worker.py" if args.fixture_worker else "code/p0_worker.py")
    header["source_pins"] = {
        "bridge": SHA(args.bridge), "owner_runtime": SHA(__file__),
        "worker": SHA(selected_worker_file),
        "cpu_channel": SHA(ROOT / "code/cpu_channel.py"),
        "prospective_contract": SHA(ROOT / "PROSPECTIVE_RUNTIME_CONTRACT.json"),
        "p0_model": SHA(ROOT / "inputs/p0_model.py"),
        "p0_checkpoint": SHA(ROOT / "inputs/p0_checkpoint.pt")}
    header["channel"]["source_sha256"] = header["source_pins"]["cpu_channel"]
    header["guard_source_sha256"] = header["source_pins"]["bridge"]
    header["clock_mapping_sha256"] = header["source_pins"]["bridge"]
    header["collector_source_sha256"] = header["source_pins"]["owner_runtime"]
    for actor in header["actors"]:
        if actor["role"] == "STUDENT":
            actor["weights_sha256"] = hashlib.sha256(b"CONSTANT_CPU_FIXTURE_NO_WEIGHTS").hexdigest() if args.fixture_worker else header["source_pins"]["p0_checkpoint"]
            actor["actor_source_sha256"] = header["source_pins"]["p0_model"]
            actor["input_adapter_sha256"] = header["source_pins"]["worker"]
    # This externally saved full header, rather than the journal's own header,
    # is the reader's independent case input.
    (out / "EXPECTED_HEADER.json").write_bytes(canonical(header) + b"\n")
    initial_bridge_sha = SHA(args.bridge)
    channel = CPUFIFO()
    owner = bridge_module.AsyncBridge(out / "ASYNC_JOURNAL.jsonl", header,
                                     expected_header=json.loads(canonical(header)))
    ctx = mp.get_context("spawn")
    parent, child = ctx.Pipe(duplex=True)
    if args.fixture_worker:
        from fixture_worker import worker_main as selected_worker
    else:
        selected_worker = worker_main
    process = ctx.Process(target=selected_worker, args=(child, str(ROOT)), name="paperb-owned-cpu-worker")
    raw = (out / "RAW_PROCESS_CHANNEL.jsonl").open("xb", buffering=0)
    ticks = []
    returned = None
    failure = None
    start_event = None
    submission_events = []
    acknowledgments = []
    inference_request_sent = False

    def retain(kind, body):
        row = {"kind": kind, "wall_ns": time.monotonic_ns(), "body": body}
        payload = canonical(row) + b"\n"
        if raw.write(payload) != len(payload):
            raise OSError("RAW short write")
        raw.flush()
        os.fsync(raw.fileno())
        return row

    def message(timeout):
        if not parent.poll(timeout):
            raise TimeoutError("OWNED_WORKER_MESSAGE_TIMEOUT")
        data = json.loads(parent.recv_bytes(2 * 1024 * 1024))
        retain("WORKER_MESSAGE", data)
        if data.get("kind") == "ERROR":
            raise RuntimeError("WORKER:" + data["message"])
        return data

    wall_begin = time.monotonic_ns()
    try:
        process.start()
        child.close()
        ready = message(30)
        if ready["kind"] != "READY" or ready["cuda_initialized"]:
            raise ValueError("CPU_WORKER_READY_REQUIRED")
        state = bridge_module.fixture_state(header, 0)
        owner.observe_state(state, wall_ns=time.monotonic_ns())
        owner.publish_packet("public-p0-input-0", public_input, wall_ns=time.monotonic_ns())
        start_event = owner.start_inference("p0-ticket-0", actor_id="student",
            actual_input_bytes=public_input, desired_ticks=[50,60,70,80,90,100,110,120],
            declared_end_tick=121, purpose="ORIGINAL_GOAL", wall_ns=time.monotonic_ns())
        snapshot = start_event["body"]["snapshot"]
        frozen = base64.b64decode(snapshot["input_bytes_b64"], validate=True)
        if frozen != public_input:
            raise ValueError("MODEL_INPUT_DIFFERS_FROM_START_PACKET")
        request = {"kind": "INFER_ONCE", "ticket_id": "p0-ticket-0",
                   "snapshot_sha256": start_event["body"]["snapshot_sha256"],
                   "input_sha256": snapshot["input_sha256"],
                   "input_base64": base64.b64encode(frozen).decode("ascii")}
        retain("WORKER_DISPATCH", {k: v for k, v in request.items() if k != "input_base64"})
        parent.send_bytes(canonical(request))
        inference_request_sent = True
        run_begin = time.monotonic()
        for tick in range(1, 122):
            if time.monotonic() - run_begin > 30:
                raise TimeoutError("OWNER_RUNTIME_WALL_CAP")
            state = bridge_module.fixture_state(header, tick)
            wall_ns = time.monotonic_ns()
            owner.observe_state(state, wall_ns=wall_ns)
            ticks.append({"tick": tick, "owner_wall_ns": wall_ns})
            # Owner-supplied current state advances independently of worker IPC.
            while returned is None and parent.poll():
                packet = message(0)
                if packet["kind"] == "RECEIVED":
                    if packet["actual_input_sha256"] != snapshot["input_sha256"]:
                        raise ValueError("WORKER_CONSUMED_DIFFERENT_INPUT")
                elif packet["kind"] == "RETURN":
                    if returned is not None:
                        raise ValueError("DUPLICATE_WORKER_RETURN")
                    returned = packet
                    if packet["input_sha256"] != snapshot["input_sha256"]:
                        raise ValueError("RETURN_INPUT_DIGEST_MISMATCH")
                    owner.accept_return("p0-ticket-0", snapshot_sha256=packet["snapshot_sha256"],
                        output_8x9=packet["output_8x9"], current_state_id=state["state_id"],
                        wall_ns=time.monotonic_ns())
                    for slot in range(8):
                        queue = owner.queue_snapshot()
                        prepared = owner.prepare_slot("p0-ticket-0", slot,
                            current_state_id=state["state_id"], queue_sha256=queue["sha256"],
                            purpose="ORIGINAL_GOAL")
                        event = owner.commit_slot(prepared, current_state_id=state["state_id"],
                            queue_sha256=queue["sha256"], wall_ns=time.monotonic_ns())
                        submission_events.append(event)
                        if prepared["disposition"] == "SUBMIT":
                            if owner.broken:
                                raise RuntimeError("NEVER_SEND_AFTER_UNCERTAIN_PERSIST")
                            committed = owner.snapshot()["commands"][prepared["command_id"]]
                            retain("CPU_CHANNEL_SEND_AFTER_COMMIT", committed)
                            channel.send(committed)
                else:
                    raise ValueError("UNEXPECTED_WORKER_MESSAGE")
            ack = channel.advance(tick)
            if ack is not None:
                # RAW first: a validator rejection cannot erase a real observation.
                retain("CPU_CHANNEL_RAW_ACK", ack)
                owner.record_channel_result(ack["command_id"], status=ack["status"],
                    current_state_id=state["state_id"], actual_target_9d=ack["actual_target_9d"],
                    claimed_owner=ack["claimed_owner"], wall_ns=time.monotonic_ns())
                acknowledgments.append(ack)
            time.sleep(.001)
        if returned is None:
            # Preserve an incomplete/censored attempt rather than extending ticks.
            retain("NO_RETURN_WITHIN_FIXED_TICK_CASE", {"last_tick": 121})
        owner.close(reason="FIXED_CPU_CASE_END", wall_ns=time.monotonic_ns())
        process.join(timeout=5)
        if process.is_alive():
            raise RuntimeError("OWNED_WORKER_NOT_EXITED_AFTER_RETURN")
        if process.exitcode != 0:
            raise RuntimeError("OWNED_WORKER_NONZERO_EXIT")
        if SHA(args.bridge) != initial_bridge_sha:
            raise ValueError("BRIDGE_SOURCE_CHANGED_DURING_RUNTIME")
        replay = bridge_module.AsyncBridge.replay(out / "ASYNC_JOURNAL.jsonl", expected_header=header)
        if replay.snapshot() != owner.snapshot():
            raise ValueError("PERSISTED_REPLAY_DIFFERS_FROM_ACCEPTED_OWNER")
    except BaseException as exc:
        failure = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        retain("ROOT_RUNTIME_ERROR_RETAINED", failure)
    finally:
        if process.pid is not None:
            if process.is_alive():
                process.terminate()
                process.join(timeout=5)
            if process.is_alive():
                process.kill()
                process.join(timeout=5)
        parent.close()
        raw.close()
    overlap = [] if returned is None else [row for row in ticks if returned["compute_start_ns"] <= row["owner_wall_ns"] <= returned["compute_end_ns"]]
    result = {"schema": "PaperBAsyncP0CrossProcessCPUResult/1",
        "status": "FAIL_RETAINED" if failure else "COMPLETE_CPU_TRANSPORT_CASE",
        "error": failure, "wall_total_s": (time.monotonic_ns() - wall_begin) / 1e9,
        "scope": "SYNTHETIC_CPU_CLOCK_AND_CPU_CHANNEL_NO_PHYSICS_NO_ROBOT_NO_SFR",
        "worker_kind": "CONSTANT_CPU_FIXTURE" if args.fixture_worker else "PRIOR_P0_ENGINEERING_MODEL",
        "inference_request_sent": inference_request_sent,
        "actual_engineering_inferences": 0 if returned is None else returned["actual_engineering_inferences"],
        "compute_ms": None if returned is None else (returned["compute_end_ns"]-returned["compute_start_ns"]) / 1e6,
        "owner_observations_during_actual_model_compute": overlap,
        "overlap_observed": bool(overlap), "synthetic_state_observations": len(ticks),
        "slot_dispositions": [e["body"]["prepared"]["disposition"] for e in submission_events],
        "CPU_channel_acks": len(acknowledgments), "worker_exit_code": process.exitcode,
        "owned_worker_alive_after_cleanup": process.is_alive(),
        "checkpoint_sha256_after": SHA(ROOT / "inputs/p0_checkpoint.pt"),
        "parameter_digest_before": None if returned is None else returned["initial_parameter_digest"],
        "parameter_digest_after": None if returned is None else returned["final_parameter_digest"],
        "public_input_sha256": hashlib.sha256(public_input).hexdigest(),
        "header_sha256": hashlib.sha256(canonical(header)).hexdigest(),
        "bridge_source_sha256": initial_bridge_sha, "new_training_updates": 0,
        "new_native_GPU_hardware_or_chemical_runs": 0, "qualified_S_F_R": 0,
        "main_M_B3": "UNTESTED", "learned_robot_policy_advantage": "NOT_TESTED"}
    (out / "OWNER_TICK_WALL_RECORDS.json").write_bytes(canonical(ticks)+b"\n")
    (out / "RESULT.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result))
    raise SystemExit(1 if failure else 0)


if __name__ == "__main__":
    main()
