"""Deterministic IPC wiring check; no model, Torch, training or simulator."""
import base64
import hashlib
import os
import time
import json
from p0_worker import canonical


def worker_main(connection, root_string):
    try:
        connection.send_bytes(canonical({"kind": "READY", "pid": os.getpid(),
            "checkpoint_sha256": None, "parameter_digest": "FIXTURE_NO_PARAMETERS",
            "torch_version": None, "cuda_initialized": False}))
        request = json.loads(connection.recv_bytes(2*1024*1024))
        raw = base64.b64decode(request["input_base64"], validate=True)
        if hashlib.sha256(raw).hexdigest() != request["input_sha256"]:
            raise ValueError("FIXTURE_INPUT_DIGEST")
        start = time.monotonic_ns()
        connection.send_bytes(canonical({"kind": "RECEIVED", "ticket_id": request["ticket_id"],
            "actual_input_sha256": request["input_sha256"], "wall_ns": start}))
        output = [[(slot*9+axis)/1000 for axis in range(9)] for slot in range(8)]
        end = time.monotonic_ns()
        connection.send_bytes(canonical({"kind": "RETURN", "ticket_id": request["ticket_id"],
            "snapshot_sha256": request["snapshot_sha256"], "input_sha256": request["input_sha256"],
            "output_8x9": output, "output_sha256": hashlib.sha256(canonical(output)).hexdigest(),
            "wall_received_ns": start, "compute_start_ns": start, "compute_end_ns": end,
            "wall_return_send_ns": time.monotonic_ns(),
            "initial_parameter_digest": "FIXTURE_NO_PARAMETERS",
            "final_parameter_digest": "FIXTURE_NO_PARAMETERS", "actual_engineering_inferences": 0,
            "new_training_updates": 0, "model_role": "CONSTANT_CPU_WIRING_FIXTURE",
            "cuda_initialized": False}))
    finally:
        connection.close()
