"""Independent, read-only CPU process/channel evidence reconciliation.

This checker does not import the bridge, its reducer, Torch or a simulator.
It binds inputs and all command handoffs to raw process/channel observations.
"""
import argparse
import base64
import hashlib
import io
import json
from pathlib import Path


def canon(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False, ensure_ascii=True).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument("--case", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    assert not a.output.exists()
    root = a.case
    header = json.loads((root / "EXPECTED_HEADER.json").read_bytes())
    result = json.loads((root / "RESULT.json").read_bytes())
    journal_bytes = (root / "ASYNC_JOURNAL.jsonl").read_bytes()
    raw_bytes = (root / "RAW_PROCESS_CHANNEL.jsonl").read_bytes()
    assert journal_bytes.endswith(b"\n") and raw_bytes.endswith(b"\n")
    events = [json.loads(row) for row in journal_bytes.splitlines()]
    raw = [json.loads(row) for row in raw_bytes.splitlines()]
    prev = "0" * 64
    high = [-1, -1, -1, -1]
    states, packets, starts, returns, commands, acknowledgments = {}, {}, {}, {}, {}, {}
    dispositions = []
    previous_command_ticks = []
    for index, event in enumerate(events):
        unsigned = {k: v for k, v in event.items() if k != "sha256"}
        assert event["schema"] == "AsyncCollectorEvent/0.1"
        assert event["seq"] == index and event["prev_sha256"] == prev
        assert event["sha256"] == sha(canon(unsigned))
        prev = event["sha256"]
        kind, body = event["kind"], event["body"]
        clock = [-1,-1,-1] if event["clock"] is None else event["clock"]
        now = clock + [event["wall_ns"]]
        assert all(n >= o for n, o in zip(now, high))
        high = now
        if kind == "CASE_BEGIN":
            assert index == 0 and body["header"] == header
            assert body["header_sha256"] == sha(canon(header))
        elif kind == "OBSERVED_STATE":
            state = body["state"]
            assert state["state_id"] not in states
            assert [state[k] for k in ("tick", "time_ns", "deadline_time_ns")] == clock
            assert state["attempt_id"] == header["attempt_id"]
            assert state["native_epoch"] == "CPU_SYNTHETIC_CLOCK_NOT_ISAAC"
            states[state["state_id"]] = state
        elif kind == "PUBLIC_PACKET":
            packet_raw = base64.b64decode(body["public_bytes_b64"], validate=True)
            assert sha(packet_raw) == body["sha256"]
            assert body["state_id"] in states and body["packet_id"] not in packets
            packets[body["packet_id"]] = body
        elif kind == "INFERENCE_START":
            snap = body["snapshot"]
            assert body["ticket_id"] not in starts
            assert body["snapshot_sha256"] == sha(canon(snap))
            packet = packets[snap["input_packet_id"]]
            assert snap["input_bytes_b64"] == packet["public_bytes_b64"]
            assert snap["input_sha256"] == packet["sha256"]
            assert snap["input_prefix"]["packet_ids"] == [snap["input_packet_id"]]
            assert snap["input_prefix"]["as_of_time_ns"] == snap["start_state"]["time_ns"]
            assert snap["desired_ticks"] == [50,60,70,80,90,100,110,120]
            assert snap["declared_end_tick"] == 121 and snap["purpose"] == "ORIGINAL_GOAL"
            assert snap["original_contract_sha256"] == sha(canon(header))
            starts[body["ticket_id"]] = event
        elif kind == "INFERENCE_RETURN":
            start = starts[body["ticket_id"]]
            assert body["snapshot_sha256"] == start["body"]["snapshot_sha256"]
            assert body["current_state_id"] in states and body["status"] == "OK"
            assert body["output_sha256"] == sha(canon(body["output_8x9"]))
            assert len(body["output_8x9"]) == 8 and all(len(r) == 9 for r in body["output_8x9"])
            returns[body["ticket_id"]] = event
        elif kind == "SLOT_DISPOSITION":
            prepared = body["prepared"]
            start = starts[prepared["ticket_id"]]
            returned = returns[prepared["ticket_id"]]
            slot = prepared["slot_index"]
            assert prepared["desired_tick"] == start["body"]["snapshot"]["desired_ticks"][slot]
            assert prepared["input_snapshot_sha256"] == start["body"]["snapshot_sha256"]
            assert prepared["return_event_sha256"] == returned["sha256"]
            assert prepared["target_9d"] == returned["body"]["output_8x9"][slot]
            assert prepared["owner"] == start["body"]["snapshot"]["actor"]
            assert prepared["current_state_id"] in states
            assert all(prepared["desired_tick"] != n for n in previous_command_ticks)
            dispositions.append(prepared)
            if prepared["disposition"] == "SUBMIT":
                assert prepared["earliest_apply_tick"] <= prepared["desired_tick"]
                commands[prepared["command_id"]] = event
                previous_command_ticks.append(prepared["desired_tick"])
            else:
                assert prepared["disposition"] in ("STALE", "PADDING", "ACTOR_REVOKED", "GUARD_REJECTED")
        elif kind == "CHANNEL_RESULT":
            assert body["command_id"] in commands
            command = commands[body["command_id"]]["body"]["prepared"]
            state = states[body["current_state_id"]]
            assert body["status"] == "APPLIED" and state["tick"] == command["desired_tick"]
            assert body["claimed_owner"] == command["owner"]
            assert body["actual_target_9d"] == command["target_9d"]
            assert body["command_id"] not in acknowledgments
            acknowledgments[body["command_id"]] = event
        elif kind == "CASE_END":
            assert index == len(events)-1
            assert not body["censored"]["pending_commands"]
            assert not body["censored"]["unreturned_tickets"]
            assert not body["censored"]["unresolved_slots"]
        else:
            raise AssertionError("Unexpected event for this narrow process fixture: " + kind)
    assert len(starts) == len(returns) == 1
    assert sorted(p["slot_index"] for p in dispositions) == list(range(8))
    assert set(commands) == set(acknowledgments)
    messages = [r for r in raw if r["kind"] == "WORKER_MESSAGE"]
    worker_return = [r for r in messages if r["body"]["kind"] == "RETURN"]
    assert len(worker_return) == 1
    worker = worker_return[0]["body"]
    start = next(iter(starts.values()))
    returned = next(iter(returns.values()))
    assert worker["snapshot_sha256"] == start["body"]["snapshot_sha256"]
    assert worker["input_sha256"] == start["body"]["snapshot"]["input_sha256"]
    assert worker["output_8x9"] == returned["body"]["output_8x9"]
    assert worker["initial_parameter_digest"] == worker["final_parameter_digest"]
    sends = [r for r in raw if r["kind"] == "CPU_CHANNEL_SEND_AFTER_COMMIT"]
    raw_acks = [r for r in raw if r["kind"] == "CPU_CHANNEL_RAW_ACK"]
    assert [r["body"]["command_id"] for r in sends] == list(commands)
    assert [r["body"]["command_id"] for r in raw_acks] == list(acknowledgments)
    for row in sends:
        assert row["wall_ns"] >= commands[row["body"]["command_id"]]["wall_ns"]
    for row in raw_acks:
        assert row["wall_ns"] <= acknowledgments[row["body"]["command_id"]]["wall_ns"]
        assert row["body"]["source"] == "CPU_FIFO_FIXTURE_NO_PHYSICAL_ACTUATION"
    assert result["error"] is None and not result["owned_worker_alive_after_cleanup"]
    assert result["new_native_GPU_hardware_or_chemical_runs"] == result["qualified_S_F_R"] == 0
    public_raw = (root / "PUBLIC_MODEL_INPUT.npz").read_bytes()
    assert sha(public_raw) == result["public_input_sha256"] == worker["input_sha256"]
    # No neural import: inspect only the bounded numeric public input container.
    import numpy as np
    with np.load(io.BytesIO(public_raw), allow_pickle=False) as bundle:
        assert set(bundle.files) == {"image", "proprio", "nominal_offsets", "mask"}
        assert bundle["image"].shape == (3,40,64) and bundle["proprio"].shape == (18,)
    checks = {"external_header_and_chain": True, "actual_start_bytes_match_delivered_packet_and_worker": True,
        "no_future_targets_in_public_tensor_bundle": True, "original_slot_indices_times_and_actor_retained": True,
        "durable_intents_precede_raw_CPU_sends": True, "raw_CPU_ack_retained_before_qualification": True,
        "worker_output_matches_every_command_row": True, "FIFO_complete_owner_target_readback": True,
        "no_parameter_updates_or_native_claim": True, "owned_worker_cleanup": True}
    verdict = {"schema": "RootIndependentAsyncRuntimeEvidence/1", "status": "PASS_NARROW_CPU_PROCESS_AND_QUEUE_EVIDENCE",
        "case": str(root), "journal_sha256": sha(journal_bytes), "raw_sha256": sha(raw_bytes),
        "events": len(events), "CPU_channel_commands": len(commands), "checks": checks,
        "actual_engineering_inferences": result["actual_engineering_inferences"],
        "overlap_observed": result["overlap_observed"], "new_native_or_training": 0,
        "qualification": "CPU_TRANSPORT_ONLY_MAIN_M_B3_UNTESTED_SFR0"}
    a.output.write_text(json.dumps(verdict, indent=2)+"\n")
    print(json.dumps(verdict))


if __name__ == "__main__":
    main()
