"""Explicit CPU FIFO fixture. It has no robot, physics or device interface."""
import copy


class CPUFIFO:
    def __init__(self):
        self.pending = []
        self.seen = set()
        self.last_tick = -1

    def send(self, committed_command):
        command = copy.deepcopy(committed_command)
        cid = command["command_id"]
        if cid in self.seen:
            raise ValueError("CPU_CHANNEL_DUPLICATE_ID_NO_RESEND")
        if command["status"] != "SUBMITTED":
            raise ValueError("CPU_CHANNEL_REQUIRES_COMMITTED_INTENT")
        if self.pending and command["desired_tick"] <= self.pending[-1]["desired_tick"]:
            raise ValueError("CPU_CHANNEL_FIFO_DESIRED_TICKS_REQUIRED")
        self.seen.add(cid)
        self.pending.append(command)

    def advance(self, tick):
        if type(tick) is not int or tick <= self.last_tick:
            raise ValueError("CPU_CHANNEL_MONOTONIC_TICK_REQUIRED")
        self.last_tick = tick
        if not self.pending or self.pending[0]["desired_tick"] > tick:
            return None
        cmd = self.pending.pop(0)
        # Any off-schedule observation remains raw before validator admission.
        return {"command_id": cmd["command_id"], "status": "APPLIED",
                "actual_target_9d": cmd["target_9d"], "claimed_owner": cmd["owner"],
                "tick": tick, "desired_tick": cmd["desired_tick"],
                "source": "CPU_FIFO_FIXTURE_NO_PHYSICAL_ACTUATION"}
