"""Pure draft roster/admission checks; no native epochs or MuJoCo import."""
import ast
import copy
import json
from pathlib import Path
import tempfile
import sys
import unittest
from unittest.mock import patch
import paired_driver as d


class DraftTests(unittest.TestCase):
    def test_fixed32_order_unique_case_and_epoch(self):
        rows=d.roster();self.assertEqual(len(rows),32);self.assertEqual(len({r['id'] for r in rows}),32);self.assertEqual(len({r['public_epoch'] for r in rows}),32)
        self.assertEqual([r['order'] for r in rows],list(range(32)))
        for i in range(8):self.assertEqual([r['method'] for r in rows[i*4:i*4+4]],list(d.METHODS))
        self.assertTrue(all(r['epoch']==0 and r['private_fault_driver_only']=='first_A_stop_drop' for r in rows))

    def test_same_spec_and_legal_public_inputs_all32(self):
        specs=[]
        for row in d.roster():
            p=d.case_spec(row);actor=d.actor_for(row,p)
            self.assertEqual(actor.method,row['method']);self.assertEqual(p['private_plant'],{'inertia':.002,'damping':.006,'fault':'first_A_stop_drop'})
            self.assertNotIn('private_plant',actor.contract.public);self.assertEqual(actor.contract.charged_decision_ns,20_000_000)
            self.assertEqual(actor.contract.public['max_requests_A_C'],4);self.assertEqual(actor.contract.public['maximum_candidates_epoch'],10000)
            specs.append(p)
        for i in range(8):
            values=specs[i*4:i*4+4]
            self.assertTrue(all(v['public']==values[0]['public'] and v['resource']==values[0]['resource'] and v['initial_state']==values[0]['initial_state'] for v in values))

    def test_arbitrary_new_row_rejected(self):
        row=copy.deepcopy(d.roster()[0]);row['method']='made_up';row['private_fault_driver_only']='none'
        with self.assertRaises(ValueError):d.case_spec(row)

    def test_draft_forbids_frozen_source_or_gate_substitution(self):
        if (d.ROOT/'SOURCE_RELEASE.json').exists():d.verify_frozen_sources()
        else:
            with self.assertRaises(ValueError):d.verify_frozen_sources()
        draft=d.base.read_json(d.ROOT/'PROTOCOL_DRAFT.json')
        with self.assertRaises(ValueError):d.validate_gates(draft,{}, {}, {}, 'a'*64,'c'*64)
        self.assertFalse((d.ROOT/'native_cases').exists())

    def future_gate(self):
        p={'status':'FROZEN_AFTER_SINGLE_INDEPENDENT_RAW_ACCEPTANCE','single_independent_raw_receipt_sha256':'c'*64,'single_independent_full_audit_artifact_sha256':'d'*64}
        single={'status':'PASS_SINGLE_STATEFUL_NATIVE_RECORDED_RAW','source_bridge_release_sha256':d.SINGLE_BRIDGE_SHA,'cpu_source_pin_sha256':d.CPU_SHA,
            'case_id':'v2_diag-A_then_C-B45-D2p8','method':'guarded_hsm_retry','controlled_native_episode_count':1,
            'complete_recorded_raw_pass':True,'independent_commands_clocks_events_pass':True,'independent_full_audit_artifact_sha256':'d'*64}
        review={'status':'PASS_PAIRED32_NATIVE_SOURCE_REVIEW','paired32_source_release_sha256':'a'*64,'single_raw_receipt_sha256':'c'*64,'single_independent_full_audit_artifact_sha256':'d'*64}
        admission={'schema':'paperb-stateful-paired32-root-admission-v1','approved':True,'paired32_source_release_sha256':'a'*64,'cpu_source_pin_sha256':d.CPU_SHA,
            'maximum_controlled_native_epochs':32,'GPU':0,'formal_statistical_trials':0,'heldout':False,'single_raw_receipt_sha256':'c'*64}
        return p,single,review,admission,'a'*64,'c'*64

    def test_future_gates_reject_recording_or_actor_pass_as_independent_RAW(self):
        values=self.future_gate();d.validate_gates(*values)
        for key,bad in [('status','RECORDED_NATIVE_DEVELOPMENT_PENDING_INDEPENDENT_RAW_ACCEPTANCE'),('complete_recorded_raw_pass',False),('controlled_native_episode_count',0),('cpu_source_pin_sha256','b'*64),('case_id','different')]:
            args=list(copy.deepcopy(values));args[1][key]=bad
            with self.assertRaises(ValueError):d.validate_gates(*args)

    def test_future_gates_reject_missing_review_wrong_source_or_over_budget(self):
        values=self.future_gate()
        for index,key,bad in [(2,'status','PENDING'),(2,'paired32_source_release_sha256','b'*64),(3,'maximum_controlled_native_epochs',33),(3,'GPU',1),(3,'heldout',True),(3,'approved',False)]:
            args=list(copy.deepcopy(values));args[index][key]=bad
            with self.assertRaises(ValueError):d.validate_gates(*args)

    def test_original_native_and_public_dependencies_exact(self):
        self.assertEqual(d.base.verify_sources()[0],d.SINGLE_BRIDGE_SHA)

    def test_actual_single_prerequisite_matches_complete_independent_audit(self):
        root=d.ROOT/'single_prerequisite';receipt=d.base.read_json(root/'PUBLIC_SINGLE_RAW_RECEIPT.json')
        full=root/receipt['independent_full_audit_artifact'];audit=d.base.read_json(full);p=d.draft_protocol()
        self.assertEqual(d.base.sha(full),receipt['independent_full_audit_artifact_sha256']);self.assertEqual(audit['status'],'PASS_NATIVE_DEVELOPMENT_RAW_AUDIT')
        self.assertEqual(audit['RAW_integrity'],'PASS');self.assertEqual(audit['independent_task_verdict'],'TRUE')
        self.assertEqual(audit['primary_controlled_native_episodes'],1);self.assertEqual(audit['diagnostic_reintegration_epochs'],1)
        self.assertEqual(p['single_independent_raw_receipt_sha256'],d.base.sha(root/'PUBLIC_SINGLE_RAW_RECEIPT.json'))
        self.assertEqual(p['single_independent_full_audit_artifact_sha256'],d.base.sha(full))

    def test_setup_constructor_failure_has_claim_and_terminal_no_native(self):
        before='mujoco' in sys.modules
        with tempfile.TemporaryDirectory() as temp:
            out=Path(temp)/'CPU_ONLY_NEGATIVE_SETUP'
            with patch.object(d,'actor_for',side_effect=ValueError('CPU_ONLY_FAKE_ACTOR_SETUP_FAILURE')):
                result=d._run_case(out,d.roster()[0],'a'*64,{'role':'CPU_ONLY_FAKE_PROOFS_NOT_NATIVE_ADMISSION'})
            self.assertTrue((out/'CASE_CLAIM.json').exists());self.assertTrue((out/'TERMINAL.json').exists())
            self.assertEqual(result['status'],'FAILED_ATTEMPT_RETAINED');self.assertFalse(result['controlled_epoch_created']);self.assertEqual(result['native_steps'],0)
            self.assertEqual(d.base.read_json(out/'raw_verdict.json')['joint'],'UNKNOWN')
        self.assertEqual('mujoco' in sys.modules,before)

    def test_resume_rejects_foreign_source_or_prerequisites_before_new_case(self):
        h='a'*64;proofs={'role':'CPU_ONLY_FAKE_PROOFS_NOT_NATIVE_ADMISSION'};row=d.roster()[0]
        with tempfile.TemporaryDirectory() as temp:
            out=Path(temp);d.base.write_json(out/'MATRIX_CLAIM.json',d.matrix_claim(h,proofs))
            case=out/row['id'];case.mkdir()
            d.base.write_json(case/'CASE_CLAIM.json',{'fixed_roster_row':row,'source_release_sha256':h,'admission_proofs':proofs,'maximum_epochs_here':1})
            d.base.write_json(case/'TERMINAL.json',{'roster_row':row,'source_release_sha256':h,'admission_proofs':proofs})
            d.validate_resume(out,h,proofs)
            with self.assertRaises(ValueError):d.validate_resume(out,'b'*64,proofs)
            with self.assertRaises(ValueError):d.validate_resume(out,h,{'role':'DIFFERENT_CPU_FAKE_PROOFS'})
            terminal=d.base.read_json(case/'TERMINAL.json');terminal['source_release_sha256']='b'*64
            (case/'TERMINAL.json').write_text(json.dumps(terminal))
            with self.assertRaises(ValueError):d.validate_resume(out,h,proofs)
            self.assertEqual(len([p for p in out.iterdir() if p.is_dir()]),1)

    def test_protocol_review_and_root_must_share_single_actual_audit_hashes(self):
        values=self.future_gate()
        for index,key,bad in [(0,'single_independent_raw_receipt_sha256','b'*64),(0,'single_independent_full_audit_artifact_sha256',None),(1,'independent_full_audit_artifact_sha256','wrong'),(2,'single_raw_receipt_sha256','b'*64),(2,'single_independent_full_audit_artifact_sha256','b'*64),(3,'single_raw_receipt_sha256','b'*64)]:
            args=list(copy.deepcopy(values));args[index][key]=bad
            with self.assertRaises(ValueError):d.validate_gates(*args)

    def test_native_imports_and_epoch_creation_only_in_admitted_worker(self):
        tree=ast.parse((d.ROOT/'code/paired_driver.py').read_text())
        for n in tree.body:
            if isinstance(n,ast.Import):self.assertNotIn('mujoco',[a.name for a in n.names])
            if isinstance(n,ast.FunctionDef) and n.name!='_run_case':
                for a in ast.walk(n):
                    if isinstance(a,ast.Call) and isinstance(a.func,ast.Attribute):self.assertNotIn(a.func.attr,('mj_step','mj_forward'))
        text=(d.ROOT/'code/paired_driver.py').read_text();self.assertEqual(text.count('model,data=create('),1)


if __name__=='__main__':unittest.main()
