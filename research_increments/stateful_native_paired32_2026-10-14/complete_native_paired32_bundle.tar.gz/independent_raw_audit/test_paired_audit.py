"""Focused32 metadata/causal gates. No native engine imported or actor executed."""
import copy
from itertools import product
import json
from pathlib import Path
import sys
import tempfile
import unittest

import audit_paired32 as a
from event_referee import first_confirmed_stop,joint,score_interval,service_capacity


def matrix_fixture():
    roster=[];receipts=[]
    for c in range(8):
        for method in a.METHODS:
            cid=str(c)+"/"+method;roster.append({"id":cid,"method":method})
            receipts.append({"case_id":cid,"method":method,"independent_task_verdict":"TRUE","RAW_integrity":"PASS",
                "status":"PASS_PAIRED_CASE_RAW_AUDIT","controlled_epoch_started":True,"diagnostic_reintegration_epochs":1})
    return roster,receipts


class PairedAuditCPU(unittest.TestCase):
    def test_no_native_or_producer_import(self):
        self.assertNotIn("mujoco",sys.modules);self.assertNotIn("paired_driver",sys.modules);self.assertNotIn("stateful_controllers",sys.modules)

    def test_all32_scope_and_diagnostics_separate(self):
        rows,receipts=matrix_fixture();s=a.aggregate(receipts,rows)
        self.assertEqual(s["planned_denominator"],32);self.assertEqual(s["diagnostic_reintegration_epochs"],32)
        self.assertEqual(s["T_F_U"],{"TRUE":32,"FALSE":0,"UNKNOWN":0})
        self.assertTrue(all(r["denominator"]==8 for r in s["by_method"].values()))

    def test_unknown_missing_and_definite_false_kept_all32(self):
        rows,receipts=matrix_fixture();receipts[0].update(independent_task_verdict="UNKNOWN",RAW_integrity="UNKNOWN",status="UNRESOLVED_ATTEMPT_RETAINED",controlled_epoch_started=None,diagnostic_reintegration_epochs=0)
        receipts[1]["independent_task_verdict"]="FALSE"
        s=a.aggregate(receipts,rows)
        self.assertEqual(s["planned_denominator"],32);self.assertEqual(s["T_F_U"],{"TRUE":30,"FALSE":1,"UNKNOWN":1})
        self.assertEqual(s["controlled_epoch_started_UNKNOWN"],1)

    def test_31case_subset_duplicate_or_relabelled_arm_rejected(self):
        rows,receipts=matrix_fixture()
        with self.assertRaises(ValueError):a.aggregate(receipts[:-1],rows)
        bad=copy.deepcopy(receipts);bad[1]["case_id"]=bad[0]["case_id"]
        with self.assertRaises(ValueError):a.aggregate(bad,rows)
        bad=copy.deepcopy(receipts);bad[0]["method"],bad[1]["method"]=bad[1]["method"],bad[0]["method"]
        with self.assertRaises(ValueError):a.aggregate(bad,rows)

    def test_claim_source_proofs_roster_bound(self):
        rows,_=matrix_fixture();proofs={"root":"r"};claim={"schema":"paperb-paired32-matrix-claim-v1","source_release_sha256":"s","admission_proofs":proofs,"fixed_roster":rows,"maximum_controlled_epochs":32}
        a.check_matrix_claim(claim,rows,"s",proofs)
        for field,value in (("source_release_sha256","foreign"),("maximum_controlled_epochs",33),("admission_proofs",{})):
            bad=copy.deepcopy(claim);bad[field]=value
            with self.assertRaises(ValueError):a.check_matrix_claim(bad,rows,"s",proofs)

    def test_required17_hash_and_missing_member(self):
        with tempfile.TemporaryDirectory(dir=a.HERE) as t:
            out=Path(t);required=["f"+str(i)+".json" for i in range(16)]+["ARTIFACT_MANIFEST.json"]
            for n in required[:-1]:(out/n).write_text("{}")
            (out/"ARTIFACT_MANIFEST.json").write_text(json.dumps({"files":{n:a.sha(out/n) for n in required[:-1]},"source_release_sha256":"s"}))
            self.assertEqual(len(a.check_case_artifacts(out,required,"s")),17)
            (out/required[0]).unlink()
            with self.assertRaises(ValueError):a.check_case_artifacts(out,required,"s")

    def test_all27_truth_vectors_and_interval_unknown(self):
        for v in product(("TRUE","FALSE","UNKNOWN"),repeat=3):
            self.assertEqual(joint(list(v)),"FALSE" if "FALSE" in v else "UNKNOWN" if "UNKNOWN" in v else "TRUE")
        self.assertEqual(score_interval([100,110],{"interval_ns":[200,210],"confirmation_ns":410},[95,105])["verdict"],"UNKNOWN")

    def test_original_onset_distinct_21points_and_no_sample_gap(self):
        raw=[{"sim_ns":0,"A_v":1.}]+[{"sim_ns":i*10_000_000,"A_v":0.} for i in range(1,22)]
        self.assertIsNone(first_confirmed_stop(raw[:-1],"A",.1,200_000_000,10_000_000))
        event=first_confirmed_stop(raw,"A",.1,200_000_000,10_000_000)
        self.assertEqual(event["interval_ns"],[0,10_000_000]);self.assertEqual(event["confirmation_ns"],210_000_000);self.assertEqual(event["confirmation_positive_samples"],21)
        self.assertIsNone(first_confirmed_stop(raw[:10]+raw[11:],"A",.1,200_000_000,10_000_000))

    def test_resource_service_not_effect_or_budget_refund(self):
        self.assertEqual(a.core.service_slot(690_000_000,450_000_000,[{"service_start_ns":650_000_000,"ack_ns":1_100_000_000}]),(1_100_000_000,1_550_000_000))
        self.assertFalse(service_capacity([{"seq":0,"service_start_ns":0,"ack_ns":20},{"seq":1,"service_start_ns":10,"ack_ns":30}]))

    def test_byte_exact_single_function_origin_and_all67_inputs(self):
        pin,root,p,rows,source=a.verify_inputs()
        self.assertEqual(pin["producer_release_sha256"],"171b6e1154341261b5437fc752f72bcbb0267ee236b344badc3f2fc189f692fd")
        self.assertEqual(len(pin["producer_files"]),67);self.assertEqual(len(rows),32)
        self.assertFalse((root/"native_cases").exists())
        origin=json.loads((a.HERE/"SOURCE_ORIGIN.json").read_text())
        for n,h in origin["byte_exact_copies"].items():self.assertEqual(a.sha(a.HERE/n),h)

    def test_paired_setup_no_fabricated_numeric_nq_readback(self):
        pin,_,_,rows,source=a.verify_inputs();row=rows[0];spec=a.case_spec(source,row);p=a.case_protocol(spec,row);I=spec["private_plant"]["inertia"]
        setup={"spec_driver_only":spec,"public_contract":{"epoch":row["public_epoch"],"dt_ns":p["dt_ns"],"charged_decision_ns":p["paid_decision_ns"],
            "sensor_period_ns":p["sensor_period_ns"],"sensor_lag_ns":p["sensor_lag_ns"],"public_json":json.dumps(spec["public"]),"resource_json":json.dumps(spec["resource"])},
            "active_model_readback":{"dt_s":.01,"dof_damping":[.006]*3,"body_inertia":[[0.,0.,0.]]+[[I/2,I/2,I]]*3,
                "initial_qpos":[0,0,0],"initial_qvel":[0,0,0],"initial_ctrl":[.06]*3},
            "source_release_sha256":pin["producer_release_sha256"],"parent_cpu_sha256":pin["public30_sha256"],"source_single_bridge_sha256":pin["single_bridge_sha256"],"private_fields_given_to_actor":False,"host_computation_steps_physics":False}
        a.check_setup32(setup,spec,row,p,pin)
        self.assertNotIn("nq",setup["active_model_readback"])
        setup["active_model_readback"]["dof_damping"][0]=.007
        with self.assertRaises(ValueError):a.check_setup32(setup,spec,row,p,pin)


if __name__=="__main__":unittest.main(verbosity=2)
