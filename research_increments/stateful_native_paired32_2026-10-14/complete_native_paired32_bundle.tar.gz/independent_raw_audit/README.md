# Prospective independent paired32 RAW audit

This wrapper binds the fixed67 producer release and copied single independent event/causality/ledger/reintegration implementation before any paired execution. `single_core.py` and `event_referee.py` are byte-exact copies of the prospectively frozen single auditor, whose actual full RAW receipt is a producer prerequisite. It imports no actor/producer or native engine during preparation and does not modify old single9, VerifiedReplay19, parent30/bridge8 or the sealed604 increment.

All32 attempted roster slots remain in denominator32 and each arm in denominator8, including missing, unstarted, failed, refused or uncertain data. A complete case has17 required artifacts, 1201 RAW, 1200 native steps,241 captures,239 delivered packets and1201 public actor frames. Artifact manifest cannot self-hash; its external digest is stored. Matrix/case claims, terminal snapshots and root proofs must bind the same fixed row, source and admitted prerequisites. Each case's events use its unique public epoch namespace even though local native RAW epoch is0. No cross-case timestamp arithmetic is permitted.

Actual public captures are pre-ACK at the same tick. Packet/ACK/reservation histories are independently matched to RAW/native time; explicit private fields cannot enter actor frames. Two virtual20ms charged ticks preserve native step continuity; host time is measured separately. Physical ACK/drop/recovery, first B crossing, onset versus200ms/21point stop confirmation, sampled B motion/control, dependency graph, nonpreemptive resource capacity and cumulative budgets are recomputed without actor success flags. A public Fraction recurrence refines the same coarse B event from delivered q/v/torque and the unchanged public model; it is not private truth or support coverage.

`SETUP.json` in paired32 uses `spec_driver_only`/`active_model_readback` and does not export numeric nq/nv/nu getters. The auditor verifies actual dt/damping/inertia/initial arrays and separately states the dimension basis: frozen driver guard,3-axis RAW and independent replay. It never manufactures getter values. `RAW_SCHEMA.partial_exception` contains an inherited `NATIVE_DEV_RESULT.json` name; frozen paired code and per-case protocol actually write `TERMINAL.json`. That metadata erratum is preserved and disclosed, with no source change.

After all matrix work is terminal or retained, root supplies a JSON notification with:

```json
{
  "root_completed_matrix_terminal_or_retained": true,
  "producer_release_sha256": "171b6e1154341261b5437fc752f72bcbb0267ee236b344badc3f2fc189f692fd",
  "auditor_release_sha256": "<this AUDITOR_RELEASE SHA>",
  "matrix_snapshot_relative_path": "MATRIX_SNAPSHOT_<actual>.json",
  "matrix_snapshot_sha256": "<actual snapshot SHA>",
  "admission_proofs": {
    "single_raw_receipt_sha256": "<exact matrix claim proof>",
    "source_review_receipt_sha256": "<exact matrix claim proof>",
    "root_admission_sha256": "<exact matrix claim proof>"
  }
}
```

Use the same MuJoCo version as recorded setup, then run:

```sh
/usr/bin/python3 -B audit_paired32.py --verify-only
/usr/bin/python3 -B audit_paired32.py --root-result-notification /absolute/root/terminal_matrix_notification.json
```

The result is write-once `PAIRED_RAW_AUDIT.json`, with per-case receipts in `case_audits/` and a precreation diagnostic claim for each eligible command replay. Each complete case allows at most one new diagnostic epoch; up to32 diagnostics are separately counted, never added to primary32. Partial/invalid cases do not run a replay. Existing diagnostic claims forbid repeated physics. Source or root matrix/proof mismatch aborts before diagnostic epochs; case-level errors stay in32.

CPU preflight is `/usr/bin/python3 -B -m unittest test_paired_audit -v`. Its source test is prospective and asserts native_cases absent; it is not a later result rerun. Preparation is metadata/negative testing only. Actual task T/F/U is distinct from structural RAW integrity and full replay acceptance. Multiple contracts are not separate episodes. The eight configurations are already seen; all methods share the original known model and first-A-drop plant. D also changes A's upper window, so this is not a C-deadline-only causal intervention. No IID/significance, heldout, agentic necessity, original robot, RGB, chemical endpoint, GPU, fit or learned-weight claim is supported.
