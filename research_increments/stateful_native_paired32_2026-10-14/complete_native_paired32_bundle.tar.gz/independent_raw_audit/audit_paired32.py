"""Fixed32 independent RAW audit. No actor/producer/original-referee execution."""
import argparse
from collections import Counter
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path

import single_core as core
from event_referee import evaluate

HERE=Path(__file__).resolve().parent
METHODS=("strong_batch","guarded_hsm_retry","event_resource_edf","joint_interval_mpc")


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def js(p):return json.loads(Path(p).read_text())
def write_once(p,value):
    with p.open("x") as f:json.dump(value,f,indent=2,sort_keys=True,allow_nan=False);f.write("\n")


def verify_inputs():
    pin=js(HERE/"INPUT_PIN.json");root=Path(pin["root"])
    core.check(sha(root/"SOURCE_RELEASE.json")==pin["producer_release_sha256"],"PAIRED67_RELEASE_CHANGED")
    for n,h in pin["producer_files"].items():core.check(not(root/n).is_symlink() and sha(root/n)==h,"PAIRED67_SOURCE_CHANGED:"+n)
    if (HERE/"AUDITOR_RELEASE.json").exists():
        for n,h in js(HERE/"AUDITOR_RELEASE.json")["files"].items():core.check(sha(HERE/n)==h,"PAIRED_AUDITOR_CHANGED:"+n)
    protocol=js(root/"PROTOCOL.json");roster=js(root/"ROSTER.json")["rows"]
    core.check(protocol["status"]=="FROZEN_AFTER_SINGLE_INDEPENDENT_RAW_ACCEPTANCE","PROTOCOL_NOT_FROZEN")
    source=js(root/"dependency_snapshot/public_component/source_inputs/scenario_PROTOCOL_V2.json")
    expected=[]
    for case in source["cases"]:
        for method in METHODS:
            order=len(expected)
            expected.append({"order":order,"id":"paired32-"+case["id"]+"__"+method,"source_case_id":case["id"],"method":method,"case":case,
                "epoch":0,"public_epoch":"paired32-"+str(order)+"-epoch0","private_fault_driver_only":"first_A_stop_drop","role":"DEVELOPMENT_SEEN_PAIRED_MECHANISM_VALIDATION_NOT_HELDOUT"})
    core.check(roster==expected and len(roster)==32,"FIXED8_BY4_ROSTER_CHANGED")
    core.check(protocol["single_independent_full_audit_artifact_sha256"]==pin["single_full_audit_sha256"],"SINGLE_INDEPENDENT_PREREQUISITE_CHANGED")
    return pin,root,protocol,roster,source


def case_spec(source,row):
    spec=json.loads(json.dumps(source));c=row["case"];spec["case_id"]=row["id"]
    spec["public"].update(D_C_ns=c["D_C_ns"],A_window_ns=c["A_window_ns"],graph_edges=c["graph_edges"],calibrated_prediction_residual_ns=[0,0])
    b=spec["resource"]["B_reservation"];b["service_end_ns"]=b["service_start_ns"]+c["B_service_ns"]
    return spec


def case_protocol(spec,row):
    return {"native_epoch":0,"expected_raw_samples":1201,"expected_native_steps":1200,"dt_ns":spec["dt_ns"],
        "horizon_ns":spec["horizon_ns"],"public_epoch_identity":row["public_epoch"],"sensor_period_ns":spec["dt_ns"]*spec["sensor_period_ticks"],
        "sensor_lag_ns":spec["sensor_lag_ns"],"paid_decision_ns":20_000_000}


def check_setup32(setup,spec,row,p,pin):
    core.check(setup["spec_driver_only"]==spec,"SETUP32_NOT_ORIGINAL_FIXED_SPEC")
    c=setup["public_contract"]
    core.check(set(c)=={"epoch","dt_ns","charged_decision_ns","sensor_period_ns","sensor_lag_ns","public_json","resource_json"},"SETUP32_PRIVATE_CONTRACT_KEYS")
    core.check(json.loads(c["public_json"])==spec["public"] and json.loads(c["resource_json"])==spec["resource"],"SETUP32_PUBLIC_INPUTS_CHANGED")
    core.check(c["epoch"]==row["public_epoch"] and c["dt_ns"]==p["dt_ns"] and c["charged_decision_ns"]==p["paid_decision_ns"],"SETUP32_CLOCK_IDENTITY")
    core.check(c["sensor_period_ns"]==p["sensor_period_ns"] and c["sensor_lag_ns"]==p["sensor_lag_ns"],"SETUP32_PUBLIC_SENSOR_CLOCK")
    active=setup["active_model_readback"];I=spec["private_plant"]["inertia"]
    core.check(active["dt_s"]==p["dt_ns"]/1e9 and active["dof_damping"]==[spec["private_plant"]["damping"]]*3,"SETUP32_ACTIVE_DT_DAMPING")
    core.check(active["body_inertia"]==[[0.,0.,0.]]+[[I/2,I/2,I]]*3,"SETUP32_ACTIVE_INERTIA")
    core.check(all(active["initial_"+k]==spec["initial_state"][v] for k,v in (("qpos","qpos"),("qvel","qvel"),("ctrl","torque"))),"SETUP32_ACTIVE_INITIAL_STATE")
    core.check(setup["source_release_sha256"]==pin["producer_release_sha256"] and setup["parent_cpu_sha256"]==pin["public30_sha256"] and setup["source_single_bridge_sha256"]==pin["single_bridge_sha256"],"SETUP32_SOURCE_IDENTITIES")
    core.check(setup["private_fields_given_to_actor"] is False and setup["host_computation_steps_physics"] is False,"SETUP32_PRIVATE_ACTOR_OR_HOST_PHYSICS")
    # Paired SETUP does not export nq/nv/nu numeric getters. Do not fabricate them.


def check_case_artifacts(out,required,release):
    hashes={n:sha(out/n) for n in required if (out/n).is_file()}
    core.check(len(hashes)==17,"MISSING_PAIRED_REQUIRED_OUTPUTS")
    manifest=js(out/"ARTIFACT_MANIFEST.json")
    core.check(manifest["source_release_sha256"]==release,"CASE_MANIFEST_SOURCE")
    for n,h in hashes.items():
        core.check(not(out/n).is_symlink(),"CASE_ARTIFACT_SYMLINK")
        if n!="ARTIFACT_MANIFEST.json":core.check(manifest["files"].get(n)==h,"CASE_ARTIFACT_SHA:"+n)
    for n,h in manifest["files"].items():core.check(Path(n).name==n and not(out/n).is_symlink() and sha(out/n)==h,"CASE_MANIFEST_EXTRA_INVALID")
    return hashes


def check_matrix_claim(claim,roster,release,proofs):
    core.check(claim=={"schema":"paperb-paired32-matrix-claim-v1","source_release_sha256":release,"admission_proofs":proofs,"fixed_roster":roster,"maximum_controlled_epochs":32},"MATRIX_RELEASE_ROSTER_OR_PREREQUISITES_CHANGED")


def audit_case(row,root,source,pin,proofs,required,audit_release):
    out=root/"native_cases"/row["id"];terminal=js(out/"TERMINAL.json") if (out/"TERMINAL.json").is_file() else None
    receipt={"schema":"PaperBPairedCaseIndependentRAW/0.1","case_id":row["id"],"method":row["method"],"source_case_id":row["source_case_id"],
        "original_role":row["role"],"public_clock_identity":row["public_epoch"],"native_raw_epoch":0,"attempt_denominator":1,
        "source_release_sha256":pin["producer_release_sha256"],"auditor_release_sha256":audit_release,
        "terminal_sha256":sha(out/"TERMINAL.json") if terminal is not None else None,
        "RAW_integrity":"UNKNOWN","independent_task_verdict":"UNKNOWN","status":"UNRESOLVED_ATTEMPT_RETAINED",
        "controlled_epoch_created":None if terminal is None else terminal.get("controlled_epoch_created"),
        "controlled_epoch_started":None if terminal is None else terminal.get("controlled_epoch_started"),
        "diagnostic_reintegration_epochs":0,"heldout":False,"GPU":0,"weights":0}
    try:
        core.check(terminal is not None,"MISSING_TERMINAL_CASE_RETAINED")
        core.check(terminal["roster_row"]==row and terminal["source_release_sha256"]==pin["producer_release_sha256"] and terminal["admission_proofs"]==proofs,"TERMINAL_FOREIGN_ROW_SOURCE_PROOFS")
        core.check(js(out/"CASE_CLAIM.json")=={"fixed_roster_row":row,"source_release_sha256":pin["producer_release_sha256"],"admission_proofs":proofs,"maximum_epochs_here":1},"CASE_CLAIM_FOREIGN_OR_RETRY")
        hashes=check_case_artifacts(out,required,pin["producer_release_sha256"]);receipt["required17_artifact_sha256"]=hashes
        core.check(terminal["status"]=="RECORDED_PENDING_INDEPENDENT_RAW_ACCEPTANCE" and terminal["error"] is None,"FAILED_OR_PARTIAL_ATTEMPT_RETAINED")
        spec=case_spec(source,row);p=case_protocol(spec,row);setup=js(out/"SETUP.json");check_setup32(setup,spec,row,p,pin)
        raw=core.parse_raw(out/"independent_samples.csv");steps=core.lines(out/"native_steps.jsonl");core.check_native_clock(raw,steps,p)
        core.check(terminal["native_steps"]==1200 and terminal["raw_samples"]==1201 and terminal["controlled_epoch_created"] is True and terminal["controlled_epoch_started"] is True and terminal["new_controlled_native_episode_count"]==1,"TERMINAL_ACTUAL_EPOCH_COUNTS")
        commands=js(out/"commands.json");submissions=core.lines(out/"submissions.jsonl");acks=core.lines(out/"ACKs.jsonl");effects=core.lines(out/"private_effects.jsonl")
        counts,pre=core.check_commands(commands,submissions,acks,effects,raw,spec)
        core.check(terminal["counts"]==counts and terminal["pending_actual_reservations"]==[],"TERMINAL_ACTUAL_LEDGER_OR_PENDING")
        captures=core.lines(out/"public_captures.jsonl");delivered=core.lines(out/"public_deliveries.jsonl");frames=core.lines(out/"public_actor_inputs.jsonl")
        core.check_public(raw,captures,delivered,frames,commands,acks,pre,p)
        ticks=core.lines(out/"controller_ticks.jsonl");decisions=js(out/"public_decisions.json");snapshot=js(out/"public_final_snapshot.json")
        controller=core.check_controller(ticks,decisions,snapshot,submissions,raw,p)
        core.check(terminal["candidate_budget_epoch"]==controller["candidate_evaluations"],"TERMINAL_CANDIDATE_COUNT")
        anchor=core.check_original_public_anchor(delivered,decisions,snapshot,spec,p)
        independent=evaluate(raw,commands,spec);core.check(independent==js(out/"raw_verdict.json"),"THIRD_REFEREE_DIFFERS_FROM_PRESERVED_OUTPUT")
        queue=[{"target":r["target"],"request_ns":r["request_ns"],"service_start_ns":r["service_start_ns"],"ACK_ns":r["ack_ns"],
                "accepted_queue_wait_ns":r["service_start_ns"]-r["request_ns"],"service_ns":r["ack_ns"]-r["service_start_ns"]} for r in commands]
        receipt.update(RAW_integrity="PASS",independent_task_verdict=independent["joint"],independent_RAW_referee=independent,public_anchor=anchor,controller=controller,
            counts={"RAW_samples":len(raw),"native_steps":len(steps),"public_captures":len(captures),"public_delivered_packets":len(delivered),"actor_public_frames":len(frames)},
            actual_service_intervals=queue,host_attempt_wall_ns=terminal["host_wall_ns"],
            model_dimensions_exported_numerically_in_paired_SETUP=False,model_dimensions_basis="frozen driver guard, 3-axis RAW and independent replay; not invented getter values")
        claim_path=HERE/"diagnostic_claims"/(row["id"]+".json")
        core.check(not claim_path.exists(),"EXISTING_DIAGNOSTIC_CLAIM_FORBIDS_REPEAT_NATIVE_REPLAY")
        write_once(claim_path,{"case_id":row["id"],"auditor_release_sha256":audit_release,"terminal_sha256":receipt["terminal_sha256"],"maximum_diagnostic_native_epochs":1,
                               "diagnostic_not_primary":True,"written_before_MjData_creation":True})
        replay=core.reintegrate(raw,commands,spec,root/"dependency_snapshot/public_component/native_integration/origin_exact/three_rotors.xml",setup["mujoco"],receipt)
        receipt.update(status="PASS_PAIRED_CASE_RAW_AUDIT",diagnostic_reintegration=replay)
    except Exception as e:
        receipt["audit_error"]={"type":type(e).__name__,"reason":str(e)}
    return receipt


def aggregate(receipts,roster):
    core.check(len(receipts)==len(roster)==32 and {r["case_id"] for r in receipts}=={r["id"] for r in roster},"ALL32_RECEIPT_DENOMINATOR_REQUIRED")
    declared={r["id"]:r for r in roster}
    core.check(all(r["method"]==declared[r["case_id"]]["method"] and r["independent_task_verdict"] in {"TRUE","FALSE","UNKNOWN"} for r in receipts),"METHOD_OR_THREE_VALUE_ATTRIBUTION_CHANGED")
    by_method={}
    for method in METHODS:
        rows=[x for x in receipts if x["method"]==method];core.check(len(rows)==8,"METHOD_DENOMINATOR8")
        by_method[method]={"denominator":8,"T_F_U":{k:sum(r["independent_task_verdict"]==k for r in rows) for k in ("TRUE","FALSE","UNKNOWN")},
            "RAW_integrity_PASS":sum(r["RAW_integrity"]=="PASS" for r in rows),"diagnostic_reintegration_epochs":sum(r["diagnostic_reintegration_epochs"] for r in rows)}
    return {"planned_denominator":32,"by_method":by_method,"T_F_U":{k:sum(r["independent_task_verdict"]==k for r in receipts) for k in ("TRUE","FALSE","UNKNOWN")},
            "RAW_integrity_PASS":sum(r["RAW_integrity"]=="PASS" for r in receipts),"complete_independent_RAW_plus_diagnostic_PASS":sum(r["status"]=="PASS_PAIRED_CASE_RAW_AUDIT" for r in receipts),
            "controlled_epoch_started_TRUE":sum(r["controlled_epoch_started"] is True for r in receipts),"controlled_epoch_started_UNKNOWN":sum(r["controlled_epoch_started"] is None for r in receipts),
            "diagnostic_reintegration_epochs":sum(r["diagnostic_reintegration_epochs"] for r in receipts),
            "old_single_primary_not_added_to32":True,"diagnostics_not_added_to_primary":True,"eight_configs_seen_not_IID_or_heldout":True,
            "missing_failed_uncertain_retained":True,"same_case_multiple_contracts_not_independent_episodes":True}


def audit_matrix(notification):
    pin,root,protocol,roster,source=verify_inputs();audit_release=sha(HERE/"AUDITOR_RELEASE.json")
    core.check(notification["root_completed_matrix_terminal_or_retained"] is True,"ROOT_TERMINAL_MATRIX_NOTICE_REQUIRED")
    core.check(notification["producer_release_sha256"]==pin["producer_release_sha256"] and notification["auditor_release_sha256"]==audit_release,"ROOT_SOURCE_OR_AUDITOR_NOTIFICATION_MISMATCH")
    snapshot_path=root/notification["matrix_snapshot_relative_path"]
    core.check(snapshot_path.parent==root and snapshot_path.name.startswith("MATRIX_SNAPSHOT_"),"ROOT_FIXED_MATRIX_SNAPSHOT_PATH")
    core.check(sha(snapshot_path)==notification["matrix_snapshot_sha256"],"ROOT_MATRIX_SNAPSHOT_BYTE_MISMATCH")
    snapshot=js(snapshot_path);core.check(snapshot["planned_denominator"]==32 and snapshot["method_denominator"]==8,"MATRIX_SCOPE")
    core.check(len(snapshot["cases"])==32 and [x["roster_row"] for x in snapshot["cases"]]==roster,"MATRIX_ALL32_SLOTS")
    claim=js(root/"native_cases/MATRIX_CLAIM.json");proofs=claim["admission_proofs"]
    core.check(proofs["single_raw_receipt_sha256"]==protocol["single_independent_raw_receipt_sha256"],"MATRIX_SINGLE_PREREQUISITE_BYTES")
    core.check(proofs==notification["admission_proofs"],"ROOT_AUTHORIZED_PROOFS_DIFFER_FROM_MATRIX")
    check_matrix_claim(claim,roster,pin["producer_release_sha256"],proofs)
    core.check(all(x.name=="MATRIX_CLAIM.json" or (x.is_dir() and x.name in {r["id"] for r in roster}) for x in (root/"native_cases").iterdir()),"FOREIGN_CASE_OR_EXTRA_ATTEMPT")
    (HERE/"diagnostic_claims").mkdir(exist_ok=False);(HERE/"case_audits").mkdir(exist_ok=False)
    receipts=[]
    for row in roster:
        terminal_path=root/"native_cases"/row["id"]/"TERMINAL.json"
        if terminal_path.is_file():
            core.check(snapshot["cases"][row["order"]]==js(terminal_path),"ROOT_SNAPSHOT_DIFFERS_FROM_TERMINAL_BYTES")
        receipt=audit_case(row,root,source,pin,proofs,protocol["outputs"]["per_case"],audit_release)
        write_once(HERE/"case_audits"/(row["id"]+".json"),receipt);receipts.append(receipt)
        print(json.dumps({"case":row["id"],"RAW":receipt["RAW_integrity"],"task":receipt["independent_task_verdict"],"diagnostic_epochs":receipt["diagnostic_reintegration_epochs"]}),flush=True)
    verify_inputs()
    summary=aggregate(receipts,roster)
    result={"schema":"PaperBPaired32IndependentRAWAudit/0.1","created_at_utc":datetime.now(timezone.utc).isoformat(),
        "status":"PASS_PAIRED32_NATIVE_RAW_AUDIT" if summary["complete_independent_RAW_plus_diagnostic_PASS"]==32 else "ALL32_RETAINED_WITH_FAILED_OR_UNRESOLVED_AUDITS",
        "producer_release_sha256":pin["producer_release_sha256"],"auditor_release_sha256":audit_release,"single_full_audit_prerequisite_sha256":pin["single_full_audit_sha256"],
        "root_matrix_snapshot_sha256":sha(snapshot_path),"summary":summary,"cases":receipts,"GPU":0,"weights":0,"heldout":False,
        "formal_statistical_trials":0,"real_robot_episodes":0,"chemical_endpoints":0,"actor_flags_not_oracle":True}
    write_once(HERE/"PAIRED_RAW_AUDIT.json",result);print(json.dumps({"status":result["status"],"summary":summary},sort_keys=True));return result


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--verify-only",action="store_true");parser.add_argument("--root-result-notification",type=Path);args=parser.parse_args()
    if args.verify_only:
        pin,_,_,rows,_=verify_inputs();print(json.dumps({"status":"PASS_PIN_ONLY_NO_NATIVE","roster":len(rows),"producer_release_sha256":pin["producer_release_sha256"],"new_native_epochs":0}))
    elif args.root_result_notification:audit_matrix(js(args.root_result_notification))
    else:parser.error("verify-only or root completed-matrix notification required")
