"""Draft paired-development driver. Default paths never import/run MuJoCo.

No source release exists at this stage. All three admission gates must pass
before a future sealed version can execute the fixed32 roster.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import time
import traceback

ROOT=Path(__file__).resolve().parents[1]
SNAPSHOT=ROOT/'dependency_snapshot/public_component'
spec=importlib.util.spec_from_file_location('copied_single_native_bridge',SNAPSHOT/'native_integration/bridge.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
from public_types import Ack
from controller_contract import PublicFrame
from stateful_controllers import METHODS

CPU_SHA='ea39d01ac8a884e9e8fb135a8a7e4bd5b9a7958d67fff4f4031dcef7bad0d800'
SINGLE_BRIDGE_SHA='fb0f660cf1b8fc0058c626c4b717f5d93e0731ca1824b1b028be671f1a688ab6'


def draft_protocol():return base.read_json(ROOT/'PROTOCOL_DRAFT.json')


def roster():
    source=base.read_json(SNAPSHOT/'source_inputs/scenario_PROTOCOL_V2.json');rows=[]
    for case in source['cases']:
        for method in METHODS:
            rows.append({'order':len(rows),'id':'paired32-'+case['id']+'__'+method,'source_case_id':case['id'],
                'method':method,'case':case,'epoch':0,'public_epoch':'paired32-'+str(len(rows))+'-epoch0',
                'private_fault_driver_only':'first_A_stop_drop','role':'DEVELOPMENT_SEEN_PAIRED_MECHANISM_VALIDATION_NOT_HELDOUT'})
    return rows


def case_spec(row):
    source=base.read_json(SNAPSHOT/'source_inputs/scenario_PROTOCOL_V2.json');p=json.loads(json.dumps(source));c=row['case']
    p['case_id']=row['id'];p['public'].update(D_C_ns=c['D_C_ns'],A_window_ns=c['A_window_ns'],graph_edges=c['graph_edges'])
    p['public']['calibrated_prediction_residual_ns']=[0,0]
    b=p['resource']['B_reservation'];b['service_end_ns']=b['service_start_ns']+c['B_service_ns']
    if p['private_plant']!={'inertia':.002,'damping':.006,'fault':'first_A_stop_drop'}:raise ValueError('same unchanged physical model/fault for all methods')
    if row not in roster():raise ValueError('only an exact fixed-roster row, no arbitrary case or method')
    return p


def actor_for(row,p):
    contract=base.Contract.create(row['public_epoch'],p['public'],p['resource'],p['dt_ns'],p['dt_ns']*p['sensor_period_ticks'],p['sensor_lag_ns'])
    return base.make_controller(row['method'],contract)


def validate_gates(protocol,single,review,admission,release_sha):
    if protocol.get('status')!='FROZEN_AFTER_SINGLE_INDEPENDENT_RAW_ACCEPTANCE':raise ValueError('DRAFT_NOT_FROZEN; native32 cannot execute')
    required_single={'status':'PASS_SINGLE_STATEFUL_NATIVE_RECORDED_RAW','source_bridge_release_sha256':SINGLE_BRIDGE_SHA,
        'cpu_source_pin_sha256':CPU_SHA,'case_id':'v2_diag-A_then_C-B45-D2p8','method':'guarded_hsm_retry',
        'controlled_native_episode_count':1,'complete_recorded_raw_pass':True,'independent_commands_clocks_events_pass':True}
    for k,v in required_single.items():
        if type(single.get(k)) is not type(v) or single[k]!=v:raise ValueError('single independent RAW prerequisite mismatch: '+k)
    if review.get('status')!='PASS_PAIRED32_NATIVE_SOURCE_REVIEW' or review.get('paired32_source_release_sha256')!=release_sha:
        raise ValueError('independent source review not passed for exact paired32 release')
    required={'schema':'paperb-stateful-paired32-root-admission-v1','approved':True,'paired32_source_release_sha256':release_sha,
        'cpu_source_pin_sha256':CPU_SHA,'maximum_controlled_native_epochs':32,'GPU':0,'formal_statistical_trials':0,'heldout':False}
    for k,v in required.items():
        if type(admission.get(k)) is not type(v) or admission[k]!=v:raise ValueError('root paired32 admission mismatch: '+k)


def verify_frozen_sources():
    path=ROOT/'SOURCE_RELEASE.json'
    if not path.exists():raise ValueError('DRAFT_NO_SOURCE_RELEASE; native execution forbidden')
    release=base.read_json(path)
    for name,h in release['files'].items():
        if base.sha(ROOT/name)!=h:raise ValueError('paired32 source mismatch: '+name)
    base.verify_sources()  # copied parent30 and single8 bytes, no native import
    return base.sha(path)


def _run_case(out,row,release_sha,proofs):
    """Called only by the admitted full-roster entry; one model/epoch per row."""
    out.mkdir(exist_ok=False);streams=base.Streams(out);start=time.monotonic_ns();p=case_spec(row);actor=actor_for(row,p)
    channel=base.ReservedChannel(p['resource']);raw=[];acks=[];applied=set();error=None;steps=0;created=False;last_tick=None
    base.write_json(out/'CASE_CLAIM.json',{'fixed_roster_row':row,'source_release_sha256':release_sha,'admission_proofs':proofs,'maximum_epochs_here':1})
    try:
        sys.path.insert(0,str(SNAPSHOT/'native_integration/origin_exact'))
        import mujoco
        from plant import create,Effects
        from referee import evaluate
        model,data=create(p['private_plant'],p['initial_state']);created=True;effects=Effects(p['private_plant'],p['resource']['B_reservation']['torque_after_ACK'])
        if model.nq!=3 or model.nv!=3 or model.nu!=3 or round(float(model.opt.timestep)*1e9)!=p['dt_ns']:raise ValueError('same original model/grid required')
        base.write_json(out/'SETUP.json',{'spec_driver_only':p,'public_contract':vars(actor.contract),'source_release_sha256':release_sha,
            'parent_cpu_sha256':CPU_SHA,'source_single_bridge_sha256':SINGLE_BRIDGE_SHA,'mujoco':mujoco.__version__,
            'active_model_readback':{'dt_s':float(model.opt.timestep),'dof_damping':model.dof_damping.tolist(),'body_inertia':model.body_inertia.tolist()},
            'GPU':0,'private_fields_given_to_actor':False,'host_computation_steps_physics':False})
        pending=[];latest=None
        for tick in range(p['horizon_ns']//p['dt_ns']+1):
            last_tick=tick
            if time.monotonic_ns()-start>120_000_000_000:raise TimeoutError('same predeclared120s case cap')
            now,seconds=base.native_now(data,tick,p['dt_ns'])
            if tick%p['sensor_period_ticks']==0:
                packet=base.capture_packet(data,now,p['sensor_lag_ns']);pending.append(packet);streams.append('public_captures.jsonl',base.asdict(packet))
            while pending and pending[0].arrival_ns<=now:
                latest=pending.pop(0);streams.append('public_deliveries.jsonl',base.asdict(latest))
            for r in channel.reservations:
                if r.ack_ns==now and r.seq not in applied:
                    effect=effects.apply(data,r)
                    if effect['actual_ACK_ns']!=now:raise RuntimeError('actual native effect clock mismatch')
                    applied.add(r.seq);ack=Ack(r.seq,r.target,r.tag,now);acks.append(ack)
                    streams.append('private_effects.jsonl',effect);streams.append('ACKs.jsonl',base.asdict(ack))
            raw_row=base.raw_sample(data,now,seconds);raw.append(raw_row);streams.sample(raw_row)
            frame=PublicFrame(actor.contract.epoch,now,latest,tuple(acks),channel.public_snapshot());frame.validate(actor.contract)
            streams.append('public_actor_inputs.jsonl',base.asdict(frame));actions=actor.advance(frame)
            for a in actions:
                if set(a)!={'client_token','target','tag','request_ns'} or a['request_ns']!=now or a['target'] not in ('A','C') or a['tag']!=a['target']+'_stop':raise ValueError('exact current legal action only')
                counts=base.audit_commands([base.asdict(r) for r in channel.reservations])
                if counts[a['target']]>=2 or sum(counts.values())>=4:raise RuntimeError('same pre-submission cumulative action cap')
                receipt=channel.submit(now,a['target'],a['tag']);streams.append('submissions.jsonl',{'request':a,'actual_accepted_reservation':base.asdict(receipt),'actual_native_time_s':seconds})
            base.audit_commands([base.asdict(r) for r in channel.reservations])
            streams.append('controller_ticks.jsonl',{'now_ns':now,'native_time_s':seconds,'phase':actor.phase,'ledger_counts':actor.ledger.counts,
                'candidate_epoch':actor.budget.epoch,'decision_count':len(actor.decisions),'pending_paid_ready_ns':None if actor.pending is None else actor.pending['ready_ns'],'actual_new_submissions':actions,'epoch':0})
            if tick<p['horizon_ns']//p['dt_ns']:
                before=float(data.time);mujoco.mj_step(model,data);steps+=1;mujoco.mj_forward(model,data)
                streams.append('native_steps.jsonl',{'step_index':steps,'epoch':0,'before_time_s':before,'after_time_s':float(data.time),'before_native_ns':round(before*1e9),'after_native_ns':round(float(data.time)*1e9),'mj_step_calls':1,'mj_forward_calls':1})
        commands=[base.asdict(r) for r in channel.reservations]
        if actor.ledger.counts!=base.audit_commands(commands) or any(r.seq not in applied for r in channel.reservations):raise RuntimeError('actual terminal command/ledger/pending closure mismatch')
        if actor.budget.epoch>10000 or any(d['budget']['candidate_evaluations']>1000 or d['ready_ns']-d['created_ns']!=20_000_000 for d in actor.decisions):raise RuntimeError('same paid decision/candidate caps')
        base.write_json(out/'raw_verdict.json',evaluate([{k:str(v) for k,v in r.items()} for r in raw],commands,p))
    except BaseException as e:
        error={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'last_tick':last_tick};base.write_json(out/'EXCEPTION.json',error)
    finally:
        streams.close();commands=[base.asdict(r) for r in channel.reservations]
        base.write_json(out/'commands.json',commands);base.write_json(out/'public_decisions.json',actor.decisions);base.write_json(out/'public_final_snapshot.json',actor.snapshot())
        if not (out/'raw_verdict.json').exists():base.write_json(out/'raw_verdict.json',{'joint':'UNKNOWN','status':'PARTIAL_FAILED_ATTEMPT_RETAINED','raw_samples':len(raw)})
        result={'schema':'paperb-paired32-case-terminal-v1','roster_row':row,'status':'RECORDED_PENDING_INDEPENDENT_RAW_ACCEPTANCE' if error is None else 'FAILED_ATTEMPT_RETAINED',
            'error':error,'controlled_epoch_created':created,'controlled_epoch_started':steps>0,'native_steps':steps,'raw_samples':len(raw),'source_release_sha256':release_sha,
            'counts':base.audit_commands(commands),'candidate_budget_epoch':actor.budget.epoch,'host_wall_ns':time.monotonic_ns()-start,
            'stream_row_counts':streams.counts,'pending_actual_reservations':[r.seq for r in channel.reservations if r.seq not in applied],
            'new_controlled_native_episode_count':int(steps>0),'same_initial_scene_no_random_seed_generalization':True,
            'GPU':0,'LLM':0,'fit':0,'new_weights':0,'heldout':False,'real_robot_episodes':0,'chemical_endpoints':0,'formal_statistical_trials':0,'independently_accepted':False}
        base.write_json(out/'TERMINAL.json',result);base.write_json(out/'ARTIFACT_MANIFEST.json',{'files':{str(x.relative_to(out)):base.sha(x) for x in sorted(out.rglob('*')) if x.is_file()},'source_release_sha256':release_sha})
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');parser.add_argument('--resume',action='store_true')
    parser.add_argument('--single-raw',type=Path);parser.add_argument('--review',type=Path);parser.add_argument('--admission',type=Path);args=parser.parse_args()
    protocol=draft_protocol()
    if not args.execute:
        print(json.dumps({'status':protocol['status'],'planned_cases':len(roster()),'new_native_epochs':0,'GPU':0,'rows':roster()},indent=2));return 0
    release_sha=verify_frozen_sources()
    if None in (args.single_raw,args.review,args.admission):parser.error('single independent RAW, source review and root admission required')
    single,review,admission=(base.read_json(p) for p in (args.single_raw,args.review,args.admission))
    validate_gates(protocol,single,review,admission,release_sha)
    if admission.get('single_raw_receipt_sha256')!=base.sha(args.single_raw) or admission.get('source_review_receipt_sha256')!=base.sha(args.review):raise ValueError('prerequisite receipt byte bindings')
    out=ROOT/'native_cases'
    if not out.exists():out.mkdir()
    elif not args.resume:raise FileExistsError('native_cases already exists; explicit resume never overwrites attempted cases')
    proofs={'single_raw_receipt_sha256':base.sha(args.single_raw),'source_review_receipt_sha256':base.sha(args.review),'root_admission_sha256':base.sha(args.admission)}
    results=[]
    for row in roster():
        case_out=out/row['id']
        if case_out.exists():
            terminal=case_out/'TERMINAL.json'
            results.append(base.read_json(terminal) if terminal.exists() else {'roster_row':row,'status':'EXISTING_PARTIAL_ATTEMPT_NOT_RERUN','independently_accepted':False})
            continue
        result=_run_case(case_out,row,release_sha,proofs);results.append(result);print(json.dumps({'case':row['id'],'status':result['status']}),flush=True)
        if result['error'] and result['error']['type'] in ('KeyboardInterrupt','SystemExit'):break
    present={r['roster_row']['id'] for r in results}
    results.extend({'roster_row':r,'status':'PLANNED_NOT_STARTED','independently_accepted':False} for r in roster() if r['id'] not in present)
    summary={'role':'DEVELOPMENT_SEEN_FIXED_PAIRED_MECHANISM_VALIDATION','planned_denominator':32,'method_denominator':8,'cases':results,'all_missing_failed_unknown_retained':True,
        'independent_RAW_acceptance_not_inferred_from_recording':True,'agentic_advantage_or_necessity':False,'heldout':False,'GPU':0,'formal_statistical_trials':0}
    target=ROOT/('MATRIX_SNAPSHOT_'+str(time.monotonic_ns())+'.json');base.write_json(target,summary)
    return 0


if __name__=='__main__':raise SystemExit(main())
