"""Compact print layout of all32 actual intervals/decisions; source stays fixed."""
import csv
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
CSV = HERE / 'inputs/ALL32_RESULTS.csv'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(CSV) == 'bf61ed86dde4f0f4da316c614e2b6a59ab67c2b358db13efceac609393efa9fa'
with CSV.open() as f:
    rows = list(csv.DictReader(f))
assert len(rows) == len({r['case_id'] for r in rows}) == 32
methods = ('strong_batch', 'guarded_hsm_retry', 'event_resource_edf', 'joint_interval_mpc')
names = ('Strong batch', 'Guarded HSM', 'Resource EDF', 'Interval MPC')
colors = ('#2f6f88', '#c57a29', '#358671', '#926a9f')
markers = ('o', 's', '^', 'D')
cases = list(dict.fromkeys(r['source_case_id'] for r in rows))
assert len(cases) == 8
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8.5,
                     'axes.labelsize': 8.5, 'axes.titlesize': 9,
                     'xtick.labelsize': 8.5, 'ytick.labelsize': 8.5,
                     'legend.fontsize': 8.5, 'svg.fonttype': 'none',
                     'pdf.fonttype': 42, 'axes.spines.top': False,
                     'axes.spines.right': False})
fig, axes = plt.subplots(1, 2, figsize=(6.75, 2.9), sharey=True,
                         gridspec_kw={'width_ratios': [2.0, 1.1]})
fig.subplots_adjust(left=.232, right=.985, bottom=.19, top=.80, wspace=.18)
axes[0].axvspan(-150, 150, color='#e9f3ed', zorder=0)
axes[0].axvline(0, color='#abb8bc', linewidth=.7, zorder=0)
labels = []
for i, case in enumerate(cases):
    subset = [r for r in rows if r['source_case_id'] == case]
    assert [r['method'] for r in subset] == list(methods)
    labels.append(('A→C' if subset[0]['graph'] == 'A_then_C' else 'C→A') +
        f" | {int(subset[0]['B_service_ns'])//1_000_000} | {int(subset[0]['D_C_ns'])/1e9:g}")
    for j, r in enumerate(subset):
        y = 7 - i + (.21, .07, -.07, -.21)[j]
        lo, hi = float(r['C_error_lower_ms']), float(r['C_error_upper_ms'])
        middle = (lo + hi) / 2
        axes[0].errorbar(middle, y, xerr=[[middle-lo], [hi-middle]],
            color=colors[j], marker=markers[j], markersize=2.8,
            elinewidth=.9, capsize=1.7, capthick=.8,
            label=names[j] if i == 0 else None)
        axes[1].plot(int(r['decisions']), y, color=colors[j],
                     marker=markers[j], markersize=2.8, linestyle='none')
for ax in axes:
    ax.set_ylim(-.5, 7.5)
    ax.set_yticks(range(8)); ax.grid(axis='x', color='#e3e7e9', linewidth=.5)
axes[0].set_yticklabels(labels[::-1])
axes[0].set_xlim(-165, 165); axes[0].set_xticks([-150, -75, 0, 75, 150])
axes[0].set_xlabel('C onset error interval (ms)')
axes[1].set_xlim(0, 17); axes[1].set_xticks([1, 4, 8, 12, 16])
axes[1].set_xlabel('Actual paid decisions')
axes[0].set_title('a  Original-event timing', loc='left', pad=5)
axes[1].set_title('b  Executed lifecycle', loc='left', pad=5)
handles, legend_labels = axes[0].get_legend_handles_labels()
fig.legend(handles, legend_labels, loc='upper center', bbox_to_anchor=(.57, 1.02),
           ncol=2, frameon=False, columnspacing=1.4, handletextpad=.4)
fig.text(.02, .83, 'Graph | B(ms) | D(s)', fontsize=8.5)
out = HERE / 'inputs'
for extension in ('pdf', 'svg', 'png'):
    fig.savefig(out / ('paired32_print.' + extension), dpi=200)
plt.close(fig)
receipt = {'schema': 'paperb-paired32-manuscript-print-figure-v1',
           'source_csv_sha256': sha(CSV),
           'independent_audit_sha256': 'ecff99605f7899785ec25c630309e0a5084039955133de33faad486ee9e8967b',
           'all32_case_ids': [r['case_id'] for r in rows],
           'all32_intervals_and_actual_decisions_present': True,
           'points_are_interval_midpoints_not_scoring': True,
           'scoring_is_whole_interval_containment': True,
           'style_font_size_pt': [8.5, 9.0], 'figure_size_in': [6.75, 2.9],
           'root_figures_unchanged_original_bytes_also_in_archive': True,
           'new_native_GPU_fit': 0,
           'files': {f'paired32_print.{e}': sha(out / f'paired32_print.{e}')
                     for e in ('pdf', 'svg', 'png')}}
(HERE / 'PRINT_FIGURE_PROVENANCE.json').write_text(json.dumps(receipt, indent=2, sort_keys=True)+'\n')
print(json.dumps({'all32_present': True, 'figure_size_in': [6.75, 2.9],
                  'font_size_pt': [8.5, 9.0], 'new_native_GPU_fit': 0}))
