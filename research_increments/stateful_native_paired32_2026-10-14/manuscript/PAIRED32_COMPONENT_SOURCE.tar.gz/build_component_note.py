"""Generate completed ICML source from the exact independently audited32 report.

No physics, policy execution, training or score reinterpretation. Only canonical
source/data copies are written in this owned manuscript directory.
"""
import csv
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RELEASE = '171b6e1154341261b5437fc752f72bcbb0267ee236b344badc3f2fc189f692fd'
AUDIT = 'ecff99605f7899785ec25c630309e0a5084039955133de33faad486ee9e8967b'
STYLE = '7cdcf90f6a59c5219e7f15c88f7ed09fcaf598dad91e6cdddc4dc3cb0e397a95'
METHODS = ('strong_batch', 'guarded_hsm_retry', 'event_resource_edf', 'joint_interval_mpc')
LABELS = ('Strong batch', 'Guarded HSM', 'Resource EDF', 'Interval MPC')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open('w') as f:
        f.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def copy_exact(source, name):
    target = HERE / 'inputs' / name
    if target.exists():
        assert sha(source) == sha(target), 'existing evidence input changed: ' + name
    else:
        shutil.copyfile(source, target)
    assert sha(source) == sha(target)
    return {'source_path': str(source), 'copied_path': str(target.relative_to(HERE)),
            'sha256': sha(target), 'bytes': target.stat().st_size}


def integer(row, key):
    value = int(row[key])
    assert str(value) == row[key], key
    return value


def interval(values):
    lo, hi = min(values), max(values)
    return str(lo) if lo == hi else f'{lo}--{hi}'


def main():
    assert sha(ROOT / 'SOURCE_RELEASE.json') == RELEASE
    manifest = load(ROOT / 'SOURCE_RELEASE.json')
    assert all(sha(ROOT / name) == expected for name, expected in manifest['files'].items())
    assert sha(HERE / 'source/icml2026.sty') == STYLE
    summary_path = ROOT / 'results/PUBLIC_SUMMARY.json'
    csv_path = ROOT / 'results/ALL32_RESULTS.csv'
    audit_path = ROOT / 'independent_raw_audit/PAIRED_RAW_AUDIT.json'
    summary = load(summary_path); audit = load(audit_path)
    assert summary['status'] == 'PASS_ALL32_SOURCE_BOUND_INDEPENDENT_RAW_REPORT'
    assert audit['status'] == 'PASS_PAIRED32_NATIVE_RAW_AUDIT'
    assert sha(audit_path) == summary['independent_audit_sha256'] == AUDIT
    assert summary['source_release_sha256'] == audit['producer_release_sha256'] == RELEASE
    assert summary['CSV_sha256'] == sha(csv_path)
    assert summary['primary_case_denominator'] == audit['summary']['planned_denominator'] == 32
    assert summary['per_method_denominator'] == 8 and summary['all32_retained']
    with csv_path.open() as f:
        reader = csv.DictReader(f); rows = list(reader)
    roster = load(ROOT / 'ROSTER.json')['rows']
    assert [r['case_id'] for r in rows] == [r['id'] for r in roster]
    assert len(rows) == len({r['case_id'] for r in rows}) == 32
    audited = {r['case_id']: r for r in audit['cases']}
    assert len(audited) == 32 and set(audited) == {r['case_id'] for r in rows}
    for row, fixed in zip(rows, roster):
        a = audited[row['case_id']]
        assert row['method'] == fixed['method'] == a['method']
        assert row['source_case_id'] == fixed['source_case_id'] == a['source_case_id']
        assert row['RAW_integrity'] == a['RAW_integrity']
        assert row['independent_joint'] == a['independent_task_verdict']
        assert row['terminal_sha256'] == a['terminal_sha256']
        assert a['source_release_sha256'] == RELEASE
        controller = a['controller']; counts = a['counts']; referee = a['independent_RAW_referee']
        for column, actual in [('decisions', controller['decisions']),
                ('candidates', controller['candidate_evaluations']),
                ('actual_A_requests', controller['actual_requests']['A']),
                ('actual_C_requests', controller['actual_requests']['C']),
                ('charged_virtual_decision_ns', controller['charged_virtual_decision_ns']),
                ('raw_samples', counts['RAW_samples']), ('native_steps', counts['native_steps']),
                ('public_captures', counts['public_captures']),
                ('delivered_packets', counts['public_delivered_packets']),
                ('diagnostic_epochs', a['diagnostic_reintegration_epochs'])]:
            assert integer(row, column) == actual, (row['case_id'], column)
        assert integer(row, 'charged_virtual_decision_ns') == integer(row, 'decisions') * 20_000_000
        assert integer(row, 'candidates') <= 10000
        assert integer(row, 'actual_A_requests') <= 2 and integer(row, 'actual_C_requests') <= 2
        assert integer(row, 'actual_A_requests') + integer(row, 'actual_C_requests') <= 4
        for axis in ('A', 'C'):
            score = referee['time_scores'][axis]
            assert row[axis + '_timing'] == score['verdict']
            assert [integer(row, axis + '_duration_lower_ns'), integer(row, axis + '_duration_upper_ns')] == score['duration_interval_ns']
        assert integer(row, 'A_window_upper_ns') == integer(row, 'D_C_ns')
        for side in ('lower', 'upper'):
            assert float(row['C_error_' + side + '_ms']) == (integer(row, 'C_duration_' + side + '_ns') - integer(row, 'D_C_ns')) / 1e6
        waits = [r['accepted_queue_wait_ns'] for r in a['actual_service_intervals'] if r['target'] in ('A', 'C')]
        assert integer(row, 'maximum_actual_A_C_queue_wait_ns') == max(waits or [0])
    totals = {k: Counter(r['independent_joint'] for r in rows)[k] for k in ('TRUE', 'FALSE', 'UNKNOWN')}
    assert totals == summary['T_F_U'] == audit['summary']['T_F_U']
    assert sum(integer(r, 'raw_samples') for r in rows) == summary['controlled_RAW_samples']
    assert sum(integer(r, 'native_steps') for r in rows) == summary['controlled_native_steps']
    assert sum(integer(r, 'diagnostic_epochs') for r in rows) == summary['diagnostic_native_epochs'] == 32
    assert summary['diagnostic_samples'] == 38432 and summary['zero_error_reintegration_cases'] == 32
    assert summary['controlled_and_diagnostic_denominators_separate'] and not summary['statistical_IID_or_CI_claim']
    assert not summary['agentic_necessity_or_advantage_supported'] and not summary['heldout']
    assert summary['random_seeds'] == summary['new_policy_weights'] == summary['GPU'] == 0
    table_rows = []
    for method, label in zip(METHODS, LABELS):
        subset = [r for r in rows if r['method'] == method]
        assert len(subset) == summary['by_method'][method]['denominator'] == 8
        tfu = {k: Counter(r['independent_joint'] for r in subset)[k] for k in ('TRUE', 'FALSE', 'UNKNOWN')}
        assert tfu == summary['by_method'][method]['T_F_U'] == audit['summary']['by_method'][method]['T_F_U']
        for key, column in [('decisions_range', 'decisions'), ('candidates_range', 'candidates'),
                            ('virtual_charge_range_ns', 'charged_virtual_decision_ns')]:
            values = [integer(r, column) for r in subset]
            assert [min(values), max(values)] == summary['by_method'][method][key]
        table_rows.append(label + ' & ' + '/'.join(str(tfu[k]) for k in ('TRUE', 'FALSE', 'UNKNOWN')) +
            ' & ' + interval([integer(r, 'decisions') for r in subset]) +
            ' & ' + interval([integer(r, 'candidates') for r in subset]) +
            ' & ' + interval([integer(r, 'charged_virtual_decision_ns') // 1_000_000 for r in subset]) + r' \\')
    # This immutable cohort is fully successful; a different future result
    # cannot silently reuse its null interpretation or completed manuscript.
    assert totals == {'TRUE': 32, 'FALSE': 0, 'UNKNOWN': 0}
    assert all(integer(r, 'actual_A_requests') == 2 and integer(r, 'actual_C_requests') == 1 for r in rows)
    fp_path = ROOT / 'figures/FIGURE_PROVENANCE.json'; fp = load(fp_path)
    assert fp['source_csv_sha256'] == sha(csv_path) and fp['independent_audit_sha256'] == AUDIT
    assert fp['all32_cases_present'] and fp['raw_interval_whole_containment_not_midpoint_scoring']
    assert all(sha(ROOT / 'figures' / n) == h for n, h in fp['files'].items())
    files = {'PAIRED_PUBLIC_SUMMARY.json': summary_path, 'ALL32_RESULTS.csv': csv_path,
             'PAIRED_RAW_AUDIT.json': audit_path, 'FIGURE_PROVENANCE.json': fp_path}
    files.update({n: ROOT / 'figures' / n for n in fp['files']})
    copied = {n: copy_exact(path, n) for n, path in files.items()}
    table = '\n'.join([r'\begin{table}[h]', r'\centering',
        r'\caption{Actual audited episodes: eight per method. T/F/U is the joint physical contract. Charge is virtual decision time.}',
        r'\label{tab:actual}', r'\small', r'\begin{tabular}{@{}lcccc@{}}', r'\toprule',
        r'Method & T/F/U & Dec. & Proposals & Charge (ms) \\', r'\midrule',
        *table_rows, r'\bottomrule', r'\end{tabular}', r'\end{table}'])
    values = {
        '@@ABSTRACT_RESULT@@': 'All 32 independently audited episodes satisfy the joint contract; strong batch ties feedback and replanning on success.',
        '@@FIGURE_CAPTION@@': 'All 32 audited development episodes. Left: C onset-error intervals relative to the original B event, with the allowed $\\pm150$ ms window shaded. Right: actual charged decision counts. Intervals, not midpoints, determine certification. Different workloads do not establish an agentic or statistical advantage.',
        '@@RESULTS_TABLE@@': table,
        '@@ACTUAL_RESULTS_TEXT@@': 'All methods are 8/8 joint TRUE (Table~\\ref{tab:actual}), with zero FALSE/UNKNOWN and A2/C1 requests throughout. Strong batch already explains all eight configurations; no feedback, replanning or learning benefit is demonstrated. Workloads are descriptive under shared caps. Maximum actual A/C queue waits are 0/0/20/10 ms for batch/HSM/EDF/MPC; B reservation wait is separate.',
        '@@ACTUAL_AUDIT_COUNTS@@': 'The 32 controlled episodes contain 38,432 RAW samples/38,400 steps. Separately, 32 diagnostic command re-integrations add 38,432 samples/38,400 steps with zero state/time error. Replays are not new primary trials.'}
    text = (HERE / 'source/paired32_component.tex.in').read_text()
    for token, replacement in values.items():
        assert text.count(token) == 1, token
        text = text.replace(token, replacement)
    assert not re.search(r'@@|\bTODO\b|\bpending\b', text, re.I)
    canonical = HERE / 'source/paired32_component.tex'
    with canonical.open('w') as f:
        f.write(text)
    save(HERE / 'ACTUAL32_INPUT_RECEIPTS.json', {
        'schema': 'paperb-paired32-manuscript-actual-inputs-v1',
        'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_release_sha256': RELEASE, 'independent_audit_sha256': AUDIT,
        'root_summary_sha256': sha(summary_path), 'all32_CSV_sha256': sha(csv_path),
        'inputs': copied, 'all32_data_compared_with_independent_audit': True,
        'primary': 32, 'diagnostic_reintegration': 32, 'heldout': False,
        'strong_batch_tie_retained': True, 'training_rows': 0, 'new_native_GPU_fit': 0,
        'canonical_tex_sha256': sha(canonical), 'official_style_sha256': STYLE})
    print(json.dumps({'status': 'COMPLETED_ACTUAL_SOURCE_GENERATED', 'primary': 32,
                      'T_F_U': totals, 'official_style_unchanged': True, 'new_native_GPU_fit': 0}, indent=2))


if __name__ == '__main__':
    main()
