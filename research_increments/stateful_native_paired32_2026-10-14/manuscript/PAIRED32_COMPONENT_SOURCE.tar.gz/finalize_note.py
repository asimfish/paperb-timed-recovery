"""Terminal paper artifact gate and source-archive readback; no new experiments."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as f:
        f.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    source = HERE / 'source/paired32_component.tex'
    pdf = HERE / 'build/paired32_component.pdf'
    assert not re.search(r'@@|\bTODO\b|\bpending\b', source.read_text(), re.I)
    assert sha(HERE/'source/icml2026.sty') == '7cdcf90f6a59c5219e7f15c88f7ed09fcaf598dad91e6cdddc4dc3cb0e397a95'
    info = subprocess.run(['pdfinfo', str(pdf)], check=True, capture_output=True, text=True).stdout
    assert re.search(r'^Pages:\s+2$', info, re.M)
    for n in ('compile_deliver1.log', 'compile_deliver2.log'):
        log = (HERE/'build'/n).read_text()
        assert not re.search(r'Overfull|undefined|Emergency stop|^! ', log, re.M | re.I), n
        assert re.search(r'Output written.*\(2 pages,', log), n
    subprocess.run(['pdftotext', '-layout', str(pdf), str(HERE/'build/FINAL_PAPER_TEXT.txt')], check=True)
    actual = json.loads((HERE/'ACTUAL32_INPUT_RECEIPTS.json').read_text())
    assert actual['all32_data_compared_with_independent_audit'] and actual['strong_batch_tie_retained']
    assert actual['canonical_tex_sha256'] == sha(source)
    assert sha(ROOT/'SOURCE_RELEASE.json') == actual['source_release_sha256']
    manifest = json.loads((ROOT/'SOURCE_RELEASE.json').read_text())
    assert all(sha(ROOT/name) == value for name,value in manifest['files'].items())
    for record in actual['inputs'].values():
        assert sha(HERE/record['copied_path']) == record['sha256']
        assert sha(Path(record['source_path'])) == record['sha256']
    printed = json.loads((HERE/'PRINT_FIGURE_PROVENANCE.json').read_text())
    assert printed['all32_intervals_and_actual_decisions_present'] and len(printed['all32_case_ids']) == 32
    assert all(sha(HERE/'inputs'/n)==value for n,value in printed['files'].items())
    for page in (1,2):
        assert (HERE/'build'/f'delivery_page-{page}.png').is_file()
    canonical = HERE/'PAIRED32_COMPONENT_NOTE.pdf'
    if canonical.exists():
        raise FileExistsError('canonical manuscript was already delivered')
    shutil.copyfile(pdf, canonical)
    outputs = [canonical, source, HERE/'source/icml2026.sty', HERE/'build_component_note.py',
        HERE/'build_print_figure.py', HERE/'finalize_note.py', HERE/'FINAL_README_cn.md',
        HERE/'BASE_INPUT_RECEIPTS.json', HERE/'ACTUAL32_INPUT_RECEIPTS.json',
        HERE/'PRINT_FIGURE_PROVENANCE.json', HERE/'PRIMARY_CITATION_READ_RECEIPTS.json',
        HERE/'BUILD_INPUT_CONTRACT.json']
    outputs += sorted((HERE/'inputs').glob('*'))
    validation = {'schema':'paperb-paired32-component-paper-build-v1',
        'status':'PASS_TWO_PAGE_ACTUAL32_ICML_COMPONENT_NOTE',
        'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'compiled_pages':2,'official_style_unchanged':True,
        'official_style_sha256':sha(HERE/'source/icml2026.sty'),
        'font_margin_or_style_hacks':False,'table_font_pt':9,'print_plot_font_pt':[8.5,9],
        'final_compile_logs':{n:sha(HERE/'build'/n) for n in ('compile_deliver1.log','compile_deliver2.log')},
        'undefined_citations':False,'overfull_boxes':False,
        'nonfatal_warnings':['hyperref title linebreak removed from PDF string','anonymous project author empty anchor ignored','underfull paragraphs/vboxes'],
        'visually_inspected_all_final_pages':[f'build/delivery_page-{p}.png' for p in (1,2)],
        'visual_inspection':'Completed by manuscript producer; root independent review follows',
        'primary_episodes':32,'primary_RAW_samples':38432,'primary_steps':38400,
        'diagnostic_reintegration_epochs':32,'diagnostic_samples':38432,'diagnostic_steps':38400,
        'T_F_U':{'TRUE':32,'FALSE':0,'UNKNOWN':0},'per_method_denominator':8,
        'strong_batch_tie_retained':True,'software_checks_separate':64,
        'single_primary_separate':1,'single_diagnostic_separate':1,
        'legacy_metadata':28,'image_action_candidates':852,'metadata_CPU_checks':34,
        'training_rows':0,'heldout':False,'statistical_or_agentic_advantage_claim':False,
        'source_release_sha256':actual['source_release_sha256'],
        'independent_audit_sha256':actual['independent_audit_sha256'],
        'source67_and_original_root_reports_figures_unchanged':True,
        'no_fake_RGB_or_added_physics':True,'new_native_GPU_fit':0,
        'outputs':{str(p.relative_to(HERE)):sha(p) for p in outputs}}
    save(HERE/'BUILD_VALIDATION.json',validation)
    bundle_files=outputs+[HERE/'BUILD_VALIDATION.json']
    archive=HERE/'PAIRED32_COMPONENT_SOURCE.tar.gz'
    with tarfile.open(archive,'x:gz') as t:
        for p in sorted(bundle_files):
            assert p.suffix!='.pyc' and 'build/' not in str(p.relative_to(HERE))
            data=p.read_bytes();item=tarfile.TarInfo(str(p.relative_to(HERE)))
            item.size=len(data);item.mtime=0;item.mode=0o644;item.uid=item.gid=0
            import io
            t.addfile(item,io.BytesIO(data))
    expected={str(p.relative_to(HERE)):sha(p) for p in bundle_files}
    with tarfile.open(archive,'r:gz') as t:
        reopened={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest()
                  for m in t.getmembers() if m.isfile()}
    assert reopened==expected
    save(HERE/'SOURCE_BUNDLE_VALIDATION.json',{'schema':'paperb-paired32-source-bundle-readback-v1',
        'status':'PASS_ALL_MEMBERS_REOPENED_AND_HASH_MATCHED','archive_sha256':sha(archive),
        'archive_bytes':archive.stat().st_size,'member_count':len(expected),'members':expected,
        'contains_actual_CSV_summary_audit_and_vector_figures':True,
        'contains_root_original_figure_bytes_and_print_variant':True,
        'draft_templates_build_products_pyc_credentials_in_archive':False,
        'new_native_GPU_fit':0})
    final={'schema':'paperb-paired32-final-manuscript-receipt-v1',
        'status':'COMPLETE_READY_FOR_ROOT_INDEPENDENT_VISUAL_FACT_REVIEW',
        'canonical_PDF':'PAIRED32_COMPONENT_NOTE.pdf','PDF_sha256':sha(canonical),
        'build_validation_sha256':sha(HERE/'BUILD_VALIDATION.json'),
        'source_archive_sha256':sha(archive),'source_bundle_validation_sha256':sha(HERE/'SOURCE_BUNDLE_VALIDATION.json'),
        'source_release_sha256':actual['source_release_sha256'],
        'independent_audit_sha256':actual['independent_audit_sha256'],
        'final_two_pages':True,'new_native_GPU_fit':0,'producer_stops_modifying_after_receipt':True}
    save(HERE/'FINAL_MANUSCRIPT_RECEIPT.json',final)
    print(json.dumps(final,indent=2))


if __name__=='__main__':
    main()
