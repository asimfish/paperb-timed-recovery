"""Accepted arrival clock, not ticket creation/return order; CPU fixtures only."""
import copy
import unittest
from unittest.mock import patch

from test_inference_clock import execution, header, setup, complete, digest, verify_parent


def request_at(request, tick, native_time, *, deadline_time=None):
    changed = copy.deepcopy(request)
    changed['execution'] = execution(tick, native_time)
    if deadline_time is not None:
        changed['execution']['state']['deadline_time_ns'] = deadline_time
    changed['prefix']['as_of_time_ns'] = native_time
    changed['desired_ticks'] = list(range(tick + 1, tick + 9))
    changed['declared_end_tick'] = tick + 8
    return changed


def return_ticket(contract, ticket_id, receipt, current, *, chunk=None):
    return contract.complete(ticket_id,
        original_snapshot_sha256=receipt['data']['snapshot_sha256'],
        original_prefix=receipt['data']['prefix'], current_execution=current,
        wall_monotonic_ns=500, chunk=[[i/100]*9 for i in range(8)] if chunk is None else chunk)


class HighwaterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.parent_receipt = verify_parent()
        cls.parent_patch = patch('inference_clock.verify_parent', return_value=cls.parent_receipt)
        cls.parent_patch.start()
        cls.addClassCleanup(cls.parent_patch.stop)

    def test_serial_rollback_after_late_unsafe_guard_rejected(self):
        c, request, receipt = setup(); complete(c, receipt, execution(1,110))
        late = c.guard_submit('t0', current_execution=execution(13,12010,lawful=False),earliest_apply_tick=14)
        self.assertEqual([s['slot'] for s in late['data']['slots'] if s['eligible_by_current_guard']], [])
        before = copy.deepcopy(c.events)
        with self.assertRaisesRegex(ValueError, 'ACCEPTED_EVENT_EXECUTION_CLOCK_ROLLBACK'):
            c.guard_submit('t0', current_execution=execution(2,120),earliest_apply_tick=3)
        self.assertEqual(c.events, before)

    def test_each_clock_dimension_rejects_independently(self):
        for key in ('tick','time_ns','deadline_time_ns'):
            with self.subTest(key=key):
                c,request,receipt=setup(); complete(c,receipt,execution(1,110))
                c.guard_submit('t0',current_execution=execution(2,120),earliest_apply_tick=3)
                rolled=execution(2,120);rolled['state'][key] -= 1
                before=copy.deepcopy(c.events)
                with self.assertRaisesRegex(ValueError,'ACCEPTED_EVENT_EXECUTION_CLOCK_ROLLBACK'):
                    c.guard_submit('t0',current_execution=rolled,earliest_apply_tick=3)
                self.assertEqual(c.events,before)

    def test_start_cannot_rollback_latest_guard(self):
        c,request,receipt=setup();complete(c,receipt,execution(1,110))
        c.guard_submit('t0',current_execution=execution(5,150),earliest_apply_tick=6)
        with self.assertRaisesRegex(ValueError,'ACCEPTED_EVENT_EXECUTION_CLOCK_ROLLBACK'):
            c.start('t1',**request_at(request,4,140))
        self.assertNotIn('t1',c.tickets)
        self.assertEqual(c.events[-1]['phase'],'CURRENT_ACTION_SUBMIT_GUARD')

    def test_return_cannot_rollback_another_ticket_guard(self):
        c,request,r0=setup();r1=c.start('t1',**request_at(request,1,110))
        return_ticket(c,'t1',r1,execution(2,120))
        c.guard_submit('t1',current_execution=execution(5,150),earliest_apply_tick=6)
        with self.assertRaisesRegex(ValueError,'ACCEPTED_EVENT_EXECUTION_CLOCK_ROLLBACK'):
            return_ticket(c,'t0',r0,execution(4,140))
        self.assertNotIn('t0',c.returns)

    def test_equal_clock_multi_events_remain_legal(self):
        c,request,r0=setup();r1=c.start('t1',**request_at(request,0,100))
        return_ticket(c,'t1',r1,execution(0,100))
        return_ticket(c,'t0',r0,execution(0,100))
        guard=c.guard_submit('t0',current_execution=execution(0,100),earliest_apply_tick=1)
        self.assertEqual([s['slot'] for s in guard['data']['slots'] if s['eligible_by_current_guard']],list(range(7)))
        self.assertEqual([row['seq'] for row in c.events],list(range(5)))
        for previous,row in zip(c.events,c.events[1:]):
            self.assertEqual(row['previous_sha256'],previous['record_sha256'])

    def test_overlapping_tickets_return_out_of_start_order_at_actual_arrival(self):
        c,request,r0=setup();r1=c.start('t1',**request_at(request,1,110))
        first=return_ticket(c,'t1',r1,execution(2,120))
        later=return_ticket(c,'t0',r0,execution(3,130))
        guarded=c.guard_submit('t1',current_execution=execution(3,130),earliest_apply_tick=4)
        self.assertEqual([row['data']['ticket_id'] for row in c.events],['t0','t1','t1','t0','t1'])
        self.assertEqual(first['data']['original_prefix']['as_of_time_ns'],110)
        self.assertEqual(later['data']['original_prefix']['as_of_time_ns'],100)
        self.assertEqual(first['data']['inference_actor']['actor_id'],'student')
        self.assertEqual([s['original_desired_tick'] for s in guarded['data']['slots']],list(range(2,10)))
        self.assertEqual(guarded['data']['S_F_R_admitted'],0)

    def test_invalid_prefix_does_not_advance_clock(self):
        c,request,r0=setup();invalid=request_at(request,10,1000)
        invalid['prefix']['as_of_time_ns']=100
        with self.assertRaisesRegex(ValueError,'PREFIX_EXACT_CLOCK'):
            c.start('invalid',**invalid)
        self.assertNotIn('invalid',c.tickets)
        accepted=c.start('lower-valid',**request_at(request,1,110))
        self.assertEqual(accepted['phase'],'INFERENCE_START')
        self.assertEqual(len(c.events),2)

    def test_failed_output_does_not_advance_clock(self):
        c,request,r0=setup()
        with self.assertRaisesRegex(ValueError,'8_BY_9'):
            return_ticket(c,'t0',r0,execution(10,1000),chunk=[])
        self.assertNotIn('t0',c.returns)
        accepted=return_ticket(c,'t0',r0,execution(1,110))
        self.assertEqual(accepted['data']['return_execution']['state']['tick'],1)
        self.assertEqual(len(c.events),2)

    def test_invalid_guard_does_not_advance_clock(self):
        c,request,r0=setup();complete(c,r0,execution(1,110))
        with self.assertRaisesRegex(ValueError,'EXPLICIT_OPERATION_PURPOSE'):
            c.guard_submit('t0',current_execution=execution(10,1000),earliest_apply_tick=11,operation_purpose='INVALID')
        accepted=c.guard_submit('t0',current_execution=execution(2,120),earliest_apply_tick=3)
        self.assertEqual(accepted['data']['current_execution']['state']['tick'],2)

    def test_event_serialization_failure_does_not_advance_clock(self):
        c,request,r0=setup();complete(c,r0,execution(1,110))
        with patch('inference_clock.digest',side_effect=ValueError('CPU_EVENT_SERIALIZATION_FAILURE')):
            with self.assertRaisesRegex(ValueError,'CPU_EVENT_SERIALIZATION_FAILURE'):
                c.guard_submit('t0',current_execution=execution(10,1000),earliest_apply_tick=11)
        self.assertEqual(len(c.events),2)
        accepted=c.guard_submit('t0',current_execution=execution(2,120),earliest_apply_tick=3)
        self.assertEqual(accepted['seq'],2)

    def test_event_capacity_failure_does_not_advance_clock(self):
        c,request,r0=setup();complete(c,r0,execution(1,110))
        for _ in range(1022):
            c.guard_submit('t0',current_execution=execution(1,110),earliest_apply_tick=2)
        before_clock=c._accepted_execution_clock
        with self.assertRaisesRegex(ValueError,'EVENT_CAP'):
            c.guard_submit('t0',current_execution=execution(10,1000),earliest_apply_tick=11)
        self.assertEqual(c._accepted_execution_clock,before_clock)
        self.assertEqual(len(c.events),1024)


if __name__=='__main__': unittest.main()
