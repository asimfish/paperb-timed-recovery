"""Version-pinned public API reproduction; original root report preserved separately."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
V01 = ROOT.parent / 'inference_prefix_clock_contract_v01_2026-10-15'
V01_FREEZE = 'f55c2221066996a4737090c7c5d619e0067b7782a7b84424a42ce4d83911d143'
V01_SOURCE = 'c2c5c0f76cb01d8bec5e89cf31c19ac6903b5c3e2784e898a0d7861a67009717'
V01_ROOT_REVIEW = '6c345a8124661c994335dd0d7a443bc94de8d9b332c7e775c180bc673aeb7048'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(source_version):
    if sha(V01 / 'SOURCE_FREEZE.json') != V01_FREEZE or sha(V01 / 'code/inference_clock.py') != V01_SOURCE or sha(V01 / 'root_review/ROOT_INDEPENDENT_REVIEW.json') != V01_ROOT_REVIEW:
        raise ValueError('EXACT_V01_AND_ROOT_RED_PINS_REQUIRED')
    path = (V01 if source_version == 'v01' else ROOT) / 'code/inference_clock.py'
    spec = importlib.util.spec_from_file_location('version_under_probe', path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    sys.path.insert(0, str(ROOT / 'tests'))
    import test_inference_clock as fixtures
    parent = module.verify_parent()
    with patch.object(module, 'verify_parent', return_value=parent), patch.object(fixtures, 'InferenceClockContract', module.InferenceClockContract):
        contract, request, receipt = fixtures.setup()
        returned = fixtures.complete(contract, receipt, fixtures.execution(1,110))
        late_execution = fixtures.execution(13,12010,lawful=False)
        rollback_execution = fixtures.execution(2,120)
        late = contract.guard_submit('t0', current_execution=late_execution, earliest_apply_tick=14)
        before = copy.deepcopy(contract.events)
        error = None; rollback = None
        try:
            rollback = contract.guard_submit('t0', current_execution=rollback_execution, earliest_apply_tick=3)
        except ValueError as exc:
            error = str(exc)
        serial_guard_rollback_closed = error == 'ACCEPTED_EVENT_EXECUTION_CLOCK_ROLLBACK' and contract.events == before
        result = {
            'schema':'InferencePrefixClockSerialRollbackProbe/1',
            'source_version':source_version, 'source_sha256':sha(path),
            'root_review_sha256':V01_ROOT_REVIEW,
            'fixture_scope':'CPU_SYNTHETIC_EQUIVALENT_ROOT_FINDING_NOT_ROOT_ORIGINAL_INPUT_RECONSTRUCTION',
            'input_clocks':{'start':[0,100,100],'return':[1,110,110],'unsafe_late_guard':[13,12010,12010],'rolled_guard':[2,120,120]},
            'parent_source_members_verified':parent['verified_members'],
            'late_guard_eligible_slots':[s['slot'] for s in late['data']['slots'] if s['eligible_by_current_guard']],
            'rollback_guard_eligible_slots':None if rollback is None else [s['slot'] for s in rollback['data']['slots'] if s['eligible_by_current_guard']],
            'rejection':error, 'event_count_before_rollback':len(before), 'event_count_after_rollback':len(contract.events),
            'accepted_events':contract.events, 'serial_guard_rollback_closed':serial_guard_rollback_closed,
            'status':'PASS_SOFTWARE_SERIAL_CLOCK_GUARD' if serial_guard_rollback_closed else 'RED_ROLLBACK_REENABLED_SLOTS',
            'adapter_status':'NOT_INTEGRATED_G1_ASYNC_PROPOSAL_SCHEMA', 'native_model_GPU_calls':0, 'S_F_R_admitted':0}
        return result


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--source-version',choices=('v01','v02'),required=True)
    args=parser.parse_args(); result=run(args.source_version)
    print(json.dumps(result,sort_keys=True,indent=2,ensure_ascii=False))
    raise SystemExit(0 if result['serial_guard_rollback_closed'] else 2)
