"""Data-only inference-start snapshot / return / current-submit clock contract.

No model, image generation, SDK, simulation step, driver or S/F/R admission.
Trusted caller observations are bound records, not physical authentication.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import re
from pathlib import Path

PARENT = Path(__file__).resolve().parents[2]/"mixed_actor_causal_registry_v01_2026-10-14/release_v02"
PARENT_SHA = "a99686f1eba78ee427ce6c0388b4a343b74b972bee191d31fba6965602bad329"
PRIVATE_KEYS = {"private_state", "object_pose", "referee", "fault", "fault_id", "known_drop_oracle", "ground_truth", "contact_rows", "reward", "success", "event_truth", "labels", "audit_only", "teacher_label"}
HASH = re.compile("^[0-9a-f]{64}$")


def plain(value, public=False, depth=0):
    if depth > 32:
        raise ValueError("NESTING_CAP")
    if type(value) is dict:
        for key, child in value.items():
            if type(key) is not str or (public and (key in PRIVATE_KEYS or key.startswith("private_"))):
                raise ValueError("PRIVATE_OR_NONSTRING_PUBLIC_KEY")
            plain(child, public, depth+1)
    elif type(value) is list:
        for child in value:
            plain(child, public, depth+1)
    elif type(value) not in (str, int, float, bool, type(None)) or (type(value) is float and not math.isfinite(value)):
        raise ValueError("FINITE_PLAIN_DATA_REQUIRED")


def canonical(value):
    plain(value)
    data = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()
    if len(data) > 4*1024*1024:
        raise ValueError("JSON_INPUT_CAP")
    return data


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def integer(value):
    if type(value) is not int or not 0 <= value < 2**63:
        raise ValueError("NONNEGATIVE_INTEGER_REQUIRED")
    return value


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_parent():
    release = PARENT/"SOURCE_RELEASE.json"
    if sha(release) != PARENT_SHA:
        raise ValueError("PINNED_G1_PARENT_RELEASE_REQUIRED")
    members = json.loads(release.read_text())["files"]
    for name, pin in members.items():
        if Path(name).is_absolute() or ".." in Path(name).parts or (PARENT/name).is_symlink() or sha(PARENT/name) != pin["sha256"]:
            raise ValueError("G1_PARENT_SOURCE_CHANGED")
    return {"parent_release_sha256": PARENT_SHA, "verified_members": len(members)}


class InferenceClockContract:
    def __init__(self, header, *, expected_header_sha256):
        self.parent_pin = verify_parent()
        if digest(header) != expected_header_sha256:
            raise ValueError("INDEPENDENT_FULL_HEADER_PIN_REQUIRED")
        required = {"schema","dataset_kind","original_attempt_id","attempt_id","native_epoch","failure_root_id",
                    "original_deadline_clock_id","original_deadline_ns","split","actors","pins","action_dim","history_cap","channel_order"}
        if set(header) != required or header["dataset_kind"] not in ("CPU_FIXTURE","PRODUCTION") or header["channel_order"] != "FIFO_ONE_APPLICATION_PER_TICK":
            raise ValueError("EXACT_G1_HEADER_FIELDS_REQUIRED")
        if not integer(header["original_deadline_ns"]):
            raise ValueError("ORIGINAL_DEADLINE_REQUIRED")
        required_pins = {"collector_source_sha256","channel_source_sha256","registry_source_sha256","split_plan_sha256","v04_manifest_sha256","audit_sources_sha256","safety_authorizer_source_sha256"}
        if set(header["pins"]) != required_pins or header["pins"]["registry_source_sha256"] != sha(PARENT/"code/mixed_actor_registry.py") or header["pins"]["v04_manifest_sha256"] != "be4882960804a9d23fb1b0d633054e3ee85d2d3c0fdec70748f7bba7fddaebdb":
            raise ValueError("EXACT_PARENT_G1_V04_SOURCE_PINS_REQUIRED")
        if header["schema"] != "PaperBMixedActorRegistryHeader/0.2" or header["action_dim"] != 9:
            raise ValueError("G1_V02_HEADER_AND_9D_COMMAND_REQUIRED")
        if set(header["actors"]) != {"STUDENT", "TEACHER"} or header["actors"]["STUDENT"]["actor_id"] == header["actors"]["TEACHER"]["actor_id"] or not 1 <= integer(header["history_cap"]) <= 512:
            raise ValueError("DISTINCT_ACTORS_AND_FINITE_HISTORY_REQUIRED")
        for actor in header["actors"].values():
            if type(actor["actor_id"]) is not str or not actor["actor_id"] or not HASH.fullmatch(str(actor["source_sha256"])):
                raise ValueError("ACTOR_SOURCE_PIN_REQUIRED")
        self.header = json.loads(canonical(header))
        self.tickets, self.returns, self.events = {}, {}, []
        self.absorbing_original_failure = False
        # Execution clock of the latest accepted arrival-log event, across tickets.
        self._accepted_execution_clock = None

    def _event(self, phase, data, *, execution):
        if len(self.events) >= 1024:
            raise ValueError("EVENT_CAP")
        row = {"seq": len(self.events), "phase": phase, "data": copy.deepcopy(data),
               "previous_sha256": self.events[-1]["record_sha256"] if self.events else digest(self.header)}
        row["record_sha256"] = digest(row)
        receipt = copy.deepcopy(row)
        clock = tuple(execution["state"][key] for key in ("tick", "time_ns", "deadline_time_ns"))
        # Nothing advances until hashing and the public receipt have fully succeeded.
        self.events.append(row)
        self._accepted_execution_clock = clock
        return receipt

    def _execution(self, execution):
        plain(execution)
        state = execution["state"]
        if type(state.get("state_id")) is not str or not state["state_id"] or not HASH.fullmatch(str(state.get("physical_state_sha256"))):
            raise ValueError("CURRENT_OBSERVED_STATE_ID_DIGEST_REQUIRED")
        for key in ("tick", "time_ns", "deadline_time_ns"):
            integer(state[key])
        if state["attempt_id"] != self.header["attempt_id"] or state["native_epoch"] != self.header["native_epoch"] or state["deadline_clock_id"] != self.header["original_deadline_clock_id"] or state["collector_source_sha256"] != self.header["pins"]["collector_source_sha256"]:
            raise ValueError("CURRENT_EXECUTION_EPISODE_CLOCK_SOURCE_REQUIRED")
        for value in (state["lawful_state"], execution["known_original_failure"], execution["original_full_failure"]):
            if type(value) is not bool:
                raise ValueError("EXPLICIT_CURRENT_BOOLEAN_FLAGS_REQUIRED")
        clock = tuple(state[key] for key in ("tick", "time_ns", "deadline_time_ns"))
        if self._accepted_execution_clock is not None and any(
                current < accepted for current, accepted in zip(clock, self._accepted_execution_clock)):
            raise ValueError("ACCEPTED_EVENT_EXECUTION_CLOCK_ROLLBACK")
        if self.absorbing_original_failure and not execution["original_full_failure"]:
            raise ValueError("ORIGINAL_FULL_FAILURE_CANNOT_BE_CLEARED")
        self.absorbing_original_failure |= execution["original_full_failure"]
        if execution["active_role"] not in ("STUDENT", "TEACHER"):
            raise ValueError("CURRENT_ACTOR_REQUIRED")
        if self.header["actors"][execution["active_role"]]["actor_id"] != execution["active_actor_id"]:
            raise ValueError("CURRENT_ACTOR_SOURCE_HEADER_MISMATCH")
        return copy.deepcopy(execution)

    def start(self, ticket_id, *, actor_role, execution, prefix, packets, policy_inputs,
              input_bindings, desired_ticks, declared_end_tick, wall_monotonic_ns,
              asset_bytes=(), teacher_private_inputs=None):
        if type(ticket_id) is not str or not ticket_id or ticket_id in self.tickets or len(self.tickets) >= 64:
            raise ValueError("UNIQUE_BOUNDED_INFERENCE_TICKET_REQUIRED")
        current = self._execution(execution); state = current["state"]
        if actor_role not in self.header["actors"]:
            raise ValueError("PINNED_INFERENCE_ACTOR_REQUIRED")
        integer(wall_monotonic_ns); integer(declared_end_tick)
        if len(desired_ticks) != 8 or any(integer(t) < state["tick"] for t in desired_ticks) or any(a >= b for a, b in zip(desired_ticks, desired_ticks[1:])):
            raise ValueError("ORIGINAL_8_SLOT_INCREASING_DESIRED_TICKS_REQUIRED")
        plain(packets, public=True); plain(policy_inputs, public=True); plain(prefix, public=True)
        fields = {"attempt_id", "native_epoch", "start", "end", "length", "digest", "packet_ids", "as_of_time_ns"}
        if type(prefix) is not dict or set(prefix) != fields or prefix["attempt_id"] != state["attempt_id"] or prefix["native_epoch"] != state["native_epoch"] or prefix["as_of_time_ns"] != state["time_ns"]:
            raise ValueError("INFERENCE_START_PREFIX_EXACT_CLOCK_REQUIRED")
        for k in ("start", "end", "length", "as_of_time_ns"):
            integer(prefix[k])
        if not 0 < prefix["length"] == prefix["end"]-prefix["start"] == len(packets) <= self.header["history_cap"] or prefix["packet_ids"] != [p["packet_id"] for p in packets] or prefix["digest"] != digest(packets):
            raise ValueError("ORIGINAL_FINITE_PREFIX_CONTENT_REQUIRED")
        ids = {}
        for packet in packets:
            for k in ("capture_time_ns", "delivery_time_ns"):
                integer(packet[k])
            if not packet["capture_time_ns"] <= packet["delivery_time_ns"] <= state["time_ns"] or packet["packet_id"] in ids or packet["attempt_id"] != state["attempt_id"] or packet["native_epoch"] != state["native_epoch"] or packet["collector_source_sha256"] != state["collector_source_sha256"]:
                raise ValueError("FUTURE_OR_DUPLICATE_OR_FOREIGN_OBSERVATION")
            if packet["state_sha256"] != digest({"features": packet["features"], "assets": packet["assets"]}):
                raise ValueError("PUBLIC_PACKET_CONTENT_DIGEST")
            ids[packet["packet_id"]] = packet
        if set(input_bindings) != set(policy_inputs) or not policy_inputs:
            raise ValueError("ACTUAL_INPUT_REFERENCE_BINDINGS_REQUIRED")
        for key, binding in input_bindings.items():
            if canonical(policy_inputs[key]) != canonical(ids[binding["packet_id"]]["features"][binding["feature_key"]]):
                raise ValueError("INPUT_NOT_ACTUAL_FROZEN_PACKET_REFERENCE")
        binaries, binary_keys, binary_size = [], set(), 0
        for binding in asset_bytes:
            data = binding["data"]
            if type(data) not in (bytes, bytearray):
                raise ValueError("ACTUAL_ALREADY_CAPTURED_BINARY_BYTES_REQUIRED")
            binary_size += len(data)
            key = (binding["packet_id"], binding["asset_index"])
            if binary_size > 16*1024*1024 or key in binary_keys:
                raise ValueError("CAPTURED_BINARY_CAP_OR_DUPLICATE_BINDING")
            binary_keys.add(key)
            frozen = bytes(data)
            asset = ids[binding["packet_id"]]["assets"][integer(binding["asset_index"])]
            if hashlib.sha256(frozen).hexdigest() != asset["sha256"]:
                raise ValueError("CAPTURED_ASSET_BYTES_DIGEST")
            binaries.append((binding["packet_id"], binding["asset_index"], frozen))
        if sum(len(b[2]) for b in binaries) > 16*1024*1024:
            raise ValueError("CAPTURED_BINARY_CAP")
        if teacher_private_inputs is not None and actor_role != "TEACHER":
            raise ValueError("STUDENT_INPUT_CANNOT_INCLUDE_TEACHER_PRIVILEGE")
        private = None if teacher_private_inputs is None else canonical(teacher_private_inputs)
        snapshot = {"ticket_id": ticket_id, "actor_role": actor_role, "actor": self.header["actors"][actor_role],
                    "start_execution": current, "prefix": prefix, "packets": packets, "policy_inputs": policy_inputs,
                    "input_bindings": input_bindings, "desired_ticks": desired_ticks, "declared_end_tick": declared_end_tick,
                    "wall_start_ns": wall_monotonic_ns, "header_sha256": digest(self.header),
                    "teacher_private_input_sha256": None if private is None else hashlib.sha256(private).hexdigest()}
        data = canonical(snapshot)
        self.tickets[ticket_id] = {"snapshot_bytes": data, "snapshot_sha256": hashlib.sha256(data).hexdigest(),
                                   "asset_bytes": tuple(binaries), "private_bytes": private}
        return self._event("INFERENCE_START", {"ticket_id": ticket_id, "snapshot_sha256": hashlib.sha256(data).hexdigest(),
                                               "prefix": prefix, "actor": snapshot["actor"], "teacher_private_input_separate": private is not None}, execution=current)

    def model_inputs(self, ticket_id):
        ticket = self.tickets[ticket_id]; snapshot = json.loads(ticket["snapshot_bytes"])
        return {"policy_inputs": snapshot["policy_inputs"], "prefix": snapshot["prefix"],
                "captured_asset_bytes": ticket["asset_bytes"],
                "asset_scope": "FROZEN_SUPPLIED_ACTUAL_BYTES_ONLY_OTHER_REFERENCES_NOT_BYTE_VERIFIED"}

    def teacher_private_inputs(self, ticket_id):
        value = self.tickets[ticket_id]["private_bytes"]
        return None if value is None else json.loads(value)

    def complete(self, ticket_id, *, original_snapshot_sha256, original_prefix, current_execution,
                 wall_monotonic_ns, chunk):
        if ticket_id in self.returns:
            raise ValueError("INFERENCE_RETURN_ALREADY_RECORDED")
        ticket = self.tickets[ticket_id]; start = json.loads(ticket["snapshot_bytes"])
        if original_snapshot_sha256 != ticket["snapshot_sha256"] or canonical(original_prefix) != canonical(start["prefix"]):
            raise ValueError("RETURN_MUST_BIND_ORIGINAL_INPUT_SNAPSHOT_AND_PREFIX")
        current = self._execution(current_execution); old, new = start["start_execution"]["state"], current["state"]
        integer(wall_monotonic_ns)
        if wall_monotonic_ns < start["wall_start_ns"] or any(new[k] < old[k] for k in ("tick", "time_ns", "deadline_time_ns")):
            raise ValueError("INFERENCE_RETURN_CLOCK_ROLLBACK")
        if type(chunk) is not list or len(chunk) != 8 or any(type(row) is not list or len(row) != 9 or any(type(v) not in (int, float) or not math.isfinite(v) for v in row) for row in chunk):
            raise ValueError("FINITE_8_BY_9_CHUNK_NOT_FLAT72_COMMAND")
        data = {"ticket_id": ticket_id, "snapshot_sha256": ticket["snapshot_sha256"], "original_prefix": start["prefix"],
                "inference_actor": start["actor"], "return_execution": current, "wall_return_ns": wall_monotonic_ns,
                "wall_latency_ns": wall_monotonic_ns-start["wall_start_ns"], "native_ticks_elapsed": new["tick"]-old["tick"],
                "original_deadline_exceeded_at_return": new["deadline_time_ns"] > self.header["original_deadline_ns"],
                "lawful_state_at_return": new["lawful_state"], "chunk": chunk, "actual_submission": False}
        self.returns[ticket_id] = canonical(data)
        return self._event("INFERENCE_RETURN", data, execution=current)

    def guard_submit(self, ticket_id, *, current_execution, earliest_apply_tick, operation_purpose="ORIGINAL_GOAL", safety_authorizations=None):
        returned = json.loads(self.returns[ticket_id]); start = json.loads(self.tickets[ticket_id]["snapshot_bytes"])
        current = self._execution(current_execution); state = current["state"]; old = returned["return_execution"]["state"]
        if any(state[k] < old[k] for k in ("tick", "time_ns", "deadline_time_ns")) or integer(earliest_apply_tick) < state["tick"]:
            raise ValueError("SUBMIT_CURRENT_CLOCK_AND_EARLIEST_APPLICATION_REQUIRED")
        if operation_purpose not in ("ORIGINAL_GOAL", "SAFE_LOCAL_RECOVERY", "SAFETY_ABORT"):
            raise ValueError("EXPLICIT_OPERATION_PURPOSE_REQUIRED")
        authorizations = safety_authorizations or {}
        slots = []
        for i, (target, desired_tick) in enumerate(zip(returned["chunk"], start["desired_ticks"])):
            reasons = []
            if current["active_actor_id"] != start["actor"]["actor_id"]:
                reasons.append("INFERENCE_OWNER_NOT_CURRENT_ACTOR")
            if desired_tick < earliest_apply_tick:
                reasons.append("STALE_ORIGINAL_DESIRED_TICK")
            if desired_tick >= start["declared_end_tick"]:
                reasons.append("DECLARED_EPISODE_TAIL_CENSORED")
            if operation_purpose == "ORIGINAL_GOAL":
                if not state["lawful_state"]: reasons.append("UNSAFE_CURRENT_EXECUTION_STATE")
                if state["deadline_time_ns"] > self.header["original_deadline_ns"]: reasons.append("ORIGINAL_DEADLINE_EXCEEDED_NOW")
                if current["original_full_failure"]: reasons.append("ABSORBING_ORIGINAL_FAILURE_NOW")
                if authorizations: reasons.append("ORIGINAL_GOAL_AUTHORIZATION_MUST_BE_NULL")
            else:
                if operation_purpose == "SAFE_LOCAL_RECOVERY" and (not current["known_original_failure"] or (state["deadline_time_ns"] > self.header["original_deadline_ns"] and not current["original_full_failure"])):
                    reasons.append("KNOWN_LOCAL_OR_POST_DEADLINE_ORIGINAL_FAILURE_REQUIRED")
                auth = authorizations.get(i)
                if type(auth) is not dict or set(auth) != {"source_sha256", "artifact_sha256", "observed_state_id", "operation_purpose", "target_sha256", "verdict"} or auth["source_sha256"] != self.header["pins"]["safety_authorizer_source_sha256"] or not HASH.fullmatch(str(auth["artifact_sha256"])) or auth["observed_state_id"] != state["state_id"] or auth["operation_purpose"] != operation_purpose or auth["target_sha256"] != digest(target) or auth["verdict"] != "LAWFUL_TARGET_AUTHORIZED":
                    reasons.append("TRUSTED_CURRENT_STATE_PER9D_TARGET_AUTHORIZATION_REQUIRED")
            slots.append({"slot": i, "target": target, "original_desired_tick": desired_tick,
                          "owner": start["actor"], "eligible_by_current_guard": not reasons, "reasons": reasons,
                          "safety_authorization": copy.deepcopy(authorizations.get(i)),
                          "actual_submitted": False, "actual_APPLIED": False})
        return self._event("CURRENT_ACTION_SUBMIT_GUARD", {"ticket_id": ticket_id, "original_prefix": start["prefix"],
            "snapshot_sha256": returned["snapshot_sha256"], "current_execution": current, "slots": slots,
            "operation_purpose": operation_purpose,
            "adapter_status": "NOT_INTEGRATED_G1_ASYNC_PROPOSAL_SCHEMA", "physical_authenticity": "NOT_PROVEN", "S_F_R_admitted": 0}, execution=current)
