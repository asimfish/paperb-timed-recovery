# Version 0.4 recovery regression contract

Preserve the original 80 tests and frozen receipts byte-exact in original_v03_snapshot. Add 18 meaningful recovery tests, with an independent frozen-v03 red replay and v04 green replay. Audit arrival170 with onset40_50 must not verify label160; moving only label to180 must pass. Native same-time source order decides evidence availability. Audit125 after decision120 but before label160 remains legitimate privileged supervision.

UNKNOWN future anchor verification remains UNKNOWN and future onset is not read. Original missing anchor rejects. Multiple anchors require all known at label. Verified recovery success requires APPLIED on declared required controls even when global objective is FALSE or UNKNOWN; definite failed TIMEOUT remains eligible RL when recovery is UNKNOWN. STATE/PROPOSAL cannot supply the original execution failure.

Full CPU98 gate, source/schema equality, unchanged old19 metadata hashes, zero native imports, writer/readback positives and retained rejected raw logs without CLOSE, immutable v02/v03 hashes, safe archive reopening and byte identity are required. No real images, SDK, native, GPU, training or parameter updates. CPU qualification is not source attestation or whole-task physical validation.
