"""Strict JSON schemas; data-only CPU boundary, draft-07."""


def obj(props, required=None):
    return {"type": "object", "properties": props,
            "required": list(props) if required is None else required,
            "additionalProperties": False}


S = {"type": "string", "minLength": 1}
NS = {"type": "integer", "minimum": 0}
SHA = {"type": "string", "pattern": "^[0-9a-f]{64}$"}
BOOL = {"type": "boolean"}
NUM = {"type": "number"}
TRI = {"enum": ["TRUE", "FALSE", "UNKNOWN"]}
STRINGS = {"type": "array", "items": S, "uniqueItems": True}
TARGET = {"type": "array", "minItems": 1, "items": NUM}
PIN = obj({"protocol_sha256": SHA, "collector_source_sha256": SHA,
           "split_plan_sha256": SHA})
ASSET = obj({"relative_path": S, "sha256": SHA, "byte_count": NS,
             "encoding": {"enum": ["JSON_FIXTURE", "RAW_BYTES", "JPEG", "PNG", "NPY"]},
             "modality": {"enum": ["SYNTHETIC_JSON", "RGB", "DEPTH", "PUBLIC_DATA"]},
             "shape": {"type": "array", "items": NS}})
HEADER = obj({
    "schema": {"const": "CausalStudentCapture/0.4"}, "episode_id": S,
    "actor_epoch": S, "clock_id": S,
    "dataset_kind": {"enum": ["CPU_FIXTURE", "PRODUCTION"]},
    "actor": obj({"actor_id": S, "source_sha256": SHA,
                  "kind": {"enum": ["STUDENT", "PUBLIC_EXPERT", "PRIVILEGED_TEACHER"]}}),
    "original_role": {"enum": ["train", "validation", "test", "calibration", "development"]},
    "split": obj({"pool": {"enum": ["FUTURE_TRAIN", "LEGACY_SEEN_TRAIN", "FUTURE_VALIDATION", "FUTURE_HELDOUT", "DEVELOPMENT_SEEN"]},
                  "group_id": S, "prospectively_frozen": BOOL,
                  "original_role_training_use": {"enum": [None, "EXPLICIT_PRESERVE_ORIGINAL_ROLE"]}}),
    "seen_before_protocol": BOOL, "pins": PIN,
    "supervision_sources": obj({"audit_sha256": {"type": "array", "items": SHA, "minItems": 1, "uniqueItems": True},
                               "teacher_sha256": {"type": "array", "items": SHA, "uniqueItems": True}}),
    "observation_mode": {"enum": ["ONLINE_DELIVERED", "OFFLINE_CAPTURE"]},
    "offline_capture_rule": {"enum": [None, "CAPTURE_BEFORE_FUTURE_SUBMISSION"]},
    "physical_effect_not_assumed_from_ack": {"const": True}})
SLOT = obj({"slot_id": S, "requested_submit_time_ns": NS, "target": TARGET,
            "required_for_execution": BOOL})
RECOVERY = obj({"failure_row_id": S, "feedback_obs_id": S,
                "original_anchor_event_ids": STRINGS,
                "verified": TRI, "recovered_objective": TRI,
                "audit_source_sha256": SHA})
PAYLOADS = {
    "capture": obj({"time_ns": NS, "obs_id": S,
                    "source_channel": {"enum": ["PUBLIC_RENDERER", "PUBLIC_SENSORS", "CPU_FIXTURE"]},
                    "source_sha256": SHA, "immutable_snapshot": {"const": True},
                    "features": {"type": "object"},
                    "assets": {"type": "array", "items": ASSET},
                    "state_sha256": SHA}),
    "delivery": obj({"time_ns": NS, "obs_id": S, "actor_id": S}),
    "visit": obj({"time_ns": NS, "obs_id": S, "actor_id": S, "state_sha256": SHA}),
    "chunk": obj({"time_ns": NS, "chunk_id": S, "obs_id": S, "actor_id": S,
                  "semantic": {"const": "FUTURE_SUBMITTED_CONTROL"},
                  "slots": {"type": "array", "minItems": 1, "items": SLOT}}),
    "submit": obj({"time_ns": NS, "chunk_id": S, "slot_id": S,
                   "request_id": S, "actor_id": S, "target": TARGET}),
    "unsubmitted": obj({"time_ns": NS, "chunk_id": S, "slot_id": S,
                        "reason": {"enum": ["TERMINAL_TAIL", "REFUSED", "FAILED"]}}),
    "channel_result": obj({"time_ns": NS, "request_id": S,
                          "status": {"enum": ["APPLIED", "DROPPED", "REJECTED", "TIMEOUT"]},
                          "application_time_ns": {"type": ["integer", "null"], "minimum": 0},
                          "effect_status": {"enum": ["UNKNOWN", "SEPARATE_AUDIT_REQUIRED"]}}),
    "audit_event": obj({"time_ns": NS, "event_id": S, "kind": S,
                        "onset_interval_ns": {"type": "array", "minItems": 2, "maxItems": 2, "items": NS},
                        "audit_source_sha256": SHA}),
    "outcome": obj({"time_ns": NS, "row_id": S, "obs_id": S,
                    "label_kind": {"enum": ["EXECUTION_OUTCOME", "STATE_LABEL", "PROPOSAL_LABEL"]},
                    "next_obs_id": {"type": ["string", "null"]}, "chunk_id": S,
                    "objective_name": S, "objective": TRI,
                    "failure_vector": STRINGS,
                    "reward": {"type": ["number", "null"]},
                    "reward_status": {"enum": ["KNOWN", "UNKNOWN"]},
                    "terminal": BOOL, "audit_source_sha256": SHA,
                    "recovery": {"anyOf": [{"type": "null"}, RECOVERY]}}),
    "teacher_query": obj({"time_ns": NS, "query_id": S, "obs_id": S,
                          "student_actor_id": S, "state_sha256": SHA,
                          "teacher_id": S,
                          "teacher_source": {"enum": ["PRIVILEGED", "DEPLOYMENT_PUBLIC"]},
                          "teacher_source_sha256": SHA,
                          "teacher_privileged_input": {"type": "object"},
                          "target_time_ns": NS, "target": TARGET})}
STREAMS = {k: "student" for k in ["capture", "delivery", "visit"]}
STREAMS.update({k: "control" for k in ["chunk", "submit", "unsubmitted", "channel_result"]})
STREAMS.update({k: "supervision" for k in ["audit_event", "outcome", "teacher_query"]})
EVENT = {"$schema": "http://json-schema.org/draft-07/schema#", "oneOf": [
    obj({"schema": {"const": "CausalStudentEvent/0.4"}, "seq": NS,
         "episode_id": S, "actor_epoch": S, "clock_id": S,
         "kind": {"const": k}, "payload": p}) for k, p in PAYLOADS.items()]}
SCHEMA = {"$schema": "http://json-schema.org/draft-07/schema#",
          "title": "Causal student capture data contract 0.4",
          "definitions": {"header": HEADER, "event": EVENT,
                          "recovery": RECOVERY},
          "oneOf": [HEADER, EVENT]}
