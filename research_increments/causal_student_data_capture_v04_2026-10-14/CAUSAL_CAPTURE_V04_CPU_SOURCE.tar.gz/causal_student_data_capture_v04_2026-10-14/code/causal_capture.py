"""Append-only student observation/control/supervision recorder and readback.

No physics, hardware, images, tensor library or model execution. Privileged
teachers may label BC/OPD, but never populate exported student features.
"""
import hashlib
import json
import math
import os
from pathlib import Path

from jsonschema import Draft7Validator
from schema_definition import EVENT, HEADER, STREAMS

FEATURE_KEYS = {"instruction", "public_contract", "public_installation_metadata",
                "public_packet", "public_ack", "public_reservations", "proprioception",
                "clock", "history"}
PRIVATE_KEYS = {"private_state", "object_pose", "referee", "fault", "fault_id",
                "known_drop_oracle", "ground_truth", "contact_rows", "reward",
                "success", "event_truth", "labels", "audit_only", "teacher_label"}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def plain(value, *, public=False):
    """Exact builtin data only; not a hostile-process sandbox."""
    if type(value) is dict:
        for key, child in value.items():
            if type(key) is not str:
                raise ValueError("NON_STRING_KEY")
            if public and (key in PRIVATE_KEYS or key.startswith("private_")):
                raise ValueError("PRIVILEGED_STUDENT_FEATURE")
            plain(child, public=public)
    elif type(value) is list:
        for child in value:
            plain(child, public=public)
    elif type(value) not in (str, int, float, bool, type(None)):
        raise ValueError("NON_PLAIN_VALUE")
    elif type(value) is float and not math.isfinite(value):
        raise ValueError("NONFINITE_VALUE")


def checked(schema, value):
    plain(value)
    errors = sorted(Draft7Validator(schema).iter_errors(value), key=lambda e: str(e.path))
    if errors:
        raise ValueError("SCHEMA_MISMATCH:" + errors[0].message)


def validate_header(header):
    checked(HEADER, header)
    if header["clock_id"] != header["episode_id"] + ":" + header["actor_epoch"]:
        raise ValueError("CLOCK_NOT_EPOCH_NAMESPACED")
    if header["observation_mode"] == "OFFLINE_CAPTURE":
        if header["offline_capture_rule"] != "CAPTURE_BEFORE_FUTURE_SUBMISSION":
            raise ValueError("OFFLINE_CAPTURE_RULE_NOT_DECLARED")
    elif header["offline_capture_rule"] is not None:
        raise ValueError("ONLINE_MODE_WITH_OFFLINE_RULE")
    pool = header["split"]["pool"]
    if pool == "FUTURE_HELDOUT" and (header["seen_before_protocol"] or not header["split"]["prospectively_frozen"]):
        raise ValueError("SEEN_OR_UNFROZEN_HELDOUT")
    if pool == "LEGACY_SEEN_TRAIN" and not header["seen_before_protocol"]:
        raise ValueError("LEGACY_TRAIN_WITHOUT_SEEN_IDENTITY")
    training = pool in {"LEGACY_SEEN_TRAIN", "FUTURE_TRAIN"}
    declaration = header["split"]["original_role_training_use"]
    if training and header["original_role"] in {"calibration", "test"} and declaration != "EXPLICIT_PRESERVE_ORIGINAL_ROLE":
        raise ValueError("ORIGINAL_TEST_OR_CALIBRATION_TRAIN_USE_NOT_DECLARED")
    if declaration is not None and not training:
        raise ValueError("ROLE_TRAIN_DECLARATION_OUTSIDE_TRAIN_POOL")


def check_split_groups(headers):
    ids, groups = set(), {}
    for h in headers:
        validate_header(h)
        if h["episode_id"] in ids:
            raise ValueError("DUPLICATE_EPISODE")
        ids.add(h["episode_id"])
        group, pool = h["split"]["group_id"], h["split"]["pool"]
        if group in groups and groups[group] != pool:
            raise ValueError("RELATED_GROUP_CROSSES_SPLITS")
        groups[group] = pool
    return groups


def state_digest(features, assets):
    return digest({"features": features, "assets": assets})


def validate_event(header, event):
    checked(EVENT, event)
    for key in ["episode_id", "actor_epoch", "clock_id"]:
        if event[key] != header[key]:
            raise ValueError("CROSS_EPOCH_OR_EPISODE")
    p, kind = event["payload"], event["kind"]
    if kind in ["audit_event", "outcome"] and p["audit_source_sha256"] not in header["supervision_sources"]["audit_sha256"]:
        raise ValueError("AUDIT_SOURCE_NOT_PROTOCOL_PINNED")
    if kind == "outcome" and p["recovery"] is not None and p["recovery"]["audit_source_sha256"] not in header["supervision_sources"]["audit_sha256"]:
        raise ValueError("RECOVERY_SOURCE_NOT_PROTOCOL_PINNED")
    if kind == "teacher_query" and p["teacher_source_sha256"] not in header["supervision_sources"]["teacher_sha256"]:
        raise ValueError("TEACHER_SOURCE_NOT_PROTOCOL_PINNED")
    if kind == "capture":
        if set(p["features"]) - FEATURE_KEYS:
            raise ValueError("UNKNOWN_STUDENT_FEATURE")
        plain(p["features"], public=True)
        if p["state_sha256"] != state_digest(p["features"], p["assets"]):
            raise ValueError("STATE_DIGEST_MISMATCH")
        if not p["assets"] and not p["features"]:
            raise ValueError("EMPTY_STUDENT_OBSERVATION")
        if header["dataset_kind"] == "PRODUCTION" and (p["source_channel"] == "CPU_FIXTURE" or
            any(a["encoding"] == "JSON_FIXTURE" or a["modality"] == "SYNTHETIC_JSON" for a in p["assets"])):
            raise ValueError("FIXTURE_NOT_PRODUCTION_OBSERVATION")
        if p["source_sha256"] != header["pins"]["collector_source_sha256"]:
            raise ValueError("CAPTURE_SOURCE_PIN_MISMATCH")


def verify_assets(capture, asset_root):
    root = Path(asset_root).resolve(strict=True)
    for asset in capture["assets"]:
        relative = Path(asset["relative_path"])
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("ASSET_PATH_ESCAPE")
        path = (root / relative).resolve(strict=True)
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError("ASSET_PATH_ESCAPE")
        if path.stat().st_size != asset["byte_count"] or file_sha(path) != asset["sha256"]:
            raise ValueError("ASSET_BYTES_MISMATCH")


def _decision(status, reasons):
    return {"eligible_by_contract": status, "reasons": reasons}


def derive(header, events, asset_root):
    """Reconstruct evidence; missing facts remain UNKNOWN, never fabricated."""
    captures, deliveries, visits, chunks, requests = {}, {}, {}, {}, {}
    slots, applications, audits, outcomes, queries = {}, {}, {}, [], []
    last_time = -1
    for expected_seq, event in enumerate(events):
        validate_event(header, event)
        if event["seq"] != expected_seq:
            raise ValueError("NONCONTIGUOUS_SEQUENCE")
        kind, p = event["kind"], event["payload"]
        t = p["time_ns"]
        if t < last_time:
            raise ValueError("LOG_TIME_ROLLBACK")
        last_time = t
        p = dict(p, _seq=event["seq"])
        if kind == "capture":
            if p["obs_id"] in captures:
                raise ValueError("OBSERVATION_ID_REUSED")
            verify_assets(p, asset_root)
            captures[p["obs_id"]] = p
        elif kind in ("delivery", "visit"):
            if p["obs_id"] not in captures or p["actor_id"] != header["actor"]["actor_id"]:
                raise ValueError("UNKNOWN_OBSERVATION_OR_ACTOR")
            if kind == "delivery":
                if p["obs_id"] in deliveries:
                    raise ValueError("DELIVERY_ID_REUSED")
                deliveries[p["obs_id"]] = p
            else:
                if header["actor"]["kind"] != "STUDENT":
                    raise ValueError("NONSTUDENT_VISIT")
                if p["state_sha256"] != captures[p["obs_id"]]["state_sha256"]:
                    raise ValueError("VISITED_STATE_MISMATCH")
                if p["obs_id"] not in deliveries:
                    raise ValueError("VISIT_WITHOUT_DELIVERY")
                if p["obs_id"] in visits:
                    raise ValueError("VISIT_ID_REUSED")
                visits[p["obs_id"]] = p
        elif kind == "chunk":
            if p["chunk_id"] in chunks or p["obs_id"] not in captures or p["actor_id"] != header["actor"]["actor_id"]:
                raise ValueError("UNKNOWN_CHUNK_OBSERVATION_OR_ACTOR")
            if any(s["requested_submit_time_ns"] < t for s in p["slots"]):
                raise ValueError("CHUNK_TARGETS_PAST_SUBMISSION")
            if len({s["slot_id"] for s in p["slots"]}) != len(p["slots"]):
                raise ValueError("CHUNK_SLOT_ID_REUSED")
            chunks[p["chunk_id"]] = p
        elif kind in ("submit", "unsubmitted"):
            chunk = chunks.get(p["chunk_id"])
            if chunk is None:
                raise ValueError("CONTROL_WITHOUT_CHUNK")
            intended = next((s for s in chunk["slots"] if s["slot_id"] == p["slot_id"]), None)
            key = (p["chunk_id"], p["slot_id"])
            if intended is None or key in slots:
                raise ValueError("UNKNOWN_OR_REUSED_SLOT")
            if kind == "submit":
                if p["actor_id"] != header["actor"]["actor_id"] or p["target"] != intended["target"]:
                    raise ValueError("SUBMITTED_TARGET_OR_ACTOR_MISMATCH")
                if t < intended["requested_submit_time_ns"] or p["request_id"] in requests:
                    raise ValueError("EARLY_SUBMISSION_OR_REUSED_REQUEST")
                requests[p["request_id"]] = p
            slots[key] = (kind, p)
        elif kind == "channel_result":
            request = requests.get(p["request_id"])
            if request is None or p["request_id"] in applications:
                raise ValueError("UNKNOWN_OR_REUSED_CHANNEL_RESULT")
            app = p["application_time_ns"]
            if p["status"] == "APPLIED":
                if app is None or not request["time_ns"] <= app <= t:
                    raise ValueError("APPLICATION_PRECEDES_SUBMISSION_OR_FUTURE")
            elif app is not None:
                raise ValueError("NONAPPLIED_WITH_APPLICATION_TIME")
            applications[p["request_id"]] = p
        elif kind == "audit_event":
            interval = p["onset_interval_ns"]
            if not p["event_id"].startswith(header["clock_id"] + ":") or p["event_id"] in audits:
                raise ValueError("ORIGINAL_EVENT_ID_REUSED_OR_FOREIGN")
            if interval[0] > interval[1] or interval[1] > t:
                raise ValueError("AUDIT_INTERVAL_INVALID_OR_FUTURE")
            audits[p["event_id"]] = p
        elif kind == "outcome":
            if p["row_id"] in {o["row_id"] for o in outcomes}:
                raise ValueError("ROW_ID_REUSED")
            if p["obs_id"] not in captures or p["chunk_id"] not in chunks:
                raise ValueError("OUTCOME_UNKNOWN_STATE_OR_CHUNK")
            if chunks[p["chunk_id"]]["obs_id"] != p["obs_id"]:
                raise ValueError("OUTCOME_CHUNK_OBSERVATION_MISMATCH")
            if p["next_obs_id"] is not None and p["next_obs_id"] not in captures:
                raise ValueError("OUTCOME_NEXT_OBSERVATION_UNKNOWN")
            if (p["reward_status"] == "KNOWN") != (p["reward"] is not None):
                raise ValueError("REWARD_KNOWN_MASK_MISMATCH")
            outcomes.append(p)
        elif kind == "teacher_query":
            if p["query_id"] in {q["query_id"] for q in queries} or p["obs_id"] not in captures:
                raise ValueError("QUERY_ID_REUSED_OR_UNKNOWN_STATE")
            if p["target_time_ns"] < t:
                raise ValueError("TEACHER_TARGET_IN_PAST")
            if p["state_sha256"] != captures[p["obs_id"]]["state_sha256"]:
                raise ValueError("TEACHER_STATE_MISMATCH")
            if p["student_actor_id"] != header["actor"]["actor_id"]:
                raise ValueError("TEACHER_STUDENT_ID_MISMATCH")
            if p["teacher_source"] == "DEPLOYMENT_PUBLIC" and p["teacher_privileged_input"]:
                raise ValueError("PUBLIC_TEACHER_WITH_PRIVILEGED_INPUT")
            queries.append(p)

    def occurred_by(value, cutoff):
        return (value["time_ns"], value["_seq"]) < (cutoff["time_ns"], cutoff["_seq"])

    def causal(chunk, cutoff):
        obs = captures[chunk["obs_id"]]
        reasons = []
        if header["observation_mode"] == "ONLINE_DELIVERED":
            delivery = deliveries.get(chunk["obs_id"])
            if delivery is None:
                reasons.append("MISSING_STUDENT_DELIVERY")
            elif (delivery["time_ns"], delivery["_seq"]) > (chunk["time_ns"], chunk["_seq"]):
                reasons.append("DELIVERY_AFTER_DECISION")
        # Global sequence and monotonic time establish capture-before-chunk.
        mask, submitted = [], []
        for intended in chunk["slots"]:
            slot = slots.get((chunk["chunk_id"], intended["slot_id"]))
            if slot is not None and not occurred_by(slot[1], cutoff):
                reasons.append("CONTROL_NOT_OCCURRED_BY_LABEL")
                slot = None
            if slot is None:
                reasons.append("MISSING_SUBMISSION_OR_EXPLICIT_TAIL_MASK")
                mask.append(None)
            else:
                mask.append(slot[0] == "submit")
                if slot[0] == "submit":
                    submitted.append(slot[1])
        if not submitted:
            reasons.append("NO_ACTUAL_FUTURE_SUBMITTED_LABEL")
        return reasons, mask, submitted

    def execution_evidence(chunk, outcome, submitted):
        """Only the as-of prefix can support an execution label.

        Required slots are declared in the immutable chunk. Optional tail slots
        may be masked, but later commands cannot be backfilled into a past row.
        A channel application is still not itself proof of physical success;
        the independent pinned objective label remains necessary.
        """
        if outcome["label_kind"] != "EXECUTION_OUTCOME":
            return ["NON_EXECUTION_LABEL"]
        rec = outcome["recovery"]
        success = outcome["objective"] == "TRUE" or (
            rec is not None and rec["verified"] == "TRUE" and rec["recovered_objective"] == "TRUE")
        known = outcome["objective"] != "UNKNOWN" or success
        required = [s for s in chunk["slots"] if s["required_for_execution"]]
        if not required:
            raise ValueError("EXECUTION_OUTCOME_WITHOUT_REQUIRED_CONTROLS")
        reasons = []
        for intended in required:
            slot = slots.get((chunk["chunk_id"], intended["slot_id"]))
            if slot is None or not occurred_by(slot[1], outcome):
                if known:
                    raise ValueError("EXECUTION_LABEL_BEFORE_REQUIRED_SUBMISSION_OR_ABORT")
                reasons.append("REQUIRED_CONTROL_UNKNOWN_AT_LABEL")
                continue
            if slot[0] == "unsubmitted":
                if success:
                    raise ValueError("EXECUTION_SUCCESS_WITH_UNSUBMITTED_REQUIRED_CONTROL")
                continue
            application = applications.get(slot[1]["request_id"])
            if application is None or not occurred_by(application, outcome):
                if known:
                    raise ValueError("EXECUTION_LABEL_BEFORE_REQUIRED_CHANNEL_RESULT")
                reasons.append("CHANNEL_RESULT_UNKNOWN_AT_LABEL")
        for submission in submitted:
            application = applications.get(submission["request_id"])
            if application is None or not occurred_by(application, outcome):
                if known:
                    raise ValueError("EXECUTION_LABEL_BEFORE_RELATED_CHANNEL_RESULT")
                reasons.append("RELATED_CHANNEL_RESULT_UNKNOWN_AT_LABEL")
            elif success and application["status"] != "APPLIED":
                raise ValueError("NONAPPLIED_CONTROL_CANNOT_SUPPORT_EXECUTION_SUCCESS")
        return reasons

    rows = []
    out_by_id = {o["row_id"]: o for o in outcomes}
    for outcome in outcomes:
        chunk = chunks[outcome["chunk_id"]]
        base_reasons, mask, submitted = causal(chunk, outcome)
        execution_reasons = execution_evidence(chunk, outcome, submitted)
        base_reasons.extend(execution_reasons)
        scope = outcome["objective"]
        bc = _decision("UNKNOWN", base_reasons) if base_reasons else _decision(
            "TRUE" if scope == "TRUE" else "FALSE" if scope == "FALSE" else "UNKNOWN",
            [] if scope == "TRUE" else ["SCOPED_OBJECTIVE_" + scope])
        recovery, rec = _decision("FALSE", ["NO_VERIFIED_RECOVERY_LABEL"]), outcome["recovery"]
        if rec is not None:
            if outcome["label_kind"] != "EXECUTION_OUTCOME":
                raise ValueError("RECOVERY_REQUIRES_EXECUTION_OUTCOME_LABEL")
            failure = out_by_id.get(rec["failure_row_id"])
            feedback = captures.get(rec["feedback_obs_id"])
            if failure is None or failure["objective"] != "FALSE" or not occurred_by(failure, outcome):
                raise ValueError("RECOVERY_ORIGINAL_FAILURE_MISSING")
            if failure["label_kind"] != "EXECUTION_OUTCOME":
                raise ValueError("RECOVERY_ORIGINAL_FAILURE_NOT_EXECUTION_OUTCOME")
            if not rec["original_anchor_event_ids"] or any(a not in audits for a in rec["original_anchor_event_ids"]):
                raise ValueError("RECOVERY_ORIGINAL_ANCHOR_MISSING")
            # Physical onset and arrival of its independent audit are distinct.
            # A late audit cannot verify an earlier label, even when its onset
            # interval describes a past event. Unknown labels retain only the
            # audit facts that were actually available in their own prefix.
            anchors = [audits[a] for a in rec["original_anchor_event_ids"]]
            known_anchors = [a for a in anchors if occurred_by(a, outcome)]
            anchor_unknown = len(known_anchors) != len(anchors)
            if anchor_unknown and rec["verified"] != "UNKNOWN":
                raise ValueError("RECOVERY_ANCHOR_NOT_KNOWN_AT_LABEL")
            if feedback is None or feedback["time_ns"] < chunks[failure["chunk_id"]]["time_ns"]:
                raise ValueError("RECOVERY_FEEDBACK_MISSING_OR_PREFAILURE_ACTION")
            if any(feedback["time_ns"] < a["onset_interval_ns"][1] for a in known_anchors):
                raise ValueError("RECOVERY_FEEDBACK_PRECEDES_ORIGINAL_EVENT")
            if (feedback["time_ns"], feedback["_seq"]) > (chunk["time_ns"], chunk["_seq"]):
                raise ValueError("RECOVERY_FEEDBACK_AFTER_RECOVERY_DECISION")
            r = list(base_reasons)
            if anchor_unknown:
                r.append("RECOVERY_ANCHOR_UNKNOWN_AT_LABEL")
            if header["observation_mode"] == "ONLINE_DELIVERED":
                d = deliveries.get(rec["feedback_obs_id"])
                if d is None or (d["time_ns"], d["_seq"]) > (chunk["time_ns"], chunk["_seq"]):
                    r.append("RECOVERY_FEEDBACK_NOT_DELIVERED")
            vals = [rec["verified"], rec["recovered_objective"]]
            value = "FALSE" if "FALSE" in vals else "UNKNOWN" if "UNKNOWN" in vals or r else "TRUE"
            recovery = _decision(value, r + ([] if value == "TRUE" else ["RECOVERY_NOT_VERIFIED_TRUE"]))
        rl_reasons = list(base_reasons)
        nxt = captures.get(outcome["next_obs_id"])
        if nxt is None:
            rl_reasons.append("MISSING_NEXT_OBSERVATION")
        elif submitted and (nxt["time_ns"], nxt["_seq"]) <= max((s["time_ns"], s["_seq"]) for s in submitted):
            rl_reasons.append("NEXT_OBSERVATION_NOT_AFTER_SUBMITTED_ACTION")
        if outcome["reward_status"] != "KNOWN":
            rl_reasons.append("REWARD_UNKNOWN_NOT_ZERO")
        if any(s["request_id"] not in applications or not occurred_by(applications[s["request_id"]], outcome) for s in submitted):
            rl_reasons.append("CHANNEL_TERMINAL_STATUS_MISSING")
        elif nxt is not None and any((applications[s["request_id"]]["time_ns"], applications[s["request_id"]]["_seq"]) >
                                    (nxt["time_ns"], nxt["_seq"]) for s in submitted):
            rl_reasons.append("NEXT_OBSERVATION_PRECEDES_CHANNEL_TERMINAL_RESULT")
        rl = _decision("UNKNOWN" if rl_reasons else "TRUE", rl_reasons)
        rows.append({"row_id": outcome["row_id"], "objective_name": outcome["objective_name"],
                     "label_kind": outcome["label_kind"],
                     "objective": scope, "failure_vector": outcome["failure_vector"],
                     "chunk_id": outcome["chunk_id"], "submitted_label_mask": mask,
                     "bc_success": bc, "bc_recovery": recovery, "offline_rl": rl,
                     "student_observation_id": outcome["obs_id"],
                     "student_available_history_ids": [oid for oid, cp in captures.items()
                         if (cp["time_ns"], cp["_seq"]) <= (chunk["time_ns"], chunk["_seq"])
                         and (header["observation_mode"] == "OFFLINE_CAPTURE" or
                              (oid in deliveries and (deliveries[oid]["time_ns"], deliveries[oid]["_seq"]) <=
                               (chunk["time_ns"], chunk["_seq"])))],
                     "not_full_episode_success_from_local_label": True})
        if outcome["label_kind"] != "EXECUTION_OUTCOME":
            rows[-1]["bc_success"] = _decision("FALSE", ["STATE_OR_PROPOSAL_IS_NOT_EXECUTION_SUCCESS"])
            rows[-1]["bc_recovery"] = _decision("FALSE", ["STATE_OR_PROPOSAL_IS_NOT_EXECUTED_RECOVERY"])
            rows[-1]["offline_rl"] = _decision("FALSE", ["STATE_OR_PROPOSAL_IS_NOT_EXECUTED_RL_TRANSITION"])
    opd = []
    for query in queries:
        reasons = []
        visit = visits.get(query["obs_id"])
        if header["actor"]["kind"] != "STUDENT" or visit is None:
            reasons.append("NO_ACTUAL_STUDENT_VISIT_EVIDENCE")
        elif (visit["time_ns"], visit["_seq"]) > (query["time_ns"], query["_seq"]):
            reasons.append("QUERY_BEFORE_STUDENT_VISIT")
        opd.append({"query_id": query["query_id"], "teacher_source": query["teacher_source"],
                    "opd_student_state_label": _decision("UNKNOWN" if reasons else "TRUE", reasons)})
    eligible_rows = sum(any(r[k]["eligible_by_contract"] == "TRUE" for k in
                            ["bc_success", "bc_recovery", "offline_rl"]) for r in rows)
    eligible_opd = sum(q["opd_student_state_label"]["eligible_by_contract"] == "TRUE" for q in opd)
    return {"status": "PASS_READBACK_CONTRACT", "episode_id": header["episode_id"],
            "dataset_kind": header["dataset_kind"], "rows": rows, "teacher_queries": opd,
            "event_count": len(events), "capture_count": len(captures),
            "synthetic_fixture_eligible_rows": eligible_rows + eligible_opd if header["dataset_kind"] == "CPU_FIXTURE" else 0,
            "actual_production_rows": eligible_rows + eligible_opd if header["dataset_kind"] == "PRODUCTION" else 0,
            "admitted_for_current_training_rows": 0,
            "native_epochs": 0, "GPU_work": 0, "parameter_updates": 0}


def student_projection(header, events):
    """Only public capture data; teacher/reward/audit labels cannot join inputs."""
    output = []
    for event in events:
        validate_event(header, event)
        if event["kind"] == "capture":
            p = event["payload"]
            output.append({"obs_id": p["obs_id"], "capture_time_ns": p["time_ns"],
                           "clock_id": header["clock_id"], "features": p["features"],
                           "assets": p["assets"], "state_sha256": p["state_sha256"]})
    return output


class JsonlCaptureWriter:
    """Single-owner write-once episode; no resume or overwritten log files."""
    def __init__(self, output, header, asset_root, *, expected_pins=None):
        validate_header(header)
        if header["dataset_kind"] == "PRODUCTION" and expected_pins is None:
            raise ValueError("PRODUCTION_REQUIRES_COLLECTOR_EXPECTED_PINS")
        if expected_pins is not None and header["pins"] != expected_pins:
            raise ValueError("EXPECTED_PROTOCOL_PINS_MISMATCH")
        self.output, self.asset_root = Path(output), Path(asset_root)
        self.output.mkdir(parents=True, exist_ok=False)
        self.header = json.loads(canonical(header))
        self.events, self.prev, self.closed = [], "0" * 64, False
        self.seen_obs, self.last_time = set(), -1
        (self.output / "HEADER.json").write_bytes(canonical(self.header) + b"\n")
        for name in ["index", "student", "control", "supervision"]:
            (self.output / (name + ".jsonl")).touch(exist_ok=False)

    def append(self, kind, payload):
        if self.closed:
            raise ValueError("CLOSED_LOG")
        event = {"schema": "CausalStudentEvent/0.4", "seq": len(self.events),
                 **{k: self.header[k] for k in ["episode_id", "actor_epoch", "clock_id"]},
                 "kind": kind, "payload": payload}
        validate_event(self.header, event)
        # Constant-size append checks; full semantic reconstruction is at close
        # and independent readback. Revalidating the entire prefix on every
        # append would make a high-rate command journal quadratic.
        p = event["payload"]
        if p["time_ns"] < self.last_time:
            raise ValueError("LOG_TIME_ROLLBACK")
        if kind == "capture":
            if p["obs_id"] in self.seen_obs:
                raise ValueError("OBSERVATION_ID_REUSED")
            verify_assets(p, self.asset_root)
        elif kind == "chunk" and p["obs_id"] not in self.seen_obs:
            raise ValueError("UNKNOWN_CHUNK_OBSERVATION_OR_ACTOR")
        event = json.loads(canonical(event))
        stream = STREAMS[kind]
        index = {"seq": event["seq"], "stream": stream, "event_sha256": digest(event),
                 "previous_index_sha256": self.prev}
        for name, value in [(stream, event), ("index", index)]:
            with (self.output / (name + ".jsonl")).open("ab") as f:
                f.write(canonical(value) + b"\n")
                f.flush()
                os.fsync(f.fileno())
        self.events.append(event)
        self.prev = digest(index)
        self.last_time = p["time_ns"]
        if kind == "capture":
            self.seen_obs.add(p["obs_id"])
        return event["seq"]

    def close(self):
        if self.closed:
            raise ValueError("ALREADY_CLOSED")
        result = derive(self.header, self.events, self.asset_root)
        receipt = {"status": "COMPLETE_LOG", "schema": "CausalStudentClose/0.4",
                   "event_count": len(self.events), "last_index_sha256": self.prev,
                   "files": {name: file_sha(self.output / name) for name in
                             ["HEADER.json", "index.jsonl", "student.jsonl", "control.jsonl", "supervision.jsonl"]}}
        with (self.output / "CLOSE.json").open("xb") as f:
            f.write(canonical(receipt) + b"\n")
        self.closed = True
        return result


def _read_jsonl(path):
    with Path(path).open("rb") as f:
        return [json.loads(line) for line in f if line.strip()]


class JsonlCaptureReader:
    def __init__(self, output, asset_root, *, expected_pins=None):
        self.output, self.asset_root = Path(output), Path(asset_root)
        self.expected_pins = expected_pins

    def readback(self):
        if not (self.output / "CLOSE.json").is_file():
            raise ValueError("INCOMPLETE_LOG_NOT_ADMITTED")
        receipt = json.loads((self.output / "CLOSE.json").read_bytes())
        if set(receipt) != {"status", "schema", "event_count", "last_index_sha256", "files"} or receipt["status"] != "COMPLETE_LOG" or receipt["schema"] != "CausalStudentClose/0.4":
            raise ValueError("INVALID_CLOSE_RECEIPT")
        expected = {"HEADER.json", "index.jsonl", "student.jsonl", "control.jsonl", "supervision.jsonl"}
        if set(receipt["files"]) != expected or any(file_sha(self.output / n) != sha for n, sha in receipt["files"].items()):
            raise ValueError("LOG_BYTES_MISMATCH")
        header = json.loads((self.output / "HEADER.json").read_bytes())
        validate_header(header)
        if header["dataset_kind"] == "PRODUCTION" and self.expected_pins is None:
            raise ValueError("PRODUCTION_REQUIRES_COLLECTOR_EXPECTED_PINS")
        if self.expected_pins is not None and header["pins"] != self.expected_pins:
            raise ValueError("EXPECTED_PROTOCOL_PINS_MISMATCH")
        streams = {s: _read_jsonl(self.output / (s + ".jsonl")) for s in ["student", "control", "supervision"]}
        positions = {s: 0 for s in streams}
        events, prev = [], "0" * 64
        for seq, index in enumerate(_read_jsonl(self.output / "index.jsonl")):
            if set(index) != {"seq", "stream", "event_sha256", "previous_index_sha256"} or index["seq"] != seq or index["previous_index_sha256"] != prev:
                raise ValueError("INDEX_CHAIN_MISMATCH")
            s = index["stream"]
            if s not in streams or positions[s] >= len(streams[s]):
                raise ValueError("INDEX_STREAM_MISMATCH")
            event = streams[s][positions[s]]
            positions[s] += 1
            if digest(event) != index["event_sha256"] or STREAMS.get(event["kind"]) != s:
                raise ValueError("INDEX_EVENT_MISMATCH")
            events.append(event)
            prev = digest(index)
        if any(positions[s] != len(streams[s]) for s in streams) or len(events) != receipt["event_count"] or prev != receipt["last_index_sha256"]:
            raise ValueError("MISSING_OR_EXTRA_LOG_EVENT")
        result = derive(header, events, self.asset_root)
        result["student_observation_catalogue"] = student_projection(header, events)
        result["catalogue_is_not_future_history_input"] = True
        return result
