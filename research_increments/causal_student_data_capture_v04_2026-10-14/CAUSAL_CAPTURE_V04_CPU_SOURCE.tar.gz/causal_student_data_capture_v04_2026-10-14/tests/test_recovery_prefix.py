"""Regression oracles for independent recovery traces; synthetic JSON only."""
import copy
from pathlib import Path
import tempfile
import unittest

from causal_capture import derive
from cpu_fixtures import header, make_asset, recovery_events


class RecoveryPrefixTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='recovery_prefix_cpu_')
        self.root = Path(self.tmp.name)
        self.h = header()
        self.events = recovery_events(make_asset(self.root), self.h)

    def tearDown(self):
        self.tmp.cleanup()

    def label(self):
        return next(p for k,p in self.events if k == 'outcome' and p['row_id'] == 'recovery_row')

    def result(self):
        events = [dict(schema='CausalStudentEvent/0.4', seq=i, kind=k, payload=p,
                       **{x:self.h[x] for x in ['episode_id','actor_epoch','clock_id']})
                  for i,(k,p) in enumerate(self.events)]
        return derive(self.h, events, self.root)['rows'][-1]

    def move_anchor(self, t, after=False):
        anchor = next(e for e in self.events if e[0] == 'audit_event')
        self.events.remove(anchor)
        anchor[1]['time_ns'] = t
        self.events.append(anchor)
        self.events.sort(key=lambda e:(e[1]['time_ns'], (1 if after else -1) if e[0]=='audit_event' else 0))

    def nonapplied(self, status):
        next(p for k,p in self.events if k=='channel_result' and p['request_id']=='recovery_req').update(status=status,application_time_ns=None)

    def test_future_anchor_onset_earlier_does_not_verify_past_recovery(self):
        self.move_anchor(170)
        with self.assertRaisesRegex(ValueError, 'RECOVERY_ANCHOR_NOT_KNOWN_AT_LABEL'):
            self.result()

    def test_anchor_same_time_after_label_source_order_is_future(self):
        self.move_anchor(160,after=True)
        with self.assertRaisesRegex(ValueError, 'RECOVERY_ANCHOR_NOT_KNOWN_AT_LABEL'):
            self.result()

    def test_anchor_same_time_before_label_source_order_is_known(self):
        self.move_anchor(160)
        self.assertEqual(self.result()['bc_recovery']['eligible_by_contract'],'TRUE')

    def test_audit_after_decision_before_label_is_valid_supervision(self):
        self.move_anchor(125)
        row=self.result()
        self.assertEqual(row['bc_recovery']['eligible_by_contract'],'TRUE')
        self.assertEqual(row['student_available_history_ids'],['obs0','feedback'])

    def test_new_late_label_after_late_anchor_is_valid(self):
        self.move_anchor(170)
        self.label()['time_ns']=180
        self.events.sort(key=lambda e:e[1]['time_ns'])
        self.assertEqual(self.result()['bc_recovery']['eligible_by_contract'],'TRUE')

    def test_unknown_future_anchor_keeps_unknown(self):
        self.move_anchor(170)
        self.label()['recovery']['verified']='UNKNOWN'
        row=self.result()
        self.assertEqual(row['bc_recovery']['eligible_by_contract'],'UNKNOWN')
        self.assertIn('RECOVERY_ANCHOR_UNKNOWN_AT_LABEL',row['bc_recovery']['reasons'])
        self.assertEqual(row['offline_rl']['eligible_by_contract'],'TRUE')

    def test_unknown_future_anchor_does_not_read_future_onset_interval(self):
        self.move_anchor(170)
        self.label()['recovery']['verified']='UNKNOWN'
        next(p for k,p in self.events if k=='audit_event')['onset_interval_ns']=[105,110]
        self.assertEqual(self.result()['bc_recovery']['eligible_by_contract'],'UNKNOWN')

    def test_known_negative_verification_cannot_borrow_future_anchor(self):
        self.move_anchor(170)
        self.label()['recovery']['verified']='FALSE'
        with self.assertRaisesRegex(ValueError, 'RECOVERY_ANCHOR_NOT_KNOWN_AT_LABEL'):
            self.result()

    def test_missing_original_anchor_stays_rejected(self):
        self.events=[e for e in self.events if e[0]!='audit_event']
        with self.assertRaisesRegex(ValueError, 'RECOVERY_ORIGINAL_ANCHOR_MISSING'):
            self.result()

    def test_one_future_anchor_among_multiple_does_not_verify(self):
        second=copy.deepcopy(next(e for e in self.events if e[0]=='audit_event'))
        second[1]['event_id'] += '_second'
        second[1]['time_ns']=170
        self.label()['recovery']['original_anchor_event_ids'].append(second[1]['event_id'])
        self.events.append(second)
        with self.assertRaisesRegex(ValueError, 'RECOVERY_ANCHOR_NOT_KNOWN_AT_LABEL'):
            self.result()

    def test_rejected_control_cannot_be_verified_recovery(self):
        self.nonapplied('REJECTED')
        with self.assertRaisesRegex(ValueError, 'NONAPPLIED_CONTROL_CANNOT_SUPPORT_EXECUTION_SUCCESS'):
            self.result()

    def test_dropped_control_cannot_be_verified_recovery(self):
        self.nonapplied('DROPPED')
        with self.assertRaisesRegex(ValueError, 'NONAPPLIED_CONTROL_CANNOT_SUPPORT_EXECUTION_SUCCESS'):
            self.result()

    def test_timeout_control_cannot_be_verified_recovery(self):
        self.nonapplied('TIMEOUT')
        with self.assertRaisesRegex(ValueError, 'NONAPPLIED_CONTROL_CANNOT_SUPPORT_EXECUTION_SUCCESS'):
            self.result()

    def test_unknown_recovery_with_timeout_retains_failed_rl(self):
        self.nonapplied('TIMEOUT')
        self.label()['recovery']['recovered_objective']='UNKNOWN'
        row=self.result()
        self.assertEqual(row['bc_recovery']['eligible_by_contract'],'UNKNOWN')
        self.assertEqual(row['offline_rl']['eligible_by_contract'],'TRUE')

    def test_required_abort_cannot_hide_behind_another_applied_control(self):
        chunk=next(p for k,p in self.events if k=='chunk' and p['chunk_id']=='recovery_chunk')
        chunk['slots'].append(dict(slot_id='r1',requested_submit_time_ns=135,target=[0.3],required_for_execution=True))
        self.events.append(('unsubmitted',dict(time_ns=145,chunk_id='recovery_chunk',slot_id='r1',reason='FAILED')))
        self.events.sort(key=lambda e:e[1]['time_ns'])
        with self.assertRaisesRegex(ValueError,'EXECUTION_SUCCESS_WITH_UNSUBMITTED_REQUIRED_CONTROL'):
            self.result()

    def test_state_original_failure_is_not_execution_failure(self):
        next(p for k,p in self.events if k=='outcome' and p['row_id']=='row0')['label_kind']='STATE_LABEL'
        with self.assertRaisesRegex(ValueError,'RECOVERY_ORIGINAL_FAILURE_NOT_EXECUTION_OUTCOME'):
            self.result()

    def test_proposal_original_failure_is_not_execution_failure(self):
        next(p for k,p in self.events if k=='outcome' and p['row_id']=='row0')['label_kind']='PROPOSAL_LABEL'
        with self.assertRaisesRegex(ValueError,'RECOVERY_ORIGINAL_FAILURE_NOT_EXECUTION_OUTCOME'):
            self.result()

    def test_verified_recovery_success_requires_channel_even_with_unknown_global_objective(self):
        self.label()['objective']='UNKNOWN'
        self.events=[e for e in self.events if not (e[0]=='channel_result' and e[1]['request_id']=='recovery_req')]
        with self.assertRaisesRegex(ValueError,'EXECUTION_LABEL_BEFORE_REQUIRED_CHANNEL_RESULT'):
            self.result()
