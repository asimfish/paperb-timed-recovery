"""Independent synthetic recovery seam replay; no native/image/SDK access."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--expect', choices=['red', 'fixed'], required=True)
    args = parser.parse_args()
    source = Path(args.source).resolve()
    sys.path.insert(0, str(source / 'code'))
    from causal_capture import JsonlCaptureWriter, JsonlCaptureReader, derive
    from cpu_fixtures import header, make_asset, recovery_events
    h = header()
    schema = h['schema'].replace('CausalStudentCapture', 'CausalStudentEvent')
    reports = []
    with tempfile.TemporaryDirectory(prefix='independent-recovery-prefix-') as unused:
        folder = Path(args.output).parent / ('synthetic_assets_'+args.expect)
        asset = make_asset(folder)
        baseline = recovery_events(asset, h)
        def move_anchor(events, time_ns, after=False):
            anchor = next(e for e in events if e[0] == 'audit_event')
            events.remove(anchor)
            anchor[1]['time_ns'] = time_ns
            key = lambda e: (e[1]['time_ns'], (1 if after else -1) if e[0] == 'audit_event' else 0)
            events.append(anchor)
            events.sort(key=key)
        def run(name, transform, expected_fixed, expected_red=None):
            events = copy.deepcopy(baseline)
            transform(events)
            wrapped = [dict(schema=schema, seq=i, kind=kind, payload=payload,
                            **{k:h[k] for k in ['episode_id','actor_epoch','clock_id']})
                       for i,(kind,payload) in enumerate(events)]
            try:
                result = derive(h, wrapped, folder)
                actual = result['rows'][-1]['bc_recovery']['eligible_by_contract']
                reasons = result['rows'][-1]['bc_recovery']['reasons']
            except ValueError as exc:
                actual, reasons = 'REJECTED', [str(exc)]
            expected = expected_fixed if args.expect == 'fixed' else (expected_red or expected_fixed)
            assert actual == expected, (name, expected, actual, reasons)
            reports.append(dict(name=name, observed=actual, reasons=reasons,
                                expected_fixed=expected_fixed, pass_expected_version=True))
        run('baseline anchor90 label160', lambda e: None, 'TRUE')
        run('late arrival170 onset40_50 label160', lambda e: move_anchor(e,170), 'REJECTED','TRUE')
        run('same native time anchor after label seq', lambda e: move_anchor(e,160,True), 'REJECTED','TRUE')
        run('same native time anchor before label seq', lambda e: move_anchor(e,160), 'TRUE')
        run('anchor125 after decision120 before label160 is privileged supervision', lambda e: move_anchor(e,125), 'TRUE')
        def late_label(e):
            move_anchor(e,170)
            label = next(p for k,p in e if k == 'outcome' and p['row_id']=='recovery_row')
            label['time_ns'] = 180
            e.sort(key=lambda pair: pair[1]['time_ns'])
        run('same late audit then new label180', late_label, 'TRUE')
        def unknown_late(e):
            move_anchor(e,170)
            next(p for k,p in e if k == 'outcome' and p['row_id']=='recovery_row')['recovery']['verified']='UNKNOWN'
        run('future anchor with UNKNOWN verification remains unknown', unknown_late, 'UNKNOWN')
        def status(e, value):
            next(p for k,p in e if k == 'channel_result' and p['request_id']=='recovery_req').update(status=value,application_time_ns=None)
        for value in ['REJECTED','DROPPED','TIMEOUT']:
            run('nonapplied '+value+' cannot support verified recovery', lambda e,v=value: status(e,v), 'REJECTED','TRUE')
        def unknown_timeout(e):
            status(e,'TIMEOUT')
            next(p for k,p in e if k=='outcome' and p['row_id']=='recovery_row')['recovery']['recovered_objective']='UNKNOWN'
        run('UNKNOWN recovery with definite failed TIMEOUT is retained', unknown_timeout, 'UNKNOWN')
        def typed_failure(e):
            next(p for k,p in e if k=='outcome' and p['row_id']=='row0')['label_kind']='STATE_LABEL'
        run('state label is not an executed original failure', typed_failure, 'REJECTED','TRUE')
        def missing_anchor(e):
            e[:] = [(k,p) for k,p in e if k!='audit_event']
        run('missing original anchor is rejected', missing_anchor, 'REJECTED')
        # Exercise the persistent public writer/readback seam for the exact
        # late-anchor trace, not only the pure derivation seam.
        events = copy.deepcopy(baseline)
        move_anchor(events,170)
        log_root = Path(args.output).parent / ('writer_'+args.expect)
        writer = JsonlCaptureWriter(log_root, h, folder)
        for kind,payload in events:
            writer.append(kind,payload)
        try:
            writer.close()
            persistent = JsonlCaptureReader(log_root,folder).readback()['rows'][-1]['bc_recovery']['eligible_by_contract']
        except ValueError as exc:
            persistent = str(exc)
        assert (persistent == 'TRUE') if args.expect=='red' else ('RECOVERY_ANCHOR_NOT_KNOWN_AT_LABEL' in persistent)
        manifest = source / 'SOURCE_MANIFEST.json'
        report = dict(status='RED_V03_RECOVERY_FUTURE_ANCHOR_AND_NONAPPLIED_REPRODUCED' if args.expect=='red' else 'PASS_V04_INDEPENDENT_RECOVERY_PREFIX_REPLAY',
                      source=str(source), source_manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest() if manifest.exists() else None,
                      probes=reports,persistent_writer_result=persistent,persistent_CLOSE_exists=(log_root/'CLOSE.json').exists(),
                      actual_production_rows=0,current_training_admitted=0,native_epochs=0,GPU_work=0,parameter_updates=0,
                      real_images_opened=0,scope='SYNTHETIC_JSON_CPU_INTERFACE_ONLY')
        with Path(args.output).open('x') as out:
            json.dump(report,out,indent=2);out.write('\n')
        print(json.dumps(dict(status=report['status'],probes=len(reports),persistent_writer_result=persistent)))


if __name__ == '__main__':
    main()
