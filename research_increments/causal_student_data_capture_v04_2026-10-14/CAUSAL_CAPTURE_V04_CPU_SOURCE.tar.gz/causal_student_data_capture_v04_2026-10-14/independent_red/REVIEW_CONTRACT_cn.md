# 独立恢复前缀审查合同

Observed：冻结v0.3在audit arrival170、原onset[40,50]、recovery label160的轨迹中，close/readback把bc_recovery判为TRUE。邻接实际反例是恢复request为REJECTED/DROPPED/TIMEOUT仍TRUE，以及STATE_LABEL FALSE作为原执行失败仍TRUE。

Expected：执行恢复标签在其自身(native time_ns, global seq)前缀内有原anchor审计证据；物理onset早于feedback不等于audit记录已到达。已verified TRUE和recovered objective TRUE需恢复chunk中声明的required controls已提交且实际APPLIED；原执行失败须EXECUTION_OUTCOME。标签后的审计不能赋予旧标签verified资格。可在晚audit后新出具outcome（180）并合法获得恢复TRUE。未知证据保留UNKNOWN，失败RL仍可独立合法。

Scope：仅source-pinned CPU synthetic JSON接口，v0.2/v0.3及其54/80测试和收据immutable。另建v0.4。不读取/data新native，不读取JPEG，不启GPU/SDK/native/train，production0/入训0/θ0。所有修复已在parent任务中授权。

Reproduction：`PYTHONDONTWRITEBYTECODE=1 python3 review_recovery_prefix.py --source ../../causal_student_data_capture_v03_2026-10-14 --output <new-directory>/V03_RED_REPLAY.json --expect red`。独立进程避免同名模块缓存；实际13项及writer/readback结果见v03_red_final，v03 manifest固定dff7372f0513af10be429ef94063f49255c36e3deaf46fdb5bf9de8553baa0aa。

Hypotheses：H1全局audits map回填未来anchor，预测只移动audit arrival不改onset时160仍TRUE且180也TRUE；实际符合。H2是物理onset未来导致拒绝，原onset40_50已早于feedback100，不符合。H3是日志回退或teacher privilege导致，轨迹单调且只审计source变化时间，privileged teacher正例不变，排除。H4恢复用途的执行检查遗漏TRUE recovered目标，预测只有recovery request从APPLIED改TIMEOUT仍TRUE；实际符合。

Integrity boundary：JSON输入经严格schema、source pins、epoch/seq和stream hash重建，再流向用途eligibility。可信collector是前提；这里确认事实可用性的约束，hash不是敌手沙箱、真实拍摄或物理成功的证明。本修复不声称新安全威胁、原生性能或机器人成功。

Repair disposition：只更正恢复资格因果合同。原80PASS逐字保留，并明确其未覆盖上述恢复缝隙；不覆盖成旧结果已足够。v04重新source freeze、CPU gate、archive逐成员重开；生产和学习实验仍未执行。
