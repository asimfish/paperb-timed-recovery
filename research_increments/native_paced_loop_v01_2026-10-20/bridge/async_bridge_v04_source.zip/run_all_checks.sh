#!/usr/bin/env bash
# v0.4 verification on the server (detached). Each step writes its own log and exit code.
set -u
cd "$(dirname "$0")"
run() { name=$1; shift; "$@" > "results/$name.log" 2>&1; echo "exit=$?" >> "results/$name.log"; }
run author_ported_v01_tests python3 -B tests/test_async_bridge.py
run hardening_v03_tests python3 -B tests/test_hardening_v03.py
run cost_v04_tests python3 -B tests/test_cost_v04.py
run capacity_tests python3 -B tests/test_capacity.py
run differential_v03_v04 python3 -B tests/differential_v03_v04.py differential_ref/async_bridge_v03.py code/async_bridge.py reviewer_rerun/out 600 20261020 results/DIFFERENTIAL_V03_V04.json
( cd reviewer_rerun/out && python3 -B -I reader_crosscheck.py > ../../results/reviewer_crosscheck_v04.log 2>&1; echo "exit=$?" >> ../../results/reviewer_crosscheck_v04.log )
( cd reviewer_rerun/out && python3 -B -I adversarial.py --budget 400 --seed 20261020 > ../../results/reviewer_adversarial_v04.log 2>&1; echo "exit=$?" >> ../../results/reviewer_adversarial_v04.log )
echo done > results/ALL_DONE
