"""Time a bridge module's reducer + byte gate on a recorded journal (no I/O); per-quarter medians by kind."""
import importlib.util
import json
import statistics
import sys
import time

bridge_path, journal, header_path, out = sys.argv[1:5]
spec = importlib.util.spec_from_file_location('bridge_timed', bridge_path)
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
h = json.load(open(header_path))
lines = open(journal, 'rb').read().splitlines()
s = b._initial(h)
t = []
for line in lines:
    e = json.loads(line)
    a = time.perf_counter()
    st = b._reduce(s, e['kind'], e['body'], e['clock'], e['wall_ns'])
    b._byte_gate(s, st, e['kind'], len(line) + 1)
    st['chain'] = e['sha256']
    if e['kind'] == 'INFERENCE_RETURN':
        st['tickets'][e['body']['ticket_id']]['return_event_sha256'] = e['sha256']
    s = st
    t.append((e['kind'], (time.perf_counter() - a) * 1e3))
kinds = ('OBSERVED_STATE', 'PUBLIC_PACKET', 'INFERENCE_START', 'SLOT_DISPOSITION', 'CHANNEL_RESULT')
res = dict(bridge=bridge_path, events=len(t), total_s=sum(x for _, x in t) / 1e3, closed=s['closed'], journal_bytes=s['journal_bytes'],
           quarters=[{k: statistics.median([x for kk, x in t[q * len(t) // 4:(q + 1) * len(t) // 4] if kk == k]) for k in kinds} for q in range(4)])
open(out, 'w').write(json.dumps(res, indent=1) + '\n')
print(json.dumps(res))
