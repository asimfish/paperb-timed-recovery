"""Strict differential: v0.4 (copy-on-write) must be observationally identical to v0.3 (deep copy).

For the comparison only, v0.4's SCHEMA/EVENT_SCHEMA module constants are set to the v0.3
strings, so identical API calls must give identical outcome codes, byte-identical journals
and canonical-identical accepted states after every call, plus identical read-only replay.
Operation sequences come from the independent reviewer's random generator (gen_op/exec_op,
including malformed 'garbage' ops), loaded by path and unmodified.

usage: differential_v03_v04.py V03_PY V04_PY REVIEWER_OUT_DIR SECONDS SEED OUT_JSON
"""
import importlib.util
import json
import os
import random
import shutil
import sys
import tempfile
import time

v03_path, v04_path, reviewer_out, seconds, seed, out_json = sys.argv[1:7]
seconds, seed = float(seconds), int(seed)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


V3 = load('bridge_v03', v03_path)
V4 = load('bridge_v04', v04_path)
assert V4.SCHEMA.endswith('/0.4') and V3.SCHEMA.endswith('/0.3')
V4.SCHEMA, V4.EVENT_SCHEMA = V3.SCHEMA, V3.EVENT_SCHEMA
sys.path.insert(0, reviewer_out)
ADV = load('reviewer_adversarial', os.path.join(reviewer_out, 'adversarial.py'))
H = ADV.H


def outcome(fn):
    try:
        fn()
        return 'ACCEPTED'
    except V3.BridgeError as e:
        return 'BridgeError:' + e.code
    except V4.BridgeError as e:
        return 'BridgeError:' + e.code
    except Exception as e:  # any raw exception is itself part of the compared outcome
        code = getattr(e, 'code', None)
        return 'RAW:' + type(e).__module__ + '.' + type(e).__name__ + (':' + code if code else '')


def state_bytes(m, b):
    return m.canonical(b._s)


def main():
    rnd = random.Random(seed)
    end = time.time() + seconds
    runs = ops = 0
    mismatches = []
    kinds = {}
    outcomes = {}
    while time.time() < end and len(mismatches) < 20:
        runs += 1
        clean = rnd.random() < 0.5
        h = H.make_header(L=rnd.choice([8, 64]), tickets=rnd.choice([6, 40]), inflight=6, refusal_reserve=4,
                          journal_bytes=rnd.choice([512000000, 200000, 60000]))
        h['schema'] = V3.SCHEMA
        tmp = tempfile.mkdtemp(prefix='diff34_')
        try:
            try:
                b3 = V3.AsyncBridge(os.path.join(tmp, 'j3'), json.loads(json.dumps(h)), expected_header=json.loads(json.dumps(h)))
            except V3.BridgeError as e:
                b3 = e.code
            try:
                b4 = V4.AsyncBridge(os.path.join(tmp, 'j4'), json.loads(json.dumps(h)), expected_header=json.loads(json.dumps(h)))
            except V4.BridgeError as e:
                b4 = e.code
            if isinstance(b3, str) or isinstance(b4, str):
                if b3 != b4 if isinstance(b3, str) and isinstance(b4, str) else True:
                    mismatches.append(dict(run=runs, where='constructor', v03=str(b3), v04=str(b4)))
                continue
            L = h['caps']['max_token_chars']
            for _ in range(rnd.randint(20, 160)):
                if b3._s['closed']:
                    break
                P = ADV.gen_op(rnd, b3._s, h, L, diff=True, clean=clean)
                r3 = outcome(lambda: ADV.exec_op(V3, b3, h, P))
                r4 = outcome(lambda: ADV.exec_op(V4, b4, h, P))
                ops += 1
                kinds[P['op']] = kinds.get(P['op'], 0) + 1
                key = r3 if r3.startswith('RAW') else r3.split(':')[0]
                outcomes[key] = outcomes.get(key, 0) + 1
                same_state = state_bytes(V3, b3) == state_bytes(V4, b4)
                same_file = open(os.path.join(tmp, 'j3'), 'rb').read() == open(os.path.join(tmp, 'j4'), 'rb').read()
                if r3 != r4 or not same_state or not same_file or b3.broken != b4.broken:
                    mismatches.append(dict(run=runs, op=P['op'], v03=r3, v04=r4, same_state=same_state, same_file=same_file))
                    break
            else:
                pass
            if b3._f and not b3._f.closed:
                b3._f.close()
            if b4._f and not b4._f.closed:
                b4._f.close()
            r3 = V3.AsyncBridge.replay(os.path.join(tmp, 'j3'), expected_header=h)
            r4 = V4.AsyncBridge.replay(os.path.join(tmp, 'j4'), expected_header=h)
            if state_bytes(V3, r3) != state_bytes(V4, r4) or state_bytes(V4, r4) != state_bytes(V4, b4):
                mismatches.append(dict(run=runs, where='replay'))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    result = dict(schema='PaperBBridgeV03V04Differential/1', seed=seed, seconds=seconds, runs=runs, ops=ops, op_kinds=kinds,
                  v03_outcome_classes=outcomes, mismatches=mismatches,
                  status='PASS_IDENTICAL' if not mismatches else 'FAIL')
    open(out_json, 'w').write(json.dumps(result, indent=1) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'mismatches'}), 'mismatches', len(mismatches))
    if mismatches:
        print(json.dumps(mismatches[:5], indent=1))
        sys.exit(1)


if __name__ == '__main__':
    main()
