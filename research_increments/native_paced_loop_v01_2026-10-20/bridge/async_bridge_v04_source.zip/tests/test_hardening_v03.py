"""v0.3 regressions for the independent v0.2 review findings T1, T1b, T2, T3 (documented scope), T5, T6, T7."""
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'code'))
import async_bridge as ab
from async_bridge import AsyncBridge, BridgeError, fixture_header, fixture_state, target_sha, canonical, digest


class AnyEq(dict):
    def __eq__(self, other):
        return True

    def __ne__(self, other):
        return False
    __hash__ = None


class EvilInt(int):
    def __eq__(self, other):
        return True

    def __ne__(self, other):
        return False

    def __add__(self, other):
        return 10**3000
    __hash__ = int.__hash__


class HardeningTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.wall = 0

    def tearDown(self):
        self.tmp.cleanup()

    def w(self):
        self.wall += 1
        return self.wall

    def bridge(self, name='j', **caps):
        h = fixture_header()
        h['caps'].update(caps)
        self.h = h
        self.b = AsyncBridge(self.root / (name + '.jsonl'), h, expected_header=copy.deepcopy(h))
        return self.b

    def ticket(self, ticks=None, end=100, purpose='ORIGINAL_GOAL', rows=None, name='j', **caps):
        b = self.bridge(name, **caps)
        b.observe_state(fixture_state(self.h, 0), wall_ns=self.w())
        b.publish_packet('p0', b'public', wall_ns=self.w())
        e = b.start_inference('t', actor_id='student', actual_input_bytes=b'public', desired_ticks=ticks or list(range(2, 10)), declared_end_tick=end, purpose=purpose, wall_ns=self.w())
        if rows is not False:
            b.accept_return('t', snapshot_sha256=e['body']['snapshot_sha256'], output_8x9=rows or [[0.5] * 9] * 8, current_state_id='state-0', wall_ns=self.w())
        return b

    def prepare(self, slot, purpose='ORIGINAL_GOAL', auth=None):
        return self.b.prepare_slot('t', slot, current_state_id=self.b.snapshot()['state']['state_id'], queue_sha256=self.b.queue_snapshot()['sha256'], purpose=purpose, authorization=auth)

    def commit(self, p):
        return self.b.commit_slot(p, current_state_id=p['current_state_id'], queue_sha256=p['queue_sha256'], wall_ns=self.w())

    def refused(self, fn, code=None):
        before, raw = self.b.snapshot(), self.b.path.read_bytes()
        with self.assertRaises(BridgeError) as e:
            fn()
        if code:
            self.assertTrue(e.exception.code.startswith(code), e.exception.code)
        self.assertEqual(before, self.b.snapshot())
        self.assertEqual(raw, self.b.path.read_bytes())
        self.assertFalse(self.b.broken)
        return e.exception.code

    def test_T1_typed_variants_of_prepared_refused(self):
        self.ticket(rows=[[1.7976931348623157e308, -0.0, 1e16] + [0.5] * 6 for _ in range(8)])
        p = self.prepare(0)
        for mutate in (lambda q: q['target_9d'].__setitem__(0, int(1.7976931348623157e308)), lambda q: q['target_9d'].__setitem__(1, 0.0),
                       lambda q: q['target_9d'].__setitem__(2, 10**16), lambda q: q.__setitem__('desired_tick', float(q['desired_tick'])),
                       lambda q: q.__setitem__('known_original_failure', 0), lambda q: q.__setitem__('actor_generation', False),
                       lambda q: q['owner'].__setitem__('actor_generation', 0.0)):
            q = copy.deepcopy(p)
            mutate(q)
            self.refused(lambda: self.commit(q), 'PREPARED_STALE_OR_TAMPERED')
        self.commit(p)  # the module-computed body is still accepted

    def test_T1b_float_tick_cannot_reach_earliest_apply_tick(self):
        T = 1234567890123456768
        self.ticket(ticks=[T + i for i in range(8)], end=ab.MAX_INT)
        q = self.prepare(0)
        q['desired_tick'] = float(T)
        self.refused(lambda: self.commit(q), 'PREPARED_STALE_OR_TAMPERED')
        nxt = self.prepare(0)
        self.assertIs(type(nxt['earliest_apply_tick']), int)

    def test_T2a_permissive_eq_owner_refused_live(self):
        self.ticket()
        self.commit(self.prepare(0))
        cmd = self.b.snapshot()['commands']['t:0']
        self.refused(lambda: self.b.record_channel_result('t:0', status='DROPPED', current_state_id='state-0', actual_target_9d=cmd['target_9d'],
                                                         claimed_owner=AnyEq({'forged_owner': 'x' * 400}), wall_ns=self.w()), 'CHANNEL_OWNER_TARGET_MISMATCH')
        self.b.record_channel_result('t:0', status='DROPPED', current_state_id='state-0', actual_target_9d=cmd['target_9d'], claimed_owner=cmd['owner'], wall_ns=self.w())
        self.b.close(reason='end', wall_ns=self.w())
        self.assertEqual(AsyncBridge.replay(self.b.path, expected_header=self.h).snapshot(), self.b.snapshot())

    def test_T2b_int_subclass_tick_refused_and_apply_tick_honest(self):
        self.ticket(ticks=list(range(5, 13)))
        p = self.prepare(0)
        q = copy.deepcopy(p)
        q['desired_tick'] = EvilInt(p['desired_tick'])
        self.commit(q)  # normalised to the same plain int, so it is the module-computed body
        stored = self.b.snapshot()['commands']['t:0']
        self.assertIs(type(stored['desired_tick']), int)
        self.assertEqual(stored['desired_tick'], 5)
        self.b.observe_state(fixture_state(self.h, 1), wall_ns=self.w())
        cmd = self.b.queue_snapshot()['commands'][0]
        self.refused(lambda: self.b.record_channel_result(cmd['command_id'], status='APPLIED', current_state_id='state-1', actual_target_9d=cmd['target_9d'],
                                                         claimed_owner=cmd['owner'], wall_ns=self.w()), 'APPLIED_ORIGINAL_TICK_OR_READY_MISMATCH')
        # A subclass passed straight to the API is normalised to a plain int before validation.
        n = self.prepare(1)
        self.assertIs(type(n['earliest_apply_tick']), int)
        self.commit(n)

    def test_T3_documented_scope_recovery_slots_censored_not_writable(self):
        self.ticket(purpose='SAFE_LOCAL_RECOVERY', events=30)
        self.refused(lambda: self.prepare(0, purpose='SAFE_LOCAL_RECOVERY'), 'RECOVERY_REQUIRES_KNOWN_FAILURE')
        end = self.b.close(reason='end', wall_ns=self.w())
        self.assertEqual(end['body']['censored']['unresolved_slots'], {'t': list(range(8))})

    def write_rechained(self, events, path):
        prev = '0' * 64
        lines = []
        for e in events:
            e = dict(e, prev_sha256=prev)
            e.pop('sha256', None)
            e['sha256'] = digest(e)
            prev = e['sha256']
            lines.append(canonical(e) + b'\n')
        path.write_bytes(b''.join(lines))

    def test_T5_replay_requires_exact_envelope_types(self):
        b = self.bridge('t5')
        b.observe_state(fixture_state(self.h, 5), wall_ns=self.w())
        b.record_capacity_refusal('K', 'R', wall_ns=self.w())
        b.close(reason='end', wall_ns=self.w())
        events = [json.loads(x) for x in b.path.read_bytes().splitlines()]
        for name, mutate in (('seq_float', lambda e: e[2].__setitem__('seq', 2.0)), ('seq_bool', lambda e: e[1].__setitem__('seq', True)),
                             ('clock_float', lambda e: e[2].__setitem__('clock', [5.0, 5000000.0, 5000000.0])), ('wall_float', lambda e: e[2].__setitem__('wall_ns', 1.0))):
            forged = copy.deepcopy(events)
            mutate(forged)
            path = self.root / (name + '.jsonl')
            self.write_rechained(forged, path)
            with self.assertRaises(BridgeError, msg=name):
                AsyncBridge.replay(path, expected_header=self.h)
        self.write_rechained(copy.deepcopy(events), self.root / 'control.jsonl')
        self.assertTrue(AsyncBridge.replay(self.root / 'control.jsonl', expected_header=self.h).snapshot()['closed'])

    def test_T6_malformed_inputs_raise_bridge_errors_without_mutation(self):
        b = self.ticket(rows=False)
        snap = b.snapshot()['tickets']['t']['snapshot_sha256']
        ok = [[0.5] * 9] * 8
        cases = [lambda: b.accept_return('t', snapshot_sha256=snap, output_8x9=[[10**400] + [0.5] * 8] + ok[1:], current_state_id='state-0', wall_ns=self.w()),
                 lambda: b.accept_return('t', snapshot_sha256=snap, output_8x9=[[float('nan')] * 9] * 8, current_state_id='state-0', wall_ns=self.w()),
                 lambda: b.accept_return('t', snapshot_sha256=snap, output_8x9=[[float('inf')] * 9] * 8, current_state_id='state-0', wall_ns=self.w()),
                 lambda: b.accept_return('t', snapshot_sha256=snap, output_8x9=ok, current_state_id='state-0', wall_ns=self.w(), status=['OK']),
                 lambda: b.transition_actor(['student'], reason='r', current_state_id='state-0', wall_ns=self.w()),
                 lambda: b.observe_state(None, wall_ns=self.w()),
                 lambda: b.observe_state(object(), wall_ns=self.w())]
        for fn in cases:
            self.refused(fn)
        b.accept_return('t', snapshot_sha256=snap, output_8x9=ok, current_state_id='state-0', wall_ns=self.w())
        p = self.prepare(0)
        q = copy.deepcopy(p)
        q['purpose'] = ['ORIGINAL_GOAL']
        self.refused(lambda: self.commit(q))
        self.refused(lambda: self.prepare(1, auth={'state_id': 's', 'purpose': ['x'], 'target_sha256': None, 'source_sha256': 'a' * 64}))
        blank = self.root / 'blank.jsonl'
        blank.write_bytes(b.path.read_bytes().splitlines(keepends=True)[0] + b'\n')
        with self.assertRaises(BridgeError):
            AsyncBridge.replay(blank, expected_header=self.h)

    def test_T7_token_limit_capped(self):
        h = fixture_header()
        h['caps']['max_token_chars'] = ab.MAX_TOKEN_LIMIT + 1
        with self.assertRaises(BridgeError) as e:
            AsyncBridge(self.root / 'big.jsonl', h, expected_header=copy.deepcopy(h))
        self.assertEqual(e.exception.code, 'TOKEN_LIMIT_TOO_LARGE')
        self.assertFalse((self.root / 'big.jsonl').exists())

    def test_live_journal_equals_normalised_bodies(self):
        """Values passed with subclass types are journaled and indexed as plain JSON values."""
        b = self.bridge('plain')
        s = fixture_state(self.h, 0)
        s['tick'] = EvilInt(0)
        event = b.observe_state(s, wall_ns=self.w())
        self.assertIs(type(b.snapshot()['state']['tick']), int)
        self.assertIs(type(event['clock'][0]), int)
        b.close(reason='end', wall_ns=self.w())
        self.assertEqual(AsyncBridge.replay(b.path, expected_header=self.h).snapshot(), b.snapshot())


if __name__ == '__main__':
    unittest.main(verbosity=2)
