"""v0.2 byte-reservation tests: every admitted case can write its reserved lifecycle and CASE_END.

Ordinary events (state, packet, start, actor transition, failure) may be refused by
capacity; reserved events (return, slot disposition, channel result, refusal receipt,
CASE_END) must never be refused once their owner was admitted.
"""
import copy
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'code'))
import async_bridge as ab
from async_bridge import AsyncBridge, BridgeError, fixture_header, target_sha, canonical, digest, sha256

TMP_PARENT = '/dev/shm' if os.path.isdir('/dev/shm') else None
BIG = 512000000
CAPACITY_CODES = {'BYTE_RESERVATION_REFUSED', 'JOURNAL_TOTAL_BYTE_CAPACITY_REFUSED'}
RESERVED = {'INFERENCE_RETURN', 'SLOT_DISPOSITION', 'CHANNEL_RESULT', 'CAPACITY_REFUSAL', 'CASE_END'}


def make_header(cap, worst=False, **caps):
    h = fixture_header()
    h['caps']['journal_bytes'] = cap
    h['caps'].update(caps)
    if worst:
        h['original_deadline_ns'] = ab.MAX_INT
        h['actors'][0]['actor_id'] = 'S' * 64
        h['actors'][1]['actor_id'] = 'T' * 64
        h['initial_actor_id'] = 'S' * 64
    return h


class Run:
    """One scripted case. Ordinary steps may be refused; afterwards only reserved work is done."""

    def __init__(self, root, name, cap, worst=False, **caps):
        self.worst = worst
        self.h = make_header(cap, worst, **caps)
        self.path = Path(root) / (name + '.jsonl')
        self.wall = ab.MAX_INT - 10**6 if worst else 0
        self.k = 0
        self.ctor_error = None
        try:
            self.b = AsyncBridge(self.path, self.h, expected_header=copy.deepcopy(self.h))
        except BridgeError as e:
            self.b = None
            self.ctor_error = e.code

    def w(self):
        self.wall += 1
        return self.wall

    def tick_of(self, k):
        return (ab.MAX_INT - 1000 + k) if self.worst else k

    def state(self, k, **kw):
        t = self.tick_of(k)
        sid = ('q' * 44 + '%020d' % k) if self.worst else 's%d' % k
        d = {'attempt_id': self.h['attempt_id'], 'native_epoch': self.h['native_epoch'], 'state_id': sid, 'physical_state_sha256': digest({'k': k}), 'tick': t, 'time_ns': t, 'deadline_clock_id': self.h['deadline_clock_id'], 'deadline_time_ns': t, 'collector_source_sha256': self.h['collector_source_sha256'], 'lawful_state': True}
        d.update(kw)
        return d

    def tid(self, i):
        return ('k' * 62 + '%02d' % i) if self.worst else 't%d' % i

    def text(self, short):
        return ('r' * 64) if self.worst else short

    def sid(self):
        return self.b.snapshot()['state']['state_id']

    def output(self):
        if self.worst:
            return [[ab.WORST_FLOAT] * 9 for _ in range(8)]
        return [[i + j / 100 for j in range(9)] for i in range(8)]

    # ordinary steps
    def obs(self, k, **kw):
        self.k = k
        return self.b.observe_state(self.state(k, **kw), wall_ns=self.w())

    def packet(self, name, data=b'public model input'):
        return self.b.publish_packet(('p' * 60 + name[-4:].rjust(4, '0')) if self.worst else name, data, wall_ns=self.w())

    def start(self, i, offsets, end_offset, purpose='ORIGINAL_GOAL'):
        s = self.b.snapshot()
        t = s['state']['tick']
        raw = ab.base64.b64decode(s['packets'][-1]['public_bytes_b64'])
        return self.b.start_inference(self.tid(i), actor_id=s['actor_id'], actual_input_bytes=raw, desired_ticks=[t + o for o in offsets], declared_end_tick=t + end_offset, purpose=purpose, wall_ns=self.w())

    def transition(self, index):
        return self.b.transition_actor(self.h['actors'][index]['actor_id'], reason=self.text('takeover'), current_state_id=self.sid(), wall_ns=self.w())

    def failure(self, known, full):
        return self.b.record_failure(known_original_failure=known, original_full_failure=full, evidence_sha256='e' * 64, current_state_id=self.sid(), wall_ns=self.w())

    # reserved steps
    def ret(self, i, status='OK'):
        tid = self.tid(i)
        sha = self.b.snapshot()['tickets'][tid]['snapshot_sha256']
        return self.b.accept_return(tid, snapshot_sha256=sha, output_8x9=self.output() if status == 'OK' else None, current_state_id=self.sid(), wall_ns=self.w(), status=status)

    def authorization(self, tid, slot):
        s = self.b.snapshot()
        t = s['tickets'][tid]
        if t['snapshot']['purpose'] == 'ORIGINAL_GOAL':
            return None
        out = t['return']['output_8x9']
        return {'state_id': s['state']['state_id'], 'purpose': t['snapshot']['purpose'], 'target_sha256': None if out is None else target_sha(out[slot]), 'source_sha256': self.h['authorization_source_sha256']}

    def dispose(self, i, slot):
        tid = self.tid(i)
        purpose = self.b.snapshot()['tickets'][tid]['snapshot']['purpose']
        p = self.b.prepare_slot(tid, slot, current_state_id=self.sid(), queue_sha256=self.b.queue_snapshot()['sha256'], purpose=purpose, authorization=self.authorization(tid, slot))
        return self.b.commit_slot(p, current_state_id=p['current_state_id'], queue_sha256=p['queue_sha256'], wall_ns=self.w())

    def channel(self, status='DROPPED'):
        cmd = self.b.queue_snapshot()['commands'][0]
        return self.b.record_channel_result(cmd['command_id'], status=status, current_state_id=self.sid(), actual_target_9d=cmd['target_9d'], claimed_owner=cmd['owner'], wall_ns=self.w())

    def refusal(self):
        return self.b.record_capacity_refusal(self.text('INFERENCE_START'), self.text('byte reservation'), wall_ns=self.w())

    def drain(self):
        """Every remaining reserved event, with no further ordinary event."""
        s = self.b.snapshot()
        for tid, t in s['tickets'].items():
            if t['return'] is None:
                self.b.accept_return(tid, snapshot_sha256=t['snapshot_sha256'], output_8x9=self.output(), current_state_id=self.sid(), wall_ns=self.w())
        for tid, t in self.b.snapshot()['tickets'].items():
            for slot in range(8):
                if str(slot) not in t['slots']:
                    purpose = t['snapshot']['purpose']
                    p = self.b.prepare_slot(tid, slot, current_state_id=self.sid(), queue_sha256=self.b.queue_snapshot()['sha256'], purpose=purpose, authorization=self.authorization(tid, slot))
                    self.b.commit_slot(p, current_state_id=p['current_state_id'], queue_sha256=p['queue_sha256'], wall_ns=self.w())
        while self.b.queue_snapshot()['commands']:
            self.channel('DROPPED')

    def close(self):
        return self.b.close(reason=self.text('scripted end'), wall_ns=self.w())


def scenario():
    """(label, kind, callable). Interleaves three tickets, actor change, failure flag and refusal receipt."""
    O = 'ORDINARY'
    steps = [
        ('obs0', O, lambda r: r.obs(0)), ('packet0', O, lambda r: r.packet('p0000')),
        ('start0', O, lambda r: r.start(0, range(2, 10), 8)),
        ('obs1', O, lambda r: r.obs(1)), ('packet1', O, lambda r: r.packet('p0001')),
        ('start1', O, lambda r: r.start(1, range(1, 9), 9, purpose='SAFETY_ABORT')),
        ('obs2', O, lambda r: r.obs(2)),
        ('ret0', 'INFERENCE_RETURN', lambda r: r.ret(0)),
    ]
    steps += [('disp0_%d' % i, 'SLOT_DISPOSITION', (lambda i: lambda r: r.dispose(0, i))(i)) for i in range(8)]
    steps += [('ret1', 'INFERENCE_RETURN', lambda r: r.ret(1))]
    steps += [('disp1_%d' % i, 'SLOT_DISPOSITION', (lambda i: lambda r: r.dispose(1, i))(i)) for i in range(8)]
    steps += [
        ('obs3', O, lambda r: r.obs(3)), ('chan_applied', 'CHANNEL_RESULT', lambda r: r.channel('APPLIED')),
        ('obs4', O, lambda r: r.obs(4)), ('chan_rejected', 'CHANNEL_RESULT', lambda r: r.channel('REJECTED')),
        ('transition', O, lambda r: r.transition(1)), ('failure', O, lambda r: r.failure(True, False)),
        ('receipt', 'CAPACITY_REFUSAL', lambda r: r.refusal()),
        ('obs5', O, lambda r: r.obs(5)), ('packet5', O, lambda r: r.packet('p0005')),
        ('start2', O, lambda r: r.start(2, range(1, 9), 9)),
        ('obs6', O, lambda r: r.obs(6)),
    ]
    return steps


def execute(root, name, cap, worst=False, **caps):
    """Run the scenario at one cap and check the closure guarantee. Returns (first refused label or None, code)."""
    r = Run(root, name, cap, worst, **caps)
    if r.b is None:
        assert r.ctor_error in CAPACITY_CODES, r.ctor_error
        assert not r.path.exists(), 'REFUSED_CONSTRUCTOR_CREATED_FILE'
        return ('CASE_BEGIN', r.ctor_error)
    refused = (None, None)
    for label, kind, fn in scenario():
        before = canonical(r.b.snapshot())
        raw = r.path.read_bytes()
        try:
            fn(r)
        except BridgeError as e:
            assert kind == 'ORDINARY', ('RESERVED_STEP_REFUSED', label, e.code, cap)
            assert e.code in CAPACITY_CODES, (label, e.code)
            assert canonical(r.b.snapshot()) == before and r.path.read_bytes() == raw and not r.b.broken
            refused = (label, e.code)
            r.refusal()
            r.drain()
            break
    end = r.close()
    live = r.b.snapshot()
    assert live['closed'] and r.path.stat().st_size == live['journal_bytes'] <= cap
    replay = AsyncBridge.replay(r.path, expected_header=r.h)
    assert replay.snapshot() == live
    r.path.unlink()
    return refused


COUNTER = [0]


def thresholds(root, worst=False, cap=BIG, stop=None):
    """Instrumented run: requirement (bytes + reservation) after CASE_BEGIN and each ordinary step.

    The cap is part of the CASE_BEGIN header bytes, so a requirement is exact only for
    caps with the same decimal digit count; see exact_threshold.
    """
    COUNTER[0] += 1
    r = Run(root, 'instrument_%d' % COUNTER[0], cap, worst)
    need = lambda: (lambda c: c['journal_bytes'] + c['byte_reserve'])(r.b.capacity_report())
    rows = [('CASE_BEGIN', need())]
    running = rows[0][1]
    for label, kind, fn in scenario():
        if stop is not None and rows[-1][0] == stop:
            return rows, r
        prior = need()
        fn(r)
        now = need()
        if kind == 'ORDINARY':
            running = max(running, now)
            rows.append((label, running))
        else:
            assert now <= prior, ('RESERVED_EVENT_INCREASED_REQUIREMENT', label, prior, now)
    r.close()
    return rows, r


def exact_threshold(root, label, worst=False):
    """Fixed point: the minimal cap admitting `label`, measured with a header that carries that cap."""
    cap = BIG
    for _ in range(6):
        rows, _ = thresholds(root, worst, cap, stop=label)
        need = dict(rows)[label]
        if need == cap:
            return cap
        cap = need
    raise AssertionError(('NO_FIXED_POINT', label, cap))


def v01_sequence(root, cap):
    """The v0.1 probe sequence (state, packet, one 8-slot start) followed by close."""
    COUNTER[0] += 1
    r = Run(root, 'v01seq_%d' % COUNTER[0], cap)
    if r.b is None:
        return 'CASE_BEGIN_REFUSED', None
    stage = 'BEGIN'
    try:
        r.obs(0); stage = 'STATE'
        r.packet('p0', b'public synthetic RGBD/proprio/offsets/mask'); stage = 'PACKET'
        r.start(0, range(0, 8), 100); stage = 'START'
    except BridgeError as e:
        assert e.code in CAPACITY_CODES, e.code
        refused = {'BEGIN': 'STATE', 'STATE': 'PACKET', 'PACKET': 'START'}[stage]
        outcome = refused + '_REFUSED_THEN_CLOSED'
    else:
        outcome = 'START_ADMITTED_THEN_CLOSED'
        need = r.b.capacity_report()
    r.close()
    assert r.path.stat().st_size == r.b.snapshot()['journal_bytes'] <= cap
    assert AsyncBridge.replay(r.path, expected_header=r.h).snapshot() == r.b.snapshot()
    size = r.path.stat().st_size
    r.path.unlink()
    return outcome, (need['journal_bytes'] + need['byte_reserve'] if outcome.startswith('START_ADMITTED') else None, size)


def v01_sequence_result(root, stride=11):
    cap = BIG
    for _ in range(6):
        outcome, info = v01_sequence(root, cap)
        assert outcome == 'START_ADMITTED_THEN_CLOSED'
        if info[0] == cap:
            break
        cap = info[0]
    threshold = cap
    sweep = [v01_sequence(root, c)[0] for c in range(1, threshold + 200, stride)]
    return {'start_threshold_bytes': threshold, 'cap_5360': v01_sequence(root, 5360)[0],
            'start_threshold_minus_1': v01_sequence(root, threshold - 1)[0], 'start_threshold': v01_sequence(root, threshold)[0],
            'sweep_cases': len(sweep), 'sweep_stride': stride, 'sweep_outcomes': {o: sweep.count(o) for o in sorted(set(sweep))},
            'sweep_unclosable_admitted_cases': 0}


class CapacityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=TMP_PARENT)
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def boundary(self, worst):
        rows, _ = thresholds(self.root, worst)
        labels = [label for i, (label, cap) in enumerate(rows) if i == 0 or cap > rows[i - 1][1]]
        self.assertGreater(len(labels), 5)
        exact = {label: exact_threshold(self.root, label, worst) for label in labels}
        for label in labels:
            cap = exact[label]
            self.assertEqual(execute(self.root, 'below', cap - 1, worst)[0], label, (label, cap))
            admitted = execute(self.root, 'at', cap, worst)[0]
            self.assertNotEqual(admitted, label, (label, cap))
            if admitted is not None:
                self.assertGreater(exact[admitted], cap)
        self.assertIsNone(execute(self.root, 'full', exact[labels[-1]], worst)[0])
        return exact

    def test_boundary_minus_plus_one_byte_every_ordinary_step(self):
        self.boundary(False)

    def test_boundary_worst_case_tokens_ints_floats(self):
        self.boundary(True)

    def test_coarse_cap_sweep_never_refuses_reserved_or_end(self):
        for worst in (False, True):
            rows, _ = thresholds(self.root, worst)
            top = rows[-1][1] + 300
            outcomes = set()
            for cap in range(1, top, 23 if not worst else 37):
                outcomes.add(execute(self.root, 'sweep', cap, worst)[0])
            self.assertIn(None, outcomes)
            self.assertIn('CASE_BEGIN', outcomes)

    def test_reserved_lines_within_bounds_and_body_fields_match_worst(self):
        for worst in (False, True):
            _, r = thresholds(self.root, worst)
            bounds = r.b.snapshot()['line_bounds']
            worst_bodies = ab.worst_bodies(r.h['caps']['max_token_chars'])
            slack = {}
            lines = r.path.read_bytes().splitlines(keepends=True)
            for raw in lines:
                event = json.loads(raw)
                kind = event['kind']
                if kind in RESERVED:
                    if kind == 'CASE_END':
                        bound = None
                    else:
                        bound = bounds[kind]
                        self.assertLessEqual(len(raw), bound, kind)
                        slack[kind] = min(slack.get(kind, bound), bound - len(raw))
                    self.assertEqual(set(event['body']), set(worst_bodies[kind]), kind)
                    if kind == 'SLOT_DISPOSITION':
                        self.assertEqual(set(event['body']['prepared']), set(worst_bodies[kind]['prepared']))
                        self.assertEqual(set(event['body']['prepared']['owner']), set(ab.worst_owner(1)))
                        if event['body']['prepared']['authorization'] is not None:
                            self.assertEqual(set(event['body']['prepared']['authorization']), set(worst_bodies[kind]['prepared']['authorization']))
            if worst:
                # Worst-mode lines come close to the bound: slack only from 19- vs 20-digit integers etc.
                self.assertLess(max(slack.values()), 200, slack)

    def test_end_bound_formula_upper_bounds_constructed_worst(self):
        h = make_header(BIG)
        b = ab.line_bounds(h)
        limit = h['caps']['max_token_chars']
        for n in range(0, 7):
            ids = ['x' * (limit - 2) + '%02d' % i for i in range(n)]
            censored = {'unreturned_tickets': ids, 'unresolved_slots': {i: list(range(8)) for i in ids}, 'pending_commands': [i + ':' + str(j) for i in ids for j in range(8)], 'unresolved_outcomes': ab.UNRESOLVED_OUTCOMES}
            actual = ab._worst_line('CASE_END', {'reason': 'r' * limit, 'censored': censored})
            self.assertLessEqual(actual, ab.end_bound(b, n))
            self.assertLessEqual(ab.end_bound(b, n) - actual, 3)

    def test_v01_counterexample_sequence_v02_refuses_before_unsafe_admission(self):
        """v0.1 admitted start at 5,260 B under a 5,360 B cap and then could not write CASE_END."""
        result = v01_sequence_result(self.root)
        self.assertEqual(result['cap_5360'], 'CASE_BEGIN_REFUSED')
        self.assertEqual(result['start_threshold_minus_1'], 'START_REFUSED_THEN_CLOSED')
        self.assertEqual(result['start_threshold'], 'START_ADMITTED_THEN_CLOSED')
        self.assertEqual(result['sweep_unclosable_admitted_cases'], 0)
        self.assertGreater(result['sweep_cases'], 1000)

    def test_ordinary_events_cannot_consume_reserved_space(self):
        cap = exact_threshold(self.root, 'start0')
        r = Run(self.root, 'zero_headroom', cap)
        r.obs(0); r.packet('p0000'); r.start(0, range(2, 10), 8)
        self.assertEqual(r.b.capacity_report()['headroom'], 0)
        before = r.b.snapshot()
        for fn in (lambda: r.obs(1), lambda: r.transition(1), lambda: r.failure(True, False), lambda: r.packet('p1')):
            with self.assertRaises(BridgeError) as e:
                fn()
            self.assertIn(e.exception.code, CAPACITY_CODES)
            self.assertEqual(r.b.snapshot(), before)
        r.ret(0)
        for i in range(8):
            r.dispose(0, i)
        while r.b.queue_snapshot()['commands']:
            r.channel('DROPPED')
        r.close()
        self.assertTrue(r.b.snapshot()['closed'])
        self.assertLessEqual(r.path.stat().st_size, cap)

    def test_multi_ticket_censored_close_at_exact_cap(self):
        big = Run(self.root, 'big', BIG)
        marks = []
        def script(r):
            r.obs(0); r.packet('p0'); r.start(0, range(2, 10), 10)
            r.obs(1); r.packet('p1'); r.start(1, range(1, 9), 9)
            r.obs(2); r.packet('p2'); r.start(2, range(5, 13), 13)
            marks.append(r.b.capacity_report())  # last ordinary step: maximal requirement
            r.ret(1)                       # returned, all 8 slots unresolved
            r.ret(0)
            for i in range(4):
                r.dispose(0, i)            # some STALE, some SUBMIT -> pending commands
        script(big)
        self.assertEqual(big.b.capacity_report()['open_tickets'], 3)
        cap = BIG
        for i in range(6):  # fixed point: the cap's own digits are in the header line
            marks.clear()
            script(Run(self.root, 'fixed%d' % i, cap))
            need = marks[0]['journal_bytes'] + marks[0]['byte_reserve']
            if need == cap:
                break
            cap = need
        marks.clear()
        tight = Run(self.root, 'tight', cap)
        script(tight)
        self.assertEqual(marks[0]['headroom'], 0)
        e = tight.close()['body']['censored']
        self.assertEqual(e['unreturned_tickets'], ['t2'])
        self.assertEqual(e['unresolved_slots'], {'t0': [4, 5, 6, 7], 't1': list(range(8)), 't2': list(range(8))})
        self.assertTrue(e['pending_commands'])
        self.assertLessEqual(tight.path.stat().st_size, cap)
        self.assertEqual(AsyncBridge.replay(tight.path, expected_header=tight.h).snapshot(), tight.b.snapshot())

    def test_close_before_first_state_and_refusal_without_state(self):
        cap = exact_threshold(self.root, 'CASE_BEGIN')
        t = Run(self.root, 'nostate', cap)
        self.assertEqual(t.b.capacity_report()['headroom'], 0)
        with self.assertRaises(BridgeError) as e:
            t.obs(0)
        self.assertIn(e.exception.code, CAPACITY_CODES)
        t.refusal()
        end = t.close()
        self.assertIsNone(end['clock'])
        self.assertEqual(AsyncBridge.replay(t.path, expected_header=t.h).snapshot(), t.b.snapshot())

    def test_refusal_reserve_exhaustion_then_close(self):
        r = Run(self.root, 'refusals', BIG)
        r.obs(0)
        for _ in range(8):
            r.refusal()
        with self.assertRaises(BridgeError) as e:
            r.refusal()
        self.assertEqual(e.exception.code, 'REFUSAL_RESERVE_EXHAUSTED')
        r.close()

    def test_end_line_cap_limits_concurrent_open_tickets(self):
        probe = Run(self.root, 'probe', BIG)
        probe.obs(0); probe.packet('p0'); probe.start(0, range(2, 10), 8)
        lines = [len(x) for x in probe.path.read_bytes().splitlines(keepends=True)]
        b = probe.b.snapshot()['line_bounds']
        k = 1
        while ab.end_bound(b, k) < max(lines) + 200:
            k += 1
        cap_line = ab.end_bound(b, k)
        r = Run(self.root, 'linecap', BIG, max_line_bytes=cap_line)
        r.obs(0); r.packet('p0')
        for i in range(k):
            r.start(i, range(2, 10), 8)
        with self.assertRaises(BridgeError) as e:
            r.start(k, range(2, 10), 8)
        self.assertEqual(e.exception.code, 'END_LINE_RESERVATION_EXCEEDS_LINE_CAP')
        end = r.close()
        self.assertLessEqual(len(canonical(end)) + 1, cap_line)

    def test_header_line_cap_below_reserved_bound_rejected(self):
        h = make_header(BIG, max_line_bytes=1000)
        with self.assertRaises(BridgeError) as e:
            AsyncBridge(self.root / 'x.jsonl', h, expected_header=copy.deepcopy(h))
        self.assertEqual(e.exception.code, 'RESERVED_LINE_BOUND_EXCEEDS_LINE_CAP')
        self.assertFalse((self.root / 'x.jsonl').exists())

    def test_reserved_line_bound_violation_detected_by_gate(self):
        r = Run(self.root, 'gate', BIG)
        s = r.b.snapshot()
        for kind in ab.FIXED_LINE_KINDS:
            with self.assertRaises(BridgeError) as e:
                ab._byte_gate(s, copy.deepcopy(s), kind, s['line_bounds'][kind] + 1)
            self.assertEqual(e.exception.code, 'RESERVED_LINE_BOUND_VIOLATED')
        closed = dict(copy.deepcopy(s), closed=True)
        with self.assertRaises(BridgeError) as e:
            ab._byte_gate(s, closed, 'CASE_END', ab.end_bound(s['line_bounds'], 0) + 1)
        self.assertEqual(e.exception.code, 'RESERVED_LINE_BOUND_VIOLATED')

    def test_replay_recomputes_reservation_and_rejects_forged_journal(self):
        cap = exact_threshold(self.root, 'start0') - 1   # the honest writer refuses start0 here
        self.assertEqual(execute(self.root, 'honest', cap)[0], 'start0')
        original = ab._byte_gate
        ab._byte_gate = lambda old, stage, kind, n: stage.__setitem__('journal_bytes', old['journal_bytes'] + n)
        try:
            r = Run(self.root, 'forged', cap)
            r.obs(0); r.packet('p0000'); r.start(0, range(2, 10), 8)
        finally:
            ab._byte_gate = original
        self.assertLessEqual(r.path.stat().st_size, cap)
        with self.assertRaises(BridgeError) as e:
            AsyncBridge.replay(r.path, expected_header=r.h)
        self.assertEqual(e.exception.code, 'BYTE_RESERVATION_REFUSED')

    def test_token_and_integer_bounds(self):
        r = Run(self.root, 'tokens', BIG)
        def unchanged(fn, code):
            before = r.b.snapshot()
            with self.assertRaises(BridgeError) as e:
                fn()
            self.assertEqual(e.exception.code, code)
            self.assertEqual(r.b.snapshot(), before)
        unchanged(lambda: r.b.observe_state(dict(r.state(0), state_id='x' * 65), wall_ns=r.w()), 'STATE_ID_SHA_REQUIRED')
        unchanged(lambda: r.b.observe_state(dict(r.state(0), state_id='bad"quote'), wall_ns=r.w()), 'STATE_ID_SHA_REQUIRED')
        unchanged(lambda: r.b.observe_state(dict(r.state(0), tick=ab.MAX_INT + 1), wall_ns=r.w()), 'STATE_TYPES_INVALID')
        unchanged(lambda: r.b.observe_state(r.state(0), wall_ns=ab.MAX_INT + 1), 'WALL_MONOTONIC_INTEGER_REQUIRED')
        r.obs(0); r.packet('p0')
        raw = b'public model input'
        unchanged(lambda: r.b.start_inference('t' * 65, actor_id='student', actual_input_bytes=raw, desired_ticks=list(range(8)), declared_end_tick=8, wall_ns=r.w()), 'TICKET_ID_INVALID_OR_DUPLICATE')
        unchanged(lambda: r.b.start_inference('t\\x', actor_id='student', actual_input_bytes=raw, desired_ticks=list(range(8)), declared_end_tick=8, wall_ns=r.w()), 'TICKET_ID_INVALID_OR_DUPLICATE')
        unchanged(lambda: r.b.start_inference('t0', actor_id='student', actual_input_bytes=raw, desired_ticks=list(range(ab.MAX_INT - 6, ab.MAX_INT + 2)), declared_end_tick=8, wall_ns=r.w()), 'ORIGINAL_SLOT_TIMES_INVALID')
        unchanged(lambda: r.b.record_capacity_refusal('k', 'r' * 65, wall_ns=r.w()), 'REFUSAL_REASON_REQUIRED')
        unchanged(lambda: r.b.transition_actor('teacher', reason='', current_state_id='s0', wall_ns=r.w()), 'ACTOR_TRANSITION_INVALID')
        r.start(0, range(0, 8), 8)
        sha = r.b.snapshot()['tickets']['t0']['snapshot_sha256']
        unchanged(lambda: r.b.accept_return('t0', snapshot_sha256=sha, output_8x9=[[2**53 + 1] * 9] * 8, current_state_id='s0', wall_ns=r.w()), 'TARGET_INT_MAGNITUDE_REFUSED')
        r.ret(0)
        q = r.b.queue_snapshot()['sha256']
        # Non-null authorization is refused even where the slot would be STALE/PADDING (v0.1 ignored it).
        unchanged(lambda: r.b.prepare_slot('t0', 0, current_state_id='s0', queue_sha256=q, purpose='ORIGINAL_GOAL', authorization={'state_id': 's0', 'purpose': 'ORIGINAL_GOAL', 'target_sha256': None, 'source_sha256': 'a' * 64}), 'ORIGINAL_GOAL_AUTHORIZATION_MUST_BE_NULL')
        unchanged(lambda: r.b.prepare_slot('t0', 0, current_state_id='s0', queue_sha256=q, purpose='ORIGINAL_GOAL', authorization={'blob': 'x' * 10**6}), 'AUTHORIZATION_SHAPE_INVALID')
        r.close()

    def test_persist_failure_on_reserved_event_breaks_without_resend(self):
        r = Run(self.root, 'persist', BIG)
        r.obs(0); r.packet('p0'); r.start(0, range(2, 10), 8)
        def fail(phase, event, f):
            if phase == 'after_flush' and event['kind'] == 'INFERENCE_RETURN':
                raise OSError('injected uncertain persistence')
        r.b._hook = fail
        before = r.b.snapshot()
        with self.assertRaises(OSError):
            r.ret(0)
        self.assertTrue(r.b.broken)
        self.assertEqual(r.b.snapshot(), before)
        with self.assertRaises(BridgeError) as e:
            r.close()
        self.assertEqual(e.exception.code, 'JOURNAL_BROKEN')
        # The fully written return line replays as accepted; the case stays INCOMPLETE (no CASE_END).
        replay = AsyncBridge.replay(r.path, expected_header=r.h).snapshot()
        self.assertIsNotNone(replay['tickets']['t0']['return'])
        self.assertFalse(replay['closed'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
