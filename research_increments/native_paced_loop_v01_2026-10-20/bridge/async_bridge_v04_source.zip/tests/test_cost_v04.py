"""v0.4 copy-on-write: earlier accepted states are never mutated, and per-event cost does not grow with history."""
import copy
import statistics
import sys
import tempfile
import time
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'code'))
import async_bridge as ab
from async_bridge import AsyncBridge, fixture_header, fixture_state, canonical


class CopyOnWriteTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir='/dev/shm')
        self.h = fixture_header()
        self.b = AsyncBridge(Path(self.tmp.name) / 'j.jsonl', self.h, expected_header=copy.deepcopy(self.h))
        self.wall = 0

    def tearDown(self):
        if self.b._f and not self.b._f.closed:
            self.b._f.close()
        self.tmp.cleanup()

    def w(self):
        self.wall += 1
        return self.wall

    def cycle(self, k, start=False):
        """One tick: observe; optionally packet+start; return/dispose/channel any pending work."""
        b = self.b
        b.observe_state(fixture_state(self.h, k), wall_ns=self.w())
        s = b._s
        for tid, t in list(s['tickets'].items()):
            if t['return'] is None:
                b.accept_return(tid, snapshot_sha256=t['snapshot_sha256'], output_8x9=[[0.1 * i] * 9 for i in range(8)], current_state_id='state-%d' % k, wall_ns=self.w())
                for slot in range(8):
                    q = b.queue_snapshot()['sha256']
                    p = b.prepare_slot(tid, slot, current_state_id='state-%d' % k, queue_sha256=q, purpose='ORIGINAL_GOAL')
                    b.commit_slot(p, current_state_id='state-%d' % k, queue_sha256=q, wall_ns=self.w())
        head = b.queue_snapshot()['commands'][:1]
        if head and head[0]['desired_tick'] <= k:
            cmd = head[0]
            b.record_channel_result(cmd['command_id'], status='APPLIED' if cmd['desired_tick'] == k else 'DROPPED', current_state_id='state-%d' % k,
                                    actual_target_9d=cmd['target_9d'], claimed_owner=cmd['owner'], wall_ns=self.w())
        if start:
            data = (b'public-%06d' % k) * 1000
            b.publish_packet('p%d' % k, data, wall_ns=self.w())
            b.start_inference('t%d' % k, actor_id='student', actual_input_bytes=data, desired_ticks=list(range(k + 1, k + 9)), declared_end_tick=10**9, wall_ns=self.w())

    def test_earlier_states_never_mutated(self):
        held = []
        for k in range(400):
            if k % 50 == 0:
                held.append((k, self.b._s, canonical(self.b._s)))
            self.cycle(k, start=(k % 8 == 0))
        for k, state, frozen in held:
            self.assertEqual(canonical(state), frozen, 'state held at tick %d was mutated' % k)
        self.b.close(reason='end', wall_ns=self.w())
        self.assertEqual(AsyncBridge.replay(self.b.path, expected_header=self.h).snapshot(), self.b.snapshot())

    def test_observe_cost_does_not_grow(self):
        early, late = [], []
        for k in range(3000):
            start = k % 8 == 0
            if not start and (k < 300 or k >= 2700):
                a = time.perf_counter()
                self.b.observe_state(fixture_state(self.h, k), wall_ns=self.w())
                (early if k < 300 else late).append(time.perf_counter() - a)
                self.cycle_rest(k)
            else:
                self.cycle(k, start=start)
        e, l = statistics.median(early), statistics.median(late)
        self.assertLess(l, 3 * e + 0.002, (e, l))

    def cycle_rest(self, k):
        """cycle() minus the observation (already timed)."""
        b = self.b
        head = b.queue_snapshot()['commands'][:1]
        if head and head[0]['desired_tick'] <= k:
            cmd = head[0]
            b.record_channel_result(cmd['command_id'], status='APPLIED' if cmd['desired_tick'] == k else 'DROPPED', current_state_id='state-%d' % k,
                                    actual_target_9d=cmd['target_9d'], claimed_owner=cmd['owner'], wall_ns=self.w())


if __name__ == '__main__':
    unittest.main(verbosity=2)
