"""v0.1 author tests ported unchanged to v0.2 except the renamed mode refusal code."""
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from async_bridge import AsyncBridge,BridgeError,fixture_header,fixture_state,sha256,canonical,target_sha

class AsyncTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.h=fixture_header();self.b=AsyncBridge(self.root/'journal.jsonl',self.h,expected_header=copy.deepcopy(self.h))
        self.wall=1;self.state(0);self.packet(b'public-model-input')
    def tearDown(self):
        if self.b._f and not self.b._f.closed:self.b._f.close()
        self.tmp.cleanup()
    def tick(self):self.wall+=1;return self.wall
    def state(self,tick,**changes):
        state=fixture_state(self.h,tick);state.update(changes)
        self.b.observe_state(state,wall_ns=self.tick());return state
    def packet(self,data):return self.b.publish_packet('packet-'+str(self.wall),data,wall_ns=self.tick())
    def start(self,tid='a',**changes):
        args=dict(actor_id=self.b.snapshot()['actor_id'],actual_input_bytes=b'public-model-input',desired_ticks=list(range(8)),declared_end_tick=8,purpose='ORIGINAL_GOAL',wall_ns=self.tick());args.update(changes)
        return self.b.start_inference(tid,**args)
    def returned(self,tid='a',event=None):
        if event is None:event=self.start(tid)
        self.b.accept_return(tid,snapshot_sha256=event['body']['snapshot_sha256'],output_8x9=[[float(i)]*9 for i in range(8)],current_state_id=self.b.snapshot()['state']['state_id'],wall_ns=self.tick())
        return event
    def prepared(self,tid='a',slot=0,purpose='ORIGINAL_GOAL',authorization=None):
        return self.b.prepare_slot(tid,slot,current_state_id=self.b.snapshot()['state']['state_id'],queue_sha256=self.b.queue_snapshot()['sha256'],purpose=purpose,authorization=authorization)
    def commit(self,p):return self.b.commit_slot(p,current_state_id=p['current_state_id'],queue_sha256=p['queue_sha256'],wall_ns=self.tick())
    def rejected_unchanged(self,fn,code=None):
        before=self.b.snapshot();raw=(self.root/'journal.jsonl').read_bytes()
        with self.assertRaises((BridgeError,ValueError,TypeError)) as error:fn()
        if code:self.assertEqual(str(error.exception),code)
        self.assertEqual(before,self.b.snapshot());self.assertEqual(raw,(self.root/'journal.jsonl').read_bytes());return error.exception
    def test_end_tick_exclusive_padding(self):
        self.returned(event=self.start(declared_end_tick=4));self.assertEqual(self.prepared(slot=4)['disposition'],'PADDING')
    def test_async_old_prefix_distinct_current(self):
        start=self.start();old=copy.deepcopy(start['body']['snapshot']);self.state(3);self.packet(b'new-public-packet')
        self.returned(event=start)
        self.assertEqual(self.b.snapshot()['tickets']['a']['snapshot'],old)
        for i in range(4):self.assertEqual(self.prepared(slot=i)['disposition'],'STALE')
        p=self.prepared(slot=4);self.assertEqual(p['disposition'],'SUBMIT');self.assertEqual(p['desired_tick'],4);self.commit(p)
        self.state(4);cmd=self.b.queue_snapshot()['commands'][0]
        self.b.record_channel_result(cmd['command_id'],status='APPLIED',current_state_id='state-4',actual_target_9d=cmd['target_9d'],claimed_owner=cmd['owner'],wall_ns=self.tick())
        self.assertEqual(self.b.snapshot()['commands']['a:4']['status'],'APPLIED')
    def test_input_must_delivered_bytes(self):
        self.rejected_unchanged(lambda:self.start(actual_input_bytes=b'not-delivered'),'ACTUAL_INPUT_MUST_EQUAL_LATEST_DELIVERED_PACKET')
    def test_mutable_bytes_rejected(self):self.rejected_unchanged(lambda:self.start(actual_input_bytes=bytearray(b'public-model-input')),'IMMUTABLE_BYTES_REQUIRED')
    def test_unbound_assets_refused(self):self.rejected_unchanged(lambda:self.start(actual_asset_bytes=[b'asset']),'ASSET_BINDINGS_UNSUPPORTED_NONEMPTY_REFUSED')
    def test_duplicate_start_return_slot_no_mutation(self):
        start=self.start();self.rejected_unchanged(lambda:self.start(),'TICKET_ID_INVALID_OR_DUPLICATE');self.returned(event=start)
        self.rejected_unchanged(lambda:self.returned(event=start),'DUPLICATE_RETURN');p=self.prepared(slot=0);self.commit(p);self.rejected_unchanged(lambda:self.prepared(slot=0),'DUPLICATE_SLOT')
    def test_return_snapshot_tamper(self):
        self.start();self.rejected_unchanged(lambda:self.b.accept_return('a',snapshot_sha256='0'*64,output_8x9=[[0.]*9]*8,current_state_id='state-0',wall_ns=self.tick()),'RETURN_START_SNAPSHOT_MISMATCH')
    def test_old_guard_after_state_advance(self):
        self.returned();p=self.prepared(slot=3);self.state(1);self.rejected_unchanged(lambda:self.commit(p),'LATEST_CURRENT_STATE_REQUIRED')
    def test_old_guard_after_queue_changes(self):
        self.returned();p=self.prepared(slot=3);self.commit(self.prepared(slot=2));self.rejected_unchanged(lambda:self.commit(p),'CURRENT_QUEUE_MISMATCH')
    def test_aba_revokes_pending_old_ticket(self):
        self.returned();self.b.transition_actor('teacher',reason='takeover',current_state_id='state-0',wall_ns=self.tick());self.b.transition_actor('student',reason='back',current_state_id='state-0',wall_ns=self.tick());self.assertEqual(self.prepared(slot=3)['disposition'],'ACTOR_REVOKED')
    def test_submitted_owner_survives_actor_switch(self):
        self.returned();p=self.prepared(slot=2);self.commit(p);self.b.transition_actor('teacher',reason='takeover',current_state_id='state-0',wall_ns=self.tick());self.state(2);cmd=self.b.queue_snapshot()['commands'][0]
        self.b.record_channel_result(cmd['command_id'],status='APPLIED',current_state_id='state-2',actual_target_9d=cmd['target_9d'],claimed_owner=cmd['owner'],wall_ns=self.tick());self.assertEqual(self.b.snapshot()['commands']['a:2']['owner']['actor_id'],'student')
    def test_fifo_reorder_rejected(self):
        self.returned();self.commit(self.prepared(slot=2));self.commit(self.prepared(slot=3));self.state(3);cmd=self.b.snapshot()['commands']['a:3'];self.rejected_unchanged(lambda:self.b.record_channel_result('a:3',status='APPLIED',current_state_id='state-3',actual_target_9d=cmd['target_9d'],claimed_owner=cmd['owner'],wall_ns=self.tick()),'FIFO_HEAD_REQUIRED')
    def test_late_bad_ack_rejected_raw_must_be_external(self):
        self.returned();self.commit(self.prepared(slot=2));self.state(3);cmd=self.b.queue_snapshot()['commands'][0];self.rejected_unchanged(lambda:self.b.record_channel_result('a:2',status='APPLIED',current_state_id='state-3',actual_target_9d=cmd['target_9d'],claimed_owner=cmd['owner'],wall_ns=self.tick()),'APPLIED_ORIGINAL_TICK_OR_READY_MISMATCH')
    def test_failure_absorbing(self):
        args=dict(current_state_id='state-0',evidence_sha256='a'*64)
        self.b.record_failure(known_original_failure=True,original_full_failure=True,wall_ns=self.tick(),**args)
        self.rejected_unchanged(lambda:self.b.record_failure(known_original_failure=False,original_full_failure=False,wall_ns=self.tick(),**args),'HARD_FAILURE_ABSORBING')
    def test_postdeadline_original_blocked_return_retained(self):
        self.h['original_deadline_ns']=1
        # Independent fixture so header is immutable once case begins.
        self.b._f.close();self.b=AsyncBridge(self.root/'late.jsonl',self.h,expected_header=copy.deepcopy(self.h));self.state(0);self.packet(b'public-model-input');start=self.start();self.state(1);self.returned(event=start);self.assertEqual(self.prepared(slot=3)['disposition'],'GUARD_REJECTED')
    def test_abort_unknown_does_not_invent_failure(self):
        self.returned(event=self.start(purpose='SAFETY_ABORT'))
        auth=dict(state_id='state-0',purpose='SAFETY_ABORT',target_sha256=target_sha([2.]*9),source_sha256=self.h['authorization_source_sha256'])
        p=self.prepared(slot=2,purpose='SAFETY_ABORT',authorization=auth);self.commit(p);self.assertFalse(self.b.snapshot()['known_original_failure']);self.assertFalse(self.b.snapshot()['original_full_failure'])
    def test_recovery_requires_known_failure(self):
        self.returned(event=self.start(purpose='SAFE_LOCAL_RECOVERY'));self.rejected_unchanged(lambda:self.prepared(slot=2,purpose='SAFE_LOCAL_RECOVERY'),'RECOVERY_REQUIRES_KNOWN_FAILURE')
    def test_wrong_current_auth_target_rejected(self):
        self.returned(event=self.start(purpose='SAFETY_ABORT'));auth=dict(state_id='state-0',purpose='SAFETY_ABORT',target_sha256='0'*64,source_sha256=self.h['authorization_source_sha256']);self.rejected_unchanged(lambda:self.prepared(slot=2,purpose='SAFETY_ABORT',authorization=auth),'CURRENT_TARGET_AUTHORIZATION_REQUIRED')
    def test_original_purpose_cannot_relabel(self):
        self.returned();self.rejected_unchanged(lambda:self.prepared(slot=2,purpose='SAFETY_ABORT'),'FROZEN_PURPOSE_MISMATCH')
    def test_clock_rollback(self):
        self.state(3);self.rejected_unchanged(lambda:self.state(2),'ACCEPTED_CLOCK_ROLLBACK');self.rejected_unchanged(lambda:self.b.publish_packet('rollback',b'packet',wall_ns=0),'ACCEPTED_CLOCK_ROLLBACK')
    def test_nan_bool_bad_shape_output(self):
        e=self.start()
        for bad in ([[0]*72],[[False]*9]*8,[[float('nan')]*9]*8,[[0]*10]*8):
            self.rejected_unchanged(lambda:self.b.accept_return('a',snapshot_sha256=e['body']['snapshot_sha256'],output_8x9=bad,current_state_id='state-0',wall_ns=self.tick()))
    def test_full_header_rehash_still_rejected(self):
        bad=copy.deepcopy(self.h);bad['actors'][0]['weights_sha256']='f'*64
        with self.assertRaisesRegex(BridgeError,'EXTERNAL_FULL_HEADER_MISMATCH'):AsyncBridge(self.root/'bad.jsonl',bad,expected_header=self.h)
        self.assertFalse((self.root/'bad.jsonl').exists())
    def test_production_rejected(self):
        bad=copy.deepcopy(self.h);bad['mode']='PRODUCTION'
        with self.assertRaisesRegex(BridgeError,'MODE_NOT_ALLOWED'):AsyncBridge(self.root/'bad.jsonl',bad,expected_header=bad)
        self.assertFalse((self.root/'bad.jsonl').exists())
    def test_prepare_pure_snapshot_copy(self):
        self.returned();before=self.b.snapshot();p=self.prepared(slot=2);self.assertEqual(before,self.b.snapshot());p['target_9d'][0]=99.;self.assertEqual(before,self.b.snapshot());self.rejected_unchanged(lambda:self.commit(p),'PREPARED_STALE_OR_TAMPERED')
    def test_replay_equal_read_only(self):
        self.returned();self.commit(self.prepared(slot=0));self.b.close(reason='author-complete',wall_ns=self.tick());r=AsyncBridge.replay(self.root/'journal.jsonl',expected_header=self.h);self.assertEqual(r.snapshot(),self.b.snapshot());self.rejected_unchanged(lambda:r.observe_state(fixture_state(self.h,2),wall_ns=self.tick()),'READ_ONLY_REPLAY')
    def test_persist_failure_failclosed_state_unchanged(self):
        before=self.b.snapshot()
        def fail(phase,event,f):
            if phase=='after_write':raise OSError('injected')
        self.b._hook=fail
        with self.assertRaises(OSError):self.b.observe_state(fixture_state(self.h,1),wall_ns=self.tick())
        self.assertTrue(self.b.broken);self.assertEqual(before,self.b.snapshot())
        with self.assertRaisesRegex(BridgeError,'JOURNAL_BROKEN'):self.b.observe_state(fixture_state(self.h,2),wall_ns=self.tick())
        r=AsyncBridge.replay(self.root/'journal.jsonl',expected_header=self.h);self.assertEqual(r.snapshot()['state']['tick'],1)
    def test_end_explicit_censor_unknown(self):
        self.start();e=self.b.close(reason='censored',wall_ns=self.tick());self.assertEqual(e['body']['censored']['unreturned_tickets'],['a']);self.assertEqual(e['body']['censored']['unresolved_slots']['a'],list(range(8)));self.assertEqual(self.b.snapshot()['reserved_events'],0)
    def test_padding_stale_error_dispositions_all_preserved(self):
        e=self.start(declared_end_tick=4);self.returned(event=e)
        for i in range(8):self.commit(self.prepared(slot=i))
        slots=self.b.snapshot()['tickets']['a']['slots'];self.assertEqual(len(slots),8);self.assertEqual(slots['0']['disposition'],'STALE');self.assertTrue(all(slots[str(i)]['disposition']=='PADDING' for i in range(4,8)))
    def test_capacity_refusal_separate_accepted_receipt(self):
        self.h['caps']['tickets']=1;self.h['caps']['inflight']=1
        self.b._f.close();self.b=AsyncBridge(self.root/'cap.jsonl',self.h,expected_header=copy.deepcopy(self.h));self.state(0);self.packet(b'public-model-input');self.start()
        before=self.b.snapshot()
        with self.assertRaisesRegex(BridgeError,'TICKET_OR_INFLIGHT_CAPACITY_REFUSED'):self.start('b')
        self.assertEqual(before,self.b.snapshot());self.b.record_capacity_refusal('INFERENCE_START','ticket cap',wall_ns=self.tick());self.assertEqual(self.b.snapshot()['refusals'],1)

    def test_unsafe_guard_records_rejection_without_execution(self):
        e=self.start();self.state(1,lawful_state=False);self.returned(event=e);p=self.prepared(slot=3);self.assertEqual(p['disposition'],'GUARD_REJECTED');self.commit(p);self.assertEqual(self.b.queue_snapshot()['commands'],[])
    def test_event_whole_ticket_reservation_and_end_preserved(self):
        self.h['caps']['events']=25
        self.b._f.close();self.b=AsyncBridge(self.root/'reserve.jsonl',self.h,expected_header=copy.deepcopy(self.h));self.state(0);self.packet(b'public-model-input')
        before=self.b.snapshot()
        with self.assertRaisesRegex(BridgeError,'EVENT_CAPACITY_REFUSED'):self.start()
        self.assertEqual(before,self.b.snapshot());self.b.record_capacity_refusal('INFERENCE_START','whole ticket reservation',wall_ns=self.tick());self.b.close(reason='capacity-only-no-dispatch',wall_ns=self.tick());self.assertTrue(self.b.snapshot()['closed'])
    def test_kind_whole_ticket_reservation(self):
        self.h['caps']['kinds']['CHANNEL_RESULT']=7
        self.b._f.close();self.b=AsyncBridge(self.root/'kindcap.jsonl',self.h,expected_header=copy.deepcopy(self.h));self.state(0);self.packet(b'public-model-input');before=self.b.snapshot()
        with self.assertRaisesRegex(BridgeError,'WHOLE_TICKET_KIND_CAPACITY_REFUSED'):self.start()
        self.assertEqual(before,self.b.snapshot())
    def test_packet_archive_is_separate_from_window(self):
        self.h['caps']['history_window']=4;self.h['caps']['packet_archive']=10
        self.b._f.close();self.b=AsyncBridge(self.root/'archive.jsonl',self.h,expected_header=copy.deepcopy(self.h));self.state(0)
        for i in range(9):self.b.publish_packet('p'+str(i),str(i).encode(),wall_ns=self.tick())
        prefix=self.b.prefix();self.assertEqual(prefix['start'],5);self.assertEqual(prefix['end'],9);self.assertEqual(prefix['packet_ids'],['p5','p6','p7','p8']);self.assertEqual(len(self.b.snapshot()['packets']),9)
    def test_reverse_order_overlapping_returns(self):
        a=self.start('a');b=self.start('b');self.state(2);self.returned('b',b);self.state(3);self.returned('a',a);self.assertEqual(self.b.snapshot()['highwater'][:3],[3,3000000,3000000]);self.assertEqual(self.b.snapshot()['tickets']['a']['snapshot']['start_state']['tick'],0)
    def test_line_reader_bound_before_parse(self):
        p=self.root/'oversized.jsonl';p.write_bytes(b'x'*(self.h['caps']['max_line_bytes']+1)+b'\n')
        with self.assertRaisesRegex(BridgeError,'READER_LINE_BYTE_CAPACITY_REFUSED'):AsyncBridge.replay(p,expected_header=self.h)
    def test_truncated_journal_unknown(self):
        p=self.root/'partial.jsonl';p.write_bytes((self.root/'journal.jsonl').read_bytes()+b'{')
        with self.assertRaisesRegex(BridgeError,'TRUNCATED_JOURNAL_UNKNOWN'):AsyncBridge.replay(p,expected_header=self.h)
    def test_replay_rehashed_extra_body_field_rejected(self):
        from async_bridge import digest
        p=self.root/'extra.jsonl';rows=[json.loads(l) for l in (self.root/'journal.jsonl').read_text().splitlines()];rows[1]['body']['hidden']='unrecognized';rows[1]['sha256']=digest({k:v for k,v in rows[1].items() if k!='sha256'})
        rows=rows[:2];p.write_bytes(b''.join(canonical(r)+b'\n' for r in rows))
        with self.assertRaisesRegex(BridgeError,'EVENT_BODY_FIELDS_REQUIRED'):AsyncBridge.replay(p,expected_header=self.h)

    def test_unsafe_authorized_abort_unknown_allowed(self):
        e=self.start(purpose='SAFETY_ABORT');self.state(1,lawful_state=False);self.returned(event=e)
        auth=dict(state_id='state-1',purpose='SAFETY_ABORT',target_sha256=target_sha([3.]*9),source_sha256=self.h['authorization_source_sha256'])
        p=self.prepared(slot=3,purpose='SAFETY_ABORT',authorization=auth);self.assertEqual(p['disposition'],'SUBMIT');self.commit(p);self.assertFalse(self.b.snapshot()['known_original_failure']);self.assertFalse(self.b.snapshot()['original_full_failure'])
    def test_unsafe_authorized_recovery_known_failure_allowed(self):
        e=self.start(purpose='SAFE_LOCAL_RECOVERY');self.state(1,lawful_state=False);self.returned(event=e)
        self.b.record_failure(known_original_failure=True,original_full_failure=True,evidence_sha256='a'*64,current_state_id='state-1',wall_ns=self.tick())
        auth=dict(state_id='state-1',purpose='SAFE_LOCAL_RECOVERY',target_sha256=target_sha([3.]*9),source_sha256=self.h['authorization_source_sha256'])
        p=self.prepared(slot=3,purpose='SAFE_LOCAL_RECOVERY',authorization=auth);self.assertEqual(p['disposition'],'SUBMIT');self.commit(p);self.assertTrue(self.b.snapshot()['original_full_failure'])
    def test_unsafe_abort_missing_or_wrong_authorization_refused(self):
        e=self.start(purpose='SAFETY_ABORT');self.state(1,lawful_state=False);self.returned(event=e)
        self.rejected_unchanged(lambda:self.prepared(slot=3,purpose='SAFETY_ABORT'),'CURRENT_TARGET_AUTHORIZATION_REQUIRED')
        wrong=dict(state_id='state-0',purpose='SAFETY_ABORT',target_sha256=target_sha([3.]*9),source_sha256=self.h['authorization_source_sha256'])
        self.rejected_unchanged(lambda:self.prepared(slot=3,purpose='SAFETY_ABORT',authorization=wrong),'CURRENT_TARGET_AUTHORIZATION_REQUIRED')
    def test_unsafe_recovery_missing_or_wrong_authorization_refused(self):
        e=self.start(purpose='SAFE_LOCAL_RECOVERY');self.state(1,lawful_state=False);self.returned(event=e)
        self.b.record_failure(known_original_failure=True,original_full_failure=True,evidence_sha256='a'*64,current_state_id='state-1',wall_ns=self.tick())
        self.rejected_unchanged(lambda:self.prepared(slot=3,purpose='SAFE_LOCAL_RECOVERY'),'CURRENT_TARGET_AUTHORIZATION_REQUIRED')
        wrong=dict(state_id='state-1',purpose='SAFE_LOCAL_RECOVERY',target_sha256=target_sha([4.]*9),source_sha256=self.h['authorization_source_sha256'])
        self.rejected_unchanged(lambda:self.prepared(slot=3,purpose='SAFE_LOCAL_RECOVERY',authorization=wrong),'CURRENT_TARGET_AUTHORIZATION_REQUIRED')

if __name__=='__main__':unittest.main(verbosity=2)
