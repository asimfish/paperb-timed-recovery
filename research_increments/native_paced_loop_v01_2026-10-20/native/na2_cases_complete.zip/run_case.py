"""Gate and launch one attempt of one declared NA2 case; retain every attempt; never rerun after the native clock started.

Checks: source freeze pins (local, external read-only scene files, driver capsule links),
declared case and fixed order (earlier cases must have a formal result), per-case attempt
budget, prior native clock, live GPU free memory (read-only nvidia-smi), unique PCI/DRM
mapping. Launches launch.sh in its own session with a wall cap; kills only that session.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CAPSULE = Path('/data/liyufeng/paperb_native_async_loop_20261019_v1/driver_capsule_570.124.06')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write_once(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


def verify_freeze():
    freeze = json.loads((ROOT / 'SOURCE_FREEZE.json').read_text())
    for name, pin in freeze['files'].items():
        if sha(ROOT / name) != pin:
            raise SystemExit('SOURCE_PIN_MISMATCH:' + name)
    for name, pin in freeze['external_read_only'].items():
        if sha(name) != pin:
            raise SystemExit('EXTERNAL_PIN_MISMATCH:' + name)
    for link, target in freeze['driver_capsule'].items():
        if os.readlink(CAPSULE / link) != target:
            raise SystemExit('CAPSULE_CHANGED:' + link)
    return freeze


def gpus():
    rows = subprocess.check_output(['nvidia-smi', '--query-gpu=uuid,pci.bus_id,memory.free,memory.used,utilization.gpu', '--format=csv,noheader,nounits'], text=True)
    out = []
    for line in rows.strip().splitlines():
        uuid, pci, free, used, util = [x.strip() for x in line.split(',')]
        out.append(dict(uuid=uuid, pci=pci, free_mib=int(free), used_mib=int(used), util=int(util)))
    return out


def mapping(uuid):
    matches = [(p, p.read_text()) for p in Path('/proc/driver/nvidia/gpus').glob('*/information') if uuid in p.read_text()]
    if len(matches) != 1:
        raise SystemExit('GPU_UUID_NOT_UNIQUE')
    p, info = matches[0]
    pci = p.parent.name
    minor = int(re.search(r'Device Minor:\s*(\d+)', info).group(1))
    drm = [d.name for d in Path('/sys/class/drm').iterdir() if re.fullmatch(r'card\d+|renderD\d+', d.name) and (d / 'device').resolve().name == pci]
    cards, renders = sorted(x for x in drm if x.startswith('card')), sorted(x for x in drm if x.startswith('renderD'))
    if len(cards) != 1 or len(renders) != 1:
        raise SystemExit('GPU_DRM_PAIR_NOT_UNIQUE')
    return dict(pci=pci, minor=minor, card=cards[0], render=renders[0])


def formal(case_dir):
    return (case_dir / 'NATIVE_CLOCK_STARTED.json').exists()


def main():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--case', required=True)
    p.add_argument('--execute', action='store_true')
    a = p.parse_args()
    freeze = verify_freeze()
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    budget = protocol['budget']
    order = budget['case_order_fixed']
    if a.case not in order:
        raise SystemExit('UNDECLARED_CASE')
    cases_root = ROOT / 'cases'
    started = {d.name.rsplit('_a', 1)[0] for d in cases_root.glob('*') if formal(d)} if cases_root.exists() else set()
    if a.case in started:
        raise SystemExit('FORMAL_NATIVE_CASE_ALREADY_STARTED:' + a.case)
    for earlier in order[:order.index(a.case)]:
        if earlier not in started:
            raise SystemExit('FIXED_ORDER_REQUIRES_EARLIER_CASE:' + earlier)
    attempts_dir = ROOT / 'launch_attempts'
    attempts_dir.mkdir(exist_ok=True)
    previous = sorted(attempts_dir.glob('%s_attempt_*[0-9].json' % a.case))
    n = len(previous) + 1
    if n > budget['max_launch_attempts_per_case']:
        raise SystemExit('LAUNCH_ATTEMPT_BUDGET_EXHAUSTED:' + a.case)
    live = gpus()
    best = max(live, key=lambda g: g['free_mib'])
    receipt = dict(schema='PaperBNA2LaunchAttempt/1', case=a.case, attempt=n, case_dir='%s_a%d' % (a.case, n), source_freeze_sha256=sha(ROOT / 'SOURCE_FREEZE.json'),
                   gpus_observed=live, selected_gpu=best['uuid'], min_free_mib=budget['gpu_min_free_mib'], foreign_processes_signaled=False, global_driver_changes=False,
                   started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    if best['free_mib'] < budget['gpu_min_free_mib']:
        receipt['status'] = 'REFUSED_GPU_FREE_MEMORY_BELOW_GATE'
        write_once(ROOT / 'resource_gate_refusals' / ('%s_%s.json' % (a.case, time.strftime('%Y%m%dT%H%M%S'))), receipt)
        raise SystemExit(receipt['status'])
    m = mapping(best['uuid'])
    receipt.update(mapping=m)
    if not a.execute:
        print(json.dumps(dict(receipt, status='VERIFY_ONLY_NOT_LAUNCHED'), indent=1))
        return
    receipt['status'] = 'LAUNCHED'
    write_once(attempts_dir / ('%s_attempt_%d.json' % (a.case, n)), receipt)
    logs = ROOT / 'logs'
    logs.mkdir(exist_ok=True)
    with (logs / ('%s.stdout.log' % receipt['case_dir'])).open('xb') as so, (logs / ('%s.stderr.log' % receipt['case_dir'])).open('xb') as se:
        start = time.monotonic()
        proc = subprocess.Popen(['bash', str(ROOT / 'launch.sh'), receipt['case_dir'], str(m['minor']), m['card'], m['render']], stdout=so, stderr=se, start_new_session=True)
        timed_out = False
        try:
            code = proc.wait(budget['child_wall_cap_s'])
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(proc.pid, signal.SIGKILL)
            code = proc.wait(30)
        wall = time.monotonic() - start
    case = ROOT / 'cases' / receipt['case_dir']
    write_once(attempts_dir / ('%s_attempt_%d_exit.json' % (a.case, n)), dict(case=a.case, attempt=n, case_dir=receipt['case_dir'], exit_code=code, timed_out=timed_out, wall_s=wall,
                                                                             native_clock_started=formal(case), result_exists=(case / 'RESULT.json').exists(),
                                                                             error_exists=(case / 'ERROR.json').exists(),
                                                                             source_freeze_unchanged_after=all(sha(ROOT / k) == v for k, v in freeze['files'].items())))
    print(json.dumps(dict(case=a.case, attempt=n, exit_code=code, timed_out=timed_out, wall_s=round(wall, 1))))


if __name__ == '__main__':
    main()
