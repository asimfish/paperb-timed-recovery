"""Offline NA2 reader: replays the journal and cross-checks it with the raw worker channel, tick log and frames.

Uses only the case directory and the frozen bridge module (read-only replay). Nothing is
re-executed. Adds to the NA1 checks: pacing (no step before its wall slot; lag statistics;
sense anchor shifts only at request ticks with no ticket in flight), the declared worker
return delay, and the per-ticket identity STALE == min(8, return_tick - start_tick).
Writes READER_REPORT.json.
"""
import argparse
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics


def load_bridge(path):
    spec = importlib.util.spec_from_file_location('frozen_bridge', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def stats(values):
    if not values:
        return None
    v = sorted(values)
    return dict(n=len(v), min=v[0], p10=v[len(v) // 10], median=statistics.median(v), p90=v[(9 * len(v)) // 10], max=v[-1], mean=statistics.fmean(v))


def main():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--case', required=True)
    p.add_argument('--bridge', required=True)
    p.add_argument('--output', default='READER_REPORT.json')
    a = p.parse_args()
    case = Path(a.case)
    bridge = load_bridge(a.bridge)
    cfg = json.loads((case / 'CASE_CONFIG.json').read_text())
    period, delay_ms = cfg['period_ns'], cfg['case']['return_delay_ms']
    checks = {}
    header = json.loads((case / 'EXPECTED_HEADER.json').read_text())
    replay = bridge.AsyncBridge.replay(case / 'ASYNC_JOURNAL.jsonl', expected_header=header).snapshot()
    checks['journal_replay_closed'] = bool(replay['closed'])
    events = [json.loads(x) for x in (case / 'ASYNC_JOURNAL.jsonl').read_bytes().splitlines()]
    end = events[-1]
    checks['last_event_case_end'] = end['kind'] == 'CASE_END'
    kinds = {}
    for e in events:
        kinds[e['kind']] = kinds.get(e['kind'], 0) + 1

    starts, returns, observed_between, queue_len_at_return = {}, {}, {}, {}
    open_tickets, queue = set(), []
    for e in events:
        k = e['kind']
        if k == 'OBSERVED_STATE':
            for t in open_tickets:
                observed_between[t] += 1
        elif k == 'INFERENCE_START':
            starts[e['body']['ticket_id']] = dict(tick=e['clock'][0], wall=e['wall_ns'])
            open_tickets.add(e['body']['ticket_id'])
            observed_between[e['body']['ticket_id']] = 0
        elif k == 'INFERENCE_RETURN':
            tid = e['body']['ticket_id']
            returns[tid] = dict(tick=e['clock'][0], wall=e['wall_ns'], status=e['body']['status'], output_sha=e['body']['output_sha256'])
            open_tickets.discard(tid)
            queue_len_at_return[tid] = len(queue)
        elif k == 'SLOT_DISPOSITION' and e['body']['prepared']['disposition'] == 'SUBMIT':
            queue.append(e['body']['prepared']['command_id'])
        elif k == 'CHANNEL_RESULT':
            queue.remove(e['body']['command_id'])
    elapsed = {t: returns[t]['tick'] - starts[t]['tick'] for t in returns}
    checks['every_started_ticket_returned_or_censored'] = set(starts) == set(returns) | set(end['body']['censored']['unreturned_tickets'])
    checks['observed_states_match_tick_gaps'] = all(observed_between[t] == elapsed[t] for t in returns)

    disp_by_ticket, disp, submitted = {}, {}, {}
    for e in events:
        if e['kind'] == 'SLOT_DISPOSITION':
            pr = e['body']['prepared']
            disp[pr['disposition']] = disp.get(pr['disposition'], 0) + 1
            disp_by_ticket.setdefault(pr['ticket_id'], []).append(pr['disposition'])
            if pr['disposition'] == 'SUBMIT':
                submitted[pr['command_id']] = pr
    stale_by_ticket = {t: d.count('STALE') for t, d in disp_by_ticket.items()}
    identity = [t for t in returns if returns[t]['status'] == 'OK' and queue_len_at_return[t] == 0]
    checks['stale_equals_min8_elapsed_when_queue_empty'] = all(stale_by_ticket[t] == min(8, elapsed[t]) for t in identity)

    channel, applied_ticks, applied_ok, applied_by_tick = {}, [], True, {}
    for e in events:
        if e['kind'] == 'CHANNEL_RESULT':
            b = e['body']
            channel[b['status']] = channel.get(b['status'], 0) + 1
            if b['status'] == 'APPLIED':
                pr = submitted[b['command_id']]
                applied_ticks.append(e['clock'][0])
                applied_by_tick[e['clock'][0]] = b['actual_target_9d']
                applied_ok &= e['clock'][0] == pr['desired_tick'] and b['actual_target_9d'] == pr['target_9d'] and pr['desired_tick'] >= pr['earliest_apply_tick']
    checks['applied_exactly_at_original_slot_tick'] = applied_ok
    checks['at_most_one_applied_per_tick'] = len(applied_ticks) == len(set(applied_ticks))

    rows = [json.loads(x) for x in (case / 'TICKS.jsonl').read_text().splitlines()]
    checks['tick_log_contiguous'] = [r['tick'] for r in rows] == list(range(len(rows)))
    target_ok, last = True, rows[0]['target'] if rows else None
    for r in rows:
        target_ok &= r['target'] == applied_by_tick.get(r['tick'], last)
        last = r['target']
    checks['stepped_target_equals_applied_or_held'] = target_ok
    checks['no_step_before_its_wall_slot'] = all(r['lag_ns'] >= 0 for r in rows)
    request_ticks = {s['tick'] for s in starts.values()}
    sense_ticks = {r['tick'] for r in rows if r['sense']}
    checks['sense_only_at_request_ticks'] = sense_ticks == request_ticks
    # A ticket is in flight on ticks start < k < return (its return is accepted before any sense at the return tick).
    checks['sense_only_with_no_ticket_in_flight'] = all(
        not any(starts[t]['tick'] < k and (t not in returns or returns[t]['tick'] > k) for t in starts) for k in sense_ticks)
    lag_ms = [r['lag_ns'] / 1e6 for r in rows]
    step_ms = [(r['step_wall_end_ns'] - r['step_wall_start_ns']) / 1e6 for r in rows]
    interval_ms = [(b['step_wall_start_ns'] - a['step_wall_start_ns']) / 1e6 for a, b in zip(rows, rows[1:]) if not b['sense']]
    shift_ms = [r['sense']['anchor_shift_ns'] / 1e6 for r in rows if r['sense']]

    raw = [json.loads(x) for x in (case / 'RAW_WORKER_CHANNEL.jsonl').read_text().splitlines()]
    inbound = [json.loads(base64.b64decode(r['body']['bytes_b64'])) for r in raw if r['direction'] == 'WORKER_TO_OWNER_RAW']
    worker_returns = {m['ticket_id']: m for m in inbound if m.get('kind') == 'RETURN'}
    dg = lambda v: hashlib.sha256(bridge.canonical(v)).hexdigest()
    checks['raw_worker_outputs_equal_journal'] = all(t in worker_returns and dg(worker_returns[t]['output_8x9']) == r['output_sha'] for t, r in returns.items() if r['status'] == 'OK')
    stopped = [m for m in inbound if m.get('kind') == 'STOPPED']
    checks['worker_parameters_unchanged'] = len(stopped) == 1 and stopped[0]['initial_parameter_digest'] == stopped[0]['final_parameter_digest'] and stopped[0]['served'] == len(worker_returns)
    checks['worker_never_initialized_cuda'] = all(not m.get('cuda_initialized') for m in inbound if 'cuda_initialized' in m)
    held_ms = [(m['delay_end_ns'] - m['delay_start_ns']) / 1e6 for m in worker_returns.values()]
    checks['declared_return_delay_honored'] = all(m['declared_return_delay_ms'] == delay_ms for m in worker_returns.values()) and all(h >= delay_ms for h in held_ms)
    compute_ms = [(m['compute_end_ns'] - m['compute_start_ns']) / 1e6 for m in worker_returns.values()]
    tickets = json.loads((case / 'TICKETS.json').read_text())
    dispatch_to_send_ms = [(worker_returns[t]['wall_return_send_ns'] - tickets[t]['dispatch_owner_ns']) / 1e6 for t in returns if t in worker_returns]
    send_to_accept_ms = [(tickets[t]['return_owner_ns'] - worker_returns[t]['wall_return_send_ns']) / 1e6 for t in returns if t in worker_returns]
    # physics steps that ran while the worker was computing or holding its return
    by_tick = {r['tick']: r for r in rows}
    steps_in_worker_interval = []
    for t, m in worker_returns.items():
        lo, hi = m['compute_start_ns'], m['delay_end_ns']
        steps_in_worker_interval.append(sum(1 for k in range(starts[t]['tick'], returns[t]['tick'] + 1) if k in by_tick and by_tick[k]['step_wall_start_ns'] < hi and by_tick[k]['step_wall_end_ns'] > lo))

    # Pacing fidelity while a ticket is in flight: steps start_tick..return_tick-1 ran before the return was accepted.
    per_tick_ms, lagged = [], 0
    for t in returns:
        k, j = starts[t]['tick'], returns[t]['tick']
        if 'dispatch_owner_ns' in tickets[t] and j > k:
            per_tick_ms.append((tickets[t]['return_owner_ns'] - tickets[t]['dispatch_owner_ns']) / 1e6 / (j - k))
            lagged += any(by_tick[x]['lag_ns'] > period for x in range(k, j) if x in by_tick)
    frames = sorted((case / 'frames').glob('*.jpg'))
    from PIL import Image
    sizes = {Image.open(f).size for f in frames}
    checks['one_decodable_frame_per_ticket'] = len(frames) == len(starts) and len(sizes) == 1

    el = list(elapsed.values())
    report = dict(schema='PaperBNA2ReaderReport/1', case=str(case), declared_return_delay_ms=delay_ms, period_ms=period / 1e6,
                  status='PASS' if all(checks.values()) else 'FAIL', checks=checks, event_kinds=kinds, tickets=len(starts), returns=len(returns),
                  identity_tickets=len(identity), dispositions=disp, channel_results=channel,
                  elapsed_ticks=stats(el), elapsed_ticks_histogram={str(v): el.count(v) for v in sorted(set(el))},
                  stale_slots_per_ticket=stats(list(stale_by_ticket.values())), stale_fraction=disp.get('STALE', 0) / max(1, sum(disp.values())),
                  physics_steps_during_worker_interval=stats(steps_in_worker_interval),
                  worker_compute_ms=stats(compute_ms), worker_held_ms=stats(held_ms), dispatch_to_worker_send_ms=stats(dispatch_to_send_ms),
                  worker_send_to_owner_accept_ms=stats(send_to_accept_ms),
                  in_flight_wall_ms_per_elapsed_tick=stats(per_tick_ms), tickets_with_step_lag_over_one_period_in_flight=lagged,
                  lag_ms=stats(lag_ms), ticks_lag_within_one_period=sum(1 for x in lag_ms if x <= period / 1e6) / max(1, len(lag_ms)),
                  step_interval_ms_excluding_sense=stats(interval_ms), step_wall_ms=stats(step_ms), sense_anchor_shift_ms=stats(shift_ms),
                  task_ticks_logged=len(rows), frames=len(frames), frame_size=sorted(sizes), censored=end['body']['censored'],
                  close_reason=end['body']['reason'], journal_bytes=replay['journal_bytes'])
    (case / a.output).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('status', 'declared_return_delay_ms', 'checks', 'tickets', 'elapsed_ticks_histogram', 'dispositions', 'channel_results',
                                             'lag_ms', 'ticks_lag_within_one_period', 'step_interval_ms_excluding_sense', 'worker_compute_ms')}, indent=1))


if __name__ == '__main__':
    main()
