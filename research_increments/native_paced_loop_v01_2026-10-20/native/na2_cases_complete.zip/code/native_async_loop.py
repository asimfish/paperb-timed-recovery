"""NA2: one wall-clock-paced native asynchronous loop per declared worker return delay.

Same preserved A-r7 scene, PhysX settings, dt, camera, warmup and P0 worker as NA1, with
AsyncBridge v0.4 (same semantics as v0.3, constant per-event cost) and the paced owner loop:
one physics tick per pace_factor*dt of wall time while the worker computes. The case id
selects the declared worker return delay. Not a task, chemistry, force or policy test.
"""
import argparse
import json
import os
from pathlib import Path
import sys
import time
import traceback

BASE_ENV = dict(os.environ)  # worker environment, captured before the Kit app mutates os.environ
started = time.monotonic()
parser = argparse.ArgumentParser(allow_abbrev=False)
parser.add_argument('--case', required=True)
parser.add_argument('--root', required=True)
from isaaclab.app import AppLauncher
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
root = Path(args.root).resolve()
out = root / 'cases' / args.case
out.mkdir(parents=True, exist_ok=False)
protocol = json.loads((root / 'protocol.json').read_text())
base_case = args.case.rsplit('_a', 1)[0]
case_cfg = [c for c in protocol['cases'] if c['id'] == base_case]
if len(case_cfg) != 1:
    raise SystemExit('UNDECLARED_CASE:' + args.case)
case_cfg = case_cfg[0]
os.environ['ALAB_PLAN_PATH'] = protocol['scene']['plan_path']
app = None
worker = None


def record(name, value):
    p = out / name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


def milestone(name, **fields):
    row = dict(event=name, wall_s=time.monotonic() - started, **fields)
    with (out / 'milestones.jsonl').open('a') as f:
        f.write(json.dumps(row) + '\n')
        f.flush()
        os.fsync(f.fileno())
    print('NA2_MILESTONE', json.dumps(row), flush=True)


try:
    milestone('APP_STARTING')
    app = AppLauncher(dict(vars(args))).app
    milestone('APP_STARTED')
    import hashlib
    import importlib.metadata
    import numpy as np
    import torch
    import omni.usd
    import omni.kit.app
    import isaaclab.sim as sim_utils
    from isaaclab.scene import InteractiveScene
    from isaacsim.core.version import get_version
    from scene_cfg_twin import GOAI_SCENE_CFG, PLAN
    from robot_collision_filters import configure
    from async_bridge import AsyncBridge, fixture_header, canonical
    from owner_loop import WorkerClient, run_paced_loop

    version = get_version()
    physx_id = omni.kit.app.get_app().get_extension_manager().get_enabled_extension_id('omni.physx')
    if version[0] != '5.1.0' or not physx_id:
        raise RuntimeError('native runtime identity unavailable')
    record('runtime_versions.json', dict(isaac_version=version, physx_extension=physx_id, isaaclab_distribution=importlib.metadata.version('isaaclab'),
                                         torch=torch.__version__, selected_experience=args.experience))
    dt = protocol['dt_s']
    px = protocol['physx']
    sim = sim_utils.SimulationContext(sim_utils.SimulationCfg(dt=dt, device='cpu', use_fabric=True, physx=sim_utils.PhysxCfg(
        solver_type=px['solver_type'], max_position_iteration_count=px['max_position_iteration_count'],
        max_velocity_iteration_count=px['max_velocity_iteration_count'], enable_ccd=px['enable_ccd'])))
    cfg = GOAI_SCENE_CFG(num_envs=1, env_spacing=2.)
    camera_name = protocol['scene']['camera']
    for name in list(vars(cfg)):
        if name.endswith('_camera') and name != camera_name:
            setattr(cfg, name, None)
    getattr(cfg, camera_name).width, getattr(cfg, camera_name).height = protocol['scene']['camera_resolution']
    scene = InteractiveScene(cfg)
    stage = omni.usd.get_context().get_stage()
    record('collision_filters.json', configure(stage, PLAN['robots']))
    callback = dict(count=0, last_dt=None)

    def on_physics(value):
        callback['count'] += 1
        callback['last_dt'] = float(value)
    sim.add_physics_callback('paperb_na2_count', on_physics)
    sim.reset()
    scene.reset()
    for asset in scene.articulations.values():
        asset.write_joint_state_to_sim(asset.data.default_joint_pos, asset.data.default_joint_vel)
        asset.set_joint_position_target(asset.data.default_joint_pos)
    robot = scene.articulations[protocol['scene']['robot']]
    camera = scene.sensors[camera_name]
    record('registry.json', dict(rigid_objects=sorted(scene.rigid_objects), articulations=sorted(scene.articulations),
                                 robot_joint_names=list(robot.joint_names), camera=camera_name))
    milestone('NATIVE_SCENE_READY', rigid=len(scene.rigid_objects), articulations=len(scene.articulations))
    limits = robot.data.joint_pos_limits[0].cpu().numpy()
    tolerance = np.asarray(protocol['guard']['position_tolerance'])
    speed = np.asarray(protocol['guard']['speed_limit'])
    T = lambda x: torch.tensor(x, dtype=torch.float32, device='cpu')

    class IsaacAdapter:
        def __init__(self):
            self.k = 0
            self.origin = float(sim.current_time)
            self.steps = 0

        def initial_target(self):
            return robot.data.default_joint_pos[0].tolist()

        def state(self):
            q = robot.data.joint_pos[0].cpu().numpy().astype(float)
            qd = robot.data.joint_vel[0].cpu().numpy().astype(float)
            lawful = bool(np.isfinite(q).all() and np.isfinite(qd).all() and not np.any(q < limits[:, 0] - tolerance)
                          and not np.any(q > limits[:, 1] + tolerance) and not np.any(abs(qd) > speed))
            native = float(sim.current_time)
            return dict(tick=self.k, time_ns=int(round((native - self.origin) * 1e9)), q=q.tolist(), qd=qd.tolist(), lawful=lawful, native_time_s=native)

        def target_admissible(self, target):
            t = np.asarray(target, dtype=float)
            return bool(t.shape == (9,) and np.isfinite(t).all() and np.all(t >= limits[:, 0]) and np.all(t <= limits[:, 1]))

        def render(self):
            native, count, q = float(sim.current_time), callback['count'], robot.data.joint_pos[0].clone()
            for _ in range(3):
                sim.render()
            camera.update(dt, force_recompute=True)
            rgb = camera.data.output['rgb'][0, :, :, :3].cpu().numpy().copy()
            if float(sim.current_time) != native or callback['count'] != count or not torch.equal(q, robot.data.joint_pos[0]):
                raise RuntimeError('RENDER_CHANGED_PHYSICS')
            w, h = protocol['scene']['camera_resolution']
            if rgb.shape != (h, w, 3) or rgb.dtype != np.uint8 or rgb.std() < 2.:
                raise RuntimeError('MISSING_OR_INVALID_SCENE_IMAGE')
            return rgb

        def step(self, target):
            robot.set_joint_position_target(T(target)[None])
            effort = torch.zeros((1, robot.num_joints))
            effort[:, :7] = robot.root_physx_view.get_gravity_compensation_forces()[:, :7]
            if not torch.isfinite(effort).all():
                raise RuntimeError('NONFINITE_GRAVITY_COMPENSATION')
            robot.set_joint_effort_target(effort)
            before, count = float(sim.current_time), callback['count']
            scene.write_data_to_sim()
            sim.step(render=False)
            scene.update(dt)
            after = float(sim.current_time)
            if callback['count'] - count != 1 or abs(callback['last_dt'] - dt) > 1e-9 or abs(after - before - dt) > 1e-7:
                raise RuntimeError('UNACCOUNTED_PHYSICS_INTEGRATION')
            self.k += 1
            self.steps += 1
            if self.steps == 1:
                record('NATIVE_CLOCK_STARTED.json', dict(native_time_s=after, physics_callbacks=callback['count'], owner_wall_s=time.monotonic() - started))

    adapter = IsaacAdapter()
    home = adapter.initial_target()
    for i in range(protocol['warmup_ticks']):
        adapter.step(home)
    warm = adapter.state()
    record('WARMUP_END.json', dict(ticks=protocol['warmup_ticks'], lawful=warm['lawful'], q=warm['q'], qd=warm['qd'], native_time_s=warm['native_time_s']))
    milestone('WARMUP_DONE', lawful=warm['lawful'])
    if not warm['lawful']:
        raise RuntimeError('WARMUP_STATE_OUTSIDE_GUARD')
    adapter.k = 0
    adapter.origin = float(sim.current_time)

    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    worker_env = {k: v for k, v in BASE_ENV.items() if k not in ('LD_PRELOAD',)}
    worker_env['CUDA_VISIBLE_DEVICES'] = ''
    worker = WorkerClient([sys.executable, '-B', str(root / 'code/p0_service_worker.py'), '--root', str(root), '--return-delay-ms', str(case_cfg['return_delay_ms'])], worker_env,
                          out / 'RAW_WORKER_CHANNEL.jsonl', out / 'worker_stderr.log')
    ready = worker.wait_message(protocol['worker_ready_timeout_s'])
    if len(ready) != 1 or ready[0].get('kind') != 'READY' or ready[0].get('cuda_initialized'):
        raise RuntimeError('CPU_WORKER_READY_REQUIRED:%s' % ready)
    record('WORKER_READY.json', ready[0])
    milestone('WORKER_READY', pid=ready[0]['pid'])

    header = fixture_header()
    header.update(mode='NATIVE_SIM', attempt_id=args.case, failure_root_id='na2-pacing-no-task-outcome',
                  native_epoch='paperb_na2:%s:%s' % (args.case, sha(root / 'protocol.json')[:16]),
                  original_deadline_ns=int(round(protocol['task_ticks'] * dt * 1e9)), deadline_clock_id='native-sim-time-since-task-origin',
                  graph_id='na2-pacing-no-chemical-task', split='TRAIN')
    pins = {name: sha(root / 'code' / name) for name in ('async_bridge.py', 'owner_loop.py', 'p0_service_worker.py', 'native_async_loop.py')}
    pins.update(protocol=sha(root / 'protocol.json'), p0_checkpoint=sha(root / 'inputs/p0_checkpoint.pt'), p0_model=sha(root / 'inputs/p0_model.py'))
    header['source_pins'] = pins
    header['clock_mapping_sha256'] = pins['protocol']
    header['collector_source_sha256'] = pins['native_async_loop.py']
    header['guard_source_sha256'] = pins['owner_loop.py']
    header['channel']['source_sha256'] = pins['owner_loop.py']
    header['channel']['latency_ticks'] = protocol['channel_latency_ticks']
    header['actors'] = [dict(actor_id='p0_student', role='STUDENT', actor_source_sha256=pins['p0_model'], weights_sha256=pins['p0_checkpoint'],
                             input_adapter_sha256=pins['p0_service_worker.py'])]
    header['initial_actor_id'] = 'p0_student'
    (out / 'EXPECTED_HEADER.json').write_bytes(canonical(header) + b'\n')
    bridge = AsyncBridge(out / 'ASYNC_JOURNAL.jsonl', header, expected_header=json.loads(canonical(header)))
    period_ns = int(round(protocol['pace_factor'] * dt * 1e9))
    record('CASE_CONFIG.json', dict(case=case_cfg, period_ns=period_ns, pace_factor=protocol['pace_factor'], dt_s=dt))
    milestone('TASK_STARTING', task_ticks=protocol['task_ticks'], return_delay_ms=case_cfg['return_delay_ms'], period_ns=period_ns)
    summary = run_paced_loop(adapter, bridge, worker, out, task_ticks=protocol['task_ticks'], request_period=protocol['request_period_ticks'],
                             period_ns=period_ns, return_wait_s=protocol['return_wait_s'], actor_id='p0_student', dt_s=dt)
    milestone('TASK_DONE', **{k: v for k, v in summary.items() if k != 'censored'})
    code, tail = worker.stop()
    worker = None
    record('RESULT.json', dict(status='NATIVE_PACED_LOOP_FINISHED', case=case_cfg, period_ns=period_ns, **summary, worker_exit_code=code, worker_tail=tail,
                               physics_steps_total=adapter.steps, warmup_ticks=protocol['warmup_ticks'], owner_wall_s=time.monotonic() - started,
                               task_success_scored=False, chemical_event_verified=False, force_qualified=False, policy_quality_claim=False))
    milestone('RESULT')
except BaseException as e:
    record('ERROR.json', dict(type=type(e).__name__, message=str(e), traceback=traceback.format_exc()))
    traceback.print_exc()
finally:
    if worker is not None:
        try:
            worker.stop(5)
        except BaseException:
            pass
    if app is not None:
        record('PROCESS_EXIT.json', dict(mode='CONTROLLED_EXIT_WITHOUT_SDK_CLEANUP', graceful_sdk_cleanup=False))
        for path in out.rglob('*.jsonl'):
            with path.open('rb') as f:
                os.fsync(f.fileno())
        os._exit(0 if (out / 'RESULT.json').exists() and not (out / 'ERROR.json').exists() else 1)
