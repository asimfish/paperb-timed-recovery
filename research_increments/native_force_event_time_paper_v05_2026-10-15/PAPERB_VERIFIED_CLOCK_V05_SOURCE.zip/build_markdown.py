"""Generate a Markdown mirror from current TeX, including every figure/table."""
import json,re
from pathlib import Path
P=Path(__file__).parent
s=(P/'main.tex').read_text()
records=json.loads((P/'citation_support.json').read_text())['references']
refs={r['key']:r for r in records}
def group(text,start):
    if text[start]!='{':raise ValueError('LATEX_BRACE_START_REQUIRED')
    depth=0
    for i in range(start,len(text)):
        if text[i]=='{' and (i==0 or text[i-1]!='\\'):depth+=1
        elif text[i]=='}' and (i==0 or text[i-1]!='\\'):
            depth-=1
            if depth==0:return text[start+1:i],i+1
    raise ValueError('BALANCED_LATEX_GROUP_REQUIRED')
def command(text,name):
    found=re.search(r'\\'+re.escape(name)+r'\s*\{',text)
    return group(text,found.end()-1)[0] if found else None
title=command(s,'icmltitle')
if not title:raise ValueError('AUTHORED_TITLE_REQUIRED')
s=s[s.index(r'\begin{abstract}'):s.index(r'\end{document}')]
s=s.replace(r'\begin{abstract}','## Abstract\n').replace(r'\end{abstract}','')
figure_count=0;table_count=0
figures=[];tables=[];label_refs={}
def figure(match):
    global figure_count
    body=match.group(0)
    source=re.search(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}',body)
    if not source:raise ValueError('FIGURE_SOURCE_REQUIRED')
    stem=Path(source.group(1));asset=stem.with_suffix('.svg')
    if not (P/asset).is_file():asset=stem
    if not (P/asset).is_file():raise ValueError('CURRENT_FIGURE_ASSET_REQUIRED')
    caption=command(body,'caption')
    if caption is None:raise ValueError('FIGURE_CAPTION_REQUIRED')
    figure_count+=1;figures.append(str(asset))
    label=command(body,'label')
    if label:label_refs[label]=figure_count
    return '\n![Figure '+str(figure_count)+': '+stem.stem+']('+str(asset)+')\n\n'+caption+'\n'
s=re.sub(r'\\begin\{figure\*?\}.*?\\end\{figure\*?\}',figure,s,flags=re.S)
def table(match):
    global table_count
    body=match.group(0);caption=command(body,'caption')
    found=re.search(r'\\begin\{tabular\}\s*\{',body)
    if not found:raise ValueError('AUTHORED_TABULAR_REQUIRED')
    _,end=group(body,found.end()-1)
    content=body[end:body.index(r'\end{tabular}',end)]
    content=re.sub(r'\\(?:toprule|midrule|bottomrule|hline)\s*','',content)
    rows=[]
    for raw in re.split(r'\\\\',content):
        if not raw.strip():continue
        rows.append([cell.strip() for cell in re.split(r'(?<!\\)&',raw.strip())])
    if not rows or any(len(row)!=len(rows[0]) for row in rows):raise ValueError('EXACT_TABLE_COLUMN_CORRESPONDENCE_REQUIRED')
    table_count+=1;tables.append({'number':table_count,'columns':len(rows[0]),'rows':len(rows)})
    label=command(body,'label')
    if label:label_refs[label]=table_count
    md='\n'+(caption+'\n\n' if caption else '')
    md+='| '+' | '.join(rows[0])+' |\n| '+' | '.join(['---']*len(rows[0]))+' |\n'
    md+=''.join('| '+' | '.join(row)+' |\n' for row in rows[1:])
    return md+'\n'
s=re.sub(r'\\begin\{table\*?\}.*?\\end\{table\*?\}',table,s,flags=re.S)
s=re.sub(r'\\section\{([^}]+)\}',r'## \1',s)
s=re.sub(r'\\subsection\{([^}]+)\}',r'### \1',s)
s=re.sub(r'\\paragraph\{([^}]+)\}',r'**\1**',s)
s=re.sub(r'\\(?:emph|textbf)\{([^}]+)\}',r'**\1**',s)
s=re.sub(r'\\texttt\{([^}]+)\}',lambda m:'`'+m.group(1).replace(r'\_','_')+'`',s)
s=s.replace(r'\begin{itemize}','').replace(r'\end{itemize}','').replace(r'\item','-')
def cite(match):
    values=[]
    for key in match.group(1).split(','):
        if key not in refs:raise ValueError('PRIMARY_CITATION_METADATA_REQUIRED:'+key)
        r=refs[key];values.append('['+r['title']+' ('+str(r['year'])+')]('+r['url']+')')
    return ', '.join(values)
s=re.sub(r'\\citep\{([^}]+)\}',cite,s)
s=re.sub(r'\\label\{[^}]+\}','',s)
s=re.sub(r'(Figure|Fig\.|Table)~\\ref\{([^}]+)\}',lambda m:m.group(1)+' '+str(label_refs[m.group(2)]) if m.group(2) in label_refs else m.group(0),s)
s=re.sub(r'\\ref\{[^}]+\}','the corresponding table or figure',s)
s=s.replace(r'\True','TRUE').replace(r'\False','FALSE').replace(r'\Unk','UNKNOWN')
s=s.replace(r'\Hist',r'\mathcal{H}').replace(r'\Data',r'\mathcal{D}')
s=s.replace(r'\(', '$').replace(r'\)', '$')
s=re.sub(r'\\begin\{equation\}', '\n$$\n',s);s=re.sub(r'\\end\{equation\}', '\n$$\n',s)
s=s.replace(r'\begin{align}', '\n$$\n'+r'\begin{aligned}'+'\n');s=s.replace(r'\end{align}', '\n'+r'\end{aligned}'+'\n$$\n')
s=s.replace(r'\nonumber','').replace(r'\\[-1mm]',r'\\')
s=re.sub(r'\\bibliography\{[^}]+\}\\bibliographystyle\{[^}]+\}','',s)
s=s.replace(r'\clearpage','').replace(r'\appendix','').replace(r'\onecolumn','')
s=s.replace(r'\%', '%').replace(r'\_', '_').replace('\\ ', ' ')
s=re.sub(r'(\$\$.*?\$\$|\$[^$]*\$)',lambda m:m.group(0).replace('TRUE',r'\mathsf{T}').replace('FALSE',r'\mathsf{F}').replace('UNKNOWN',r'\mathsf{U}'),s,flags=re.S)
s=re.sub(r'\n{3,}','\n\n',s).strip()
header='# '+title+'\n\nResearch draft; **MAJOR_OPEN**. Evidence checkpoint: 15 October 2026. The main VLA comparison remains unexecuted; one bounded engineering checkpoint exists. Physics qualification and native student-collector integration remain open.\n\n'
bibliography='\n\n## References\n\n'+''.join('- ['+r['title']+']('+r['url']+') ('+str(r['year'])+').\n' for r in records)+'\nPrimary-source metadata is supplied in [refs.bib](refs.bib) and [citation_support.json](citation_support.json).\n'
(P/'paper.md').write_text(header+s+bibliography+'\n')
(P/'MARKDOWN_GENERATION_RECEIPT.json').write_text(json.dumps({'status':'CURRENT_TEX_MIRROR_GENERATED','figure_count':figure_count,'figures':figures,'table_count':table_count,'tables':tables,'primary_citations':len(records),'hardcoded_table_values':False},indent=2)+'\n')
print('Wrote current TeX Markdown mirror: '+str(figure_count)+' figures / '+str(table_count)+' tables.')
