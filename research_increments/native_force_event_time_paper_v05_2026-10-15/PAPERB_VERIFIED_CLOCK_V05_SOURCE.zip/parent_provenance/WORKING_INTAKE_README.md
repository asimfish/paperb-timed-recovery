# Event-timed robot policy research draft

This bundle contains the ICML-format research draft **Failure-Preserving Experience for Event-Timed Robot Policies: A Causal Contract and a Predeclared Learning Study**, with TeX, Markdown, nine primary-source references, and code-native vector figures. The compiled PDF is delivered separately.

**Scientific status: MAJOR_OPEN.** The policy study is proposed and unexecuted. No new VLA weights, OPD student rollouts, force-qualified training admissions, real-hardware results, or chemical success are reported. The existing mechanical, clock, symbolic-adaptation, interface, and collection results are diagnostics in distinct scopes. Four strong controllers tie on primary timing and original mechanism predicates; this is not full strict-hold or force acceptance. The M0/M1 batch retains two attempts, one completed collection, and zero accepted force-detail gates.

The contract separates physical occurrence from confirmation and audit arrival. A late audit can establish that an event occurred before the original deadline without modifying that deadline or earlier policy history; only a provable physical violation sets an absorbing hard failure. Typed S/F/R distinguishes complete success, teacher correction at student visits, and verified executed recovery. The proposed ledger uses the same public information as its closest student-state imitation baseline. The common warm start is S512 and the ancestral-plus-adaptation budget is at most 1,024 unique state/target pairs, not episodes.

Predeclared means a repository hash-frozen contract, not OSF or another external registration. Official ICML2026 style and bibliography files are unmodified; the official `[preprint]` option displays Preprint/date, with a research-draft work-in-progress notice. Anonymous author/institution metadata and omitted contact are placeholders, not an asserted real correspondence address. The target submission year, track, and formal rules must be reconfirmed before submission.

To compile using an existing TeX distribution:

```bash
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
```

The generated bibliography is also supplied as `main.bbl`. No shell escape or external paid writing API is required. To regenerate the figures with Python and Matplotlib, run `python3 -B generate_figures.py`; to regenerate the Markdown mirror, run `python3 -B build_markdown.py`. Figure values are pinned inherited diagnostic summaries; these scripts perform no native simulation, robot control, training, or raw-trace read. Figure artifacts are PDF/SVG/PNG; there is no force-success curve or generated robot-video frame.

The source manifest binds only this portable document bundle. It is not a raw-experiment archive or a claim of physical or scientific acceptance. The companion project page distinguishes native execution, base trace integrity, force qualification, and proposed learning: [force diagnostics](https://asimfish.github.io/paperb-timed-recovery/force-diagnostics.html).
