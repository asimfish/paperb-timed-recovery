"""Maintain a readable Markdown mirror of the authored TeX, not a new paper."""
import re,json
from pathlib import Path
P=Path(__file__).parent
s=(P/'main.tex').read_text()
metadata=P/'citation_support.json'
if not metadata.exists():metadata=P.parent.parent/'literature_work/citation_support.json'
records=json.loads(metadata.read_text())['references']
refs={r['key']:r for r in records}
title=re.search(r'\\icmltitle\{([^}]+)\}',s).group(1)
s=s[s.index(r'\begin{abstract}'):s.index(r'\end{document}')]
s=s.replace(r'\begin{abstract}','## Abstract\n').replace(r'\end{abstract}','')
figure_sources=['method_contract','negative_controls']
def fig(m):
 b=m.group(0);stem=next(x for x in figure_sources if x in b);caption=re.search(r'\\caption\{(.+?)\}\s*\\label',b,re.S).group(1)
 return '\n![Figure: '+stem+'](figures/'+stem+'.svg)\n\n'+caption+'\n'
s=re.sub(r'\\begin\{figure\*\}.*?\\end\{figure\*\}',fig,s,flags=re.S)
tables={
 'tab:native':'''| Measurement | M0 | M1 |
|---|---:|---:|
| Started attempts | 1 | 1 |
| Child/cleanup wall (s) | 700.055 | 842.628 |
| Complete native collection | No | Yes |
| Base complete trace accepted | No | Yes |
| Force-detail gate | Not reached | Rejected |
| Strict sampled hold | UNKNOWN | FALSE |
| Load/force qualification | UNKNOWN | UNKNOWN |
| New weights/admissions | 0/0 | 0/0 |''',
 'tab:arms':'''| Arm | S | F | R | Ledger | Change |
|---|---:|---:|---:|---|---|
| B0 | 1024 | 0 | 0 | No | No explicit time |
| B1 | 1024 | 0 | 0 | No | TimeDP |
| B2 | 1024 | 0 | 0 | No | External timer |
| B3 | 512 | 256 | 256 | No | Student-state imitation |
| M | 512 | 256 | 256 | Yes | Candidate |
| A0 | 1024 | 0 | 0 | Yes | Success only |
| AF | 768 | 256 | 0 | Yes | No R |
| AR | 768 | 0 | 256 | Yes | No F |'''}
def table(m):
 b=m.group(0)
 for label,md in tables.items():
  if label in b:return '\n'+md+'\n'
 return '''\n| Scope | Denominator and boundary |
|---|---|
| Paired32 | 32 development episodes; no heldout learned policy |
| Clock54 | 54 actual CPU trials; not LLM or hardware |
| Adaptation | 69,120 repeated symbolic evaluation rows; not independent tasks |
| ARIS | One episode; base accepted after two schema repairs; strict FALSE/load UNKNOWN |
| M0 | One started attempt, 700.055 s, incomplete collection |
| M1 | One complete collection, 842.628 s, force audit rejected |
| New learning | Zero new VLA weights, student OPD rollouts, or heldout learning evaluations |\n'''
s=re.sub(r'\\begin\{table\}.*?\\end\{table\}',table,s,flags=re.S)
s=re.sub(r'\\section\{([^}]+)\}',r'## \1',s)
s=re.sub(r'\\subsection\{([^}]+)\}',r'### \1',s)
s=re.sub(r'\\paragraph\{([^}]+)\}',r'**\1**',s)
s=re.sub(r'\\(?:emph|textbf)\{([^}]+)\}',r'**\1**',s)
s=re.sub(r'\\texttt\{([^}]+)\}',lambda m:'`'+m.group(1).replace(r'\_','_')+'`',s)
s=s.replace(r'\begin{itemize}','').replace(r'\end{itemize}','').replace(r'\item','-')
def cite(m):
 out=[]
 for key in m.group(1).split(','):
  r=refs[key];out.append('['+r['title']+' ('+str(r['year'])+')]('+r['url']+')')
 return ', '.join(out)
s=re.sub(r'\\citep\{([^}]+)\}',cite,s)
s=re.sub(r'\\label\{[^}]+\}','',s)
s=re.sub(r'Table~\\ref\{tab:native\}','the force-instrumentation table',s)
s=re.sub(r'Table~\\ref\{tab:arms\}','the proposed-arms table',s)
s=re.sub(r'\\ref\{[^}]+\}','the corresponding table or figure',s)
s=s.replace(r'\True','TRUE').replace(r'\False','FALSE').replace(r'\Unk','UNKNOWN')
s=s.replace(r'\Hist',r'\mathcal{H}').replace(r'\Data',r'\mathcal{D}')
s=s.replace(r'\(', '$').replace(r'\)', '$')
s=re.sub(r'\\begin\{equation\}', '\n$$\n',s);s=re.sub(r'\\end\{equation\}', '\n$$\n',s)
s=s.replace(r'\begin{align}', '\n$$\n'+r'\begin{aligned}'+'\n');s=s.replace(r'\end{align}', '\n'+r'\end{aligned}'+'\n$$\n')
s=s.replace(r'\nonumber','').replace(r'\\[-1mm]',r'\\')
s=re.sub(r'\\bibliography\{[^}]+\}\\bibliographystyle\{[^}]+\}','',s)
s=s.replace(r'\clearpage','').replace(r'\appendix','').replace(r'\onecolumn','')
s=s.replace(r'\%', '%').replace(r'\_', '_').replace('\\ ', ' ')
s=re.sub(r'(\$\$.*?\$\$|\$[^$]*\$)',lambda m:m.group(0).replace('TRUE',r'\mathsf{T}').replace('FALSE',r'\mathsf{F}').replace('UNKNOWN',r'\mathsf{U}'),s,flags=re.S)
s=re.sub(r'\n{3,}','\n\n',s).strip()
header='# '+title+'\n\nResearch draft; **MAJOR_OPEN**. Evidence as of 14 October 2026. The proposed learning study is unexecuted; new VLA weights and force-qualified admissions are zero.\n\n'
bibliography='\n\n## References\n\n'+''.join('- ['+r['title']+']('+r['url']+') ('+str(r['year'])+').\n' for r in records)+'\nFull primary-source metadata is supplied in [refs.bib](refs.bib) and [citation_support.json](citation_support.json).\n'
(P/'paper.md').write_text(header+s+bibliography+'\n')
print('Wrote paper.md from TeX; primary-source links and mathematical expressions preserved.')
