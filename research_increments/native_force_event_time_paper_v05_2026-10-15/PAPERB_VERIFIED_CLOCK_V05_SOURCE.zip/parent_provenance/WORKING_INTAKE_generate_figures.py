"""Code-native manuscript diagrams; numeric panels use pinned inherited summaries only."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT=Path(__file__).parent/'figures';OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
INK='#173043';BLUE='#2878B5';GREEN='#2C8B78';ORANGE='#C47825';RED='#B54E52';LIGHT='#F3F6F8'
def box(ax,x,y,w,h,title,body,color=BLUE,dashed=False):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012,rounding_size=0.022',lw=1.15,edgecolor=color,facecolor=LIGHT,linestyle='--' if dashed else '-'))
 ax.text(x+.025,y+h-.046,title,va='top',weight='bold',color=color,fontsize=8.0)
 ax.text(x+.025,y+h-.112,body,va='top',linespacing=1.36,color=INK,fontsize=7.5)
def arrow(ax,p,q,color=INK,style='-',bend=0):
 ax.add_patch(FancyArrowPatch(p,q,arrowstyle='-|>',mutation_scale=10,linewidth=1,color=color,linestyle=style,connectionstyle=f'arc3,rad={bend}'))
fig=plt.figure(figsize=(7.1,3.8));ax=fig.add_axes([.012,.025,.976,.94]);ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
ax.text(.015,.99,'A  Physical contract: original attempt and deadline stay fixed',weight='bold',color=INK,fontsize=9,va='top')
box(ax,.015,.655,.255,.24,'Physical events / requests','onset interval ≠ confirmation\nsubmit ≠ apply ≠ effect\nnoncancellable commitment',BLUE)
box(ax,.355,.655,.29,.24,'Prefix verifier','only arrived, qualified evidence\nTRUE / FALSE / UNKNOWN\nhard FALSE remains absorbing',ORANGE)
box(ax,.73,.655,.255,.24,'Local recovery','hard miss survives recovery\nreset → new attempt identity\nold attempt remains counted',RED)
arrow(ax,(.275,.775),(.346,.775));arrow(ax,(.65,.775),(.72,.775))
ax.text(.015,.58,'B  Proposed policy study: matched controls',weight='bold',color=INK,fontsize=9)
box(ax,.015,.21,.255,.275,'Public decision history','delivered RGB / proprioception\npublic event + request packets\nprivate referee signals excluded',BLUE)
box(ax,.355,.21,.29,.275,'Residual ledger + TimeDP','original window / known dwell\nresources / pending commitments\nM vs. same-pool B3; untrained',GREEN,True)
box(ax,.73,.21,.255,.275,'Typed training pairs','S: verified complete success\nF: teacher correction\n    at student visits\nR: executed, verified recovery',GREEN,True)
arrow(ax,(.275,.342),(.346,.342));arrow(ax,(.72,.342),(.65,.342),GREEN,style='--')
arrow(ax,(.625,.645),(.625,.5),ORANGE);ax.text(.44,.526,'public packet only',fontsize=6.3,color=ORANGE);arrow(ax,(.855,.645),(.855,.5),RED)
ax.text(.49,.083,'Shared weights → deployment → new verified experience',ha='center',color=INK,fontsize=8)
arrow(ax,(.43,.207),(.43,.12),GREEN,style='--');arrow(ax,(.91,.105),(.88,.205),GREEN,style='--',bend=.08)
ax.text(.015,.012,'Solid: specified interface. Dashed: proposed learning / absorption, no new policy result.',color='#5D6871',fontsize=7)
for ext in ('pdf','svg','png'):fig.savefig(OUT/f'method_contract.{ext}',dpi=220,bbox_inches='tight')
plt.close(fig)
fig,axs=plt.subplots(1,3,figsize=(7.1,2.3));fig.subplots_adjust(left=.065,right=.99,bottom=.23,top=.78,wspace=.43)
axs[0].bar(range(4),[8,8,8,8],color=[BLUE,GREEN,ORANGE,'#796BA3'],width=.65);axs[0].set_xticks(range(4),['Batch','HSM','EDF','MPC'],fontsize=7);axs[0].set_ylim(0,9);axs[0].set_yticks([0,4,8]);axs[0].set_ylabel('Primary joint TRUE / 8 known cells',fontsize=7);axs[0].set_title('A  Strong scheduler ties',loc='left',fontsize=8,weight='bold')
for i in range(4):axs[0].text(i,8.15,'8/8',ha='center',fontsize=7)
xs=[0,1,2];axs[1].bar([x-.18 for x in xs],[18,9,18],width=.35,color=BLUE,label='Native');axs[1].bar([x+.18 for x in xs],[9,9,18],width=.35,color=ORANGE,label='Wall');axs[1].set_xticks(xs,['Paused','Blocking','Scheduled'],fontsize=6.5);axs[1].set_ylim(0,20);axs[1].set_yticks([0,9,18]);axs[1].set_ylabel('TRUE / 18 CPU trials',fontsize=7);axs[1].set_title('B  Two clocks differ',loc='left',fontsize=8,weight='bold');axs[1].legend(frameon=False,fontsize=6.5,loc='upper left',bbox_to_anchor=(0,1.01),ncol=2)
axs[2].bar([0,1,2],[23.6979166667,29.0364583333,100],color=[BLUE,ORANGE,GREEN],width=.65);axs[2].set_xticks([0,1,2],['History','Expert','Rule memory'],fontsize=6.5);axs[2].set_ylim(0,115);axs[2].set_yticks([0,50,100]);axs[2].set_ylabel('Retained-history score (%)',fontsize=7);axs[2].set_title('C  Memory is a strong control',loc='left',fontsize=8,weight='bold')
for i,v in enumerate([23.6979166667,29.0364583333,100]):axs[2].text(i,v+3,f'{v:.1f}',ha='center',fontsize=7)
fig.text(.065,.04,'Inherited development diagnostics; distinct scopes, not measurements of the proposed learned method.',fontsize=7,color='#5D6871')
for ext in ('pdf','svg','png'):fig.savefig(OUT/f'negative_controls.{ext}',dpi=220,bbox_inches='tight')
plt.close(fig)
(OUT/'FIGURE_SCOPE.json').write_text(json.dumps({'method_contract':'schematic proposed mechanism; no empirical policy result','negative_controls':'pinned inherited paired32 / clock54 / symbolic adaptation summaries','force_numeric_figures':0,'new_native_runs':0,'new_training_runs':0,'new_raw_reads':0},indent=2)+'\n')
