"""Plot only SHA-bound fixed-window series exported by the prospective reader."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def load_case(directory):
    report_path = directory / 'REPORT.json'
    series_path = directory / 'AUDITED_SERIES.json'
    report = json.loads(report_path.read_text())
    series = json.loads(series_path.read_text())
    pin = report.get('series_sha256') or report.get('audited_series_sha256')
    if pin != sha(series_path):
        raise ValueError('AUDITED_SERIES_PIN_REQUIRED')
    rows = series['rows']
    if len(rows) != 49 or [r['tick'] for r in rows] != list(range(rows[0]['tick'], rows[0]['tick'] + 49)):
        raise ValueError('FIXED_ALL49_SERIES_REQUIRED')
    if any(r['case_id'] != series['case_id'] for r in rows):
        raise ValueError('CASE_ID_MISMATCH')
    return series, report, {'report_sha256':sha(report_path), 'series_sha256':sha(series_path)}


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--audit-root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args = parser.parse_args()
    ids = ['cal_force_c0_freefall_v03','cal_force_c1_stack_v03','cal_force_c2_rotated_v03','cal_force_c3_actor_order_v03','cal_force_c4_mass_v03','cal_force_c1_stack_processing_off_v03']
    cases = {}; provenance = {}
    for case_id in ids:
        directory = args.audit_root / case_id
        if (directory / 'AUDITED_SERIES.json').is_file():
            series, report, pins = load_case(directory)
            cases[case_id] = (series, report);provenance[case_id] = pins
    if not cases:
        raise ValueError('NO_AUDIT_BOUND_NATIVE_SERIES_NO_FIGURE')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42,'axes.titlesize':12,'axes.labelsize':11})
    fig, axes = plt.subplots(3, 2, figsize=(7.0, 7.3), layout='constrained')
    blue, orange, gray = '#216b89', '#b06938', '#7c8588'
    titles = ['A  Free fall','B  Gravity support','C  Rotated fixture','D  Scene order reversed','E  Doubled top mass','F  Processing OFF']
    for i, case_id in enumerate(ids):
        ax=axes.flat[i];ax.set_title(titles[i],loc='left',fontweight='bold')
        if case_id not in cases:
            ax.text(.5,.5,'No auditable native series',ha='center',va='center',transform=ax.transAxes,color=gray)
            ax.set_axis_off();continue
        rows=cases[case_id][0]['rows']
        x=np.array([r['native_time_s'] for r in rows]); x=(x-x[0])*1000
        if i==0:
            y=np.array([r['acceleration_A_world'][2] for r in rows])
            expected=np.array([r['gravity_world'][2] for r in rows]); tol=.05
            label='Measured acceleration'; unit='World z acceleration (m/s²)'
        else:
            component=0 if i==2 else 2
            y=np.array([r['pair_normal_AB_world'][component] for r in rows])
            expected=np.array([-r['mass_A_kg']*r['gravity_world'][component] for r in rows])
            tol=np.array([max(.01,.02*r['mass_A_kg']*np.linalg.norm(r['gravity_world'])) for r in rows])
            label='Measured pair force';unit='World '+('x' if i==2 else 'z')+' force (N)'
        ax.fill_between(x,expected-tol,expected+tol,color=orange,alpha=.13,label='Frozen tolerance')
        ax.plot(x,expected,'--',color=orange,lw=1.15,label='Independent expectation')
        ax.plot(x,y,color=blue,lw=1.3,marker='.',ms=2.3,label=label)
        ax.set_xlabel('Within fixed window (ms)');ax.set_ylabel(unit)
        ax.grid(axis='y',alpha=.14);ax.set_xlim(0,x[-1])
        if i==0:ax.legend(frameon=False,fontsize=9,loc='best')
    args.out.mkdir(parents=True,exist_ok=True)
    outputs={}
    for suffix in ['svg','pdf','png']:
        target=args.out/('signed_force_calibration.'+suffix)
        if target.exists():raise ValueError('NO_OVERWRITE_FIGURE')
        fig.savefig(target,dpi=180,metadata={'Creator':'Paper B; independently audited native fixed-window traces'} if suffix=='pdf' else None)
        outputs[target.name]={'sha256':sha(target),'bytes':target.stat().st_size}
    plt.close(fig)
    receipt={'schema':'PaperBNativeForceCalibrationFigure/1','input_audits':provenance,'outputs':outputs,'fixed_window_samples_per_case':49,'smoothing':False,'window_search':False,'qualified_SFR_admission':0,'scope':'Five positive fixtures and one predeclared disabled-processing negative control; all actual numeric failures retained. No hardware or learned-method claim.', 'native_epochs_per_case':1, 'negative_control_case':'cal_force_c1_stack_processing_off_v03'}
    with (args.out/'FIGURE_RECEIPT.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
    print(json.dumps(receipt))

if __name__=='__main__':main()
