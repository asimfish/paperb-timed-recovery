# Confirmed Contribution

## Core Contribution

| Field | Content |
|---|---|
| Main contribution statement | Specify and software-test a failure-preserving causal experience contract, then propose an equal-information residual-ledger policy absorption experiment whose learned advantage remains untested. |
| Contribution type | new analysis-or-benchmark |
| One-sentence reviewer payoff | A usable correction or safe local recovery need not corrupt the identity or deadline verdict of its original failed operation. |

## Why This Contribution Is Needed

| Field | Content |
|---|---|
| Field problem | Robot agents collect experience for temporally constrained operations whose physical effects and independent observations occur at different times. |
| Specific gap | Final workspace state, command acknowledgement and teacher proposals cannot substitute for qualified physical outcome or actual student execution in feedback admitted to policy learning. |
| Concrete challenge | Delayed/partial evidence, original irreversible failure, actor takeovers and uncertain contact representations coexist in one recorded attempt. |
| Why prior work leaves it unresolved | Chronos addresses physical-time action policies; DAgger addresses visited-state supervision; chemistry twins address simulation and workflow. The proposed test addresses their causal evidence interface, without claiming those established ideas are new. |

## How This Paper Responds

| Field | Content |
|---|---|
| Design response | Separate occurrence/confirmation/audit/delivery; preserve original deadline/attempt/failure; admit typed S/F/R and source-bound actors; derive the ledger only from the exact finite baseline prefix. |
| Evidence required | Independently qualified physical force/events, prospective native collector and legal actual student-state pairs, equal-budget M/B3 learned results, parameter retention, task-graph transfer and independent chemistry endpoints. |
| Evidence available | Existing scheduler tie/clock/symbolic controls; retained M0/M1 failures; lossless M2 selected raw trace; one tiny P0 engineering checkpoint; G1 bridge 90 current CPU tests plus 6 independent probes and complete synthetic long-trace audit; v02 conditional freefall pass/retained support rejection; v03 five ON conditional passes and disabled negative-control measurement failure. |
| Evidence missing | Force SI/frame/load/unload qualification and native full learning collector; main VLA weights, qualified S/F/R pools, untouched task-composition evaluation and hardware/chemistry results. Root-sealed v03 readback closes the six-case conditional fixture study; robot learning and physical endpoint gaps remain. |

## Claim Boundary

| Field | Content |
|---|---|
| Strong claims allowed | Explicit contract invariants and scoped software conformance, retained diagnostic outcomes, real parameter updates in one engineering CPU checkpoint, a falsifiable unexecuted main learning study. |
| Claims to soften or avoid | Main VLA improvement, first time-aware VLA, real student rollouts from synthetic CPU events, physics qualification from signed-format consistency, recovery erasing original hard failure, retrospective M1 scalar recovery. |
| Novelty risk | A deterministic ledger and DAgger-like aggregation are established ideas; the learned contribution requires a controlled M/B3 advantage from the same data/history, not an extra teacher or timer. |
| Significance risk | Present evidence is an engineering/causal contract draft, insufficient for a top-conference method acceptance claim until the preregistered learned and physical gates are met. |
