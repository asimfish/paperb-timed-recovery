# Versioned rewrite matrix

| Parent unit | v04 change | Evidence preserved |
|---|---|---|
| Abstract and introduction | Distinguish M2 lossless case, one P0 engineering checkpoint and synthetic G1 from main VLA | No gained policy/chemical/hardware result claimed |
| History/ledger | Declare identical finite prefix plus shared public clock; deterministic-information consequence | Original interval/failure equations unchanged; no private teacher input |
| Typed F/R | Bind confirmed failedstudent APPLIED action; R purpose and post-D originalFALSE explicit | Teacher target remains unexecuted supervision; safety abort not S/R |
| Native table | Add M2 censored column and scopes | M0/M1 failure records and original numbers unchanged |
| Limitations | Remove obsolete source-only lossless-capture and global all-weights-zero narrative | General physical qualification and main method remain open |
| Appendix | Add exact M2/P0/G1, retained calibration/shutdown accounting and P0 actual figure | No raw scalar retrofitting, no future native PASS or invented series |
| Markdown | General authored table/figure extraction and resolved labels | Values derive from current TeX; no hardcoded older result table |
| Provenance | Old manifest/input pins retained under parent_provenance, new current input pins reserved | Parent hashes never masquerade as current hashes |
