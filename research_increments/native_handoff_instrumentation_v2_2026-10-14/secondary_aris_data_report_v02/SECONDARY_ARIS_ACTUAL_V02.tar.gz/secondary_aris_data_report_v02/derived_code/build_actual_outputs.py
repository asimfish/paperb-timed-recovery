"""CPU descriptive figures/media from saved actual getter/JPEG observations.

This code is bound after actual secondary readback, never a new referee or a
change to frozen postreader/physical semantics. No simulation/ML imports.
"""
from collections import Counter
import csv
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = Path('/data/liyufeng/paperb_handoff_instrumentation_20261014_v2_aris')
CASE = RUNTIME / 'cases/dev_seen_handoff_instrumentation_002_aris'
TASK = CASE / 'task'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def put(path, value):
    with path.open('x') as out:
        json.dump(value,out,indent=2,sort_keys=True,allow_nan=False);out.write('\n')


def number(value):
    return float(value) if value not in ('',None) else None


def norm(values):
    return math.sqrt(sum(v*v for v in values)) if all(v is not None for v in values) else None


def main():
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    from PIL import Image

    source_csv=ROOT/'actual/physical_timeline.csv'
    with source_csv.open() as stream:
        rows=list(csv.DictReader(stream))
    summary=json.loads((ROOT/'actual/SUMMARY.json').read_text())
    operation=json.loads((TASK/'expanded_events.json').read_text())
    timing=json.loads((TASK/'timing_score.json').read_text())
    assert len(rows)==28016
    origin=float(rows[0]['native_time_s'])
    observed=summary['physical']['unique_value_counts']
    assert len(observed['scene_gravity_world_m_s2'])==1 and observed['scene_gravity_world_m_s2'][0]['rows']==28016
    gravity=observed['scene_gravity_world_m_s2'][0]['value']
    output=ROOT/'derived';output.mkdir(exist_ok=False)
    figs=ROOT/'figures';figs.mkdir(exist_ok=False)
    media=ROOT/'media';media.mkdir(exist_ok=False)
    for row in rows:
        row['task_native_elapsed_s']=float(row['native_time_s'])-origin
        row['actual_COM_linear_speed_m_s']=norm([number(row[k]) for k in ['vx_m_s','vy_m_s','vz_m_s']])
        row['actual_COM_angular_speed_rad_s']=norm([number(row[k]) for k in ['wx_rad_s','wy_rad_s','wz_rad_s']])
        row.update(scene_gravity_x_m_s2=gravity[0],scene_gravity_y_m_s2=gravity[1],scene_gravity_z_m_s2=gravity[2],
                   backend_kinematic='UNKNOWN_NO_INSTALLED_TENSOR_GETTER',backend_constraints='UNKNOWN_NO_COMPLETE_INSTALLED_GETTER',
                   velocity_measurement='ACTUAL_GET_VELOCITIES_WORLD_COM_NOT_POSE_FINITE_DIFFERENCE')
    with (output/'actual_getter_parameters_velocity.csv').open('x',newline='') as out:
        writer=csv.DictWriter(out,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    pre=[r for r in rows if r['phase']=='PRE_WRITE'];post=[r for r in rows if r['phase']=='POST_STEP']
    assert len(pre)==len(post)==14007
    # Preserve representative actual raw getter fields and all endpoint scope.
    with (TASK/'physical_snapshots.jsonl').open() as stream:
        first=json.loads(next(stream))
        last=first
        for line in stream:last=json.loads(line)
    speed=[r['actual_COM_linear_speed_m_s'] for r in post]
    angular=[r['actual_COM_angular_speed_rad_s'] for r in post]
    mechanism=dict(status='SECONDARY_ACTUAL_GETTER_DESCRIPTIVE_ONLY',case='dev_seen_handoff_instrumentation_002_aris',
        dataset_role='DEVELOPMENT_SEEN',shared_denominator=1,physical_rows=28016,states=14007,submitted=13995,applied=13995,
        scalar_getter_counts=observed,phase_counts=summary['physical']['phase_counts'],
        instantaneous_PRE_active_counts=dict(Counter(r['instantaneous_active'] for r in pre)),
        permanent_PRE_active_counts=dict(Counter(r['permanent_active'] for r in pre)),
        instantaneous_PRE_force_body_N_counts=dict(Counter(r['instantaneous_force_body_N'] for r in pre)),
        permanent_PRE_force_body_N_counts=dict(Counter(r['permanent_force_body_N'] for r in pre)),
        first_rigid_body_getters=first['rigid_body'],first_external_wrench_buffers=first['external_wrench_buffers'],
        endpoint_usd=dict(begin=first.get('usd_inventory'),end=last.get('usd_inventory')),
        actual_COM_linear_speed=dict(max_m_s=max(speed),median_m_s=float(np.median(speed)),p95_m_s=float(np.quantile(speed,.95)),
            known_samples=sum(v is not None for v in speed),unknown_samples=sum(v is None for v in speed)),
        actual_COM_angular_speed=dict(max_rad_s=max(angular)),
        source_velocity='root_physx_view.get_velocities WORLD COM; not pose-difference proxy',
        original_sampled_hold=False,missing_bilateral_sample_indices=operation['sampled_contact_hold']['missing_bilateral_sample_indices'],
        original_timing_score=timing,independent_load='UNKNOWN_INSTRUMENTATION_ONLY',
        physical_missing_boundary='Backend kinematic/constraints and calibrated contact force balance unresolved; zero composer buffers do not prove total external forces zero',
        inherited_reader_status=summary['status'],depth_shape_findings=summary['findings_count'],depth_shape='400x640x1 float32 observed; frozen reader expects400x640',
        task_RGB_depth_captures=176,initial_RGB_depth_capture=1,total_RGB_depth_captures=177,
        capture_delivery='OFFLINE_CAPTURE; policy delivery None; not proof student saw images',
        original_score_source=dict(path=str(TASK/'expanded_events.json'),sha256=sha(TASK/'expanded_events.json')),
        numpy=np.__version__,matplotlib=matplotlib.__version__,native_modules_loaded=[m for m in ['torch','isaacsim','isaaclab'] if m in sys.modules],
        new_native=0,GPU=0,training_admitted=0,new_weights=0)
    put(output/'ACTUAL_GETTER_MECHANISM.json',mechanism)
    time=np.array([r['task_native_elapsed_s'] for r in post])
    linear=np.array(speed);spin=np.array(angular)
    release=operation['events']['supported_release'];grasp=operation['events']['bilateral_grasp']
    release_onset=release['event']['bounds_s'][1]-origin
    release_confirm=release['confirmation_time_s']-origin
    applied=operation['applied_commands']['release']['bounds_s'][0]-origin
    missed=operation['sampled_contact_hold']['missing_bilateral_sample_indices']
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
    fig,ax=plt.subplots(3,1,figsize=(11,9),constrained_layout=True)
    fig.suptitle('DEVELOPMENT_SEEN | original sampled hold = FALSE | independent load = UNKNOWN\nActual getter readback; not a successful learning demonstration',fontsize=13)
    ax[0].plot(time,linear,color='#185b83',lw=.8,label='Actual COM linear speed from get_velocities')
    ax[0].set_ylabel('Linear speed (m/s)');ax[0].set_title('(a) Full 14,007 POST_STEP velocity samples',loc='left')
    other=ax[0].twinx();other.plot(time,spin,color='#b66716',lw=.5,alpha=.55,label='Actual COM angular speed');other.set_ylabel('Angular speed (rad/s)',color='#b66716')
    ax[0].axvline(grasp['event']['bounds_s'][1]-origin,color='#8a9299',ls=':',lw=1)
    ax[0].axvline(release_onset,color='#742424',ls=':',lw=1)
    ax[0].legend(loc='upper left',frameon=False)
    zoom=(time>release_onset-.6)&(time<release_confirm+.25)
    ax[1].plot(time[zoom],linear[zoom],color='#185b83',lw=1,label='Actual COM speed')
    ax[1].scatter(time[missed],linear[missed],s=27,marker='s',color='#bf4141',zorder=5,label='11 missing bilateral-contact samples')
    for t,label,color in [(applied,'Open command APPLIED','#8d6505'),(release_onset,'Release onset upper bound','#632929'),(release_confirm,'Release confirmation','#777777')]:
        ax[1].axvline(t,color=color,ls='--',lw=1,label=label)
    ax[1].set_title('(b) Native release neighborhood: application, onset and confirmation remain distinct',loc='left')
    ax[1].set_ylabel('Linear speed (m/s)');ax[1].legend(loc='upper left',frameon=False,fontsize=8,ncol=2)
    pret=np.array([r['task_native_elapsed_s'] for r in pre])
    for kind,col in [('instantaneous','#185b83'),('permanent','#b66716')]:
        values=[json.loads(r[kind+'_force_body_N'])[0][0][2] if r[kind+'_force_body_N'] else np.nan for r in pre]
        ax[2].plot(pret,values,label=kind+' PRE_WRITE commanded body-frame Fz',color=col,lw=1,ls='-' if kind=='instantaneous' else '--')
    ax[2].set_title('(c) PRE_WRITE input buffers: both composers inactive at all 14,007 ticks',loc='left')
    ax[2].set_ylabel('Body-frame input Fz (N)');ax[2].set_ylim(-.1,.1);ax[2].legend(loc='upper left',frameon=False,fontsize=9)
    for a in ax:
        a.set_xlabel('Actual native elapsed time from TASK_BEGIN (s)');a.grid(alpha=.15)
    for ext in ['svg','pdf','png']:
        fig.savefig(figs/('actual_velocity_release_mechanism.'+ext),dpi=180,metadata={'Creator':'Secondary actual CPU getter report'} if ext in ['svg','pdf'] else None)
    plt.close(fig)
    # Video uses the exact video_frames subset; native time is the display PTS
    # source. Irregular gaps display the last captured image, with no new views.
    captures=json.loads((TASK/'capture_index.json').read_text())
    video=json.loads((TASK/'video_frames.json').read_text())
    frames=video['frames'];assert len(frames)==168
    assert all(abs(frames[i+1]['native_time_s']-frames[i]['native_time_s']-1/6)<1e-6 for i in range(len(frames)-1))
    for frame in frames:
        assert frame in captures and sha(TASK/frame['image'])==frame['image_sha256']
    zero=frames[0]['native_time_s']
    concat=media/'actual_frames.ffconcat'
    with concat.open('x') as out:
        out.write('ffconcat version 1.0\n')
        for i,frame in enumerate(frames):
            path=(TASK/frame['image']).resolve();assert "'" not in str(path)
            out.write("file '"+str(path)+"'\n")
            duration=frames[i+1]['native_time_s']-frame['native_time_s'] if i+1<len(frames) else 1/6
            out.write('duration '+format(duration,'.12f')+'\n')
        out.write("file '"+str((TASK/frames[-1]['image']).resolve())+"'\n")
    mp4=media/'development_seen_actual_native_rgb.mp4'
    banner='DEVELOPMENT_SEEN | old hold FALSE | load UNKNOWN | not training data'
    command=['ffmpeg','-hide_banner','-nostdin','-loglevel','warning','-threads','2','-f','concat','-safe','0','-i',str(concat),
        '-vf',"settb=expr=1/240000,setpts=N*40000,drawbox=x=0:y=0:w=iw:h=25:color=black@0.80:t=fill,drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:text='"+banner+"':x=7:y=6:fontsize=11:fontcolor=white",
        '-vsync','vfr','-r','6','-c:v','libx264','-preset','medium','-crf','20','-threads','2','-pix_fmt','yuv420p','-video_track_timescale','240000','-movflags','+faststart','-an','-n',str(mp4)]
    with (media/'FFMPEG.log').open('x') as out:
        out.write(json.dumps(command)+'\n');out.flush();subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,check=True)
    probe=subprocess.run(['ffprobe','-v','error','-select_streams','v:0','-show_frames','-show_streams','-show_format','-of','json',str(mp4)],capture_output=True,text=True,check=True)
    decoded=json.loads(probe.stdout);put(media/'FFPROBE.json',decoded)
    pts=[float(f['best_effort_timestamp_time']) for f in decoded['frames']]
    assert len(pts)==len(frames)+1 and all(a<b for a,b in zip(pts,pts[1:]))
    mapping=[]
    for i,frame in enumerate(frames):
        mapping.append(dict(encoded_frame=i,camera_capture_index=captures.index(frame),command_index=frame['command_index'],
            native_time_s=frame['native_time_s'],task_native_elapsed_s=frame['native_time_s']-origin,
            expected_video_pts_s=frame['native_time_s']-zero,actual_video_pts_s=pts[i],
            native_epoch=frame['native_epoch'],source_JPEG=frame['image'],source_JPEG_sha256=frame['image_sha256'],
            image_sha_verified=True,display='SAVED_CAMERA_FRAME_NO_INTERPOLATION'))
    max_error=max(abs(v['expected_video_pts_s']-v['actual_video_pts_s']) for v in mapping)
    assert max_error<.01,max_error
    poster_index=min(range(len(frames)),key=lambda i:abs(frames[i]['native_time_s']-(origin+32)))
    shutil.copyfile(TASK/frames[poster_index]['image'],media/'poster_actual_native.jpg')
    assert sha(media/'poster_actual_native.jpg')==frames[poster_index]['image_sha256']
    with Image.open(media/'poster_actual_native.jpg') as image:
        image.load();assert image.size==(640,400) and image.mode=='RGB'
    put(media/'VIDEO_NATIVE_TIME_MAPPING.json',dict(status='PASS_ACTUAL_JPEG_SUBSET_AND_NATIVE_PTS_MAPPING',role='DEVELOPMENT_SEEN',
        source_capture_index_sha256=sha(TASK/'capture_index.json'),source_video_frames_sha256=sha(TASK/'video_frames.json'),
        camera_images=168,encoded_frames=169,last_duplicate_display_frame='Repeat of final captured image to honor final display interval; not a new capture',
        task_origin_native_s=origin,video_zero_native_s=zero,native_epoch=frames[0]['native_epoch'],
        mapping=mapping,maximum_video_pts_rounding_error_s=max_error,
        poster=dict(source_frame=poster_index,source_JPEG=frames[poster_index]['image'],source_sha256=frames[poster_index]['image_sha256']),
        codec='CPU libx264; no GPU',no_synthetic_or_AI_frames=True,not_real_robot='ACTUAL_NATIVE_SIMULATION_CAMERA',
        old_sampled_hold=False,independent_load='UNKNOWN',training_admitted=0,
        sampling='Validated6Hz actual native samples; container240000Hz timebase; no motion interpolation',
        observation_mode='OFFLINE_CAPTURE',student_delivery=None,mp4_sha256=sha(mp4)))
    print(json.dumps(dict(status='DERIVED_CPU_ACTUAL_OUTPUTS_WRITTEN',getter_rows=28016,plot_formats=['SVG','PDF','PNG'],camera_frames=168,encoded_frames=169,max_PTS_error_s=max_error)))


if __name__=='__main__':
    main()
