"""Write-once reproduction of the actual PRE composer CSV/receipt export.

The same body was executed as a CPU command during this descriptive report;
this source file preserves that command for another empty output directory.
"""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json


def main():
    root=Path(__file__).resolve().parents[1]
    path=Path('/data/liyufeng/paperb_handoff_instrumentation_20261014_v2_aris/cases/dev_seen_handoff_instrumentation_002_aris/task/physical_snapshots.jsonl')
    before=hashlib.sha256(path.read_bytes()).hexdigest()
    counts,rows={},[]
    with path.open() as stream:
        for line in stream:
            value=json.loads(line)
            if value['phase']!='PRE_WRITE':continue
            row=dict(tick=value['tick'],phase='PRE_WRITE',native_time_s=value['native_clock_before']['time_s'])
            for kind in ['instantaneous','permanent']:
                record=value['external_wrench_buffers'][kind];body=record.get('value') or {}
                for key in ['active','force_body_frame_N','torque_body_frame_N_m']:
                    encoded=json.dumps(body.get(key),sort_keys=True)
                    name=kind+'_'+key;counts.setdefault(name,Counter())[encoded]+=1;row[name]=encoded
                row[kind+'_status']=record['status']
            rows.append(row)
    assert len(rows)==14007 and hashlib.sha256(path.read_bytes()).hexdigest()==before
    with (root/'derived/PRE_WRITE_COMPOSER_PARAMETERS.csv').open('x',newline='') as out:
        writer=csv.DictWriter(out,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    receipt=dict(status='PASS_ACTUAL_PRE_COMPOSER_PARAMETERS_EXPORTED',rows=14007,source_sha256=before,
        raw_hash_unchanged=True,unique_value_counts={k:dict(v) for k,v in counts.items()},
        frame='BODY_LINK_FRAME',units=['N','N m'],no_total_force_or_load_claim=True)
    for name,values in receipt['unique_value_counts'].items():
        if name.endswith('torque_body_frame_N_m'):assert values=={'[[[0.0, 0.0, 0.0]]]':14007}
    with (root/'derived/PRE_WRITE_COMPOSER_READBACK.json').open('x') as out:
        json.dump(receipt,out,indent=2,sort_keys=True);out.write('\n')


if __name__=='__main__':
    main()
