# ARIS 次级reader v02：明确depth ABI修复

本版在已知同一个episode旧secondary actual177个DEPTH_SHAPE_DTYPE红后修复，非事前盲测、非第三独立裁判。SDK camera.py明示distance_to_image_plane为(H,W,1)，producer将depth[0].cpu().numpy()原样NPZ保存。因此只将旧2D期望改为exact(height,width,1)、floating kind；不squeeze、不接受多channel/axes/NaN/negative infinity/负深度。不修改任何物理getter/validator、FIFO、source、clock、事件或时间阈值。

旧16source、实际177红、CPU30历史及首次媒体ffmpeg4.4 option失败完整保存在inherited_red并逐字hash；原旧目录不改。新focus8项CPU shape/refusal检查实际运行，旧30只历史不说重跑。修复后的第二次实际CPU读仍是同一case、同一原生episode，共同分母1；新native/GPU/train/θ/labels0。

全部28016 snapshots/14007states/13995submit+apply保留。task captures176+initial1=177，video subset168原JPEG。旧hold FALSE（11missing ticks）与independentload UNKNOWN保持；backend constraint/kinematic和卸载、force-balance仍未验证。实际velocity来自get_velocities COM，不是旧pose差分代理。所有图、video均DEVELOPMENT_SEEN和非成功学习示范。

新视频仅依据原video_frames/capture_index实际JPEG映射。ffmpeg4.4使用已验证6Hz样本序列生成视频PTS，并保留每frame实际native/task时钟与编码PTS的实测误差；无AI/运动插值，最后显示重复帧另标为display而非newcapture。poster为原JPEG逐字复制。物理判分从不使用video时钟。
