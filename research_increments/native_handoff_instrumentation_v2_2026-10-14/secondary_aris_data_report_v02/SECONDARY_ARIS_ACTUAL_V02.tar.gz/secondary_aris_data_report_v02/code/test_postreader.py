"""Tiny CPU fixtures, not production rows or robot episodes."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

import numpy as np
from PIL import Image
from physical_capture import capture_snapshot,digest
from postreader import Report,check_physical,check_fifo,check_captures,run

EPOCH="SYNTHETIC_NOT_NATIVE"
BODY="/World/StationA/precursor_1"


class FakeBody:
    def get_transforms(self):return [[0.,0.,1.,0.,0.,0.,1.]]
    def get_velocities(self):return [[0.]*6]
    def get_accelerations(self):return [[0.]*6]
    def get_masses(self):return [[.135]]
    def get_inv_masses(self):return [[1/.135]]
    def get_coms(self):return [[0.,0.,0.,0.,0.,0.,1.]]
    def get_inertias(self):return [[1.,0.,0.,0.,1.,0.,0.,0.,1.]]
    def get_disable_gravities(self):return [[0]]
    def get_disable_simulations(self):return [[0]]
class FakeSim:
    def get_gravity(self):return [0.,0.,-9.81]
class FakeComposer:
    active=False
    composed_force_as_torch=[[[0.,0.,0.]]]
    composed_torque_as_torch=[[[0.,0.,0.]]]
class FakeAsset:
    instantaneous_wrench_composer=FakeComposer()
    permanent_wrench_composer=FakeComposer()


def snapshot(tick,phase,time,count):
    return capture_snapshot(body_view=FakeBody(),simulation_view=FakeSim(),rigid_object=FakeAsset(),
       clock_read=lambda:dict(native_epoch=EPOCH,time_s=time,callback_count=count),tick=tick,phase=phase,body_path=BODY)


def seal(row):
    row['record_sha256']=digest({k:v for k,v in row.items() if k!='record_sha256'})
    return row


def fixtures():
    source=[0,0,1];delay=1;dt=.01;arm=[[.1]*7,[.2]*7];grip=[[.01]*2,[.02]*2]
    states=[];dispatch=[];events=[];pending=[];appsrc=-1;appid=-1;ta,tg=arm[0],grip[0]
    physical=[snapshot(-1,'TASK_BEGIN',0.,10)]
    for i in range(4):
        before=i*.01;after=(i+1)*.01;submitted=None;applied=None
        if i<3:
            s=source[i];submitted=dict(command_id=i,source_index=s,enqueue_tick=i,ready_tick=i+1,sampled_delay_ticks=1,
                native_epoch=EPOCH,enqueue_time_s=before,ready_time_nominal_prediction_s=(i+1)*dt,arm_target=arm[s],grip_target=grip[s]);pending.append(submitted)
        if pending and pending[0]['ready_tick']<=i:
            applied=dict(pending.pop(0),apply_tick=i,apply_time_s=before,ready_observed_time_s=before)
            appsrc,appid=applied['source_index'],applied['command_id'];ta,tg=applied['arm_target'],applied['grip_target']
        ids=[p['command_id'] for p in pending]
        states.append(dict(command_index=i,native_epoch=EPOCH,native_before_s=before,native_after_s=after,semantic_tick=11+i,
            source_command_index=appsrc,submitted_source_command_index=source[i] if i<3 else None,applied_source_command_index=appsrc,
            applied_command_id=appid,pending_command_ids=ids,arm_target=ta,grip_target=tg,q_all=[.3]*9,qd_all=[0.]*9,
            object_pose=[0.,0.,1.,1.,0.,0.,0.]))
        dispatch.append(dict(tick=i,native_epoch=EPOCH,native_before_s=before,submitted=submitted,applied=applied,pending_command_ids=ids,
            held_previous_target=applied is None,applied_source_command_index=appsrc,applied_command_id=appid))
        if submitted:events.append(dict(event='SUBMITTED',**submitted))
        if applied:events.append(dict(event='APPLIED',**applied))
        physical += [snapshot(i,'PRE_WRITE',before,10+i),snapshot(i,'POST_STEP',after,11+i)]
    physical.append(snapshot(4,'TASK_END',.04,14))
    return physical,states,dispatch,events,dict(source_indices=source),arm,grip


def phys(rows=None,states=None):
    p,s,*_=fixtures();report=Report()
    result=check_physical(report,p if rows is None else rows,s if states is None else states,count=4,epoch=EPOCH,body_path=BODY)
    return report,result
def fifo(states=None,dispatch=None,events=None):
    _,s,d,e,plan,a,g=fixtures();report=Report()
    result=check_fifo(report,s if states is None else states,d if dispatch is None else dispatch,e if events is None else events,plan,a,g,delay=1,epoch=EPOCH,dt=.01)
    return report,result


def capture_files(path, *, depth=None):
    path=Path(path);(path/'images').mkdir();(path/'depth').mkdir()
    jpeg=path/'images/00001.jpg';Image.fromarray(np.full((3,4,3),100,dtype=np.uint8)).save(jpeg)
    dp=path/'depth/00001.npz';np.savez_compressed(dp,depth_m=np.ones((3,4),dtype=np.float32) if depth is None else depth)
    from postreader import sha
    return dict(command_index=1,native_epoch=EPOCH,native_time_s=.01,rendered_state_native_time_s=.01,
        observation_mode='OFFLINE_CAPTURE',policy_delivery_time_s=None,physics_callbacks_during_render=0,physical_state_changed=False,
        image='images/00001.jpg',image_sha256=sha(jpeg),depth='depth/00001.npz',native_rgb_sha256='0'*64,
        student_proprioception=dict(joint_positions=[.3]*9,joint_velocities=[0.]*9))


class ReaderTests(unittest.TestCase):
    def test_physical_complete(self):
        r,s=phys();self.assertEqual(r.errors,[]);self.assertEqual(s['load_bearing_verdict'],'UNKNOWN_INSTRUMENTATION_ONLY')
    def test_no_native_modules(self):self.assertFalse(any(x in sys.modules for x in ('isaacsim','omni.physics.tensors','torch','mujoco')))
    def test_missing_post_is_retained(self):
        p,*_=fixtures();p.pop(2);r,_=phys(p);self.assertTrue(r.errors)
    def test_mixed_epoch(self):
        p,*_=fixtures();p[2]['native_clock_before']['native_epoch']=p[2]['native_clock_after']['native_epoch']='FOREIGN';seal(p[2]);r,_=phys(p);self.assertTrue(any(x['code']=='PHYSICAL_EPOCH' for x in r.errors))
    def test_phase_order(self):
        p,*_=fixtures();p[1],p[2]=p[2],p[1];r,_=phys(p);self.assertTrue(any(x['code']=='PHYSICAL_PHASE_SEQUENCE' for x in r.errors))
    def test_callback_jump(self):
        p,*_=fixtures();p[2]['native_clock_before']['callback_count']=p[2]['native_clock_after']['callback_count']=12;seal(p[2]);r,_=phys(p);self.assertTrue(any(x['code']=='PRE_POST_CALLBACK_INCREMENT' for x in r.errors))
    def test_semantic_callback(self):
        _,s,*_=fixtures();s[0]['semantic_tick']=999;r,_=phys(states=s);self.assertTrue(any(x['code']=='POST_CALLBACK_STATE_SEMANTIC_TICK' for x in r.errors))
    def test_pose_quaternion_order(self):
        _,s,*_=fixtures();s[0]['object_pose']=[0.,0.,1.,0.,0.,0.,1.];r,_=phys(states=s);self.assertTrue(any(x['code']=='POST_TRANSFORM_STATE_POSE_EXACT' for x in r.errors))
    def test_hash_corruption(self):
        p,*_=fixtures();p[1]['tick']=2;r,_=phys(p);self.assertTrue(any(x['code']=='PHYSICAL_STRUCTURE' for x in r.errors))
    def test_bad_flag_shape(self):
        p,*_=fixtures();p[1]['rigid_body']['gravity_disabled_flag']['value']=[0];seal(p[1]);r,_=phys(p);self.assertTrue(any(x['code']=='PHYSICAL_STRUCTURE' for x in r.errors))
    def test_unknown_getter_never_zero(self):
        p,*_=fixtures();p[1]['rigid_body']['gravity_disabled_flag']=dict(status='UNKNOWN',value=None,reason='GETTER_EXCEPTION');seal(p[1]);r,s=phys(p)
        self.assertEqual(s['unknown_getter_counts']['gravity_disabled_flag:GETTER_EXCEPTION'],1);self.assertIsNone(s['timeline'][1]['gravity_disabled_flag']);self.assertEqual(s['load_bearing_verdict'],'UNKNOWN_INSTRUMENTATION_ONLY')
    def test_disabled_gravity_no_new_label(self):
        p,*_=fixtures();p[1]['rigid_body']['gravity_disabled_flag']['value']=[[1]];seal(p[1]);r,s=phys(p);self.assertEqual(s['load_bearing_verdict'],'UNKNOWN_INSTRUMENTATION_ONLY')
    def test_broken_line_keeps_position(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'raw.jsonl';path.write_text('{"tick":0}\nBROKEN\n{"tick":2}\n');r=Report();v=r.jsonl(path);self.assertEqual(len(v),3);self.assertEqual(v[1]['_reader_invalid_line'],2)
    def test_nonfinite_json_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'raw.jsonl';path.write_text('{"x":NaN}\n');r=Report();v=r.jsonl(path);self.assertEqual(len(r.errors),1)
    def test_fifo_complete(self):r,s=fifo();self.assertEqual(r.errors,[]);self.assertEqual(s['observed_applied'],3)
    def test_fifo_initial_held_target(self):
        _,s,*_=fixtures();self.assertEqual(s[0]['applied_source_command_index'],-1);r,_=fifo(s);self.assertEqual(r.errors,[])
    def test_future_target_as_applied_rejected(self):
        _,s,*_=fixtures();s[2]['arm_target']=[.2]*7;r,_=fifo(s);self.assertTrue(any(x['code']=='ACTUAL_TARGET_MATCHES_APPLIED' for x in r.errors))
    def test_pending_packet_omitted(self):
        _,_,d,*_=fixtures();d[0]['pending_command_ids']=[];r,_=fifo(dispatch=d);self.assertTrue(any(x['code']=='FIFO_PENDING_EXACT' for x in r.errors))
    def test_incomplete_tail(self):
        _,s,d,e,*_=fixtures();r,_=fifo(s[:-1],d[:-1],e[:-1]);self.assertTrue(any(x['code']=='STATE_ROW_COUNT' for x in r.errors))
    def test_command_event_dropped(self):
        *_,e,plan,a,g=fixtures();r,_=fifo(events=e[:-1]);self.assertTrue(any(x['code']=='COMMAND_EVENT_STREAM_EXACT' for x in r.errors))
    def test_decoded_jpeg_depth(self):
        with tempfile.TemporaryDirectory() as tmp:
            c=capture_files(tmp);r=Report();s=check_captures(r,[c],Path(tmp),fixtures()[1],epoch=EPOCH,width=4,height=3,expected_indices=[1]);self.assertEqual(r.errors,[]);self.assertEqual(s['records'][0]['native_rgb_sha256_recomputation'],'NOT_RECOMPUTABLE_FROM_SAVED_LOSSY_JPEG')
    def test_jpeg_byte_tampering(self):
        with tempfile.TemporaryDirectory() as tmp:
            c=capture_files(tmp);c['image_sha256']='f'*64;r=Report();check_captures(r,[c],Path(tmp),fixtures()[1],epoch=EPOCH,width=4,height=3);self.assertTrue(any(x['code']=='JPEG_BYTE_SHA' for x in r.errors))
    def test_depth_positive_inf_is_background_unknown(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=np.ones((3,4),dtype=np.float32);d[0,0]=np.inf;c=capture_files(tmp,depth=d);r=Report();s=check_captures(r,[c],Path(tmp),fixtures()[1],epoch=EPOCH,width=4,height=3);self.assertEqual(r.errors,[]);self.assertEqual(s['records'][0]['depth']['positive_inf_pixels'],1)
    def test_depth_negative_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            c=capture_files(tmp,depth=np.full((3,4),-1,dtype=np.float32));r=Report();check_captures(r,[c],Path(tmp),fixtures()[1],epoch=EPOCH,width=4,height=3);self.assertTrue(r.errors)
    def test_depth_shape_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            c=capture_files(tmp,depth=np.ones((4,3),dtype=np.float32));r=Report();check_captures(r,[c],Path(tmp),fixtures()[1],epoch=EPOCH,width=4,height=3);self.assertTrue(any(x['code']=='DEPTH_SHAPE_DTYPE' for x in r.errors))
    def test_capture_proprio_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            c=capture_files(tmp);c['student_proprioception']['joint_positions'][0]=9;r=Report();check_captures(r,[c],Path(tmp),fixtures()[1],epoch=EPOCH,width=4,height=3);self.assertTrue(any(x['code']=='CAPTURE_PROPRIO_STATE_EXACT' for x in r.errors))
    def test_capture_epoch_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            c=capture_files(tmp);c['native_epoch']='FOREIGN';r=Report();check_captures(r,[c],Path(tmp),fixtures()[1],epoch=EPOCH,width=4,height=3);self.assertTrue(any(x['code']=='CAPTURE_EPOCH' for x in r.errors))
    def test_capture_path_escape(self):
        with tempfile.TemporaryDirectory() as tmp:
            c=capture_files(tmp);c['image']='../outside.jpg';r=Report();check_captures(r,[c],Path(tmp),fixtures()[1],epoch=EPOCH,width=4,height=3);self.assertTrue(any(x['code']=='CAPTURE_EXCEPTION_RETAINED' for x in r.errors))
    def test_all_missing_case_keeps_one_denominator(self):
        with tempfile.TemporaryDirectory() as tmp:
            runtime=Path(tmp)/'EMPTY_NOT_NATIVE';runtime.mkdir();out=Path(tmp)/'SYNTHETIC_REPORT'
            s=run(runtime,out);self.assertEqual(s['shared_denominator'],1);self.assertEqual(s['missing_or_failed_cases_excluded'],0);self.assertEqual(s['status'],'PARTIAL_OR_INVALID_RETAINED');self.assertEqual(s['new_controlled_native_epochs'],0)
    def test_report_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            runtime=Path(tmp)/'EMPTY_NOT_NATIVE';runtime.mkdir();out=Path(tmp)/'SYNTHETIC_REPORT';out.mkdir()
            with self.assertRaises(FileExistsError):run(runtime,out)


if __name__=='__main__':unittest.main()
