"""Eight ABI/refusal tests only; inherited CPU30 is not rerun."""
import copy
from pathlib import Path
import tempfile
import unittest

import numpy as np
from PIL import Image

from postreader import Report, check_captures, sha


class DepthABITests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='secondary-depth-abi-cpu-')
        self.root=Path(self.tmp.name)
        self.h,self.w=3,4
        Image.new('RGB',(self.w,self.h),(20,40,60)).save(self.root/'mock.jpg',format='JPEG')
        self.record=dict(command_index=0,native_epoch='CPU_ONLY_EPOCH',native_time_s=0.0,
            rendered_state_native_time_s=0.0,observation_mode='OFFLINE_CAPTURE',policy_delivery_time_s=None,
            physics_callbacks_during_render=0,physical_state_changed=False,image='mock.jpg',
            image_sha256=sha(self.root/'mock.jpg'),depth='mock.npz',
            student_proprioception=dict(joint_positions=[0.0]*9,joint_velocities=[0.0]*9))

    def tearDown(self):
        self.tmp.cleanup()

    def run_array(self,values):
        np.savez_compressed(self.root/'mock.npz',depth_m=values)
        report=Report()
        result=check_captures(report,[copy.deepcopy(self.record)],self.root,[{'native_before_s':0.0}],
            epoch='CPU_ONLY_EPOCH',width=self.w,height=self.h,expected_indices=[0])
        return report,result

    def reject(self,values,code):
        report,result=self.run_array(values)
        self.assertIn(code,[v['code'] for v in report.errors])
        self.assertEqual(result['count'],1)
        self.assertEqual(result['records'][0]['depth']['shape'],list(values.shape))

    def test_exact_channels_last_float32_preserved(self):
        report,result=self.run_array(np.full((self.h,self.w,1),2.0,dtype=np.float32))
        self.assertEqual(report.errors,[])
        self.assertEqual(result['records'][0]['depth']['shape'],[self.h,self.w,1])
        self.assertEqual(result['records'][0]['depth']['dtype'],'float32')

    def test_legacy_2d_is_not_silently_accepted(self):
        self.reject(np.ones((self.h,self.w),dtype=np.float32),'DEPTH_SHAPE_DTYPE')

    def test_multichannel_is_rejected(self):
        self.reject(np.ones((self.h,self.w,3),dtype=np.float32),'DEPTH_SHAPE_DTYPE')

    def test_channel_first_axes_are_rejected(self):
        self.reject(np.ones((1,self.h,self.w),dtype=np.float32),'DEPTH_SHAPE_DTYPE')

    def test_integer_dtype_is_rejected(self):
        self.reject(np.ones((self.h,self.w,1),dtype=np.int32),'DEPTH_SHAPE_DTYPE')

    def test_nan_is_rejected(self):
        values=np.ones((self.h,self.w,1),dtype=np.float32);values[0,0,0]=np.nan
        self.reject(values,'DEPTH_NEGATIVE_OR_NAN')

    def test_negative_finite_and_negative_infinity_are_rejected(self):
        for value,code in [(-1.0,'DEPTH_NEGATIVE_OR_NAN'),(-np.inf,'DEPTH_NEGATIVE_INFINITY')]:
            with self.subTest(value=value):
                values=np.ones((self.h,self.w,1),dtype=np.float32);values[0,0,0]=value
                self.reject(values,code)

    def test_positive_infinity_background_counted_not_zero(self):
        values=np.full((self.h,self.w,1),2.0,dtype=np.float32);values[0,0,0]=np.inf
        report,result=self.run_array(values)
        self.assertEqual(report.errors,[])
        depth=result['records'][0]['depth']
        self.assertEqual(depth['positive_inf_pixels'],1)
        self.assertEqual(depth['finite_pixels'],11)
        self.assertEqual(depth['minimum_finite_m'],2.0)
        self.assertTrue(np.isposinf(values[0,0,0]))


if __name__=='__main__':
    unittest.main()
