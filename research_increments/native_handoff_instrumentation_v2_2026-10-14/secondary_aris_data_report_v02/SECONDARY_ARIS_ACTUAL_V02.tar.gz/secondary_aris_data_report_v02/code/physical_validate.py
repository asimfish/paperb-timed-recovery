"""Pure CPU structural validator. Observability is not a physical-task label."""
import hashlib
import json
import math

SHAPES = {
    "transform_xyz_xyzw": (1, 7),
    "velocity_world_com_linear_angular": (1, 6),
    "acceleration_world_com_linear_angular": (1, 6),
    "mass_kg": (1, 1), "inverse_mass_per_kg": (1, 1),
    "com_local_xyz_xyzw": (1, 7),
    "inertia_com_body_frame_column_major_kg_m2": (1, 9),
    "gravity_disabled_flag": (1, 1), "simulation_disabled_flag": (1, 1),
}


def _plain(value):
    if value is None or type(value) in (str, bool, int):
        return True
    if type(value) is float:
        return math.isfinite(value)
    if type(value) is list:
        return all(_plain(v) for v in value)
    if type(value) is dict:
        return all(type(k) is str and _plain(v) for k, v in value.items())
    return False


def _shape(value, dimensions):
    if not dimensions:
        return type(value) in (float, int) and type(value) is not bool and math.isfinite(value)
    return type(value) is list and len(value) == dimensions[0] and all(
        _shape(v, dimensions[1:]) for v in value)


def validate_snapshot(row):
    errors, unknown = [], []
    if type(row) is not dict or not _plain(row):
        return {"structure_pass": False, "errors": ["NOT_FINITE_PLAIN_JSON"],
                "load_bearing_verdict": "UNKNOWN"}
    from physical_capture import SCHEMA, PHASES, digest
    if row.get("schema") != SCHEMA or row.get("phase") not in PHASES or type(row.get("tick")) is not int:
        errors.append("SCHEMA_PHASE_TICK")
    before, after = row.get("native_clock_before"), row.get("native_clock_after")
    for name, clock in (("before", before), ("after", after)):
        if type(clock) is not dict or set(clock) != {"native_epoch", "time_s", "callback_count"}:
            errors.append("CLOCK_" + name)
        elif type(clock["native_epoch"]) is not str or not clock["native_epoch"] or type(clock["callback_count"]) is not int or clock["callback_count"] < 0 or type(clock["time_s"]) not in (int, float) or type(clock["time_s"]) is bool:
            errors.append("CLOCK_TYPES_" + name)
    if row.get("no_native_step_during_getters") is not (before == after):
        errors.append("CLOCK_CERTIFICATE_MISMATCH")
    if before != after:
        errors.append("GETTER_CLOCK_ADVANCED")
    fields = row.get("rigid_body")
    if type(fields) is not dict or set(fields) != set(SHAPES):
        errors.append("RIGID_FIELD_SET")
    else:
        for name, shape in SHAPES.items():
            record = fields[name]
            if type(record) is not dict or record.get("status") not in ("OBSERVED", "UNKNOWN"):
                errors.append("GETTER_RECORD_" + name)
            elif record["status"] == "UNKNOWN":
                if record.get("value") is not None or not record.get("reason"):
                    errors.append("UNKNOWN_NOT_EXPLAINED_" + name)
                unknown.append(name)
            elif not _shape(record.get("value"), shape):
                errors.append("SHAPE_" + name)
            elif name.endswith("_flag") and record["value"][0][0] not in (0, 1):
                errors.append("FLAG_VALUE_" + name)
        mass = fields["mass_kg"]
        if mass.get("status") == "OBSERVED" and _shape(mass.get("value"), (1, 1)) and mass["value"][0][0] <= 0:
            errors.append("NONPOSITIVE_MASS")
    gravity = row.get("scene_gravity_world_m_s2")
    if type(gravity) is not dict or gravity.get("status") not in ("OBSERVED", "UNKNOWN"):
        errors.append("GRAVITY_RECORD")
    elif gravity["status"] == "OBSERVED" and not _shape(gravity.get("value"), (3,)):
        errors.append("GRAVITY_SHAPE")
    elif gravity["status"] == "UNKNOWN":
        if gravity.get("value") is not None or not gravity.get("reason"):
            errors.append("GRAVITY_UNKNOWN_NOT_EXPLAINED")
        unknown.append("scene_gravity")
    wrenches = row.get("external_wrench_buffers")
    if type(wrenches) is not dict or set(wrenches) != {"instantaneous", "permanent"}:
        errors.append("WRENCH_FIELD_SET")
    else:
        for kind, entry in wrenches.items():
            if type(entry) is not dict or entry.get("status") not in ("OBSERVED", "UNKNOWN"):
                errors.append("WRENCH_RECORD_" + kind)
            elif entry["status"] == "UNKNOWN":
                if entry.get("value") is not None or not entry.get("reason"):
                    errors.append("WRENCH_UNKNOWN_NOT_EXPLAINED_" + kind)
                unknown.append("wrench_" + kind)
            else:
                value = entry.get("value")
                if type(value) is not dict or set(value) != {"active", "force_body_frame_N", "torque_body_frame_N_m"} or type(value.get("active")) is not bool or not _shape(value.get("force_body_frame_N"), (1, 1, 3)) or not _shape(value.get("torque_body_frame_N_m"), (1, 1, 3)):
                    errors.append("WRENCH_VALUE_" + kind)
    if row.get("load_bearing_verdict") != "UNKNOWN_INSTRUMENTATION_ONLY":
        errors.append("FORBIDDEN_LOAD_BEARING_LABEL")
    clean = {k: v for k, v in row.items() if k != "record_sha256"}
    if row.get("record_sha256") != digest(clean):
        errors.append("RECORD_HASH")
    return {"structure_pass": not errors, "errors": errors, "missing_getters": unknown,
            "all_body_getters_observed": not unknown and not errors,
            "load_bearing_verdict": "UNKNOWN", "native_epochs_created": 0}
