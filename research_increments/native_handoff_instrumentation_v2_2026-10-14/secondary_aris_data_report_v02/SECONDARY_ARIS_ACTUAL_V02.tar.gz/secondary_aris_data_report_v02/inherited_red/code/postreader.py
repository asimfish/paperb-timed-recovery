"""Frozen secondary producer-side description; not an independent referee.

Pure offline reading. Never imports Isaac/torch, advances physics, fits a model,
or replaces a missing physical observation with zero. Raw sources are not edited.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import platform

from physical_validate import validate_snapshot

DESIGN_ROOT = Path(__file__).resolve().parents[1]
FIXED_CASE = "dev_seen_handoff_instrumentation_002_aris"
EXECUTION_SHA = "eb807cffef785271e6fc6b7558598c29c6a8c76af46f043ea321a74935fab34c"
PROTOCOL_SHA = "eacc4d996d56514e8db9ea72eb8cce77b45bf43fcaa6cea5afa8b2eeb9c22c6e"
SCHEDULE_SHA = "f440d540d8abd1660b7eb3d2b5647ea2f561c63ec4115509b16e1608e99b4f43"
COMPONENT_SHA = "19a8c09af7909ddd6050509b74c0c1ba9e4ede6f9c47c988f47e8938b54b0e79"
COMMAND_SHA = "03a63a0b77037785741540465ef39d8b0a45e17563f9ec5b9c15133497de410a"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_loads(text):
    def bad(value): raise ValueError("nonfinite JSON token " + value)
    return json.loads(text, parse_constant=bad)


class Report:
    def __init__(self): self.errors, self.artifacts = [], {}
    def error(self, code, **evidence): self.errors.append(dict(code=code, **evidence))
    def check(self, predicate, code, **evidence):
        if not predicate: self.error(code, **evidence)
        return predicate
    def json(self, path, *, missing_error=True):
        path = Path(path)
        if not path.is_file():
            if missing_error: self.error("MISSING_FILE", path=str(path))
            return None
        self.artifacts[str(path)] = sha(path)
        try: return json_loads(path.read_text())
        except Exception as exc:
            self.error("JSON_READ_ERROR", path=str(path), exception_type=type(exc).__name__, reason=str(exc)); return None
    def jsonl(self, path):
        path = Path(path)
        if not path.is_file(): self.error("MISSING_FILE", path=str(path)); return []
        self.artifacts[str(path)] = sha(path)
        rows = []
        with path.open() as f:
            for index, line in enumerate(f, 1):
                try:
                    value = json_loads(line)
                    if type(value) is not dict: raise ValueError("row must be JSON object")
                    rows.append(value)
                except Exception as exc:
                    # Preserve row position. Do not slide all later ticks after a
                    # corrupt line or quietly exclude the failed sample.
                    self.error("JSONL_ROW_ERROR", path=str(path), line=index, reason=str(exc))
                    rows.append({"_reader_invalid_line": index})
        return rows


def target_lists(command_file):
    import numpy as np
    with np.load(command_file, allow_pickle=False) as raw:
        if set(raw.files) != {"q_target", "grip_target", "metadata_json"}:
            raise ValueError("pinned command NPZ schema")
        arm, grip = raw["q_target"], raw["grip_target"]
        if arm.shape[1:] != (7,) or grip.shape[1:] != (2,) or len(arm) != len(grip):
            raise ValueError("command targets shape")
        if not np.isfinite(arm).all() or not np.isfinite(grip).all():
            raise ValueError("nonfinite command target")
        return arm.tolist(), grip.tolist()


def observed_value(row, name):
    body = row.get("rigid_body", {})
    field = body.get(name, {}) if type(body) is dict else {}
    if type(field) is not dict: return None
    return field.get("value") if field.get("status") == "OBSERVED" else None


def check_physical(report, rows, states, *, count, epoch, body_path):
    report.check(len(rows) == 2 * count + 2, "PHYSICAL_ROW_COUNT", observed=len(rows), expected=2*count+2)
    sequence = [(-1, "TASK_BEGIN")]
    sequence.extend((i, phase) for i in range(count) for phase in ("PRE_WRITE", "POST_STEP"))
    sequence.append((count, "TASK_END"))
    phase_counts, unknown, values = Counter(), Counter(), defaultdict(Counter)
    timeline, indexed = [], {}
    for index, row in enumerate(rows):
        phase, tick = row.get("phase"), row.get("tick")
        phase_counts[str(phase)] += 1
        if index < len(sequence): report.check((tick, phase) == sequence[index], "PHYSICAL_PHASE_SEQUENCE", row=index, expected=sequence[index], observed=[tick, phase])
        else: report.error("EXTRA_PHYSICAL_ROW", row=index)
        checked = validate_snapshot(row)
        report.check(checked.get("structure_pass") is True, "PHYSICAL_STRUCTURE", row=index, validation=checked)
        before, after = row.get("native_clock_before", {}), row.get("native_clock_after", {})
        report.check(before.get("native_epoch") == epoch and after.get("native_epoch") == epoch, "PHYSICAL_EPOCH", row=index)
        report.check(row.get("body_path") == body_path, "PHYSICAL_BODY_PATH", row=index)
        if type(tick) is int and type(phase) is str:
            key = (tick, phase)
            if key in indexed: report.error("DUPLICATE_PHYSICAL_KEY", row=index, key=list(key))
            indexed[key] = row
        body_records = row.get("rigid_body", {})
        for name, record in (body_records.items() if type(body_records) is dict else []):
            if type(record) is not dict: continue
            if record.get("status") != "OBSERVED": unknown[name + ":" + str(record.get("reason"))] += 1
            else: values[name][json.dumps(record.get("value"),sort_keys=True)] += 1
        gravity = row.get("scene_gravity_world_m_s2", {})
        if gravity.get("status") != "OBSERVED": unknown["scene_gravity:" + str(gravity.get("reason"))] += 1
        else: values["scene_gravity_world_m_s2"][json.dumps(gravity.get("value"))] += 1
        for kind, record in row.get("external_wrench_buffers", {}).items():
            if type(record) is dict and record.get("status") != "OBSERVED": unknown["wrench_"+kind+":"+str(record.get("reason"))] += 1
        def flatten(name, n):
            v = observed_value(row, name)
            return v[0] if type(v) is list and len(v) == 1 and type(v[0]) is list and len(v[0]) == n else [None] * n
        pose, velocity = flatten("transform_xyz_xyzw",7), flatten("velocity_world_com_linear_angular",6)
        mass, gravflag, simflag = flatten("mass_kg",1), flatten("gravity_disabled_flag",1), flatten("simulation_disabled_flag",1)
        entry = dict(row=index,tick=tick,phase=phase,native_time_s=before.get("time_s"),physics_callbacks=before.get("callback_count"),
                     mass_kg=mass[0],gravity_disabled_flag=gravflag[0],simulation_disabled_flag=simflag[0])
        entry.update(dict(zip(("x_m","y_m","z_m","qx","qy","qz","qw"),pose)))
        entry.update(dict(zip(("vx_m_s","vy_m_s","vz_m_s","wx_rad_s","wy_rad_s","wz_rad_s"),velocity)))
        for kind in ("instantaneous", "permanent"):
            wr = row.get("external_wrench_buffers", {}).get(kind, {}).get("value") or {}
            entry[kind+"_active"] = wr.get("active")
            force = wr.get("force_body_frame_N")
            entry[kind+"_force_body_N"] = json.dumps(force) if force is not None else None
        timeline.append(entry)
    for i, state in enumerate(states):
        pre, post = indexed.get((i,"PRE_WRITE")), indexed.get((i,"POST_STEP"))
        if pre is None or post is None: report.error("MISSING_PRE_POST_PAIR", tick=i); continue
        pc, qc = pre.get("native_clock_before",{}), post.get("native_clock_before",{})
        report.check(pc.get("time_s") == state.get("native_before_s") and qc.get("time_s") == state.get("native_after_s"), "PRE_POST_STATE_CLOCK", tick=i)
        report.check(type(pc.get("callback_count")) is int and type(qc.get("callback_count")) is int and qc["callback_count"] == pc["callback_count"]+1, "PRE_POST_CALLBACK_INCREMENT", tick=i)
        report.check(qc.get("callback_count")==state.get("semantic_tick"),"POST_CALLBACK_STATE_SEMANTIC_TICK",tick=i)
        if i:
            prior = indexed.get((i-1,"POST_STEP"),{}).get("native_clock_before",{})
            report.check(prior == pc, "ADJACENT_PHYSICS_CLOCK", tick=i)
        pose = observed_value(post,"transform_xyz_xyzw")
        if type(pose) is list and len(pose)==1 and type(pose[0]) is list and len(pose[0])==7:
            xyz, qx, qy, qz, qw = pose[0][:3], *pose[0][3:]
            report.check(xyz+[qw,qx,qy,qz] == state.get("object_pose"), "POST_TRANSFORM_STATE_POSE_EXACT", tick=i)
        else: report.error("POST_TRANSFORM_NOT_OBSERVED", tick=i)
    begin, end = indexed.get((-1,"TASK_BEGIN")), indexed.get((count,"TASK_END"))
    if begin and states and indexed.get((0,"PRE_WRITE")):
        report.check(begin.get("native_clock_before") == indexed[(0,"PRE_WRITE")].get("native_clock_before"), "TASK_BEGIN_CLOCK")
    if end and states and indexed.get((count-1,"POST_STEP")):
        report.check(end.get("native_clock_before") == indexed[(count-1,"POST_STEP")].get("native_clock_before"), "TASK_END_CLOCK")
    return dict(phase_counts=dict(phase_counts),unknown_getter_counts=dict(unknown),
                unique_value_counts={name:[dict(value=json.loads(v),rows=n) for v,n in counts.items()] for name,counts in values.items()
                                     if name in {"mass_kg","inverse_mass_per_kg","gravity_disabled_flag","simulation_disabled_flag","scene_gravity_world_m_s2"}},
                timeline=timeline,load_bearing_verdict="UNKNOWN_INSTRUMENTATION_ONLY")


def check_fifo(report, states, dispatch, events, schedule, arm, grip, *, delay, epoch, dt):
    source = schedule["source_indices"]; count = len(source)+delay
    report.check(len(states)==count,"STATE_ROW_COUNT",observed=len(states),expected=count)
    report.check(len(dispatch)==count,"DISPATCH_ROW_COUNT",observed=len(dispatch),expected=count)
    expected_events, pending, applied_source, applied_id = [], [], -1, -1
    target_arm,target_grip=arm[0],grip[0]
    origin=states[0].get("native_before_s") if states else None
    for i in range(min(len(states),len(dispatch))):
        state, row=states[i],dispatch[i]
        report.check(state.get("command_index")==i and row.get("tick")==i,"FIFO_TICK",tick=i)
        report.check(state.get("native_epoch")==epoch and row.get("native_epoch")==epoch,"FIFO_EPOCH",tick=i)
        before=state.get("native_before_s")
        report.check(row.get("native_before_s")==before,"DISPATCH_STATE_CLOCK",tick=i)
        if i: report.check(states[i-1].get("native_after_s")==before,"STATE_ADJACENT_CLOCK",tick=i)
        if type(before) in (int,float) and type(state.get("native_after_s")) in (int,float):
            report.check(abs(state["native_after_s"]-before-dt)<=1e-7,"STATE_DT",tick=i)
        submit=None
        if i<len(source):
            src=source[i]
            submit=dict(command_id=i,source_index=src,enqueue_tick=i,ready_tick=i+delay,sampled_delay_ticks=delay,native_epoch=epoch,
                        enqueue_time_s=before,ready_time_nominal_prediction_s=origin+(i+delay)*dt,
                        arm_target=arm[src],grip_target=grip[src])
            pending.append(submit)
        apply=None
        if pending and pending[0]["ready_tick"]<=i:
            apply=dict(pending.pop(0),apply_tick=i,apply_time_s=before,ready_observed_time_s=before)
            applied_id,applied_source=apply["command_id"],apply["source_index"]
            target_arm,target_grip=apply["arm_target"],apply["grip_target"]
        report.check(row.get("submitted")==submit,"FIFO_SUBMITTED_EXACT",tick=i)
        report.check(row.get("applied")==apply,"FIFO_APPLIED_EXACT",tick=i)
        ids=[p["command_id"] for p in pending]
        report.check(row.get("pending_command_ids")==ids and state.get("pending_command_ids")==ids,"FIFO_PENDING_EXACT",tick=i)
        report.check(row.get("held_previous_target") is (apply is None),"FIFO_HOLD",tick=i)
        report.check(state.get("submitted_source_command_index")== (source[i] if i<len(source) else None),"STATE_SUBMISSION_INDEX",tick=i)
        report.check(state.get("applied_source_command_index")==applied_source and state.get("source_command_index")==applied_source and state.get("applied_command_id")==applied_id,"STATE_APPLIED_INDEX",tick=i)
        report.check(row.get("applied_source_command_index")==applied_source and row.get("applied_command_id")==applied_id,"DISPATCH_APPLIED_INDEX",tick=i)
        report.check(state.get("arm_target")==target_arm and state.get("grip_target")==target_grip,"ACTUAL_TARGET_MATCHES_APPLIED",tick=i)
        if submit is not None: expected_events.append(dict(event="SUBMITTED",**submit))
        if apply is not None: expected_events.append(dict(event="APPLIED",**apply))
    report.check(events==expected_events,"COMMAND_EVENT_STREAM_EXACT",observed=len(events),expected=len(expected_events))
    submitted=sum(e.get("event")=="SUBMITTED" for e in events); applied=sum(e.get("event")=="APPLIED" for e in events)
    report.check(submitted==len(source) and applied==len(source),"COMMAND_EVENT_DENOMINATOR",submitted=submitted,applied=applied,expected=len(source))
    report.check(not pending,"FIFO_TAIL_PENDING",pending=len(pending))
    return dict(source_command_submissions=len(source),expected_task_steps=count,observed_state_rows=len(states),observed_dispatch_rows=len(dispatch),
                observed_submitted=submitted,observed_applied=applied,tail_ticks=delay,observed_terminal_pending=len(pending))


def confined_file(root, relative):
    if type(relative) is not str or Path(relative).is_absolute() or ".." in Path(relative).parts:
        raise ValueError("nonlocal capture path")
    p=(root/relative).resolve()
    if not p.is_relative_to(root.resolve()): raise ValueError("capture path escape")
    return p


def check_captures(report, records, task, states, *, epoch, width, height, expected_indices=None, initial_proprio=None):
    # Decoder imports only at offline read time. No physics SDK or torch.
    import numpy as np
    from PIL import Image
    results=[]; seen=[]
    for n,record in enumerate(records):
        try:
            tick=record["command_index"];seen.append(tick)
            report.check(type(tick) is int and 0<=tick<=len(states),"CAPTURE_TICK",row=n)
            expected_time=states[0]["native_before_s"] if tick==0 and states else states[tick-1]["native_after_s"] if type(tick) is int and 0<tick<=len(states) else None
            report.check(record.get("native_epoch")==epoch,"CAPTURE_EPOCH",row=n)
            report.check(record.get("native_time_s")==expected_time and record.get("rendered_state_native_time_s")==expected_time,"CAPTURE_NATIVE_CLOCK",row=n)
            report.check(record.get("observation_mode")=="OFFLINE_CAPTURE" and record.get("policy_delivery_time_s") is None,"CAPTURE_MODE",row=n)
            report.check(record.get("physics_callbacks_during_render")==0 and record.get("physical_state_changed") is False,"CAPTURE_NO_PHYSICS_CHANGE",row=n)
            jpeg=confined_file(task,record["image"]);depth=confined_file(task,record["depth"])
            jsha=sha(jpeg);dsha=sha(depth);report.artifacts[str(jpeg)]=jsha;report.artifacts[str(depth)]=dsha
            report.check(jsha==record.get("image_sha256"),"JPEG_BYTE_SHA",row=n)
            with Image.open(jpeg) as image:
                image.load();report.check(image.format=="JPEG" and image.size==(width,height) and image.mode=="RGB","JPEG_DECODE",row=n)
            with np.load(depth,allow_pickle=False) as raw:
                report.check(set(raw.files)=={"depth_m"},"DEPTH_NPZ_KEYS",row=n)
                d=raw["depth_m"]
                report.check(d.shape==(height,width) and d.dtype.kind=="f","DEPTH_SHAPE_DTYPE",row=n,shape=list(d.shape),dtype=str(d.dtype))
                finite=np.isfinite(d);neg=int(np.count_nonzero(finite & (d<0)))
                report.check(neg==0 and int(np.count_nonzero(np.isnan(d)))==0,"DEPTH_NEGATIVE_OR_NAN",row=n)
                depth_summary=dict(shape=list(d.shape),dtype=str(d.dtype),finite_pixels=int(finite.sum()),positive_inf_pixels=int(np.isposinf(d).sum()),negative_inf_pixels=int(np.isneginf(d).sum()),negative_finite_pixels=neg,
                                   minimum_finite_m=float(d[finite].min()) if finite.any() else None,maximum_finite_m=float(d[finite].max()) if finite.any() else None)
                report.check(depth_summary["negative_inf_pixels"]==0,"DEPTH_NEGATIVE_INFINITY",row=n)
            proprio=record.get("student_proprioception",{})
            if tick>0 and tick<=len(states):
                state=states[tick-1];report.check(proprio.get("joint_positions")==state.get("q_all") and proprio.get("joint_velocities")==state.get("qd_all"),"CAPTURE_PROPRIO_STATE_EXACT",row=n)
            else:
                for name in ("joint_positions","joint_velocities"):
                    report.check(type(proprio.get(name)) is list and len(proprio[name])==9 and all(type(v) in (int,float) and math.isfinite(v) for v in proprio[name]),"INITIAL_CAPTURE_PROPRIO_SHAPE",row=n,name=name)
                if initial_proprio is not None:
                    report.check(proprio==initial_proprio,"INITIAL_CAPTURE_AFTER_INSTALLATION_PROPRIO_EXACT",row=n)
            results.append(dict(command_index=tick,jpeg_byte_sha256=jsha,depth_byte_sha256=dsha,depth=depth_summary,
                                native_rgb_sha256_recorded=record.get("native_rgb_sha256"),native_rgb_sha256_recomputation="NOT_RECOMPUTABLE_FROM_SAVED_LOSSY_JPEG",
                                capture_mode="OFFLINE_CAPTURE",policy_delivery=None))
        except Exception as exc:
            report.error("CAPTURE_EXCEPTION_RETAINED",row=n,exception_type=type(exc).__name__,reason=str(exc))
            results.append(dict(row=n,status="UNKNOWN_EXCEPTION_RETAINED"))
    report.check(len(seen)==len(set(seen)),"CAPTURE_DUPLICATE_INDEX")
    if expected_indices is not None: report.check(seen==expected_indices,"CAPTURE_FIXED_INDEX_LIST",observed=seen,expected=expected_indices)
    return dict(count=len(records),decoder_numpy=np.__version__,decoder_pillow=Image.__version__,records=results,
                depth_sha_scope="NEW_OFFLINE_BYTE_HASH;PRODUCER_DID_NOT_LOG_DEPTH_BYTE_SHA",native_raw_rgb_hash_not_recomputed=True)


def write_json(path,value):
    with Path(path).open("x") as f: json.dump(value,f,sort_keys=True,indent=2,allow_nan=False)


def run(runtime, output):
    runtime,output=Path(runtime).resolve(),Path(output).resolve()
    output.mkdir(parents=True,exist_ok=False)
    report=Report();case=runtime/"cases"/FIXED_CASE;task=case/"task"
    protocol=json_loads((DESIGN_ROOT/"inputs/protocol.json").read_text())
    schedule=json_loads((DESIGN_ROOT/"inputs/FROZEN_DEVELOPMENT_SCHEDULE.json").read_text())
    source=schedule["source_indices"];delay=12;count=len(source)+delay
    epoch="paperb_handoff_instrumentation_v1:"+FIXED_CASE+":"+PROTOCOL_SHA
    release=report.json(runtime/"EXECUTION_RELEASE.json")
    report.check(release is not None and sha(runtime/"EXECUTION_RELEASE.json")==EXECUTION_SHA,"EXECUTION_RELEASE_PIN")
    if type(release) is dict:
        for relative,expected in release.get("files",{}).items():
            try:report.check(sha(confined_file(runtime,relative))==expected,"EXECUTION_FILE_PIN",path=relative)
            except Exception as exc:report.error("SOURCE_PIN_EXCEPTION",path=relative,reason=str(exc))
    for name,expected in (("protocol.json",PROTOCOL_SHA),("FROZEN_DEVELOPMENT_SCHEDULE.json",SCHEDULE_SHA),("PHYSICAL_COMPONENT_RELEASE.json",COMPONENT_SHA),("inputs/commands.npz",COMMAND_SHA)):
        try:report.check(sha(runtime/name)==expected,"FIXED_INPUT_PIN",path=name)
        except Exception as exc:report.error("FIXED_INPUT_MISSING",path=name,reason=str(exc))
    worker=report.json(runtime/"logs"/(FIXED_CASE+".json"))
    result=report.json(case/"RESULT.json")
    failure_snapshot=report.json(task/"FAILED_PHYSICAL_SNAPSHOT.json",missing_error=False)
    if failure_snapshot is not None:report.error("FAILED_PHYSICAL_SNAPSHOT_RETAINED",snapshot=failure_snapshot)
    report.check(type(worker) is dict and worker.get("status")=="COMPLETE" and worker.get("exit_code")==0,"WORKER_NOT_COMPLETE",observed=worker)
    report.check(type(result) is dict and result.get("status")=="BASELINE_COMMANDS_COMPLETED" and result.get("commands")==count and result.get("native_epoch")==epoch,"PRODUCER_NOT_COMPLETE_OR_WRONG_EPOCH")
    case_record=report.json(case/"case.json")
    if type(case_record) is dict:
        report.check(case_record.get("protocol_sha256")==PROTOCOL_SHA and case_record.get("execution_release_sha256")==EXECUTION_SHA,"CASE_SOURCE_BINDING")
        report.check(case_record.get("case",{}).get("id")==FIXED_CASE,"CASE_ID")
    physical=report.jsonl(task/"physical_snapshots.jsonl");states=report.jsonl(task/"states.jsonl")
    dispatch=report.jsonl(task/"dispatch.jsonl");events=report.jsonl(task/"command_events.jsonl")
    physical_result=check_physical(report,physical,states,count=count,epoch=epoch,body_path=protocol["object_prim"])
    arm,grip=target_lists(DESIGN_ROOT/"inputs/commands.npz")
    fifo_result=check_fifo(report,states,dispatch,events,schedule,arm,grip,delay=delay,epoch=epoch,dt=protocol["dt_s"])
    captures=report.json(task/"capture_index.json")
    if captures is None:
        captures=report.jsonl(task/"captures.jsonl")
        report.error("PARTIAL_CAPTURE_INDEX_NO_INITIAL_CAPTURE_IMPUTATION")
    origin=states[0].get("native_before_s") if states else None
    expected=[0]
    if len(states)==count and origin is not None:
        ends={p["end_tick"] for p in schedule["stage_plan"]}
        expected += [i+1 for i,state in enumerate(states) if i+1 in ends or ((i+1)%40==0 and 9<=state.get("native_after_s",float("-inf"))-origin<37)]
    else: expected=None
    initial=report.json(case/"CONTROLLER_AFTER.json")
    initial_proprio=None
    if type(initial) is dict:
        try:
            arm_record=initial['cached_scene_state_preimage']['arms']['fr3_A']
            initial_proprio=dict(joint_positions=arm_record['q'][0],joint_velocities=arm_record['qd'][0])
            report.check(initial.get("native_epoch")==epoch,"INSTALLATION_EPOCH")
            report.check(initial.get("native_time_s")==origin,"INSTALLATION_TO_TASK_TIME")
        except Exception as exc:report.error("INITIAL_PROPRIO_PREIMAGE_MISSING",reason=str(exc))
    capture_result=check_captures(report,captures if type(captures) is list else [],task,states,epoch=epoch,width=640,height=400,expected_indices=expected,initial_proprio=initial_proprio)
    captures_partial=report.jsonl(task/"captures.jsonl")
    if type(captures) is list:report.check(captures_partial==captures[1:],"CAPTURE_APPEND_STREAM_EXACT")
    receipt=report.json(task/"physical_capture_receipt.json")
    if type(receipt) is dict:
        report.check(receipt.get("rows")==len(physical) and receipt.get("expected_task_ticks")==count and receipt.get("expected_rows")==2*count+2,"PHYSICAL_RECEIPT_ROWS")
        report.check(receipt.get("component_release_sha256")==COMPONENT_SHA and receipt.get("source_sha256")=="d10610f5d508a37b65f2978fadbae304b0001606d51faf0511c8805ce4ae0d5f" and receipt.get("validator_sha256")=="d6c1d09324a0b054a5058c76ac4af9ba493e25c267c3099366a3274ed564bea0","PHYSICAL_RECEIPT_SOURCE_PIN")
        report.check(receipt.get("load_bearing_verdict")=="UNKNOWN_INSTRUMENTATION_ONLY","PHYSICAL_RECEIPT_NO_NEW_LABEL")
    queue=report.json(task/"queue_completion.json")
    if type(queue) is dict:
        report.check(queue.get("submitted")==len(source) and queue.get("applied")==len(source) and queue.get("tail_flush_ticks")==delay and queue.get("pending_command_ids")==[] and queue.get("queue_complete") is True,"QUEUE_TERMINAL")
    for path,before_hash in list(report.artifacts.items()):
        try:report.check(sha(path)==before_hash,"RAW_CHANGED_DURING_READ",path=path)
        except Exception as exc:report.error("RAW_DISAPPEARED_DURING_READ",path=path,reason=str(exc))
    with (output/"physical_timeline.csv").open("x",newline="") as f:
        rows=physical_result.pop("timeline")
        if rows:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    summary=dict(schema="paperb-secondary-native-instrumentation-data-report-v1",
                 status="PASS_SECONDARY_COMPLETE_DATA_READBACK" if not report.errors else "PARTIAL_OR_INVALID_RETAINED",
                 authority="SECONDARY_PRODUCER_DESCRIPTIVE_PROCESSOR_NOT_THIRD_INDEPENDENT_REFEREE",
                 source_release_sha256=EXECUTION_SHA,postreader_protocol_sha256=sha(DESIGN_ROOT/"POSTREADER_PROTOCOL.json"),
                 postreader_source_release_sha256=sha(DESIGN_ROOT/"SOURCE_RELEASE.json") if (DESIGN_ROOT/"SOURCE_RELEASE.json").is_file() else None,
                 fixed_case_id=FIXED_CASE,expected_native_epoch=epoch,shared_denominator=1,
                 expected_physical_rows=2*count+2,observed_physical_rows=len(physical),physical=physical_result,fifo=fifo_result,captures=capture_result,
                 findings_count=len(report.errors),raw_artifact_sha256=report.artifacts,
                 worker_terminal=worker,producer_result_present=result is not None,failed_physical_snapshot_present=failure_snapshot is not None,
                 getter_unknown_rows_preserved=True,missing_or_failed_cases_excluded=0,native_restarts=0,new_controlled_native_epochs=0,
                 load_bearing_verdict="UNKNOWN_INSTRUMENTATION_ONLY",training_admitted=0,new_weights=0,
                 actual_numpy_version=capture_result["decoder_numpy"],python_version=platform.python_version())
    write_json(output/"FINDINGS.json",report.errors);write_json(output/"SUMMARY.json",summary)
    write_json(output/"REPORT_OUTPUT_VALIDATION.json",dict(status="WRITTEN_EXCLUSIVE_NO_RAW_MUTATION",files={p.name:sha(p) for p in output.iterdir() if p.is_file()},shared_denominator=1))
    return summary


def main():
    parser=argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--runtime-root",required=True);parser.add_argument("--output",required=True)
    args=parser.parse_args()
    source=json_loads((DESIGN_ROOT/"SOURCE_RELEASE.json").read_text())
    for relative,expected in source["files"].items():
        if sha(confined_file(DESIGN_ROOT,relative))!=expected:raise ValueError("postreader frozen source changed: "+relative)
    summary=run(args.runtime_root,args.output)
    print(json.dumps({k:summary[k] for k in ("status","shared_denominator","observed_physical_rows","findings_count","load_bearing_verdict")}))


if __name__=="__main__": main()
