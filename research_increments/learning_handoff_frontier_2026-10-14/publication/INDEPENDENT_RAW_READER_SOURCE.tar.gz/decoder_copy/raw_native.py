"""Raw observation primitives for the independent expanded-scene auditor."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np

from independent_protocol import supported_event


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def read_jsonl(path):
    with Path(path).open() as f:
        return [json.loads(line) for line in f if line.strip()]


def under(path, prefix):
    return path == prefix or path.startswith(prefix + '/')


def contact_signals(row, object_prim, robot_prim, support_prefixes):
    """Bilateral/any-finger/support values from paired raw contact points."""
    if row.get('errors'):
        return None, None, None
    if type(row.get('callbacks')) is not int or row['callbacks'] <= 0:
        return None, None, None
    sides, support = set(), False
    for point in row['contacts']:
        names = [point[k] for k in ('actor0', 'actor1', 'collider0', 'collider1')]
        impulse = point['impulse']
        if any(type(x) not in (int, float) or not math.isfinite(x) for x in impulse):
            return None, None, None
        if not any(under(p, object_prim) for p in names) or sum(x*x for x in impulse) <= 1e-16:
            continue
        for side in ('left', 'right'):
            if any(under(p, robot_prim) and side in p and ('finger' in p or 'fingertip' in p) for p in names):
                sides.add(side)
        if any(under(p, prefix) for p in names for prefix in support_prefixes):
            support = True
    return sides == {'left', 'right'}, bool(sides), support


def observations_to_arrays(obs):
    return dict(t=np.array([o['native_after_s'] - obs[0]['native_before_s'] for o in obs]),
                q=np.array([o['q_all'][:7] for o in obs]), qd=np.array([o['qd_all'][:7] for o in obs]),
                q_all=np.array([o['q_all'] for o in obs]), qd_all=np.array([o['qd_all'] for o in obs]),
                tcp=np.array([o['tcp'] for o in obs]), jaw_width_m=np.array([o['jaw_width_m'] for o in obs]),
                obj_precursor_1=np.array([o['object_pose'] for o in obs]))


def validate_raw(obs, contacts, epoch, dt_s):
    if not obs or len(obs) != len(contacts):
        raise ValueError('nonempty aligned raw state and contact rows required')
    for tick, (o, c) in enumerate(zip(obs, contacts)):
        if o['command_index'] != tick or c['tick'] != tick or o['native_epoch'] != epoch:
            raise ValueError('tick identity or epoch mismatch')
        if abs(o['native_after_s'] - o['native_before_s'] - dt_s) >= 1e-7:
            raise ValueError('native step differs from pinned dt')
        if tick and abs(obs[tick-1]['native_after_s'] - o['native_before_s']) >= 1e-9:
            raise ValueError('native clock discontinuity')
        if c.get('errors'):
            raise ValueError('raw contact parse errors')
        if type(c.get('callbacks')) is not int or c['callbacks'] <= 0:
            raise ValueError('raw contact callback coverage missing')
        if not all(math.isfinite(x) for k in ('q_all', 'qd_all', 'tcp', 'object_pose', 'arm_target', 'grip_target') for x in o[k]):
            raise ValueError('nonfinite native measurement or target')
    return {'samples': len(obs), 'epoch': epoch, 'dt_s': dt_s,
            'native_span_s': obs[-1]['native_after_s'] - obs[0]['native_before_s']}


def tilt_radians(poses):
    q = np.asarray(poses, dtype=float)[:, 3:]
    q = q / np.linalg.norm(q, axis=1, keepdims=True)
    return np.arccos(np.clip(1 - 2*(q[:, 1]**2 + q[:, 2]**2), -1, 1))


def derive_events(obs, contacts, contract, release_config):
    epoch = obs[0]['native_epoch']
    obj = contract['object_prims']['precursor_1']
    robot = contract['robot_prim']
    signals = [contact_signals(row, obj, robot, release_config['support_prim_prefixes']) for row in contacts]
    bilateral, any_finger, support = ([r[i] for r in signals] for i in range(3))
    times = [row['native_after_s'] for row in obs]
    contact = supported_event(bilateral, times, epoch, 3)
    empty = {'status': 'UNAVAILABLE', 'event': None, 'reason': 'contact not confirmed'}
    if contact['event'] is None:
        return {'bilateral_contact': contact, 'verified_stable_release': empty}, bilateral
    first_confirmed = contact['confirmation_sample_index']
    poses = np.asarray([row['object_pose'] for row in obs])
    tilt = tilt_radians(poses)
    release_mask = []
    for tick, row in enumerate(obs):
        # Actor phase labels/command indices cannot determine physical events.
        # The only ordering prerequisite is a previously confirmed raw grasp.
        eligible = tick > first_confirmed
        if any_finger[tick] is None or support[tick] is None:
            release_mask.append(None)
        else:
            release_mask.append(bool(eligible and not any_finger[tick] and support[tick] and
                                     row['jaw_width_m'] >= release_config['jaw_width_min_m'] and
                                     tilt[tick] <= release_config['tilt_max_rad']))
    count = release_config['confirmation_samples']
    release = {'status': 'NOT_DETECTED', 'event': None}
    if None in release_mask:
        release = {'status': 'UNAVAILABLE', 'event': None, 'reason': 'missing raw release predicate'}
    else:
        for start in range(max(1, first_confirmed + 1), len(obs) - count + 1):
            if not all(release_mask[start:start+count]):
                continue
            displacement = np.linalg.norm(poses[start:start+count, :3] - poses[start, :3], axis=1)
            if displacement.max() > release_config['max_displacement_m']:
                continue
            release = {'status': 'DETECTED', 'event': {'clock_id': epoch,
                       'bounds_s': [obs[start]['native_before_s'], obs[start]['native_after_s']]},
                       'onset_sample_index': start, 'confirmation_sample_index': start+count-1,
                       'confirmation_time_s': obs[start+count-1]['native_after_s'],
                       'confirmation_count': count, 'max_window_displacement_m': float(displacement.max()),
                       'semantics': 'EARLIEST_VERIFIED_STABLE_RELEASE_WINDOW_ONSET',
                       'physical_first_unload_time_established': False,
                       'physical_continuity_between_ticks_established': False}
            break
    return {'bilateral_contact': contact, 'verified_stable_release': release}, bilateral
