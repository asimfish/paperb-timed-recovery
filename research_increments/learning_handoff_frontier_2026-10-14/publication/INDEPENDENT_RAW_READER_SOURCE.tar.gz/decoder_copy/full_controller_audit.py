"""Complete independent exported-controller and state-preimage audit.

Imports no native installation/helper/scheduler code. Parameters are compared
from RAW snapshots, and hashes are rebuilt from complete exported preimages.
"""
import hashlib
import json
import math
import numpy as np


def require(ok, message):
    if not ok:
        raise ValueError(message)


def canonical_sha(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, allow_nan=False).encode()).hexdigest()


def numeric(value, shape, allow_infinity=False):
    def convert(x):
        if isinstance(x, list):
            return [convert(y) for y in x]
        if x == 'POSITIVE_INFINITY' and allow_infinity:
            return float('inf')
        require(isinstance(x, (float, int)) and not isinstance(x, bool), 'non-numeric RAW tensor value')
        require(math.isfinite(x), 'non-finite numeric tensor entry')
        return x
    a = np.asarray(convert(value), dtype=np.float64)
    require(a.shape == shape, 'RAW tensor shape mismatch')
    return a


def preimage_checks(snapshot, registry):
    require(snapshot['hash_serialization'] == 'json.dumps(preimage,sort_keys=True,allow_nan=False).encode()', 'state hash encoding differs')
    cached = snapshot['cached_scene_state_preimage']
    fresh = snapshot['fresh_physics_view_state_preimage']
    for kind, value in (('cached_scene_state', cached), ('fresh_physics_view_state', fresh)):
        require(set(value) == {'bodies', 'arms'}, 'state preimage schema mismatch')
        require(set(value['bodies']) == set(registry['rigid_objects']) and set(value['arms']) == set(registry['articulations']), 'state preimage omits scene registry')
        require(canonical_sha(value) == snapshot[kind + '_sha256'], 'state preimage does not reproduce SHA: ' + kind)
    for body in cached['bodies'].values():
        require(set(body) == {'pos', 'quat', 'lin_vel', 'ang_vel'}, 'cached body field missing')
        for key, shape in (('pos', (1, 3)), ('quat', (1, 4)), ('lin_vel', (1, 3)), ('ang_vel', (1, 3))):
            numeric(body[key], shape)
    for arm in cached['arms'].values():
        require(set(arm) == {'q', 'qd', 'pos', 'quat'}, 'cached articulation field missing')
        q = np.asarray(arm['q'])
        require(q.ndim == 2 and q.shape[0] == 1 and q.shape[1] > 0, 'cached articulation joint layout invalid')
        for key, shape in (('q', q.shape), ('qd', q.shape), ('pos', (1, 3)), ('quat', (1, 4))):
            numeric(arm[key], shape)
    for body in fresh['bodies'].values():
        require(set(body) == {'transforms', 'velocities'}, 'fresh body fields missing')
        numeric(body['transforms'], (1, 7))
        numeric(body['velocities'], (1, 6))
    for name, arm in fresh['arms'].items():
        require(set(arm) == {'root_transforms', 'root_velocities', 'dof_positions', 'dof_velocities'}, 'fresh articulation fields missing')
        shape = np.asarray(cached['arms'][name]['q']).shape
        for key, sh in (('root_transforms', (1, 7)), ('root_velocities', (1, 6)), ('dof_positions', shape), ('dof_velocities', shape)):
            numeric(arm[key], sh)
    return dict(cached_sha256_recomputed=snapshot['cached_scene_state_sha256'], fresh_sha256_recomputed=snapshot['fresh_physics_view_state_sha256'],
                registered_bodies_included=len(cached['bodies']), registered_articulations_included=len(cached['arms']))


def parameter_checks(snapshot, key):
    value = snapshot[key]
    meta = snapshot['active_tensor_metadata']
    require(set(value) == set(meta) == {'stiffness', 'damping', 'effort_limits'}, 'active tensor schema mismatch')
    arrays = {}
    for name in ('stiffness', 'damping', 'effort_limits'):
        require(meta[name] == {'shape': [1, 9], 'dtype': 'torch.float32'}, 'active tensor metadata mismatch')
        arrays[name] = numeric(value[name], (1, 9), name == 'effort_limits')
    return arrays


def audit_full_controller(before, after, installation, end, transient, protocol, registry, epoch, t0, tN, n_samples, end_state=None):
    names = protocol['joint_names']
    require(len(names) == 9 and len(set(names)) == 9, 'joint declaration invalid')
    ids = [names.index(name) for name in ('fr3_finger_joint1', 'fr3_finger_joint2')]
    others = [i for i in range(len(names)) if i not in ids]
    actor = protocol['common_actor_installation']
    require(actor['baseline'] == 800. and actor['candidate'] == 1600. and actor['damping_unchanged'] == 40. and actor['unconditional_for_all_20_episodes'] is True, 'common gain rule changed')
    require(installation['before'] == before and installation['after'] == after, 'embedded installation snapshots differ from separate RAW')
    require(installation['finger_joint_indices'] == ids and installation['finger_joint_names'] == ['fr3_finger_joint1', 'fr3_finger_joint2'], 'installation joint identity differs')
    require(installation['original_baseline_transient_verdict'] == transient and transient['status'] == 'PASS', 'gain installed before original matched baseline PASS')
    require(installation['same_unconditional_gain_for_all_methods'] is True and installation['baseline_stiffness_N_per_m'] == 800. and installation['candidate_stiffness_N_per_m'] == 1600., 'conditional gain rule altered')
    require(installation['parameter_installation_location'] == 'AFTER_ORIGINAL_BASELINE_ACCEPTANCE_BEFORE_TASK', 'installation location altered')
    preimages = []
    for snapshot, phase in ((before, 'BEFORE_INSTALLATION'), (after, 'AFTER_INSTALLATION')):
        require(snapshot['phase'] == phase and snapshot['native_epoch'] == epoch, 'controller observation epoch/phase mismatch')
        require(snapshot['native_time_s'] == t0 and snapshot['physics_callbacks'] == protocol['warmup_ticks'] + protocol['restore_ticks'], 'installation advanced native time/callback')
        require(snapshot['parameters_authoritative_from'] == 'ACTIVE_PHYSX_VIEWS', 'USD/cache substituted for actual installed values')
        require(snapshot['cached_state_scope'] == 'ISAACLAB_SCENE_DATA_CACHED_TENSORS' and snapshot['fresh_state_scope'] == 'FRESH_RIGID_AND_ARTICULATION_PHYSX_VIEW_GETTERS', 'state preimage scope changed')
        require(snapshot['object_state_writes'] == snapshot['robot_state_writes'] == 0, 'installation state rewrite')
        preimages.append(preimage_checks(snapshot, registry))
    for key in ('cached_scene_state_preimage', 'fresh_physics_view_state_preimage', 'cached_scene_state_sha256', 'fresh_physics_view_state_sha256'):
        require(before[key] == after[key], 'gain installation changed state: ' + key)
    v0 = parameter_checks(before, 'active')
    v1 = parameter_checks(after, 'active')
    vN = parameter_checks(end, 'actual')
    require(np.array_equal(v0['stiffness'][:, ids], [[800., 800.]]) and np.array_equal(v1['stiffness'][:, ids], [[1600., 1600.]]), 'actual hand gain differs from declared 800→1600')
    require(np.array_equal(v0['stiffness'][:, others], v1['stiffness'][:, others]), 'other-joint stiffness changed')
    require(np.array_equal(v0['damping'][:, ids], [[40., 40.]]), 'actual initial hand damping not40')
    for key in ('damping', 'effort_limits'):
        require(np.array_equal(v0[key], v1[key]), 'before-after ' + key + ' changed')
    for key in v1:
        require(np.array_equal(v1[key], vN[key]), 'after-end ' + key + ' changed')
    require(np.array_equal(numeric(before['hand_actuator_cache_stiffness'], (1, 2)), [[800., 800.]]) and np.array_equal(numeric(after['hand_actuator_cache_stiffness'], (1, 2)), [[1600., 1600.]]), 'hand model cache differs from actual gain')
    require(end['native_epoch'] == epoch and end['native_time_s'] == tN and end['physics_callbacks'] == protocol['warmup_ticks'] + protocol['restore_ticks'] + n_samples, 'end observation time/epoch/callback differs from actual native endpoint')
    require(end['phase'] == 'END_TASK' and end['endpoint_drives_equal'] is True, 'end readback phase/immutability mismatch')
    require(end['active'] == end['actual'], 'end active/actual aliases differ')
    require(np.array_equal(numeric(end['hand_actuator_cache_stiffness'], (1, 2)), [[1600., 1600.]]), 'end hand actuator cache differs from actual gain')
    require(installation['object_state_writes'] == installation['robot_state_writes'] == 0, 'installation receipt state write')
    end_verified = False
    if protocol['active_readback_protocol'].get('end_fresh_and_cached_preimages', False):
        preimages.append(preimage_checks(end, registry))
        require(end_state is not None, 'last raw state missing for end preimage audit')
        cached = end['cached_scene_state_preimage']
        fresh = end['fresh_physics_view_state_preimage']
        require(cached['arms']['fr3_A']['q'][0] == end_state['q_all'] and cached['arms']['fr3_A']['qd'][0] == end_state['qd_all'], 'cached end robot differs from final raw trajectory')
        require(fresh['arms']['fr3_A']['dof_positions'][0] == end_state['q_all'] and fresh['arms']['fr3_A']['dof_velocities'][0] == end_state['qd_all'], 'fresh end robot differs from final raw trajectory')
        pose = cached['bodies'][protocol['object']]['pos'][0] + cached['bodies'][protocol['object']]['quat'][0]
        require(pose == end_state['object_pose'], 'cached end bottle differs from final raw trajectory')
        transform = fresh['bodies'][protocol['object']]['transforms'][0]
        require(transform[:3] + [transform[6]] + transform[3:6] == end_state['object_pose'], 'fresh end bottle differs from final raw trajectory')
        end_verified = True
    return dict(status='PASS_COMPLETE_EXPORTED_CONTROLLER_AND_STATE_PREIMAGE_AUDIT', before_after_K_D_effort_from_RAW_exact=True, after_end_K_D_effort_from_RAW_exact=True,
                two_hand_gains_before=[800., 800.], two_hand_gains_after=[1600., 1600.], two_hand_gains_end=[1600., 1600.],
                all_other_joint_K_unchanged=True, full_before_after_preimages_exact=True, preimage_hashes_independently_recomputed=preimages,
                end_preimages_and_trajectory_consistency_checked=end_verified, native_epoch=epoch, installation_native_time_s=t0, end_native_time_s=tN,
                installation_callbacks=before['physics_callbacks'], end_callbacks=end['physics_callbacks'], no_hidden_PhysX_solver_state_claim=True)
