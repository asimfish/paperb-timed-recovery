"""CPU-only event/interval auditor. No executor scores or simulator access.

All time bounds use the native clock epoch. Sampled hold is explicitly distinct
from an event gap and from physical continuity between observation endpoints.
"""
from __future__ import annotations

import math


def bounds(item):
    if not isinstance(item, dict) or not isinstance(item.get('clock_id'), str) or not item['clock_id']:
        raise ValueError('event needs a nonempty clock_id')
    value = item.get('bounds_s')
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError('event needs two bounds')
    if any(type(x) not in (int, float) or not math.isfinite(x) for x in value) or value[0] > value[1]:
        raise ValueError('finite ordered bounds required')
    return value


def gap_interval(reference, effect):
    """Signed effect-minus-reference interval; never subtract across epochs."""
    if reference is None or effect is None:
        return None
    a, b = bounds(reference), bounds(effect)
    if reference['clock_id'] != effect['clock_id']:
        raise ValueError('native epoch mismatch')
    return [b[0] - a[1], b[1] - a[0]]


def interval_verdict(reference, effect, lower_s, upper_s):
    if any(type(x) not in (int, float) or not math.isfinite(x) for x in (lower_s, upper_s)) or lower_s > upper_s:
        raise ValueError('finite ordered contract bounds required')
    if reference is None or effect is None:
        return {'verdict': 'UNAVAILABLE', 'gap_interval_s': None, 'pass': False}
    try:
        gap = gap_interval(reference, effect)
    except ValueError as exc:
        return {'verdict': 'INVALID_CLOCK_OR_BOUNDS', 'gap_interval_s': None, 'pass': False, 'reason': str(exc)}
    lo, hi = gap
    result = ('PASS' if lo >= lower_s and hi <= upper_s else
              'EARLY' if hi < lower_s else 'LATE' if lo > upper_s else 'INDETERMINATE')
    return {'verdict': result, 'gap_interval_s': gap, 'pass': result == 'PASS'}


def requested_gap_verdict(reference, effect, requested_s, tolerance_s):
    """Preserve the old native exact error arithmetic and inclusive limits."""
    if type(requested_s) not in (int, float) or type(tolerance_s) not in (int, float) or not math.isfinite(requested_s) or not math.isfinite(tolerance_s) or tolerance_s < 0:
        raise ValueError('finite request and nonnegative tolerance required')
    if reference is None or effect is None:
        return {'verdict': 'UNAVAILABLE', 'error_interval_s': None, 'timing_pass': False}
    try:
        gap = gap_interval(reference, effect)
    except ValueError as exc:
        return {'verdict': 'INVALID_CLOCK_OR_BOUNDS', 'error_interval_s': None, 'timing_pass': False, 'reason': str(exc)}
    lo, hi = gap[0] - requested_s, gap[1] - requested_s
    verdict = ('PASS' if lo >= -tolerance_s and hi <= tolerance_s else
               'EARLY' if hi < -tolerance_s else 'LATE' if lo > tolerance_s else 'INDETERMINATE')
    return {'verdict': verdict, 'error_interval_s': [lo, hi], 'timing_pass': verdict == 'PASS'}


def supported_event(signal, after_times, epoch, confirmation_count=3, search_from=1):
    """First false->true transition with K measured positive confirmations.

    The first positive observation gives the event bracket. Confirmation time
    gives confidence latency only and is never substituted for onset time.
    Missing observations prohibit a certified first-event result.
    """
    if len(signal) != len(after_times) or not isinstance(epoch, str) or not epoch:
        raise ValueError('signal/time alignment and epoch required')
    if type(confirmation_count) is not int or confirmation_count < 1:
        raise ValueError('positive integer confirmation_count required')
    if any(v is not True and v is not False and v is not None for v in signal):
        raise ValueError('tri-state signals only')
    if any(type(t) not in (int, float) or not math.isfinite(t) for t in after_times):
        raise ValueError('finite times required')
    if any(b <= a for a, b in zip(after_times, after_times[1:])):
        raise ValueError('strictly increasing sample times required')
    if None in signal:
        return {'status': 'UNAVAILABLE', 'event': None, 'reason': 'missing or invalid raw signal'}
    if len(signal) >= confirmation_count and all(signal[:confirmation_count]):
        return {'status': 'LEFT_CENSORED', 'event': None,
                'reason': 'positive confirmation begins at first sample without a preceding negative observation'}
    for start in range(max(1, search_from), len(signal) - confirmation_count + 1):
        if signal[start - 1] is False and all(signal[start:start + confirmation_count]):
            return {'status': 'DETECTED',
                    'event': {'clock_id': epoch, 'bounds_s': [after_times[start - 1], after_times[start]]},
                    'onset_sample_index': start,
                    'confirmation_sample_index': start + confirmation_count - 1,
                    'confirmation_time_s': after_times[start + confirmation_count - 1],
                    'confirmation_count': confirmation_count,
                    'physical_continuity_between_ticks_established': False}
    return {'status': 'NOT_DETECTED', 'event': None}


def sampled_hold(signal, after_times, onset_index, release_index, minimum_s):
    """Certify endpoint-sampled bilateral contact over the declared interval.

    Conservative supported duration runs from the first positive sample to
    the last positive sample before release. Any missing or negative sample
    inside it fails. This cannot prove continuous physical force between ticks.
    """
    if len(signal) != len(after_times) or type(minimum_s) not in (int, float) or not math.isfinite(minimum_s) or minimum_s < 0:
        raise ValueError('aligned signal/times and nonnegative minimum required')
    if onset_index is None or release_index is None:
        return {'verdict': 'UNAVAILABLE', 'pass': False, 'supported_duration_s': None,
                'semantics': 'SAMPLED_ENDPOINT_CONTACT_ONLY', 'physical_continuity_between_ticks_established': False}
    if not (0 <= onset_index < release_index <= len(signal)):
        raise ValueError('ordered contact and release indices required')
    selected = signal[onset_index:release_index]
    if any(x is None for x in selected):
        verdict, duration = 'UNAVAILABLE', None
    elif not all(x is True for x in selected):
        verdict, duration = 'INTERRUPTED', None
    else:
        duration = after_times[release_index - 1] - after_times[onset_index]
        verdict = 'PASS' if duration >= minimum_s else 'TOO_SHORT'
    return {'verdict': verdict, 'pass': verdict == 'PASS', 'supported_duration_s': duration,
            'semantics': 'SAMPLED_ENDPOINT_CONTACT_ONLY', 'physical_continuity_between_ticks_established': False}


def aggregate(episodes):
    """Every declared episode enters denominator, including absent/invalid rows."""
    counts = {}
    contract_count = 0
    passed = 0
    for ep in episodes:
        contracts = ep.get('contracts', [])
        contract_count += len(contracts)
        status = ep.get('status', 'MISSING')
        counts[status] = counts.get(status, 0) + 1
        complete = bool(contracts) and all(row.get('pass') is True for row in contracts) and ep.get('primary_joint_pass', True) is True
        passed += int(status == 'COMPLETE_RAW_AUDIT' and ep.get('task_mechanism_pass') is True and complete)
    return {'declared_native_episodes': len(episodes), 'contract_evaluations': contract_count,
            'joint_task_and_all_contract_pass_episodes': passed,
            'joint_success_rate': passed / len(episodes) if episodes else None,
            'statuses': counts,
            'contract_evaluations_are_not_independent_episodes': True}


def audit_fifo(submissions, applications, states, initial_target, require_flushed=True):
    """Check the delivered zero-order hold from raw dispatch and actual writes.

    Normalized fields: command_id/source_index/arm_target/grip_target;
    submissions additionally enqueue_tick/ready_tick; applications apply_tick;
    measured states tick/applied_command_id and targets. The initial target is
    not a fictitious queued command and uses command_id=None.
    """
    known = {}
    for row in submissions:
        cid = row['command_id']
        if cid in known or type(row['enqueue_tick']) is not int or type(row['ready_tick']) is not int:
            raise ValueError('unique submissions and integer ticks required')
        if not 0 <= row['enqueue_tick'] <= row['ready_tick']:
            raise ValueError('readiness cannot precede enqueue')
        known[cid] = row
    applied_ids = [row['command_id'] for row in applications]
    if len(set(applied_ids)) != len(applied_ids):
        raise ValueError('command applied more than once')
    if applied_ids != [row['command_id'] for row in submissions][:len(applied_ids)]:
        raise ValueError('FIFO order violated')
    previous = -1
    for row in applications:
        cid, tick = row['command_id'], row['apply_tick']
        if cid not in known or type(tick) is not int or tick <= previous:
            raise ValueError('unknown command or multiple applications per tick')
        if tick < known[cid]['ready_tick']:
            raise ValueError('command applied before readiness')
        previous = tick
    if require_flushed and len(applications) != len(submissions):
        raise ValueError('unapplied tail commands remain')
    current, app_cursor = initial_target, 0
    for tick, row in enumerate(states):
        if row['tick'] != tick:
            raise ValueError('missing or unordered measured tick')
        if app_cursor < len(applications) and applications[app_cursor]['apply_tick'] == tick:
            current = known[applications[app_cursor]['command_id']]
            app_cursor += 1
        if any(row[k] != current[k] for k in ('command_id', 'source_index', 'arm_target', 'grip_target')):
            raise ValueError('actual write differs from last applied command')
    if app_cursor != len(applications):
        raise ValueError('applications outside measured timeline')
    return {'status': 'PASS_FIFO_ACTUAL_APPLICATIONS', 'submitted_commands': len(submissions),
            'applied_commands': len(applications), 'observed_ticks': len(states),
            'queue_acceptance_is_not_physical_effect': True}


def calibration_interval_coverage(observed, calibration):
    """Sample-bracket inclusion only, without a probability/coverage claim."""
    for pair in (observed, calibration):
        if len(pair) != 2 or any(type(x) not in (int, float) or not math.isfinite(x) for x in pair) or pair[0] > pair[1]:
            raise ValueError('finite ordered sampled intervals required')
    a, b = observed
    c, d = calibration
    verdict = ('CONTAINED' if a >= c and b <= d else
               'BELOW' if b < c else 'ABOVE' if a > d else 'INDETERMINATE')
    return {'verdict': verdict, 'observed_mechanical_interval_s': list(observed),
            'frozen_calibration_interval_s': list(calibration),
            'certified_outside_observed_envelope': verdict in ('BELOW', 'ABOVE'),
            'sample_interval_contained': verdict == 'CONTAINED',
            'statistical_coverage_guarantee': False}
