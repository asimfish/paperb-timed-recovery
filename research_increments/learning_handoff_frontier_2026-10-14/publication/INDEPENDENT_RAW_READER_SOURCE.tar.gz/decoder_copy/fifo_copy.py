"""Exact extracted legacy independent FIFO functions, no executor imports."""
import numpy as np
from independent_protocol import audit_fifo

def require(condition, message):
    if not condition:
        raise ValueError(message)

def normalized_packet(packet):
    return {k: packet[k] for k in ('command_id', 'source_index', 'enqueue_tick', 'ready_tick', 'arm_target', 'grip_target')}

def queue_audit(obs, dispatch, commands, schedule, case, epoch):
    require(len(dispatch) == len(obs), 'dispatch rows missing')
    submitted, applied, event_rows, pending = [], [], [], []
    source_indices = schedule['source_indices']
    delay = case['public_transport_delay_ticks']
    require(len(obs) == len(source_indices) + delay, 'timeline does not include complete FIFO flush')
    for tick, (state, row) in enumerate(zip(obs, dispatch)):
        require(row['tick'] == tick and row['native_epoch'] == epoch and row['native_before_s'] == state['native_before_s'], 'dispatch native identity mismatch')
        packet = row['submitted']
        expected_source = source_indices[tick] if tick < len(source_indices) else None
        require(state['submitted_source_command_index'] == expected_source, 'submission schedule differs from frozen source list')
        require((packet is None) == (expected_source is None), 'submitted packet missing/unexpected')
        if packet is not None:
            require(packet['command_id'] == len(submitted) and packet['source_index'] == expected_source and packet['enqueue_tick'] == tick, 'submission identity mismatch')
            require(packet['ready_tick'] == tick+delay and packet['sampled_delay_ticks'] == delay and packet['native_epoch'] == epoch, 'public fixed delay mismatch')
            require(packet['enqueue_time_s'] == state['native_before_s'], 'enqueue timestamp is not actual native timestamp')
            require(np.array_equal(packet['arm_target'], commands['q_target'][expected_source]) and np.array_equal(packet['grip_target'], commands['grip_target'][expected_source]), 'packet target differs from pinned command')
            submitted.append(normalized_packet(packet)); pending.append(packet['command_id'])
            event_rows.append(dict(event='SUBMITTED', **packet))
        delivered = row['applied']
        if delivered is not None:
            require(pending and pending[0] == delivered['command_id'], 'applied packet is not FIFO head')
            pending.pop(0)
            require(delivered['apply_tick'] == tick and delivered['apply_time_s'] == state['native_before_s'], 'application is not actual native timestamp')
            require(delivered['native_epoch'] == epoch, 'applied packet epoch mismatch')
            origin = submitted[delivered['command_id']]
            require(all(delivered[k] == origin[k] for k in origin), 'applied packet differs from submitted packet')
            require(delivered['enqueue_time_s'] == obs[delivered['enqueue_tick']]['native_before_s'], 'applied packet enqueue timestamp mismatch')
            # Readiness is a prospective tick condition. If a measured ready
            # timestamp is supplied, it must come from the actual native row.
            if 'ready_observed_time_s' in delivered:
                require(delivered['ready_observed_time_s'] == obs[delivered['ready_tick']]['native_before_s'], 'ready observed time mismatch')
            applied.append(dict(command_id=delivered['command_id'], apply_tick=tick))
            event_rows.append(dict(event='APPLIED', **delivered))
        require(row['pending_command_ids'] == pending and state['pending_command_ids'] == pending, 'pending FIFO identity mismatch')
        require(row['held_previous_target'] is (delivered is None), 'held-target flag mismatch')
        require(row['applied_source_command_index'] == state['source_command_index'] == state['applied_source_command_index'], 'actual applied source mismatch')
        require(row['applied_command_id'] == state['applied_command_id'], 'actual applied id mismatch')
    normalized_states = [dict(tick=i, command_id=o['applied_command_id'], source_index=o['source_command_index'],
                              arm_target=o['arm_target'], grip_target=o['grip_target']) for i, o in enumerate(obs)]
    initial = dict(command_id=-1, source_index=-1,
                   arm_target=commands['q_target'][0].tolist(), grip_target=commands['grip_target'][0].tolist())
    result = audit_fifo(submitted, applied, normalized_states, initial)
    return result, event_rows
