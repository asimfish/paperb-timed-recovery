"""Independent one-attempt RAW auditor, CPU only; no physics/App imports."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys
import time

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "decoder_copy"))
from raw_native import derive_events, observations_to_arrays, validate_raw, sha256
from independent_protocol import requested_gap_verdict
from fifo_copy import queue_audit
from full_controller_audit import audit_full_controller
from trajectory_audit import rescore


def require(value, message):
    if not value:
        raise ValueError(message)


def read_json(path):
    return json.loads(Path(path).read_text())


def read_jsonl(path):
    with Path(path).open() as stream:
        return [json.loads(line) for line in stream if line.strip()]


def digest(row):
    return hashlib.sha256(json.dumps(row, sort_keys=True, allow_nan=False, separators=(",", ":")).encode()).hexdigest()


def finite_plain(value):
    if type(value) in (str, bool, int, type(None)):
        return True
    if type(value) is float:
        return math.isfinite(value)
    if type(value) is list:
        return all(finite_plain(v) for v in value)
    if type(value) is dict:
        return all(type(k) is str and finite_plain(v) for k, v in value.items())
    return False


def shape(value, dimensions):
    if not dimensions:
        return type(value) in (int, float) and type(value) is not bool and math.isfinite(value)
    return type(value) is list and len(value) == dimensions[0] and all(shape(v, dimensions[1:]) for v in value)


BODY_SHAPES = {
    "transform_xyz_xyzw": (1, 7), "velocity_world_com_linear_angular": (1, 6),
    "acceleration_world_com_linear_angular": (1, 6), "mass_kg": (1, 1), "inverse_mass_per_kg": (1, 1),
    "com_local_xyz_xyzw": (1, 7), "inertia_com_body_frame_column_major_kg_m2": (1, 9),
    "gravity_disabled_flag": (1, 1), "simulation_disabled_flag": (1, 1),
}


def observation(record, dimensions, name):
    require(type(record) is dict and record.get("status") in ("OBSERVED", "UNKNOWN"), "getter record: " + name)
    if record["status"] == "UNKNOWN":
        require(record.get("value") is None and type(record.get("reason")) is str and record["reason"], "unexplained missing getter: " + name)
        return None
    require(shape(record.get("value"), dimensions), "getter shape: " + name)
    return record["value"]


def validate_physical_row(row):
    """Separate implementation, never calls executor physical_validate."""
    require(type(row) is dict and finite_plain(row), "nonfinite/nonplain physical row")
    require(row["schema"] == "paperb-handoff-physical-snapshot-v1", "physical schema")
    require(type(row["tick"]) is int and row["phase"] in ("TASK_BEGIN", "PRE_WRITE", "POST_STEP", "TASK_END"), "physical phase/tick")
    require(row["load_bearing_verdict"] == "UNKNOWN_INSTRUMENTATION_ONLY", "instrumentation invented load label")
    require(row["active_kinematic_flag_status"] == "UNKNOWN_NO_INSTALLED_TENSOR_GETTER" and row["backend_constraint_inventory_status"] == "UNKNOWN_NO_COMPLETE_INSTALLED_GETTER", "unmeasured backend evidence invented")
    require(row["record_sha256"] == digest({k: v for k, v in row.items() if k != "record_sha256"}), "physical record hash")
    clocks = [row["native_clock_before"], row["native_clock_after"]]
    for clock in clocks:
        require(type(clock) is dict and set(clock) == {"native_epoch", "time_s", "callback_count"}, "physical clock fields")
        require(type(clock["native_epoch"]) is str and clock["native_epoch"] and type(clock["time_s"]) in (int, float) and type(clock["time_s"]) is not bool and type(clock["callback_count"]) is int and clock["callback_count"] >= 0, "physical clock types")
    require(clocks[0] == clocks[1] and row["no_native_step_during_getters"] is True, "getter advanced time/epoch/callback")
    require(set(row["rigid_body"]) == set(BODY_SHAPES), "physical getter field set")
    values = {name: observation(row["rigid_body"][name], dimensions, name) for name, dimensions in BODY_SHAPES.items()}
    for name in ("gravity_disabled_flag", "simulation_disabled_flag"):
        if values[name] is not None:
            require(type(values[name][0][0]) is int and values[name][0][0] in (0, 1), "non uint8/plain01 flag")
    if values["mass_kg"] is not None:
        require(values["mass_kg"][0][0] > 0, "nonpositive active mass")
    values["scene_gravity_world_m_s2"] = observation(row["scene_gravity_world_m_s2"], (3,), "scene gravity")
    require(set(row["external_wrench_buffers"]) == {"instantaneous", "permanent"}, "composer field set")
    for name, record in row["external_wrench_buffers"].items():
        require(record["status"] in ("OBSERVED", "UNKNOWN"), "composer status")
        if record["status"] == "UNKNOWN":
            require(record.get("value") is None and record.get("reason"), "composer missing reason")
            values["wrench_" + name] = None
        else:
            value = record["value"]
            require(set(value) == {"active", "force_body_frame_N", "torque_body_frame_N_m"} and type(value["active"]) is bool, "composer raw fields")
            require(shape(value["force_body_frame_N"], (1, 1, 3)) and shape(value["torque_body_frame_N_m"], (1, 1, 3)), "composer shape")
            values["wrench_" + name] = value
    return values


def physical_audit(path, states, epoch, protocol, installed):
    counts = Counter(); statuses = {}; first = {}; last = {}; ranges = {}; failures = []
    expected = [("TASK_BEGIN", -1)] + [(phase, i) for i in range(len(states)) for phase in ("PRE_WRITE", "POST_STEP")] + [("TASK_END", len(states))]
    position_exact, velocity_observed = 0, 0
    rows = 0
    with Path(path).open() as stream:
        for ordinal, line in enumerate(stream):
            row = json.loads(line); values = validate_physical_row(row)
            require(ordinal < len(expected) and (row["phase"], row["tick"]) == expected[ordinal], "physical phase order/missing/duplicate")
            require(row["body_path"] == protocol["object_prim"], "physical body identity")
            phase, tick = expected[ordinal]
            step = max(0, min(tick, len(states) - 1))
            time_s = states[0]["native_before_s"] if phase == "TASK_BEGIN" else states[-1]["native_after_s"] if phase == "TASK_END" else states[step]["native_before_s" if phase == "PRE_WRITE" else "native_after_s"]
            callbacks = protocol["warmup_ticks"] + protocol["restore_ticks"] + (0 if phase == "TASK_BEGIN" else len(states) if phase == "TASK_END" else tick + int(phase == "POST_STEP"))
            require(row["native_clock_before"] == {"native_epoch": epoch, "time_s": time_s, "callback_count": callbacks}, "physical clock differs from real per-tick RAW")
            counts[phase] += 1; rows += 1
            for name, value in values.items():
                counter = statuses.setdefault(name, Counter()); counter["UNKNOWN" if value is None else "OBSERVED"] += 1
                if value is not None:
                    first.setdefault(name, value); last[name] = value
                    if name in ("gravity_disabled_flag", "simulation_disabled_flag"):
                        ranges.setdefault(name, Counter())[str(value[0][0])] += 1
            if values["mass_kg"] is not None:
                require(values["mass_kg"] == installed["mass_after_kg"], "per-row actual mass changed")
            if values["inertia_com_body_frame_column_major_kg_m2"] is not None:
                require(values["inertia_com_body_frame_column_major_kg_m2"] == installed["inertia_after"], "per-row actual inertia changed")
            if phase == "POST_STEP":
                transform = values["transform_xyz_xyzw"]
                if transform is not None:
                    t = transform[0]
                    require(t[:3] + [t[6]] + t[3:6] == states[tick]["object_pose"], "POST_STEP fresh pose differs from state RAW")
                    position_exact += 1
                velocity_observed += int(values["velocity_world_com_linear_angular"] is not None)
    require(rows == 2 * len(states) + 2, "physical snapshot count incomplete")
    return {"status": "PASS_INDEPENDENT_PHYSICAL_RAW_STRUCTURE_CLOCK", "rows": rows, "phases": dict(counts),
        "getter_status_counts": {k: dict(v) for k, v in statuses.items()}, "flag_values_counts": {k: dict(v) for k, v in ranges.items()},
        "first_observed_values": first, "last_observed_values": last,
        "POST_STEP_transform_matches_RAW_exact_samples": position_exact, "POST_STEP_actual_velocity_observed_samples": velocity_observed,
        "missing_getters_retained_UNKNOWN": True, "load_bearing_verdict": "UNKNOWN", "physical_continuity_or_signed_load_not_established": True}


def mass_audit(directory, case):
    installation = read_json(directory / "mass_parameter_readback.json")
    end = read_json(directory / "task/installed_properties_end.json")
    require(installation["requested_factor"] == case["mass_factor"], "mass roster mismatch")
    report = {}
    for name, before, request, after, final, atol in (("mass", "mass_before_kg", "mass_requested_kg", "mass_after_kg", "mass_kg", 1e-8), ("inertia", "inertia_before", "inertia_requested", "inertia_after", "inertia", 1e-10)):
        a, q, v = (np.asarray(installation[k], dtype=np.float32) for k in (before, request, after))
        require(np.isfinite(a).all() and np.isfinite(q).all() and np.isfinite(v).all(), "nonfinite mass/inertia")
        require(np.array_equal(a * np.float32(case["mass_factor"]), q), "requested mass/inertia scale")
        error = np.abs(v - q); bound = np.float32(atol) + np.float32(1e-6) * np.abs(q)
        require((error <= bound).all() and installation[after] == end[final], "installed tolerance or endpoint change")
        report[name] = {"requested": q.tolist(), "actual": v.tolist(), "absolute_error": error.tolist(), "allowed_absolute_error": bound.tolist()}
    require(installation["installed_before_warmup"] and installation["installed_before_task"], "mass installed during task")
    return installation, report


def safe_asset(task, relative):
    p = Path(relative)
    require(not p.is_absolute() and ".." not in p.parts, "capture asset path escape")
    path = task / p
    require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(task.resolve()), "missing/nonregular capture asset")
    return path


def capture_audit(task, states, schedule, protocol, epoch):
    rows = read_json(task / "capture_index.json")
    wanted = {0, *[s["end_tick"] for s in schedule["stage_plan"]]}
    origin = states[0]["native_before_s"]
    video_ids = []
    for i, state in enumerate(states):
        if (i + 1) % 40 == 0 and protocol["video_start_task_s"] <= state["native_after_s"] - origin < protocol["video_end_task_s"]:
            wanted.add(i + 1); video_ids.append(i + 1)
    require([r["command_index"] for r in rows] == sorted(wanted), "capture roster differs from frozen stage/native time windows")
    require(read_jsonl(task / "captures.jsonl") == rows[1:], "capture append log/index differs")
    require(read_json(task / "video_frames.json")["frames"] == [r for r in rows if r["command_index"] in video_ids], "video roster differs")
    output = []; last_frame = -1; future_pairs = 0
    for row in rows:
        index = row["command_index"]
        clock = origin if index == 0 else states[index - 1]["native_after_s"]
        require(row["native_epoch"] == epoch and row["native_time_s"] == row["rendered_state_native_time_s"] == clock, "capture native clock")
        require(row["observation_mode"] == "OFFLINE_CAPTURE" and row["policy_delivery_time_s"] is None, "image delivery invented")
        require(row["physics_callbacks_during_render"] == 0 and row["physical_state_changed"] is False, "camera advanced physics")
        require(type(row["camera_frame"]) is int and row["camera_frame"] > last_frame, "camera frame reused")
        last_frame = row["camera_frame"]
        expected_q = read_json(task.parent / "CONTROLLER_AFTER.json")["fresh_physics_view_state_preimage"]["arms"]["fr3_A"] if index == 0 else None
        q = expected_q["dof_positions"][0] if index == 0 else states[index - 1]["q_all"]
        qd = expected_q["dof_velocities"][0] if index == 0 else states[index - 1]["qd_all"]
        require(row["student_proprioception"] == {"joint_positions": q, "joint_velocities": qd}, "student proprio differs from capture state")
        image = safe_asset(task, row["image"]); depth = safe_asset(task, row["depth"])
        require(sha256(image) == row["image_sha256"], "JPEG byte hash differs")
        with Image.open(image) as pic:
            require(pic.format == "JPEG" and pic.size == tuple(protocol["camera_resolution"]), "JPEG format/dimension")
            pixels = np.asarray(pic.convert("RGB")); pic.load()
        require(pixels.shape == (400, 640, 3) and pixels.dtype == np.uint8, "decoded RGB shape")
        require(type(row["native_rgb_sha256"]) is str and len(row["native_rgb_sha256"]) == 64, "missing native pre-JPEG RGB digest")
        with np.load(depth, allow_pickle=False) as value:
            require(set(value.files) == {"depth_m"}, "depth archive fields")
            d = value["depth_m"]
            require(d.shape == (400, 640) and np.issubdtype(d.dtype, np.floating), "depth shape/dtype")
            finite = np.isfinite(d); invalid = np.isnan(d) | np.isneginf(d) | (finite & (d < 0))
            require(not invalid.any(), "invalid depth scalar values")
            finite_fraction = float(finite.mean())
        next_tick = index if index < len(schedule["source_indices"]) else None
        if next_tick is not None:
            require(states[next_tick]["native_before_s"] >= clock, "offline image paired to past submission")
            future_pairs += 1
        output.append({"command_index": index, "native_time_s": clock, "JPEG_sha256": sha256(image), "depth_sha256": sha256(depth),
            "JPEG_decoded_std": float(pixels.std()), "depth_finite_fraction": finite_fraction,
            "legal_next_submission_tick": next_tick, "policy_delivery": "UNKNOWN", "lossy_JPEG_does_not_reconstruct_native_RGB_digest": True})
    return {"status": "PASS_CAPTURE_RAW_BYTES_CLOCK_AND_OFFLINE_PAIRING", "RGBD_count": len(rows), "video_frames": len(video_ids),
        "legal_future_submission_pairs": future_pairs, "terminal_captures_without_future_submission_retained": len(rows) - future_pairs,
        "actual_policy_image_delivery_or_use_claimed": False, "training_rows_admitted": 0, "captures": output}


def completed_case(root, protocol, ap):
    case = protocol["cases"][0]; directory = root / "cases" / case["id"]; task = directory / "task"
    terminal = read_json(directory / "RESULT.json")
    require(not (directory / "ERROR.json").exists() and terminal["status"] == "BASELINE_COMMANDS_COMPLETED", "native failed or incomplete")
    epoch = "paperb_handoff_instrumentation_v1:" + case["id"] + ":" + sha256(root / "protocol.json")
    require(terminal["native_epoch"] == epoch, "trial epoch not full-new-source-bound")
    binding = read_json(directory / "case.json")
    require(binding["case"] == case and binding["protocol_sha256"] == sha256(root / "protocol.json") and binding["execution_release_sha256"] == ap["source_release_sha256"], "runtime source identity")
    require(binding["command_policy_sha256"] == sha256(root / "inputs/commands.npz") and binding["current_private_events_used_for_scheduling"] is False and binding["current_mass_used_for_scheduling"] is False, "private scheduling input or command source mismatch")
    schedule = read_json(directory / "schedule_decision.json")
    require(schedule == read_json(root / "FROZEN_DEVELOPMENT_SCHEDULE.json"), "seen schedule changed")
    require(binding["schedule_sha256"] == hashlib.sha256(json.dumps(schedule, sort_keys=True).encode()).hexdigest(), "schedule source binding")
    states, contacts = read_jsonl(task / "states.jsonl"), read_jsonl(task / "contact_rows.jsonl")
    require(len(states) == ap["task_samples"], "task RAW sample count")
    native = validate_raw(states, contacts, epoch, protocol["dt_s"])
    require(all(c["callbacks"] == 1 for c in contacts), "per-tick native contact callback count")
    with np.load(root / "inputs/commands.npz", allow_pickle=False) as saved:
        commands = {k: saved[k] for k in saved.files}
    fifo, events = queue_audit(states, read_jsonl(task / "dispatch.jsonl"), commands, schedule, case, epoch)
    require(events == read_jsonl(task / "command_events.jsonl"), "actual command journal/FIFO disagreement")
    require(fifo["submitted_commands"] == fifo["applied_commands"] == ap["submissions"], "submit/application denominator")
    queue_end = read_json(task / "queue_completion.json")
    require(queue_end["submitted"] == queue_end["applied"] == ap["submissions"] and queue_end["pending_command_ids"] == [] and queue_end["tail_flush_ticks"] == ap["tail_ticks"], "queue endpoint")
    arrays = observations_to_arrays(states)
    with np.load(task / "measured_arrays.npz", allow_pickle=False) as saved:
        require(set(saved.files) == set(arrays) and all(np.array_equal(saved[k], value) for k, value in arrays.items()), "NPZ vs RAW exact mismatch")
    contract = read_json(task / "contract.json")
    require(contract["independent_native_epoch"] == epoch and contract["origin_tick"] == 0, "contract epoch")
    coverage = read_json(task / "contact_coverage.json")
    require(coverage["missing_bodies"] == [] and coverage["callbacks"] == len(states) and protocol["object_prim"] in coverage["expected_bodies"] and all(any(side + "finger" in p for p in coverage["expected_bodies"]) for side in ("left", "right")), "contact coverage")
    mechanical = rescore(arrays, contract, contacts, True)
    stored = read_json(task / "independent_score.json")
    require(all(stored[k] == value for k, value in mechanical.items()), "old mechanical score RAW recomputation differs")
    mechanism = all(v for k, v in mechanical["conditions"].items() if k != "not_diagnostic")
    require(stored["task_mechanism_pass"] is mechanism, "stored mechanism differs")
    config = protocol["release_definition"]
    release = dict(support_prim_prefixes=config["support_prim_prefixes"], jaw_width_min_m=config["min_jaw_width_m"], tilt_max_rad=float(np.radians(config["max_tilt_deg"])), confirmation_samples=config["confirmation_count"], max_displacement_m=config["max_confirmation_displacement_m"])
    measured_events, bilateral = derive_events(states, contacts, contract, release)
    cached = read_json(task / "expanded_events.json")
    for ours, theirs in (("bilateral_contact", "bilateral_grasp"), ("verified_stable_release", "supported_release")):
        event = measured_events[ours]; saved = cached["events"][theirs]
        if event["event"] is None:
            require(saved["event"] is None, "executor invented measured event")
        else:
            require(saved["event"] == event["event"] and saved["onset_index"] == event["onset_sample_index"] and saved["confirmation_index"] == event["confirmation_sample_index"] and saved["confirmation_time_s"] == event["confirmation_time_s"], "onset/confirmation disagreement")
    cue = read_json(task / "public_cue.json")
    cue_tick = next(i for i, index in enumerate(schedule["source_indices"]) if index == protocol["cue_source_index"])
    require(cue["clock_id"] == epoch and cue["submission_tick"] == cue_tick and cue["bounds_s"] == [states[cue_tick]["native_before_s"]] * 2, "actual public cue")
    a, b = measured_events["bilateral_contact"], measured_events["verified_stable_release"]
    timing = {"contact": requested_gap_verdict(cue, a["event"], case["requested_contact_gap_s"], case["contact_tolerance_s"]), "release": requested_gap_verdict(cue, b["event"], case["requested_contact_gap_s"] + case["requested_contact_to_release_s"], protocol["primary_score_definition"]["release_tolerance_s"]), "duration_gap": requested_gap_verdict(a["event"], b["event"], case["requested_contact_to_release_s"], case["duration_tolerance_s"])}
    stored_timing = read_json(task / "timing_score.json")
    require(all(stored_timing[k] == v for k, v in timing.items()), "timing RAW recomputation differs")
    begin, end = a.get("onset_sample_index"), b.get("onset_sample_index")
    missing = [i for i in range(begin, end) if bilateral[i] is not True] if begin is not None and end is not None else None
    hold = missing == []
    require(cached["sampled_contact_hold"]["sampled_contact_hold"] is hold and (missing is None or cached["sampled_contact_hold"]["missing_bilateral_sample_indices"] == missing), "strict hold erased/changed")
    joint = mechanism and not schedule["schedule_refused"] and all(v["timing_pass"] for v in timing.values())
    require(stored_timing["joint_time_and_mechanism"] is joint and stored_timing["joint_with_sampled_hold"] is (joint and hold), "joint disagreement")
    installed, mass = mass_audit(directory, case)
    physical = physical_audit(task / "physical_snapshots.jsonl", states, epoch, protocol, installed)
    receipt = read_json(task / "physical_capture_receipt.json")
    require(receipt["rows"] == receipt["expected_rows"] == ap["physical_rows"] and receipt["source_sha256"] == sha256(root / "physical_capture.py") and receipt["validator_sha256"] == sha256(root / "physical_validate.py"), "physical capture closure")
    registry = read_json(directory / "registry.json")
    require(len(registry["rigid_objects"]) == 56 and len(registry["articulations"]) == 9 and registry["particle_prims"] == [], "original scene registry scope changed")
    after_controller = read_json(directory / "CONTROLLER_AFTER.json")
    controller = audit_full_controller(read_json(directory / "CONTROLLER_BEFORE.json"), after_controller, read_json(directory / "CONTROLLER_INSTALLATION.json"), read_json(task / "ACTIVE_DRIVE_END.json"), read_json(directory / "uninterrupted_transient_verdict.json"), protocol, registry, epoch, states[0]["native_before_s"], states[-1]["native_after_s"], len(states), states[-1])
    origin = read_json(task / "controller_origin.json")
    require(origin["task_origin_native_s"] == states[0]["native_before_s"] == origin["installation_after_native_s"] == after_controller["native_time_s"] and origin["native_epoch"] == epoch and origin["physics_callbacks"] == origin["installation_after_physics_callbacks"] == after_controller["physics_callbacks"] and origin["no_physics_steps_between_installation_and_task"] is True, "installation/task origin clock mismatch")
    warmup = read_jsonl(directory / "setup/native_clock.jsonl")
    require(len(warmup) == protocol["warmup_ticks"] and all(r["tick"] == i + 1 and abs(r["native_after_s"] - r["native_before_s"] - protocol["dt_s"]) < 1e-7 and (i == 0 or r["native_before_s"] == warmup[i - 1]["native_after_s"]) for i, r in enumerate(warmup)), "warmup continuity")
    require(abs(states[0]["native_before_s"] - warmup[-1]["native_after_s"] - protocol["restore_ticks"] * protocol["dt_s"]) < protocol["restore_ticks"] * 1e-7, "matched30-step gap")
    require(read_json(directory / "setup/stability.json")["status"] == "PASS", "original warmup stable-start gate denied")
    require(terminal["native_steps"] == ap["task_samples"] + ap["warmup_and_matched_transient_steps"], "total native step accounting")
    captures = capture_audit(task, states, schedule, protocol, epoch)
    write = read_json(task / "action_write_audit.json")
    require(write["prohibited_calls"] == [] and all(write[k] == 0 for k in ("object_pose_writes", "robot_pose_writes", "robot_joint_state_writes")), "task state rewrite")
    return {"status": "PASS_ONE_NATIVE_HANDOFF_RAW_AUDIT", "case_id": case["id"], "role": "DEVELOPMENT_SEEN_INSTRUMENTATION", "native": native, "total_native_steps_including_warmup": terminal["native_steps"], "warmup_rows": len(warmup), "matched_transient_steps": protocol["restore_ticks"], "FIFO": fifo, "physical": physical, "controller": controller, "installed_properties": mass, "mechanical_task_pass": mechanism, "fresh_mechanical_score": mechanical, "events": measured_events, "timing_scores": timing, "primary_joint_pass": joint, "strict_sampled_hold": {"pass": hold, "missing_bilateral_sample_indices": missing, "continuous_between_ticks_proved": False}, "joint_with_hold_pass": joint and hold, "captures": captures, "load_bearing_verdict": "UNKNOWN", "training_admitted": 0, "new_weights": 0, "OPD_student_rollouts": 0}


def partial_inventory(directory):
    """Retain available evidence counts after any terminal failure, no imputation."""
    result = {"case_directory_exists": directory.is_dir(), "counts_are_not_complete_epoch_acceptance": True, "files": {}}
    for name in ("task/states.jsonl", "task/contact_rows.jsonl", "task/dispatch.jsonl", "task/command_events.jsonl", "task/physical_snapshots.jsonl", "task/captures.jsonl"):
        path = directory / name
        info = {"available": path.is_file(), "rows": 0, "parse_errors": [], "phase_counts": {}}
        phases = Counter()
        if path.is_file():
            with path.open() as stream:
                for index, line in enumerate(stream):
                    if not line.strip(): continue
                    info["rows"] += 1
                    try:
                        row = json.loads(line)
                        if name.endswith("physical_snapshots.jsonl"):
                            phases[row.get("phase", "MISSING_PHASE")] += 1
                    except Exception as exc:
                        if len(info["parse_errors"]) < 5: info["parse_errors"].append({"line": index, "type": type(exc).__name__, "message": str(exc)})
            info["phase_counts"] = dict(phases)
        result["files"][name] = info
    for name in ("ERROR.json", "task/FAILED_PHYSICAL_SNAPSHOT.json"):
        if (directory / name).is_file():
            result[name] = {"sha256": sha256(directory / name), "bytes": (directory / name).stat().st_size}
    return result


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False); parser.add_argument("--root", required=True); parser.add_argument("--root-result-notification", required=True)
    args = parser.parse_args(); started = time.monotonic(); ap = read_json(HERE / "AUDIT_PROTOCOL.json")
    require(np.__version__ == "1.26.0", "use original SDK NumPy1.26.0 CPU decoder")
    release = read_json(HERE / "AUDITOR_RELEASE.json")
    for name, expected in release["files"].items():
        require(sha256(HERE / name) == expected, "auditor source changed")
    root = Path(args.root).resolve(); source = read_json(root / "EXECUTION_RELEASE.json")
    require(sha256(root / "EXECUTION_RELEASE.json") == ap["source_release_sha256"], "native source release differs")
    for name, expected in source["files"].items():
        require(sha256(root / name) == expected, "frozen source differs")
    notice = read_json(args.root_result_notification)
    require(notice["source_release_sha256"] == ap["source_release_sha256"] and notice["case_id"] == ap["case_id"] and notice["execution_terminal"] is True, "root terminal notification missing/mismatched")
    worker_path = root / "logs" / (ap["case_id"] + ".json")
    require(sha256(worker_path) == notice["worker_log_sha256"], "worker terminal identity differs")
    worker = read_json(worker_path)
    require(worker["case_id"] == ap["case_id"] and worker["status"] in ("COMPLETE", "FAILED_RETAINED") and worker["formal_episode_started"] is True, "resource refusal is not a native episode")
    output = {"schema": "IndependentOneNativeHandoffRawAudit/0.1", "created_at_utc": datetime.now(timezone.utc).isoformat(), "declared_primary_attempts": 1, "source_release_sha256": ap["source_release_sha256"], "auditor_release_sha256": sha256(HERE / "AUDITOR_RELEASE.json"), "root_notification_sha256": sha256(args.root_result_notification), "worker_terminal_sha256": sha256(worker_path), "worker_completion": worker, "new_diagnostic_reintegration_epochs": 0, "load_bearing_verdict": "UNKNOWN", "training_admitted": 0}
    directory = root / "cases" / ap["case_id"]
    result_path = directory / "RESULT.json"
    require((notice["result_sha256"] is None and not result_path.exists()) or (notice["result_sha256"] is not None and sha256(result_path) == notice["result_sha256"]), "result notification identity differs")
    try:
        require(worker["status"] == "COMPLETE" and worker["exit_code"] == 0 and worker["timed_out"] is False and worker["owned_process_group_empty"] is True, "failed/timedout/nonempty native worker retained")
        output.update(completed_case(root, read_json(root / "protocol.json"), ap))
    except Exception as exc:
        output.update(status="FAIL_OR_PARTIAL_NATIVE_RAW_AUDIT_RETAINED", error={"type": type(exc).__name__, "message": str(exc)}, observed_task_verdict="UNKNOWN_UNLESS_INDEPENDENTLY_COMPLETED", primary_attempt_still_in_denominator=True, available_partial_RAW=partial_inventory(directory))
    output["actual_allocated_GPU_wall_upper_hours"] = worker["allocated_gpu_hours_upper_bound"]
    require(abs(worker["allocated_gpu_hours_upper_bound"] - worker["wall_s"] / 3600) < 1e-12, "allocated cost differs from actual wall")
    output["cost_scope"] = "Actual child-attempt wall incl startup/termination/cleanup;700s is child deadline, not total-wall promise"
    output["all_case_regular_RAW_members"] = {str(p.relative_to(root)): {"sha256": sha256(p), "bytes": p.stat().st_size} for p in sorted(directory.rglob("*")) if p.is_file() and not p.is_symlink()}
    for name, expected in source["files"].items():
        require(sha256(root / name) == expected, "native source changed during audit")
    output["CPU_audit_wall_s"] = time.monotonic() - started
    with (HERE / "NATIVE_RAW_AUDIT.json").open("x") as stream:
        json.dump(output, stream, indent=2, sort_keys=True, allow_nan=False); stream.write("\n")
    print(json.dumps({"status": output["status"], "primary_attempts": 1, "load_bearing": "UNKNOWN", "audit_sha256": sha256(HERE / "NATIVE_RAW_AUDIT.json")}, sort_keys=True))


if __name__ == "__main__":
    main()
