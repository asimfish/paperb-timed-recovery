"""Synthetic independent RAW denials. No producer fixtures or new trial reads."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

import numpy as np
from audit_native_handoff import BODY_SHAPES, digest, validate_physical_row, physical_audit, safe_asset, partial_inventory
from independent_protocol import supported_event, requested_gap_verdict, audit_fifo


def tensor(dimensions, value=0.):
    return [tensor(dimensions[1:], value) for _ in range(dimensions[0])] if dimensions else value


def row(phase="TASK_BEGIN", tick=-1, time=0., callbacks=0):
    fields = {name: {"status": "OBSERVED", "value": tensor(dimensions)} for name, dimensions in BODY_SHAPES.items()}
    fields["mass_kg"]["value"] = [[.2]]
    fields["inverse_mass_per_kg"]["value"] = [[5.]]
    fields["transform_xyz_xyzw"]["value"] = [[0., 0., 0., 0., 0., 0., 1.]]
    for name in ("gravity_disabled_flag", "simulation_disabled_flag"):
        fields[name]["value"] = [[0]]
    value = {"schema": "paperb-handoff-physical-snapshot-v1", "tick": tick, "phase": phase, "body_path": "/World/FakeCPU",
        "native_clock_before": {"native_epoch": "FAKE_CPU_ONLY", "time_s": time, "callback_count": callbacks},
        "native_clock_after": {"native_epoch": "FAKE_CPU_ONLY", "time_s": time, "callback_count": callbacks}, "no_native_step_during_getters": True,
        "rigid_body": fields, "scene_gravity_world_m_s2": {"status": "UNKNOWN", "value": None, "reason": "CPU_HAS_NO_SCENE"},
        "external_wrench_buffers": {kind: {"status": "OBSERVED", "value": {"active": False, "force_body_frame_N": [[[0., 0., 0.]]], "torque_body_frame_N_m": [[[0., 0., 0.]]]}} for kind in ("instantaneous", "permanent")},
        "external_wrench_buffer_role": "PRE_WRITE_IS_INPUT_TO_NEXT_WRITE;POST_STEP_MAY_ALREADY_BE_CLEARED", "usd_inventory": None,
        "backend_constraint_inventory_status": "UNKNOWN_NO_COMPLETE_INSTALLED_GETTER", "active_kinematic_flag_status": "UNKNOWN_NO_INSTALLED_TENSOR_GETTER", "load_bearing_verdict": "UNKNOWN_INSTRUMENTATION_ONLY"}
    value["record_sha256"] = digest(value)
    return value


def rehash(value):
    value["record_sha256"] = digest({k: v for k, v in value.items() if k != "record_sha256"})
    return value


class IndependentRawCPU(unittest.TestCase):
    def test_native_precision_and_no_physics_imports(self):
        self.assertEqual(np.__version__, "1.26.0")
        self.assertFalse(any(k == "torch" or k == "omni" or k.startswith("isaac") for k in sys.modules))

    def test_explicit_missing_getter_retains_UNKNOWN(self):
        r = row(); r["rigid_body"]["velocity_world_com_linear_angular"] = {"status": "UNKNOWN", "value": None, "reason": "GETTER_EXCEPTION"}
        self.assertIsNone(validate_physical_row(rehash(r))["velocity_world_com_linear_angular"])

    def test_unknown_without_reason_or_with_fabricated_zero_rejected(self):
        for record in ({"status": "UNKNOWN", "value": None}, {"status": "UNKNOWN", "value": [[0.] * 6], "reason": "NONE"}):
            r = row(); r["rigid_body"]["velocity_world_com_linear_angular"] = record
            with self.assertRaises(ValueError): validate_physical_row(rehash(r))

    def test_bool_or_flat_flags_do_not_silently_normalize(self):
        for value in ([[False]], [0], [[2]]):
            r = row(); r["rigid_body"]["gravity_disabled_flag"]["value"] = value
            with self.assertRaises(ValueError): validate_physical_row(rehash(r))

    def test_getter_clock_change_rejected_even_if_hash_rebuilt(self):
        r = row(); r["native_clock_after"]["callback_count"] += 1
        with self.assertRaises(ValueError): validate_physical_row(rehash(r))

    def test_record_tampering_and_loadbearingTRUE_rejected(self):
        r = row(); r["rigid_body"]["mass_kg"]["value"] = [[.3]]
        with self.assertRaises(ValueError): validate_physical_row(r)
        r = row(); r["load_bearing_verdict"] = "TRUE"
        with self.assertRaises(ValueError): validate_physical_row(rehash(r))

    def fixture(self):
        states = [{"native_before_s": 0., "native_after_s": .01, "object_pose": [0., 0., 0., 1., 0., 0., 0.]}]
        rows = [row(), row("PRE_WRITE", 0), row("POST_STEP", 0, .01, 1), row("TASK_END", 1, .01, 1)]
        protocol = {"object_prim": "/World/FakeCPU", "warmup_ticks": 0, "restore_ticks": 0}
        installation = {"mass_after_kg": [[.2]], "inertia_after": tensor((1, 9))}
        return states, rows, protocol, installation

    def audit_fixture(self, rows, states, protocol, installed):
        with tempfile.TemporaryDirectory(prefix="independent_raw_handoff_cpu_") as t:
            p = Path(t) / "FAKE_CPU_NOT_NATIVE.jsonl"
            p.write_text("".join(json.dumps(r) + "\n" for r in rows))
            return physical_audit(p, states, "FAKE_CPU_ONLY", protocol, installed)

    def test_physical_order_and_xyzw_to_wxyz_exact(self):
        states, rows, protocol, installed = self.fixture()
        r = self.audit_fixture(rows, states, protocol, installed)
        self.assertEqual(r["POST_STEP_transform_matches_RAW_exact_samples"], 1)
        self.assertEqual(r["load_bearing_verdict"], "UNKNOWN")

    def test_missing_duplicate_or_reordered_phase_rejected(self):
        states, rows, protocol, installed = self.fixture()
        for changed in (rows[:-1], [rows[0], rows[2], rows[1], rows[3]], [*rows, rows[-1]]):
            with self.assertRaises(ValueError): self.audit_fixture(changed, states, protocol, installed)

    def test_POST_pose_or_cross_epoch_or_callbacks_mismatch_rejected(self):
        states, rows, protocol, installed = self.fixture()
        for field in ("pose", "epoch", "callback"):
            changed = copy.deepcopy(rows)
            if field == "pose": changed[2]["rigid_body"]["transform_xyz_xyzw"]["value"][0][0] = .001
            elif field == "epoch":
                for k in ("native_clock_before", "native_clock_after"): changed[2][k]["native_epoch"] = "OTHER"
            else:
                for k in ("native_clock_before", "native_clock_after"): changed[2][k]["callback_count"] = 9
            rehash(changed[2])
            with self.assertRaises(ValueError): self.audit_fixture(changed, states, protocol, installed)

    def test_onset_and_confirmation_remain_distinct_left_censored_UNKNOWN(self):
        e = supported_event([False, True, True, True], [0., .01, .02, .03], "e", 3)
        self.assertEqual(e["event"]["bounds_s"], [0., .01]); self.assertEqual(e["confirmation_time_s"], .03)
        self.assertIsNone(supported_event([True, True, True], [.01, .02, .03], "e", 3)["event"])

    def test_cross_epoch_time_subtraction_not_scored(self):
        result = requested_gap_verdict({"clock_id": "a", "bounds_s": [0., 0.]}, {"clock_id": "b", "bounds_s": [1., 1.]}, 1., .01)
        self.assertFalse(result["timing_pass"]); self.assertEqual(result["verdict"], "INVALID_CLOCK_OR_BOUNDS")

    def test_queued_command_is_not_an_applied_target(self):
        command = {"command_id": 0, "source_index": 0, "enqueue_tick": 0, "ready_tick": 1, "arm_target": [.3], "grip_target": [.02]}
        initial = {"command_id": -1, "source_index": -1, "arm_target": [.1], "grip_target": [.01]}
        states = [{"tick": 0, **initial}, {"tick": 1, **{k: command[k] for k in initial}}]
        self.assertEqual(audit_fifo([command], [{"command_id": 0, "apply_tick": 1}], states, initial)["applied_commands"], 1)
        states[0].update({k: command[k] for k in initial})
        with self.assertRaises(ValueError): audit_fifo([command], [{"command_id": 0, "apply_tick": 1}], states, initial)

    def test_capture_asset_escape_or_symlink_rejected(self):
        with tempfile.TemporaryDirectory(prefix="independent_capture_path_cpu_") as t:
            p = Path(t); (p / "regular").write_text("fake")
            self.assertEqual(safe_asset(p, "regular"), p / "regular")
            (p / "alias").symlink_to(p / "regular")
            for name in ("../outside", "alias"):
                with self.assertRaises(ValueError): safe_asset(p, name)

    def test_partial_or_malformed_RAW_retained_not_completed(self):
        with tempfile.TemporaryDirectory(prefix="independent_partial_cpu_") as t:
            p = Path(t); (p / "task").mkdir(); (p / "task/states.jsonl").write_text('{}\n{"bad_tail"\n')
            report = partial_inventory(p)
            self.assertTrue(report["counts_are_not_complete_epoch_acceptance"])
            self.assertEqual(report["files"]["task/states.jsonl"]["rows"], 2)
            self.assertEqual(len(report["files"]["task/states.jsonl"]["parse_errors"]), 1)


if __name__ == "__main__": unittest.main(verbosity=2)
