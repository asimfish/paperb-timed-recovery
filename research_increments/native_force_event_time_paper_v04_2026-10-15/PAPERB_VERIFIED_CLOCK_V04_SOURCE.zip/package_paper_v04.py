"""Package only a terminally checked document, without publish/native side effects."""
from pathlib import Path
import hashlib,json,zipfile,argparse
P=Path(__file__).resolve().parent
A=argparse.ArgumentParser();A.add_argument('outdir',type=Path);args=A.parse_args()
required=['main.tex','refs.bib','citation_support.json','icml2026.sty','icml2026.bst','main.pdf','paper.pdf','paperB_verified_clock_v04.pdf','paper.md','README.md','build_markdown.py','generate_figures.py','generate_calibration_figure_paper_v04.py','build_evidence_pins_v04.py','pdf_layout_check_v04.py','package_paper_v04.py','check_document_v04.py','INPUT_EVIDENCE_PIN_V04.json','PARENT_TEX_PIN.json','P0_FIGURE_INPUT_PINS.json','FORCE_V02_FIGURE_INPUT_PINS.json','MARKDOWN_GENERATION_RECEIPT.json','VERIFICATION_CONTRACT_V04.json','FINAL_CURRENT_DOCUMENT_CHECKS.json','PDF_LAYOUT_FINAL.json','LATEX_GUARD_FINAL.json','VISUAL_CHECK_FINAL.json','FINAL_COMPILE_COMMANDS.json','main.log','compile_bibtex.log']
check=json.loads((P/'FINAL_CURRENT_DOCUMENT_CHECKS.json').read_text())
if check['document_status']!='PASS_DOCUMENT_SCOPE':raise ValueError('FINAL_DOCUMENT_GATE_NOT_PASS')
pin=json.loads((P/'INPUT_EVIDENCE_PIN_V04.json').read_text())
if pin['status']!='RESEARCH_DRAFT_SCIENTIFIC_MAJOR_OPEN_CURRENT_FROZEN':raise ValueError('FINAL_ROOT_OUTCOME_BOUNDARY_REQUIRED')
sha=lambda d:hashlib.sha256(d).hexdigest()
pdfsha=sha((P/'main.pdf').read_bytes())
if any(sha((P/n).read_bytes())!=pdfsha for n in ['paper.pdf','paperB_verified_clock_v04.pdf']):raise ValueError('PDF_ALIASES_NOT_IDENTICAL')
if check['pdf_sha256']!=pdfsha:raise ValueError('STALE_CURRENT_PDF_CHECK')
for name, expected in [('icml2026.sty','7cdcf90f6a59c5219e7f15c88f7ed09fcaf598dad91e6cdddc4dc3cb0e397a95'),('icml2026.bst','0ec3d5eb9b02efb7e0b44a32f3775882f42a743d0bdc618f34e6936309b98764')]:
 if sha((P/name).read_bytes())!=expected:raise ValueError('TEMPLATE_MODIFIED')
paths=set(required)
for folder in ['figures','paper_rewriting_output','parent_provenance','document_checks','curated_calibration_v03']:
 paths.update(str(f.relative_to(P)) for f in (P/folder).rglob('*') if f.is_file())
paths.update(n for n in ['PDF_LAYOUT_INITIAL.json','PDF_LAYOUT_INITIAL_FAILURE.json','PDF_LAYOUT_OBSERVER_FIX.json','PDF_LAYOUT_V02_CLI_FAILURE.json','PDF_LAYOUT_V02_CLI_FAILURE_EMPTY.json','EVIDENCE_PIN_ALIAS_FAILURE.json','INPUT_EVIDENCE_PIN_V04_INTAKE.json','INPUT_EVIDENCE_PIN_V04_WORKING.json'] if (P/n).exists())
paths.update(f.name for f in P.glob('compile_pass*.log'))
if (P/'FORCE_V03_FIGURE_INPUT_PINS.json').exists():paths.add('FORCE_V03_FIGURE_INPUT_PINS.json')
files={name:{'bytes':(P/name).stat().st_size,'sha256':sha((P/name).read_bytes())} for name in sorted(paths)}
release={'schema':'PaperBCurrentManuscriptSourceRelease/4','status':'RESEARCH_DRAFT_SCIENTIFIC_MAJOR_OPEN','document_status':'PASS_DOCUMENT_SCOPE','root_independent_document_review':'PENDING_ROOT_NOT_AUTHOR_ATTESTED','files':files,'file_count':len(files),'current_tex_sha256':files['main.tex']['sha256'],'current_pdf_sha256':pdfsha,'parent_provenance_namespace':'parent_provenance','old_manifests_identify_parent_not_current':True,'source_notes':'No native RAW, trained policy weights, re-decoded data, publication mutation or experimental execution in this bundle.'}
releasebytes=(json.dumps(release,indent=2)+'\n').encode();(P/'MANUSCRIPT_SOURCE_RELEASE_V04.json').write_bytes(releasebytes)
args.outdir.mkdir(parents=True,exist_ok=True)
zipname=args.outdir/'PAPERB_VERIFIED_CLOCK_V04_SOURCE.zip'
with zipfile.ZipFile(zipname,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in sorted(paths):z.write(P/name,name)
 z.writestr('MANUSCRIPT_SOURCE_RELEASE_V04.json',releasebytes)
with zipfile.ZipFile(zipname) as z:
 if z.testzip() is not None:raise ValueError('ZIP_CRC_FAILURE')
 names=z.namelist()
 if len(names)!=len(set(names)) or set(names)!=paths|{'MANUSCRIPT_SOURCE_RELEASE_V04.json'}:raise ValueError('ZIP_NAMESET_FAILURE')
 for name,pins in files.items():
  d=z.read(name)
  if len(d)!=pins['bytes'] or sha(d)!=pins['sha256']:raise ValueError('ZIP_FULL_BYTE_READBACK_FAILURE:'+name)
 if z.read('MANUSCRIPT_SOURCE_RELEASE_V04.json')!=releasebytes:raise ValueError('ZIP_RELEASE_NOT_EXACT')
receipt={'schema':'PaperBCurrentManuscriptPackageReadback/1','status':'PASS_ALL_ARCHIVED_BYTES_CRC_AND_HASHES','members':len(paths)+1,'zip_bytes':zipname.stat().st_size,'zip_sha256':sha(zipname.read_bytes()),'source_release_sha256':sha(releasebytes),'pdf_sha256':pdfsha,'readback_all_members':True,'current_source_not_old_parent':True,'scientific_status':'MAJOR_OPEN','independent_root_review':'PENDING_ROOT'}
(P/'PACKAGE_READBACK_V04.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
