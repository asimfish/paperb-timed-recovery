"""Verify a current document candidate; no simulation, RAW decoder or publish."""
from pathlib import Path
import hashlib,json,re,subprocess
P=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
tex=(P/'main.tex').read_text();pdf=(P/'main.pdf').read_bytes();log=(P/'main.log').read_text()
md=(P/'paper.md').read_text();receipt=json.loads((P/'MARKDOWN_GENERATION_RECEIPT.json').read_text())
pages=subprocess.check_output(['pdftotext','-layout',str(P/'main.pdf'),'-']).decode().split('\f');pages=[s for s in pages if s.strip()]
reference_start=next(i for i,s in enumerate(pages) if re.search(r'^\s*References(?:\s{2,}|\s*$)',s,re.M))
appendix_start=next(i for i,s in enumerate(pages) if 'Evidence Levels and Reproducibility' in s)
checks={}
checks['official_style_byteexact']=all(sha((P/n).read_bytes())==h for n,h in [('icml2026.sty','7cdcf90f6a59c5219e7f15c88f7ed09fcaf598dad91e6cdddc4dc3cb0e397a95'),('icml2026.bst','0ec3d5eb9b02efb7e0b44a32f3775882f42a743d0bdc618f34e6936309b98764')])
checks['body_pages_at_most_eight']=reference_start<=8
checks['compile_current_no_overfull_undefined']=not re.search(r'Overfull \\[hv]box|LaTeX Warning:.*(?:undefined|multiply defined)|There were undefined',log)
checks['anonymous_research_preprint']=r'\usepackage[preprint]{icml2026}' in tex and 'Anonymous Authors' in pages[0] and 'Research draft; work in progress.' in pages[0]
checks['all_figures_tables_md_mirrored']=receipt['figure_count']==len(re.findall(r'\\begin\{figure\*?\}',tex)) and receipt['table_count']==len(re.findall(r'\\begin\{table\*?\}',tex)) and len(re.findall(r'!\[Figure \d+:',md))==receipt['figure_count']
checks['primary_citation_metadata_all_used']=set(re.findall(r'\\citep\{([^}]+)\}',tex))<=set(r['key'] for r in json.loads((P/'citation_support.json').read_text())['references'])
checks['retained_actual_figures_and_layout_derivative_pinned']=True
figure_pin_paths=['P0_FIGURE_INPUT_PINS.json','FORCE_V02_FIGURE_INPUT_PINS.json']
if (P/'FORCE_V03_FIGURE_INPUT_PINS.json').exists():figure_pin_paths.append('FORCE_V03_FIGURE_INPUT_PINS.json')
for name in figure_pin_paths:
 obj=json.loads((P/name).read_text())
 for file,pins in obj['files'].items():
  f=P/file
  if not f.is_file() or f.stat().st_size!=pins['bytes'] or sha(f.read_bytes())!=pins['sha256']:checks['retained_actual_figures_and_layout_derivative_pinned']=False
checks['current_pdf_layout_external_observer']=False
if (P/'PDF_LAYOUT_FINAL.json').is_file():
 obj=json.loads((P/'PDF_LAYOUT_FINAL.json').read_text());checks['current_pdf_layout_external_observer']=obj['ok'] and obj['pdf_sha256']==sha(pdf) and obj['log_sha256']==sha((P/'main.log').read_bytes()) and obj['pages']==len(pages)
checks['current_latex_guard_zero_findings']=(P/'LATEX_GUARD_FINAL.json').is_file() and json.loads((P/'LATEX_GUARD_FINAL.json').read_text())==[]
checks['current_input_namespace']=False
if (P/'INPUT_EVIDENCE_PIN_V04.json').is_file():
 obj=json.loads((P/'INPUT_EVIDENCE_PIN_V04.json').read_text());checks['current_input_namespace']=obj['status']=='RESEARCH_DRAFT_SCIENTIFIC_MAJOR_OPEN_CURRENT_FROZEN' and obj['main_VLA_runs']==0 and obj['engineering_checkpoint_runs']==1 and obj['G1_native_student_runs']==0 and obj['S_F_R_admitted']==0
checks['main_critical_study_contract_preserved']=all(v in tex for v in ['1,024 unique','1024','10,000 adaptation updates','5,000-update ancestor','0.15','0.30','50\\% ceiling','DATA\\_NOT\\_READY','all planned attempts','discarded earlier evidence','separate versioned budget namespace'])
checks['legacy_M1_not_reconstructed']='M1\'s omitted scalar is not retrospectively reconstructed' in tex and 'both legacy rejection records remain unchanged' in tex
checks['synthetic_G1_no_student_native_claim']='zero native installation, model calls or real student rollouts' in tex
checks['P0_not_VLA_or_generalization']='not a full VLA' in tex and 'no language encoder' in tex and 'no heldout episode' in tex.lower()
checks['v02_measurement_failure_and_partial_batch_retained']=all(v in tex for v in ['fails 98 support checks','approximately 0.981 N','Three other cases remain unexecuted','AFTER\\_APP\\_CLOSE','Python-level return','remain unknown'])
checks['parent_provenance_namespace_explicit']='parent\\_provenance' in tex and (P/'parent_provenance/MANUSCRIPT_SOURCE_RELEASE.json').is_file()
checks['final_allpage_author_visual_bound']=False
if (P/'VISUAL_CHECK_FINAL.json').exists():
 obj=json.loads((P/'VISUAL_CHECK_FINAL.json').read_text());checks['final_allpage_author_visual_bound']=obj['pdf_sha256']==sha(pdf) and obj['all_pages_seen']==list(range(1,len(pages)+1)) and not obj['independent_review_panel']
result={'schema':'PaperBFinalCurrentDocumentChecks/1','document_status':'PASS_DOCUMENT_SCOPE' if all(checks.values()) else 'PENDING_OR_FAILED_DOCUMENT_SCOPE','scientific_status':'MAJOR_OPEN','pdf_sha256':sha(pdf),'tex_sha256':sha((P/'main.tex').read_bytes()),'log_sha256':sha((P/'main.log').read_bytes()),'total_pages':len(pages),'body_pages':reference_start,'reference_pages':appendix_start-reference_start,'appendix_pages':len(pages)-appendix_start,'figure_count':receipt['figure_count'],'table_count':receipt['table_count'],'checks':checks,'failed_or_pending':[k for k,v in checks.items() if not v],'check_scope':'Authored consistency checks plus independently implemented existing TeX/PDF guards; root human review separate','author_checks_native_GPU_or_training':0,'root_independent_document_review':'PENDING_ROOT'}
(P/'FINAL_CURRENT_DOCUMENT_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
