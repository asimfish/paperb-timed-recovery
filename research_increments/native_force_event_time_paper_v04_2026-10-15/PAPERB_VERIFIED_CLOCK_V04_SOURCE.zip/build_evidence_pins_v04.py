"""Bind curated existing summaries only. Never execute native readers or open RAW."""
import hashlib,json
from pathlib import Path
import argparse
P=Path(__file__).resolve().parent
A=argparse.ArgumentParser();A.add_argument('increment_root',type=Path);A.add_argument('--final',action='store_true');args=A.parse_args()
intake=json.loads((P/'INPUT_EVIDENCE_PIN_V04_INTAKE.json').read_text())
aliases=list(intake['inputs'])+[
 'systematic_study_v01_2026-10-14/FINAL_RECEIPT.json',
 'systematic_study_v01_2026-10-14/ROOT_P0_DATA_AND_CHECKPOINT_READBACK.json',
 'systematic_study_v01_2026-10-14/P0_FIGURE_PIN.json',
 'native_shutdown_diagnostic_v01_2026-10-15/actual_audit/dev_shutdown_after_fixture_001/REPORT.json',
 'native_shutdown_diagnostic_v01_2026-10-15/root_execution/ROOT_RETAINED_DIAGNOSIS.json',
 'signed_force_fixture_calibration_v02_2026-10-15/root_execution/ROOT_BATCH_V02_RETAINED_CLOSURE.json',
 'signed_force_fixture_calibration_v02_2026-10-15/actual_audits/cal_force_c0_freefall_v02/REPORT.json',
 'signed_force_fixture_calibration_v02_2026-10-15/actual_audits/cal_force_c1_stack_v02/REPORT.json',
 'signed_force_fixture_calibration_v02_2026-10-15/independent_reader/PROSPECTIVE_READER_FREEZE.json',
 'signed_force_fixture_calibration_v02_2026-10-15/publication/figures_observed_v02/FIGURE_RECEIPT.json',
 'signed_force_fixture_calibration_v03_2026-10-15/collector/SOURCE_FREEZE.json',
 'signed_force_fixture_calibration_v03_2026-10-15/collector/EXECUTION_RELEASE.json',
 'signed_force_fixture_calibration_v03_2026-10-15/collector_checks/READONLY_VERIFICATION.json',
 'signed_force_fixture_calibration_v03_2026-10-15/collector/FINAL_RECEIPT.json',
 'signed_force_fixture_calibration_v03_2026-10-15/independent_reader/FINAL_RECEIPT.json',
 'signed_force_fixture_calibration_v03_2026-10-15/independent_reader/PROSPECTIVE_READER_FREEZE.json',
 'signed_force_fixture_calibration_v03_2026-10-15/independent_reader/SOURCE_REVIEW.json',
 'signed_force_fixture_calibration_v03_2026-10-15/root_execution/ROOT_BATCH_V03_ACTUAL_CLOSURE.json',
 'signed_force_fixture_calibration_v03_2026-10-15/publication/ACTUAL_CALIBRATION_SUMMARY.json',
 'signed_force_fixture_calibration_v03_2026-10-15/publication/figures/FIGURE_RECEIPT.json',
 'inference_prefix_clock_contract_v02_2026-10-15/root_review/INDEPENDENT_REVIEW.json',
 'inference_prefix_clock_contract_v02_2026-10-15/SOURCE_FREEZE.json',
 'inference_prefix_clock_contract_v02_2026-10-15/FINAL_RECEIPT.json',
 'signed_force_fixture_calibration_v03_2026-10-15/publication/plot_calibration.py']
closure_path=args.increment_root/'signed_force_fixture_calibration_v03_2026-10-15/root_execution/ROOT_BATCH_V03_ACTUAL_CLOSURE.json'
closurebytes=closure_path.read_bytes()
if hashlib.sha256(closurebytes).hexdigest()!='7ef83aaad95068f4da00dbefcf7ee8da7a1e83c2c7b5c0a575a1c60fa8718108':raise ValueError('ROOT_FROZEN_CLOSURE_SHA_REQUIRED')
closure=json.loads(closurebytes)
expected=['cal_force_c1_stack_processing_off_v03','cal_force_c0_freefall_v03','cal_force_c1_stack_v03','cal_force_c2_rotated_v03','cal_force_c3_actor_order_v03','cal_force_c4_mass_v03']
assert [c['case_id'] for c in closure['cases']]==expected and closure['actual_v03_epochs']==6 and closure['actual_controlled_steps']==5365
for c in closure['cases']:
 for kind in ['report','series']:
  alias='signed_force_fixture_calibration_v03_2026-10-15/actual_audits/'+c['case_id']+'/'+('REPORT.json' if kind=='report' else 'AUDITED_SERIES.json')
  d=(args.increment_root/alias).read_bytes()
  assert hashlib.sha256(d).hexdigest()==c[kind]['sha256'] and len(d)==c[kind]['bytes']
  aliases.append(alias)
files={}
for alias in aliases:
 f=args.increment_root/alias
 if f.stat().st_size>2*1024*1024:raise ValueError('CURATED_INPUT_SIZE_REQUIRED')
 data=f.read_bytes();files[alias]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'source_file_included':False}
oldpin=P/'parent_provenance/INPUT_EVIDENCE_PIN_V03.json'
result={'schema':'PaperBManuscriptV04CurrentEvidence/1','status':'WORKING_PENDING_ROOT_V03_BOUNDED_OUTCOMES','curated_only_no_new_RAW_read':True,'inputs':files,'parent_input_pin':{'file':str(oldpin.relative_to(P)),'sha256':hashlib.sha256(oldpin.read_bytes()).hexdigest(),'interpretation':'Historical parent evidence pins; old counts do not describe current v04'},'author_native_GPU_modeltraining':0,'main_VLA_runs':0,'engineering_checkpoint_runs':1,'G1_native_student_runs':0,'v01_v02_calibration_actual_epochs':3,'shutdown_diag_actual_epochs_separate':1,'M0_M1_M2_actual_epochs_separate':3,'S_F_R_admitted':0,'v03_outcomes':'PENDING_ROOT','template':json.loads(oldpin.read_text())['template']}
if args.final:
 assert closure['execution_state']=='CLOSED_ALL6_DISTINCT_CASES_ONCE' and closure['positive_conditional_passes']==5 and closure['qualified_S_F_R']==0 and closure['main_M_B3']=='UNTESTED'
 result.update(status='RESEARCH_DRAFT_SCIENTIFIC_MAJOR_OPEN_CURRENT_FROZEN',v03_outcomes='FIVE_ON_CONDITIONAL_PASS_OFF_MEASUREMENT_FAILURE_RETAINED',v03_actual_epochs=6,v03_actual_controlled_steps=5365,calibration_family_actual_epochs=9,calibration_shutdown_phase_actual_epochs=10,calibration_shutdown_phase_controlled_steps=6774,root_v03_closure_sha256=hashlib.sha256(closurebytes).hexdigest(),prefix_clock_v02='SCOPED_CPU_HIGHWATER_PASS_NOT_NATIVE_INTEGRATED_NOT_WHOLE_API_TRANSACTIONAL')
 for alias,v in result['inputs'].items():
  if '/actual_audits/' in alias and alias.startswith('signed_force_fixture_calibration_v03_'):
   bundled='curated_calibration_v03/'+alias.split('/actual_audits/',1)[1]
   f=P/bundled
   if f.is_file():
    assert hashlib.sha256(f.read_bytes()).hexdigest()==v['sha256']
    v.update(source_file_included=True,bundled_path=bundled)
 alias='signed_force_fixture_calibration_v03_2026-10-15/publication/plot_calibration.py'
 assert hashlib.sha256((P/'parent_provenance/ROOT_V03_CALIBRATION_FIGURE_PARENT.py').read_bytes()).hexdigest()==result['inputs'][alias]['sha256']
 result['inputs'][alias].update(source_file_included=True,bundled_path='parent_provenance/ROOT_V03_CALIBRATION_FIGURE_PARENT.py')
 filename='INPUT_EVIDENCE_PIN_V04.json'
else:filename='INPUT_EVIDENCE_PIN_V04_WORKING.json'
(P/filename).write_text(json.dumps(result,indent=2)+'\n')
print('Bound current curated inputs:',len(files))
