from pathlib import Path
import json,hashlib
ROOT=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
gate=json.loads((ROOT/'CPU_PREFLIGHT.json').read_text())
if gate['status']!='PASS_CPU_PREFLIGHT':raise ValueError('preflight failed')
protocol=json.loads((ROOT/'protocol.json').read_text())
if sha(ROOT/'frozen_native_scheduler.py')!=protocol['source']['frozen_scheduler_sha256']:
    raise ValueError('original frozen planner copy differs')
files=['candidate_solver.py','independent_oracle.py','roster.py','run_validation.py','test_cpu_protocol.py',
       'freeze_sources.py','frozen_native_scheduler.py','protocol.json','CPU_PREFLIGHT.json']
receipt=dict(schema='paperb-pure-cpu-execution-release-v1',files={n:sha(ROOT/n) for n in files},
        scope='DIGITAL_CONTRACT_MATH_ONLY',native_episode_count=0,physics_sample_count=0,
        frozen_before_full_matrix=True)
with (ROOT/'EXECUTION_RELEASE.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(dict(status='FROZEN_PURE_CPU_SOURCE',files=len(files),release_sha256=sha(ROOT/'EXECUTION_RELEASE.json'))))
