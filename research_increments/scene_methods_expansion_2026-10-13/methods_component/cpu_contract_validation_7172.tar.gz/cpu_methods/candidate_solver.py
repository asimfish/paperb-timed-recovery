"""An exact grid solver candidate, separate from the frozen native controller.

Only mechanical timing intervals, public contracts and a minimum skill gap are
inputs. This is mathematical scheduling, not a learned or physical controller.
"""
from fractions import Fraction as F

def ceilq(x):return -((-x.numerator)//x.denominator)
def floorq(x):return x.numerator//x.denominator

def solve(case):
    dt=F(case['dt_ratio']);delay=case['public_delay_ticks']*dt
    D,H,eps=map(F,[case['contact_request_s'],case['duration_request_s'],case['tolerance_s']])
    a0,a1=[F(x)+delay for x in case['mechanical_contact_interval_s']]
    b0,b1=[F(x)+delay for x in case['mechanical_release_interval_s']]
    minimum=F(case['min_skill_gap_s']);earliest=F(case['earliest_contact_dispatch_s'])
    if dt<=0 or eps<0 or a0>a1 or b0>b1:
        raise ValueError('ordered finite intervals and nonnegative tolerance required')
    al,ah=D-eps-a0,D+eps-a1
    bl,bh=D+H-eps-b0,D+H+eps-b1
    dl,dh=H-eps-b0+a1,H+eps-b1+a0
    first_a=max(ceilq(al/dt),ceilq(earliest/dt));last_a=floorq(ah/dt)
    first_b,last_b=ceilq(bl/dt),floorq(bh/dt)
    ideal_a=D-(a0+a1)/2;ideal_b=D+H-(b0+b1)/2
    choices=[]
    for ai in range(first_a,last_a+1):
        lo=max(first_b,ceilq((ai*dt+minimum)/dt),ceilq((ai*dt+dl)/dt))
        hi=min(last_b,floorq((ai*dt+dh)/dt))
        if lo>hi:continue
        # The objective is convex in b for fixed a: only the nearest two grid
        # points to the ideal b (clamped to its interval) can be optimal.
        near={max(lo,min(hi,floorq(ideal_b/dt))),max(lo,min(hi,ceilq(ideal_b/dt)))}
        for bi in near:
            cost=(ai*dt-ideal_a)**2+(bi*dt-ideal_b)**2
            choices.append((cost,ai,bi))
    if not choices:
        return dict(status='REFUSED',selected_ticks=None,objective_ratio=None,considered_contact_ticks=max(0,last_a-first_a+1))
    cost,ai,bi=min(choices)
    return dict(status='FEASIBLE',selected_ticks=[ai,bi],objective_ratio=str(cost),considered_contact_ticks=max(0,last_a-first_a+1))
