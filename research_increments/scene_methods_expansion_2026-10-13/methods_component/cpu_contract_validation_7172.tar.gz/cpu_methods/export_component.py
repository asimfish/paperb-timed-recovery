"""Archive exact CPU sources/raw results and reopen every member for hashing."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).parent
AUDIT=Path('/data/liyufeng/paperb_scene_methods_audit_20261013_v1/cpu_extensions')
DEST=Path('/mnt/nas/data/lyf/chem_mem/awesome_memory_chem/papers/paperB/research_increments/scene_methods_expansion_2026-10-13/methods_component')
NATIVE=Path('/data/liyufeng/paperb_scene_methods_expansion_20261013_v1')

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def write(path,obj):
    with path.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False);f.write('\n')

def native_source_unchanged():
    r=json.loads((NATIVE/'EXECUTION_RELEASE.json').read_text())
    for n,h in r['files'].items():
        if sha(NATIVE/n)!=h:raise ValueError('native frozen source changed: '+n)
    return sha(NATIVE/'EXECUTION_RELEASE.json')

def main():
    native_before=native_source_unchanged()
    frozen=json.loads((ROOT/'EXECUTION_RELEASE.json').read_text())
    for n,h in frozen['files'].items():
        if sha(ROOT/n)!=h:raise ValueError('CPU frozen source changed: '+n)
    summary=json.loads((ROOT/'SUMMARY.json').read_text())
    for n,h in summary['artifacts'].items():
        if sha(ROOT/n)!=h:raise ValueError('CPU raw artifact changed: '+n)
    third=json.loads((AUDIT/'PUBLIC_NUMERIC_AUDIT.json').read_text())
    if third['status']!='PASS_COMPONENT_EXACT_INTEGER_RECOMPUTATION' or third['candidate_exact_matches']!=7172:
        raise ValueError('independent audit not passed')
    if sha(AUDIT/'NUMERIC_MATRIX_AUDIT_V2.json')!=third['full_audit_sha256']:
        raise ValueError('independent audit identity mismatch')
    full=json.loads((AUDIT/'NUMERIC_MATRIX_AUDIT_V2.json').read_text())
    for n,h in full['source_artifact_sha256'].items():
        if sha(ROOT/n)!=h:raise ValueError('third-party raw source mismatch: '+n)
    for n,h in full['auditor_source_sha256'].items():
        if sha(AUDIT/n)!=h:raise ValueError('third-party auditor source changed: '+n)
    if sha(AUDIT/'NUMERIC_MATRIX_AUDIT_ROWS_V2.jsonl')!=full['independent_rows_sha256']:
        raise ValueError('third-party independent rows changed')
    owned=list(frozen['files'])+['EXECUTION_RELEASE.json','ROSTER.jsonl','results.jsonl','oracle_pairs.jsonl',
        'SUMMARY.json','TARGETED_COUNTEREXAMPLES.json','PUBLIC_SUMMARY.json','PUBLIC_SUMMARY_verified.json',
        'README_cn.md','export_component.py']
    independent=['PUBLIC_NUMERIC_AUDIT.json','NUMERIC_MATRIX_AUDIT_V2.json','NUMERIC_MATRIX_AUDIT_ROWS_V2.jsonl',
        'audit_numeric_matrix_v2.py','integer_grid_oracle_full.py','test_integer_grid_oracle.py','integer_grid_oracle.py',
        'MIDPOINT_FALSE_REFUSAL_COUNTEREXAMPLE.json']
    members={str(Path('cpu_methods')/n):ROOT/n for n in owned}
    members.update({str(Path('cpu_methods/third_audit')/n):AUDIT/n for n in independent})
    expected={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in members.items()}
    DEST.mkdir(exist_ok=False)
    archive=DEST/'cpu_contract_validation_7172.tar.gz'
    with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
        for name in sorted(members):
            p=members[name]
            if p.is_symlink() or not p.is_file():raise ValueError('only regular explicitly listed artifacts allowed')
            info=tar.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
            with p.open('rb') as f:tar.addfile(info,f)
    actual={}
    with tarfile.open(archive,'r:gz') as tar:
        for member in tar:
            if not member.isfile() or Path(member.name).is_absolute() or '..' in Path(member.name).parts or member.name in actual:
                raise ValueError('invalid archive member')
            h=hashlib.sha256();f=tar.extractfile(member)
            for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
            actual[member.name]=dict(sha256=h.hexdigest(),bytes=member.size)
    if actual!=expected:raise ValueError('reopened archive member hash/size mismatch')
    native_after=native_source_unchanged()
    if native_after!=native_before:raise ValueError('native source freeze changed during export')
    write(DEST/'SOURCE_MEMBERS.json',dict(schema='paperb-cpu-archive-members-v1',members=expected,
          execution_release_sha256=sha(ROOT/'EXECUTION_RELEASE.json'),frozen_native_release_sha256=native_before,
          no_native_results_in_archive=True,native_episode_count=0))
    exports={'summary.json':ROOT/'PUBLIC_SUMMARY_verified.json','summary_pending.json':ROOT/'PUBLIC_SUMMARY.json',
        'counterexamples.json':ROOT/'TARGETED_COUNTEREXAMPLES.json','README_cn.md':ROOT/'README_cn.md',
        'THIRD_AUDIT.json':AUDIT/'PUBLIC_NUMERIC_AUDIT.json','THIRD_AUDIT_full.json':AUDIT/'NUMERIC_MATRIX_AUDIT_V2.json',
        'EXECUTION_RELEASE.json':ROOT/'EXECUTION_RELEASE.json'}
    for name,source in exports.items():
        with (DEST/name).open('xb') as f:f.write(source.read_bytes())
        if sha(DEST/name)!=sha(source):raise ValueError('public export mismatch: '+name)
    receipt=dict(schema='paperb-cpu-archive-reopen-validation-v1',status='PASS_REOPENED_EVERY_MEMBER_EXACT',
        archive_name=archive.name,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,
        member_count=len(actual),all_member_hashes_exact=True,member_manifest_sha256=sha(DEST/'SOURCE_MEMBERS.json'),
        cpu_execution_release_sha256=sha(ROOT/'EXECUTION_RELEASE.json'),native_source_freeze_sha256=native_after,
        frozen_native_sources_unchanged=True,conditions=7172,native_episode_count=0,physics_sample_count=0,
        independent_audit_sha256=sha(AUDIT/'PUBLIC_NUMERIC_AUDIT.json'),
        exports={n:sha(DEST/n) for n in exports},builder_sha256=sha(Path(__file__)))
    write(DEST/'ARCHIVE_VALIDATION.json',receipt)
    print(json.dumps({k:receipt[k] for k in ('status','archive_bytes','archive_sha256','member_count','frozen_native_sources_unchanged')}))

if __name__=='__main__':main()
