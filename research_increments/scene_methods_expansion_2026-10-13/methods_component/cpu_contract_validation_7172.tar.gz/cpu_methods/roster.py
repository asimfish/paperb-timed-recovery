"""Deterministic synthetic conditions; random seed here is not a physical seed."""
from fractions import Fraction as F
import itertools
import random

def make_case(id,dt,ac,bc,wa,wb,delay,eps,D,H,minimum,family='grid'):
    ac,bc,wa,wb=map(F,[ac,bc,wa,wb])
    return dict(id=id,family=family,dt_ratio=dt,mechanical_contact_interval_s=[str(ac-wa/2),str(ac+wa/2)],
        mechanical_release_interval_s=[str(bc-wb/2),str(bc+wb/2)],public_delay_ticks=delay,tolerance_s=eps,
        contact_request_s=D,duration_request_s=H,min_skill_gap_s=minimum,earliest_contact_dispatch_s='4')

def roster(protocol):
    g=protocol['full_grid']
    dimensions=[g[k] for k in ('dt_ratios','contact_centers_s','release_centers_s','width_pairs_s','public_delay_ticks',
                               'tolerances_s','contact_requests_s','duration_requests_s','min_skill_gap_s')]
    rows=[]
    for i,(dt,ac,bc,w,delay,e,D,H,minimum) in enumerate(itertools.product(*dimensions)):
        rows.append(make_case(f'grid_{i:05}',dt,ac,bc,*w,delay,e,D,H,minimum))
    rng=random.Random(protocol['synthetic_sampling_seed'])
    for i in range(protocol['random_draws']):
        dt=rng.choice(['1/240','1/120','1/60','1/40'])
        ac=F(rng.randint(100,280),1000);bc=F(rng.randint(50,180),1000)
        wa=F(rng.randint(1,120),1000);wb=F(rng.randint(1,80),1000)
        D=F(rng.randint(81,120),20);H=F(rng.randint(340,380),20)
        rows.append(make_case(f'draw_{i:05}',dt,str(ac),str(bc),str(wa),str(wb),rng.choice([0,1,12]),
                     str(F(rng.randint(2,60),1000)),str(D),str(H),str(rng.choice([17,18,19])),'synthetic_draw'))
    rows.append(make_case('counterexample_midpoint_false_refusal','1/240','.160','.120','.004','.004',0,'.025','5','17.95','18','targeted'))
    rows.append(make_case('counterexample_two_absolute_windows_gap_failure','1/240','.200','.120','.040','.040',0,'.025','5','18','17','targeted'))
    rows.append(make_case('counterexample_grid_quantization','1/40','.200','.100','.0005','.0005',0,'.001','5.003','18.003','17','targeted'))
    rows.append(make_case('counterexample_wide_calibration_refusal','1/240','.200','.100','.060','.060',0,'.025','5','18','17','targeted'))
    return rows
