import unittest
from integer_grid_oracle import classify, oracle


def example(**values):
    case = dict(dt_ratio='1/240', contact_request_s='5', duration_request_s='17.95', tolerance_s='.025',
                min_skill_gap_s='18', earliest_contact_dispatch_s='4', public_delay_ticks=0,
                mechanical_contact_interval_s=['.158', '.162'], mechanical_release_interval_s=['.118', '.122'])
    case.update(values)
    return case


class IntegerOracleTests(unittest.TestCase):
    def test_exact_counterexample_witness(self):
        case = example()
        self.assertTrue(classify(case, [1161, 5481])['joint'])
        self.assertIn([1161, 5481], oracle(case)['feasible_pairs'])

    def test_wide_interval_cannot_fit_absolute_window(self):
        result = oracle(example(mechanical_contact_interval_s=['.17', '.23']))
        self.assertEqual(result['feasible_pair_count'], 0)
        self.assertIsNone(result['selected_ticks'])

    def test_unique_exact_grid_plan(self):
        result = oracle(example(duration_request_s='18', tolerance_s='0',
                                mechanical_contact_interval_s=['.175', '.175'], mechanical_release_interval_s=['.1', '.1']))
        self.assertEqual(result['feasible_pairs'], [[1158, 5496]])
        self.assertEqual(result['selected_ticks'], [1158, 5496])
        self.assertEqual(result['objective_ratio'], '0')

    def test_known_shared_delay_cancels_in_duration(self):
        case = example(public_delay_ticks=12)
        point = [1161-12, 5481-12]
        self.assertTrue(classify(case, point)['joint'])

    def test_two_absolute_windows_do_not_imply_duration(self):
        case = example(duration_request_s='18', min_skill_gap_s='17',
                       mechanical_contact_interval_s=['.18', '.22'], mechanical_release_interval_s=['.1', '.14'])
        result = classify(case, [1152, 5491])
        self.assertTrue(result['contact'])
        self.assertTrue(result['release'])
        self.assertFalse(result['duration_gap'])

    def test_earliest_action_is_a_constraint(self):
        result = oracle(example(earliest_contact_dispatch_s='6'))
        self.assertEqual(result['feasible_pair_count'], 0)


if __name__ == '__main__':
    unittest.main()
