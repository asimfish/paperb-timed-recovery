"""Execute the frozen CPU-only matrix and retain every rejection/exception."""
import hashlib
import json
from fractions import Fraction as F
from pathlib import Path
import time
from collections import Counter
import frozen_native_scheduler as old
from candidate_solver import solve
from independent_oracle import enumerate_pairs,classify
from roster import roster

ROOT=Path(__file__).parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def old_inputs(case,protocol,method):
    dt=F(case['dt_ratio']);first_close=int(F(4)/dt);first_open=first_close+int(F(case['min_skill_gap_s'])/dt)
    pp=dict(dt_s=float(dt),nominal_mechanical_latency_s=protocol['nominal_mechanical_latency_s'],
            first_close_source_index=first_close,first_open_source_index=first_open,cue_source_index=0,total_commands=first_open+1,
            stage_plan=[dict(id='complete',start_tick=0,end_tick=first_open+1)],
            primary_score_definition=dict(release_tolerance_s=float(F(case['tolerance_s']))))
    cc=dict(id=case['id'],role='test',method=method,public_transport_delay_ticks=case['public_delay_ticks'],
            requested_contact_gap_s=float(F(case['contact_request_s'])),requested_contact_to_release_s=float(F(case['duration_request_s'])),
            contact_tolerance_s=float(F(case['tolerance_s'])),duration_tolerance_s=float(F(case['tolerance_s'])))
    mm=dict(status='FROZEN_CALIBRATION',mechanical_latency_intervals_s={
        'contact':[float(F(x)) for x in case['mechanical_contact_interval_s']],
        'release':[float(F(x)) for x in case['mechanical_release_interval_s']]})
    return cc,pp,mm

def run_old(case,protocol,method):
    cc,pp,mm=old_inputs(case,protocol,method)
    try:
        schedule=old.dispatch_schedule(cc,pp,mm)
        pair=[pp['first_close_source_index']+schedule['hold_before_close_ticks'],
              pp['first_open_source_index']+schedule['hold_before_close_ticks']+schedule['hold_before_release_ticks']]
        checks=classify(case,pair)
        refused=schedule['schedule_refused']
        return dict(method=method,status='REFUSED_WITH_DIAGNOSTIC_FALLBACK' if refused else 'SCHEDULED',
                    selected_ticks=None if refused else pair,diagnostic_fallback_ticks=pair if refused else None,
                    robust_checks=checks,robust_joint_pass=not refused and checks['joint'],
                    joint_interval_certificate=schedule['joint_interval_certificate'],exception=None)
    except Exception as e:
        return dict(method=method,status='EXCEPTION_RETAINED_AS_REJECTION',selected_ticks=None,
                    diagnostic_fallback_ticks=None,robust_checks=None,robust_joint_pass=False,
                    joint_interval_certificate=None,exception=dict(type=type(e).__name__,message=str(e)))

def synthetic_detection_examples():
    rows=[dict(native_before_s=i*.01,native_after_s=(i+1)*.01) for i in range(105)]
    onset=old.confirm_event(rows,[i>=100 for i in range(105)],3,'synthetic_clock','synthetic_contact')
    cue=dict(clock_id='synthetic_clock',bounds_s=[0.,0.])
    confirmed=dict(clock_id='synthetic_clock',bounds_s=[onset['confirmation_time_s']]*2)
    correct=old.score_gap(cue,onset['event'],1.005,.015)
    substituted=old.score_gap(cue,confirmed,1.005,.015)
    left=old.confirm_event(rows,[True]*len(rows),3,'synthetic_clock','already_true')
    return dict(scope='SYNTHETIC_SAMPLES_ONLY; NO_NEW_SENSOR_DATA',onset=onset,onset_score=correct,
                incorrectly_substituted_confirmation_score=substituted,left_censored=left,
                occurrence_confirmation_separation_pass=correct['timing_pass'] and not substituted['timing_pass'],
                left_censor_pass=left['status']=='LEFT_CENSORED' and left['event'] is None)

def main():
    release=json.loads((ROOT/'EXECUTION_RELEASE.json').read_text())
    for n,h in release['files'].items():
        if sha(ROOT/n)!=h:raise ValueError('frozen CPU source changed: '+n)
    protocol=json.loads((ROOT/'protocol.json').read_text());cases=roster(protocol)
    start=time.monotonic();counts={m:Counter() for m in protocol['methods']};old_false_refusal=[];old_false_feasible=[]
    candidate_mismatches=[];oracle_pairs=0;targeted=[];main_domain=[]
    with (ROOT/'ROSTER.jsonl').open('x') as roster_file,(ROOT/'results.jsonl').open('x') as result_file, \
         (ROOT/'oracle_pairs.jsonl').open('x') as oracle_file:
        for i,c in enumerate(cases):
            roster_file.write(json.dumps(c,sort_keys=True)+'\n')
            oracle=enumerate_pairs(c);candidate=solve(c);oracle_pairs+=oracle['pairs_checked']
            cand_matches=(candidate['selected_ticks']==oracle['selected_ticks'] and candidate['objective_ratio']==oracle['objective_ratio'])
            if not cand_matches:candidate_mismatches.append(c['id'])
            methods=[run_old(c,protocol,m) for m in protocol['methods']]
            for row in methods:
                counts[row['method']]['denominator']+=1;counts[row['method']][row['status']]+=1
                counts[row['method']]['robust_joint_pass']+=int(row['robust_joint_pass'])
                counts[row['method']]['contact_and_release_pass_gap_fail']+=int(row['robust_checks'] is not None and
                    row['robust_checks']['contact'] and row['robust_checks']['release'] and not row['robust_checks']['duration_gap'])
            joint=methods[-1];exists=oracle['feasible_pair_count']>0
            old_accept=joint['selected_ticks'] is not None
            if exists and not old_accept:old_false_refusal.append(c['id'])
            if old_accept and not joint['robust_checks']['joint']:old_false_feasible.append(c['id'])
            result=dict(case_id=c['id'],oracle_feasible=exists,oracle_feasible_pair_count=oracle['feasible_pair_count'],
                oracle_selected_ticks=oracle['selected_ticks'],methods=methods,candidate=candidate,candidate_matches_oracle=cand_matches,
                old_joint_false_refusal=exists and not old_accept,old_joint_false_feasible=old_accept and not joint['robust_checks']['joint'])
            result_file.write(json.dumps(result,sort_keys=True,allow_nan=False)+'\n')
            oracle_file.write(json.dumps(dict(case_id=c['id'],**oracle),sort_keys=True)+'\n')
            if c['family']=='targeted':targeted.append(dict(case=c,result=result,oracle=oracle))
            if (c['family']=='grid' and c['dt_ratio']=='1/240' and c['tolerance_s']=='0.025'
                  and c['duration_request_s'] in ('18','18.5') and c['min_skill_gap_s']=='17'):
                main_domain.append(result)
            if (i+1)%1000==0:print(json.dumps(dict(conditions_processed=i+1,conditions_total=len(cases),wall_s=time.monotonic()-start)),flush=True)
    detection=synthetic_detection_examples()
    native_static=dict(scope='STATIC CONTRACT CHECK; SYNTHETIC LATENCY DOMAINS; NO A-TEST LABELS OR NEW CALIBRATION',
        native_H_s=[18,18.5],native_min_skill_s=17,dt_ratio='1/240',matched_synthetic_conditions=len(main_domain),
        midpoint_precheck_false_refusals=sum(r['old_joint_false_refusal'] for r in main_domain),
        prior_joint_stage_margin_s=[18+protocol['nominal_mechanical_latency_s']['contact']-protocol['nominal_mechanical_latency_s']['release']-17-1/240,
                                  18.5+protocol['nominal_mechanical_latency_s']['contact']-protocol['nominal_mechanical_latency_s']['release']-17-1/240],
        calibrated_sufficient_condition='mean_release_lag - mean_contact_lag <= H - min_skill_gap - dt; ACTUAL NEW CALIBRATION STILL UNAVAILABLE',
        unconstrained_calibration_immunity_proven=False)
    status='PASS_CANDIDATE_WITH_RETAINED_OLD_PLANNER_COUNTEREXAMPLES' if not candidate_mismatches and not old_false_feasible and all((detection['occurrence_confirmation_separation_pass'],detection['left_censor_pass'])) else 'FAIL_RETAINED_FOR_REVIEW'
    report=dict(schema='paperb-cpu-joint-scheduler-validation-v1',status=status,total_conditions=len(cases),
        full_grid_conditions=sum(c['family']=='grid' for c in cases),synthetic_draw_conditions=sum(c['family']=='synthetic_draw' for c in cases),
        targeted_conditions=len(targeted),method_comparisons=len(cases)*len(protocol['methods']),method_summary={m:dict(v) for m,v in counts.items()},
        candidate_denominator=len(cases),candidate_complete_oracle_matches=len(cases)-len(candidate_mismatches),
        candidate_mismatch_ids=candidate_mismatches,old_joint_false_refusal_ids=old_false_refusal,old_joint_false_feasible_ids=old_false_feasible,
        independently_enumerated_pair_checks=oracle_pairs,old_exceptions_kept_in_denominator=True,
        native_episode_count=0,physics_sample_count=0,learning_updates=0,
        interval_scope=protocol['synthetic_interval_semantics'],synthetic_sampling_seed=protocol['synthetic_sampling_seed'],physical_seed=None,
        wall_s=time.monotonic()-start,execution_release_sha256=sha(ROOT/'EXECUTION_RELEASE.json'),protocol_sha256=sha(ROOT/'protocol.json'),
        artifacts={n:sha(ROOT/n) for n in ('ROSTER.jsonl','results.jsonl','oracle_pairs.jsonl')},native_static_scope=native_static,
        occurrence_confirmation=detection)
    for name,value in [('SUMMARY.json',report),('TARGETED_COUNTEREXAMPLES.json',targeted)]:
        with (ROOT/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({k:report[k] for k in ('status','total_conditions','method_comparisons','candidate_complete_oracle_matches','independently_enumerated_pair_checks','wall_s')},sort_keys=True))

if __name__=='__main__':main()
