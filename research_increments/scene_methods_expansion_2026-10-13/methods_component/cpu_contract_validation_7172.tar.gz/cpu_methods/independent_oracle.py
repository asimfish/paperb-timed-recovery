"""Full finite pair enumeration; never imports either scheduler implementation."""
from fractions import Fraction as F

def classify(case,pair):
    dt=F(case['dt_ratio']);q=case['public_delay_ticks']*dt
    D,H,e=map(F,[case['contact_request_s'],case['duration_request_s'],case['tolerance_s']])
    a,b=[int(x)*dt for x in pair]
    mechanical_a=list(map(F,case['mechanical_contact_interval_s']))
    mechanical_b=list(map(F,case['mechanical_release_interval_s']))
    contact=all(D-e <= a+q+x <= D+e for x in mechanical_a)
    release=all(D+H-e <= b+q+x <= D+H+e for x in mechanical_b)
    gap=all(H-e <= b-a+y-x <= H+e for x in mechanical_a for y in mechanical_b)
    skill=a >= F(case['earliest_contact_dispatch_s']) and b-a >= F(case['min_skill_gap_s'])
    return dict(contact=contact,release=release,duration_gap=gap,min_skill=skill,
                joint=contact and release and gap and skill)

def enumerate_pairs(case):
    dt=F(case['dt_ratio']);q=case['public_delay_ticks']*dt
    D,H,e=map(F,[case['contact_request_s'],case['duration_request_s'],case['tolerance_s']])
    ma=list(map(F,case['mechanical_contact_interval_s']));mb=list(map(F,case['mechanical_release_interval_s']))
    # Enumerate a superset of each absolute window, then independently test
    # all four effect corners and the mechanical dependency on each pair.
    a_start=max(0,int((D-e-q-max(ma))/dt)-2)
    a_stop=int((D+e-q-min(ma))/dt)+3
    b_start=max(0,int((D+H-e-q-max(mb))/dt)-2)
    b_stop=int((D+H+e-q-min(mb))/dt)+3
    feasible=[];count=0
    # First eliminate individually impossible absolute dispatches. This does
    # not use a gap bound or either planner's candidate set.
    valid_a=[i for i in range(a_start,a_stop+1) if all(D-e<=i*dt+q+x<=D+e for x in ma)]
    valid_b=[i for i in range(b_start,b_stop+1) if all(D+H-e<=i*dt+q+x<=D+H+e for x in mb)]
    differences=[y-x for x in ma for y in mb]
    earliest=F(case['earliest_contact_dispatch_s']);minimum=F(case['min_skill_gap_s'])
    for ai in valid_a:
        for bi in valid_b:
            count+=1
            delta=(bi-ai)*dt
            if ai*dt >= earliest and delta >= minimum and all(H-e<=delta+x<=H+e for x in differences):
                feasible.append([ai,bi])
    ideal_a=D-q-(ma[0]+ma[1])/2;ideal_b=D+H-q-(mb[0]+mb[1])/2
    scored=[((ai*dt-ideal_a)**2+(bi*dt-ideal_b)**2,ai,bi) for ai,bi in feasible]
    best=min(scored) if scored else None
    return dict(feasible_pairs=feasible,feasible_pair_count=len(feasible),absolute_a_ticks=valid_a,
                absolute_b_ticks=valid_b,pairs_checked=count,
                selected_ticks=[best[1],best[2]] if best else None,objective_ratio=str(best[0]) if best else None)
