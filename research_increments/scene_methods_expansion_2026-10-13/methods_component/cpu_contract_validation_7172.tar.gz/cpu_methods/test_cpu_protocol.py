import json
from pathlib import Path
import tempfile
import unittest
from fractions import Fraction as F
from roster import roster,make_case
from candidate_solver import solve
from independent_oracle import enumerate_pairs,classify
from run_validation import run_old,synthetic_detection_examples

ROOT=Path(__file__).parent
P=json.loads((ROOT/'protocol.json').read_text())

class CPUProtocolTests(unittest.TestCase):
    def test_roster_deterministic_and_complete(self):
        a=roster(P);b=roster(P)
        self.assertEqual(a,b);self.assertEqual(len(a),7172)
        self.assertEqual(len({r['id'] for r in a}),7172)

    def test_old_midpoint_false_refusal_is_retained(self):
        c=next(c for c in roster(P) if c['id']=='counterexample_midpoint_false_refusal')
        result=run_old(c,P,'joint_interval_scheduler');oracle=enumerate_pairs(c)
        self.assertEqual(result['status'],'EXCEPTION_RETAINED_AS_REJECTION')
        self.assertGreater(oracle['feasible_pair_count'],0)
        self.assertTrue(classify(c,[1161,5481])['joint'])
        self.assertEqual(solve(c)['selected_ticks'],oracle['selected_ticks'])

    def test_two_absolute_windows_pass_but_gap_fails(self):
        c=next(c for c in roster(P) if c['id']=='counterexample_two_absolute_windows_gap_failure')
        r=run_old(c,P,'calibrated_interval')
        self.assertTrue(r['robust_checks']['contact']);self.assertTrue(r['robust_checks']['release'])
        self.assertFalse(r['robust_checks']['duration_gap']);self.assertFalse(r['robust_joint_pass'])

    def test_known_fifo_shift_preserves_gap(self):
        c=make_case('fifo','1/240','.2','.1','.004','.004',0,'.025','5','18','17')
        a=solve(c);b=solve(dict(c,public_delay_ticks=12))
        self.assertEqual(b['selected_ticks'],[t-12 for t in a['selected_ticks']])

    def test_wide_intervals_are_refused(self):
        c=next(c for c in roster(P) if c['id']=='counterexample_wide_calibration_refusal')
        self.assertEqual(solve(c)['status'],'REFUSED');self.assertFalse(enumerate_pairs(c)['feasible_pairs'])

    def test_grid_quantization_changes_feasibility(self):
        c=next(c for c in roster(P) if c['id']=='counterexample_grid_quantization')
        self.assertEqual(solve(c)['status'],'REFUSED')
        self.assertEqual(solve(dict(c,dt_ratio='1/1000'))['status'],'FEASIBLE')

    def test_minimum_skill_gap_can_block_absolute_windows(self):
        c=make_case('minimum','1/240','.2','.1','.004','.004',0,'.025','5','17.2','18')
        o=enumerate_pairs(c)
        self.assertTrue(o['absolute_a_ticks']);self.assertTrue(o['absolute_b_ticks'])
        self.assertFalse(o['feasible_pairs']);self.assertEqual(solve(c)['status'],'REFUSED')

    def test_candidate_matches_full_enumeration_at_targeted_conditions(self):
        for c in roster(P):
            if c['family']!='targeted':continue
            a,b=solve(c),enumerate_pairs(c)
            self.assertEqual(a['selected_ticks'],b['selected_ticks'])
            self.assertEqual(a['objective_ratio'],b['objective_ratio'])

    def test_interval_widening_cannot_add_feasible_pairs(self):
        base=make_case('narrow','1/240','.2','.1','.004','.004',0,'.025','5','18','17')
        wide=dict(base,mechanical_contact_interval_s=['.18','.22'],mechanical_release_interval_s=['.08','.12'])
        a={tuple(p) for p in enumerate_pairs(base)['feasible_pairs']};b={tuple(p) for p in enumerate_pairs(wide)['feasible_pairs']}
        self.assertTrue(b<=a)

    def test_confirmation_time_is_not_occurrence_time(self):
        e=synthetic_detection_examples()
        self.assertTrue(e['occurrence_confirmation_separation_pass']);self.assertTrue(e['left_censor_pass'])

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(CPUProtocolTests))
    if not result.wasSuccessful():raise SystemExit(1)
    with (ROOT/'CPU_PREFLIGHT.json').open('x') as f:
        json.dump(dict(status='PASS_CPU_PREFLIGHT',test_count=result.testsRun,scope='SMALL_EXCLUDED_PROTOCOL_PREFLIGHT',
                       native_episode_count=0,physics_sample_count=0),f,indent=2);f.write('\n')
