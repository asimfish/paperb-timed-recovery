"""Restricted public calibrated linear-rotor prediction, not a chemical model."""
import math
from interfaces import Interval


def verdict(reference, effect, window, prediction=False):
    labels = ('PREDICTED_ELIGIBLE', 'PREDICTED_INELIGIBLE', 'UNRESOLVED') if prediction else ('TRUE', 'FALSE', 'UNKNOWN')
    if reference is None or effect is None:
        return labels[2]
    lower, upper = effect.lo - reference.hi, effect.hi - reference.lo
    if window[0] <= lower and upper <= window[1]:
        return labels[0]
    if upper < window[0] or lower > window[1]:
        return labels[1]
    return labels[2]


def cross_for_model(packet, i, zero_ns, model, spec):
    dt = spec['dt_ns']
    if zero_ns % dt:
        raise ValueError('native control must align with integration grid')
    mass, damping = model['inertia'], model['damping']
    decay = mass / (mass + dt / 1e9 * damping)
    start = packet.capture_ns
    velocity = packet.velocities[i]
    zero_ns = max(start, zero_ns)
    ticks = (zero_ns - start) // dt
    steady = spec['drive_torque'] / damping if packet.powered[i] else 0.
    velocity = steady + (velocity - steady) * decay ** ticks
    threshold = spec['speed_threshold']
    if velocity <= threshold:
        # The public observer supplies a measured crossing once it is known.
        return Interval(zero_ns, zero_ns)
    n = max(1, math.ceil(math.log(threshold / velocity) / math.log(decay)))
    while velocity * decay ** n > threshold:
        n += 1
    while n > 1 and velocity * decay ** (n - 1) <= threshold:
        n -= 1
    return Interval(zero_ns + (n - 1) * dt, zero_ns + n * dt)


def completion(observer, i, zero_ns, spec):
    if observer.effects[i] is not None:
        return observer.effects[i]
    if observer.pending_low[i] is not None and not observer.latest.powered[i]:
        # Passive nonnegative rotors cannot recover above threshold. Retain the
        # observed segment's original start instead of moving it to a new ACK.
        return observer.pending_low[i][0]
    values = [cross_for_model(observer.latest, i, zero_ns, m, spec) for m in spec['models'][i]]
    return Interval(min(x.lo for x in values), max(x.hi for x in values))


def first_zero(observer, minimum_ack, target, spec, pending_B_ack=None):
    """Earliest grid-aligned global zero with supported B crossing lower bound."""
    dt = spec['dt_ns']
    lo = (minimum_ack + dt - 1) // dt
    hi = spec['horizon_ns'] // dt
    def enough(tick):
        zero = tick * dt
        if pending_B_ack is not None:
            zero = min(zero, pending_B_ack)
        return completion(observer, 1, zero, spec).lo >= target
    if not enough(hi):
        return None
    while lo < hi:
        mid = (lo + hi) // 2
        if enough(mid):
            hi = mid
        else:
            lo = mid + 1
    return lo * dt


def planned_B_ack(observer, now, free_at, spec, window_B, reservations):
    current = next((r.ack_ns for r in reservations if r.target == 'B'), None)
    if current is not None:
        return current
    if observer.references[1] is None:
        return None
    ref = observer.references[1]
    target = ref.hi + (window_B[0] + window_B[1]) // 2
    earliest = max(now, free_at) + spec['selective_B_delay_ns']
    zero = first_zero(observer, earliest, target, spec)
    return zero
