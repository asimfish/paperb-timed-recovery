"""Own MuJoCo plant. Hidden case and actuation effects never enter controller."""
from pathlib import Path
import xml.etree.ElementTree as ET
import mujoco

HERE = Path(__file__).resolve().parent


def model_for(A_setting, B_setting):
    root = ET.fromstring((HERE / 'shared_bus.xml').read_text())
    for name, setting in [('A', A_setting), ('B', B_setting)]:
        body = root.find(f'./worldbody/body[@name="{name}"]')
        inertia = setting['inertia']
        body.find('inertial').set('diaginertia', f'{inertia / 2} {inertia / 2} {inertia}')
        body.find('joint').set('damping', str(setting['damping']))
    return mujoco.MjModel.from_xml_string(ET.tostring(root, encoding='unicode'))


def apply(data, reservation, fault, bus_latched):
    if reservation.target == 'global':
        data.ctrl[:] = 0
        return True, True
    drop = reservation.target == 'A' and (reservation.tag == 'initial_A' and fault != 'none'
                                          or reservation.tag == 'retry_A' and fault == 'persistent_primary')
    if not drop:
        data.ctrl[0 if reservation.target == 'A' else 1] = 0
    if bus_latched:
        data.ctrl[:] = 0
    return not drop, bus_latched
