"""Bounded pre-run contracts; native probe is not a task success trial."""
from dataclasses import asdict
import json
from pathlib import Path
import mujoco
from interfaces import Packet
from controller import GraphController, public_reference
from referee_graph import stop_events, evaluate, validate
from plant import model_for

HERE=Path(__file__).resolve().parent

def main():
    p=json.loads((HERE/'PROTOCOL.json').read_text());c=json.loads((HERE/'CALIBRATION.json').read_text())
    public={k:p[k] for k in ['dt_ns','horizon_ns','speed_threshold','reference_angle_rad','drive_torque','hold_ns','first_A_delay_ns','selective_B_delay_ns','relay_delay_ns']};public['models']=[c['A_models'],c['B_models']]
    packet=Packet(0,p['public_delivery_delay_ns'],(0.,0.),(0.,0.),(True,True))
    plans=[]
    for graph in list(p['graphs']):
        for arm in p['arms']:
            actor=GraphController(arm,public,p['graphs'][graph]);actor.install(p['public_delivery_delay_ns'],packet)
            plans.append({'graph':graph,'arm':arm,'plan_found':actor.plan is not None,'form':None if actor.plan is None else actor.plan['form'],'commands':None if actor.plan is None else actor.plan['commands']})
    assert all(not row['plan_found'] for row in plans if row['graph']=='S-infeasible-cycle' and row['arm']!='legacy_order_scheduler')
    # Initial stationary samples cannot be a stop; 20 points span only190ms.
    rows=[[i*10000000,0.,0.,0.,0.,0.,0.] for i in range(30)]
    assert stop_events(rows,p)==[None,None]
    moving=[[0,0.,1.,0.,1.,.06,.06]]
    low=[[i*10000000,2.,0.,2.,0.,0.,0.] for i in range(1,22)]
    assert stop_events(moving+low[:20],p)==[None,None]
    events=stop_events(moving+low,p)
    assert all(x['low_sample_count']==21 and x['confirmation_ns']==210000000 for x in events)
    # Confirm the inherited native implicit rotor matches the public parameter equation.
    m=model_for(p['private_A_setting'],p['private_B_setting']);d=mujoco.MjData(m);d.ctrl[:]=p['drive_torque'];mujoco.mj_forward(m,d)
    v=0.;decay=.002/(.002+.01*.006);maximum=0.
    for k in range(100):
        mujoco.mj_step(m,d);mujoco.mj_forward(m,d);v=10+(v-10)*decay;maximum=max(maximum,abs(float(d.qvel[0])-v))
    assert maximum<1e-12
    result={'schema':'task-graph-preflight-v1','status':'PASS_BOUNDED_PRE_RUN_CONTRACTS','plans':plans,'initial_rest_not_stop':True,'20_points_190ms_not_confirmed':True,'21_points_200ms_confirmed':True,'native_probe_steps':100,'native_probe_is_task_episode':False,'maximum_native_equation_error':maximum,'GPU':False,'new_weights':0}
    with (HERE/'PREFLIGHT.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k!='plans'}))
if __name__=='__main__':main()
