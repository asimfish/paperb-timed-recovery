"""Public-calibration finite dispatch search; no MuJoCo/true-model/fault inputs."""
from dataclasses import asdict
import math
from interfaces import Interval
from prediction import cross_for_model, verdict


def public_reference(packet, axis, model, spec):
    q = float(packet.positions[axis])
    v = float(packet.velocities[axis])
    dt = spec['dt_ns']
    decay = model['inertia'] / (model['inertia'] + dt / 1e9 * model['damping'])
    steady = spec['drive_torque'] / model['damping']
    for n in range(1, spec['horizon_ns'] // dt + 1):
        old = q
        v = steady + (v-steady) * decay
        q += v*dt/1e9
        if old < spec['reference_angle_rad'] <= q:
            return Interval(packet.capture_ns+(n-1)*dt, packet.capture_ns+n*dt)
    return None


def envelope(xs):
    return None if any(x is None for x in xs) else Interval(min(x.lo for x in xs), max(x.hi for x in xs))


def graph_eligible(graph, refs, effects, zeros, spec):
    if any(e is None for e in effects):
        return False
    for axis in range(2):
        if verdict(refs[axis], effects[axis], graph['windows_ns'][axis], True) != 'PREDICTED_ELIGIBLE':
            return False
    for before, after in graph['edges']:
        if effects[after].lo-effects[before].hi < graph['minimum_edge_gap_ns']:
            return False
    if graph['B_power_hold_lower_ns'] is not None:
        if zeros[1] < refs[1].hi+graph['B_power_hold_lower_ns']:
            return False
    return True


class GraphController:
    """Search graph-constrained models on the same first delivered packet.

    legacy_order_scheduler retains a prior A-before-B command form and only
    checks independent endpoint windows. It is a strong independent-window
    ablation, not a reproduction of earlier multi-episode history controls.
    """
    def __init__(self, arm, public_spec, graph):
        self.arm, self.spec, self.graph = arm, public_spec, graph
        self.plan = None
        self.plan_checked = False
        self.decisions = []
        self.sent = set()

    def install(self, now, packet):
        s=self.spec;dt=s['dt_ns'];stop=s['horizon_ns']
        refs=[envelope([public_reference(packet,i,m,s) for m in s['models'][i]]) for i in range(2)]
        if any(r is None for r in refs):
            self.decisions.append({'now_ns':now,'reason':'public_reference_unresolved'})
            return
        effects=[]
        eligible=[]
        for i in range(2):
            table={}
            for zero in range(now,stop+1,dt):
                table[zero]=envelope([cross_for_model(packet,i,zero,m,s) for m in s['models'][i]])
            effects.append(table)
            eligible.append([t for t,e in table.items() if verdict(refs[i],e,self.graph['windows_ns'][i],True)=='PREDICTED_ELIGIBLE'])
        guard=self.arm=='reference_guarded_graph_scheduler'
        graph_check=self.arm!='legacy_order_scheduler'
        selected=None;candidates=0
        def consider(zeros,commands,form):
            nonlocal selected,candidates
            e=[effects[i][zeros[i]] for i in range(2)]
            if graph_check and not graph_eligible(self.graph,refs,e,zeros,s):return
            if guard and any(zeros[i]<refs[i].hi for i in range(2)):return
            candidates+=1
            cost=(sum(x.hi for x in e),len(commands),tuple((x[0],x[1],x[2]) for x in commands),form)
            if selected is None or cost<selected[0]:
                selected=(cost,{'form':form,'commands':commands,'zero_times_ns':zeros,
                    'predicted_effects':[asdict(x) for x in e],'public_reference_envelope':[asdict(x) for x in refs]})
        # Actual selective bus is serial; global relay runs outside it.
        da=s['first_A_delay_ns'];db=s['selective_B_delay_ns'];dg=s['relay_delay_ns']
        for a in eligible[0]:
            if a-da<now:continue
            for b in eligible[1]:
                if b-db<now:continue
                if a<=b-db:
                    consider([a,b],[(a-da,'A','initial_A'),(b-db,'B','selective_B')],'selective_A_then_B')
                if graph_check and b<=a-da:
                    consider([a,b],[(b-db,'B','selective_B'),(a-da,'A','initial_A')],'selective_B_then_A')
        if graph_check:
            for g in set(eligible[0]).intersection(eligible[1]):
                if g-dg>=now:consider([g,g],[(g-dg,'global','relay')],'global_relay')
            for a in eligible[0]:
                if a-da<now:continue
                for g in eligible[1]:
                    if g>=a and g-dg>=now:
                        consider([a,g],[(a-da,'A','initial_A'),(g-dg,'global','relay')],'selective_A_then_global')
            for b in eligible[1]:
                if b-db<now:continue
                for g in eligible[0]:
                    if g>=b and g-dg>=now:
                        consider([g,b],[(b-db,'B','selective_B'),(g-dg,'global','relay')],'selective_B_then_global')
        self.plan=None if selected is None else selected[1]
        self.decisions.append({'now_ns':now,'consumed_packet':asdict(packet),'arm':self.arm,
            'graph':self.graph,'candidate_count':candidates,'selected_plan':self.plan,
            'planning_source':'public calibration set and delivered packet only',
            'private_fault_or_model_read':False})

    def requests(self, now, packet):
        if packet is None:return []
        if not self.plan_checked:
            self.plan_checked=True;self.install(now,packet)
        if self.plan is None:return []
        out=[]
        for i,(t,target,tag) in enumerate(self.plan['commands']):
            if i not in self.sent and t<=now:
                self.sent.add(i);out.append((target,tag))
        return out
