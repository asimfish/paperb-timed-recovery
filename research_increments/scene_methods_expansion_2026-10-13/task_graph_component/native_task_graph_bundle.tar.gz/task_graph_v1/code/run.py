"""Frozen finite native CPU execution; one episode is one 10-second trajectory."""
import argparse
import csv
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import shutil
import time
import mujoco
import numpy as np
from interfaces import Channel, Packet
from plant import model_for, apply
from controller import GraphController
from referee_graph import evaluate

HERE=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def csv_write(p,rows):
    with p.open('x',newline='') as f:
        w=csv.writer(f);w.writerow(['sim_ns','A_position','A_velocity','B_position','B_velocity','A_drive_next_interval','B_drive_next_interval','native_time_s','epoch_id']);w.writerows(rows)
def native_model(p):return model_for(p['private_A_setting'],p['private_B_setting'])
def initial(m,p):
    d=mujoco.MjData(m);d.qpos[:]=p['initial_state']['qpos'];d.qvel[:]=p['initial_state']['qvel'];d.ctrl[:]=p['drive_torque'];mujoco.mj_forward(m,d);return d
def state(now,d):
    q=d.qpos.copy();v=d.qvel.copy();u=d.ctrl.copy()
    native_ns=round(float(d.time)*1e9)
    if native_ns!=now:raise RuntimeError('Native MuJoCo time differs from registered grid')
    return [native_ns,float(q[0]),float(v[0]),float(q[1]),float(v[1]),float(u[0]),float(u[1]),float(d.time),0]
def fullpower(p):
    m=native_model(p);d=initial(m,p);rows=[]
    for k in range(p['horizon_ns']//p['dt_ns']+1):
        rows.append(state(k*p['dt_ns'],d))
        if k<p['horizon_ns']//p['dt_ns']:mujoco.mj_step(m,d);mujoco.mj_forward(m,d)
    return rows
def execute(out,p,calibration,case,arm,reference_rows):
    out.mkdir(exist_ok=False)
    m=native_model(p);d=initial(m,p)
    graph=p['graphs'][case['graph_id']]
    public={k:p[k] for k in ['dt_ns','horizon_ns','speed_threshold','reference_angle_rad','drive_torque','hold_ns','first_A_delay_ns','selective_B_delay_ns','relay_delay_ns']}
    public['models']=[calibration['A_models'],calibration['B_models']]
    controller=GraphController(arm,public,graph)
    channel=Channel({('A','initial_A'):p['first_A_delay_ns'],('B','selective_B'):p['selective_B_delay_ns'],('global','relay'):p['relay_delay_ns']})
    pending=[];latest=None;applied=set();bus_latched=False;rows=[];deliveries=[];private_effects=[];inputs=[]
    start=time.monotonic_ns()
    for tick in range(p['horizon_ns']//p['dt_ns']+1):
        now=tick*p['dt_ns']
        packet=Packet(now,now+p['public_delivery_delay_ns'],tuple(d.qpos.copy().tolist()),tuple(d.qvel.copy().tolist()),tuple(bool(x) for x in d.ctrl.copy()))
        pending.append(packet)
        while pending and pending[0].arrival_ns<=now:
            latest=pending.pop(0);deliveries.append(asdict(latest))
        for r in channel.reservations:
            if r.ack_ns<=now and r.seq not in applied:
                applied.add(r.seq);success,bus_latched=apply(d,r,'none',bus_latched)
                private_effects.append({'seq':r.seq,'scheduled_ack_ns':r.ack_ns,'actual_apply_ns':now,'applied_to_plant':success,'bus_latched':bus_latched})
        inputs.append({'consumer_now_ns':now,'latest_capture_ns':None if latest is None else latest.capture_ns,'latest_arrival_ns':None if latest is None else latest.arrival_ns})
        for target,tag in controller.requests(now,latest):channel.submit(now,target,tag)
        rows.append(state(now,d))
        if tick<p['horizon_ns']//p['dt_ns']:mujoco.mj_step(m,d);mujoco.mj_forward(m,d)
    csv_write(out/'independent_samples.csv',rows)
    verdict=evaluate(rows,reference_rows,graph,p)
    write(out/'contract.json',{'case':case,'graph':graph,'public_spec':public,'initial_epoch':'one native epoch at 0 ns','arm':arm})
    write(out/'commands.json',[asdict(r) for r in channel.reservations])
    write(out/'private_plant_effects.json',private_effects)
    write(out/'public_deliveries.json',deliveries)
    write(out/'public_actor_inputs.json',inputs)
    write(out/'public_decisions.json',controller.decisions)
    write(out/'independent_verdict.json',verdict)
    write(out/'model_runtime.json',{'mujoco':mujoco.__version__,'numpy':np.__version__,'mjcf_sha256':digest(HERE/'shared_bus.xml'),'dt_s':m.opt.timestep,'nq':m.nq,'nv':m.nv,'nu':m.nu,'contacts_enabled':False,'initial_state':p['initial_state']})
    summary={'episode_id':out.name,'case_id':case['id'],'graph_id':case['graph_id'],'role':case['role'],'arm':arm,'samples':len(rows),'commands':len(channel.reservations),'joint_original_contract':verdict['joint_original_contract'],'host_elapsed_ns':time.monotonic_ns()-start,'host_work_advances_plant':False,'neural_training_runs':0,'chemical_or_lab_robot_credit':0}
    write(out/'summary.json',summary)
    return summary
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    release=json.loads((HERE/'EXECUTION_RELEASE.json').read_text())
    assert release['status']=='FROZEN_BEFORE_NATIVE_EXECUTION'
    assert all(digest(HERE/n)==h for n,h in release['files'].items())
    p=json.loads((HERE/'PROTOCOL.json').read_text());c=json.loads((HERE/'CALIBRATION.json').read_text())
    args.out.mkdir(exist_ok=False)
    (args.out/'source_snapshot').mkdir()
    for n in release['files']:shutil.copy2(HERE/n,args.out/'source_snapshot'/n)
    write(args.out/'execution_release_snapshot.json',release)
    reference=fullpower(p);csv_write(args.out/'original_fullpower_reference.csv',reference)
    slots=[]
    for case in p['main_cases']:
        for arm in p['arms']:
            slots.append(execute(args.out/(case['id']+'--'+arm),p,c,case,arm,reference))
            print(json.dumps(slots[-1]),flush=True)
    for case in p['sentinel_cases']:
        slots.append(execute(args.out/(case['id']+'--'+case['arm']),p,c,case,case['arm'],reference));print(json.dumps(slots[-1]),flush=True)
    write(args.out/'results.json',{'schema':'task-graph-native-results-v1','slots':slots,'main_rollouts':12,'sentinel_rollouts':2,'controlled_native_samples':sum(s['samples'] for s in slots),'reference_oracle_integrations':1,'reference_oracle_samples':len(reference),'independent_main_contract_instances':4,'confirmatory':False,'weights':0,'RGB':0,'chemistry_or_A_B_C_robot':0})
if __name__=='__main__':main()
