"""Raw-state interval referee. No controller flags, predictions, or plan labels."""
import csv
import math


def conjunction(values):
    if 'FALSE' in values:return 'FALSE'
    return 'TRUE' if all(v=='TRUE' for v in values) else 'UNKNOWN'


def read_rows(path):
    with open(path) as f:
        return [[int(r['sim_ns']),float(r['A_position']),float(r['A_velocity']),float(r['B_position']),
                 float(r['B_velocity']),float(r['A_drive_next_interval']),float(r['B_drive_next_interval'])]
                for r in csv.DictReader(f)]


def validate(rows,spec):
    expected=spec['horizon_ns']//spec['dt_ns']+1
    if len(rows)!=expected or rows[0][0]!=0 or rows[-1][0]!=spec['horizon_ns']:
        raise ValueError('complete one-epoch native grid required')
    if any(r[0]!=i*spec['dt_ns'] or not all(math.isfinite(v) for v in r[1:]) for i,r in enumerate(rows)):
        raise ValueError('nonfinite values or grid gap')


def angle_references(rows,spec):
    out=[]
    for i in range(2):
        found=None
        for n in range(1,len(rows)):
            if rows[n-1][1+2*i]<spec['reference_angle_rad']<=rows[n][1+2*i]:
                found=[rows[n-1][0],rows[n][0]];break
        out.append(found)
    return out


def stop_events(rows,spec):
    events=[]
    for i in range(2):
        moving=False;pending=None;event=None
        for n,row in enumerate(rows):
            low=abs(row[2+2*i])<=spec['speed_threshold']
            if not low:
                moving=True;pending=None
            elif moving:
                if pending is None:
                    pending=(n,[rows[n-1][0],row[0]])
                if row[0]-rows[pending[0]][0]>=spec['hold_ns']:
                    event={'occurrence_interval_ns':pending[1],'confirmation_ns':row[0],
                           'low_sample_count':n-pending[0]+1,'had_prior_moving_sample':True};break
        events.append(event)
    return events


def timing(ref,event,window,end,hold):
    if ref is None:return 'UNKNOWN'
    if event is None:return 'FALSE' if end>ref[1]+window[1]+hold else 'UNKNOWN'
    e=event['occurrence_interval_ns'];lo=e[0]-ref[1];hi=e[1]-ref[0]
    if window[0]<=lo and hi<=window[1]:return 'TRUE'
    if hi<window[0] or lo>window[1]:return 'FALSE'
    return 'UNKNOWN'


def evaluate(rows,original_rows,graph,spec):
    validate(rows,spec);validate(original_rows,spec)
    refs=angle_references(original_rows,spec);current_refs=angle_references(rows,spec);stops=stop_events(rows,spec)
    values={}
    for i,name in enumerate(['A','B']):
        values[name+'_time']=timing(refs[i],stops[i],graph['windows_ns'][i],rows[-1][0],spec['hold_ns'])
        # No actual original anchor -> FALSE, not a newly reset clock.
        values[name+'_original_reference']='TRUE' if refs[i] is not None and current_refs[i]==refs[i] else 'FALSE'
    edge_values=[]
    for before,after in graph['edges']:
        if stops[before] is None or stops[after] is None:edge_values.append('FALSE');continue
        a=stops[before]['occurrence_interval_ns'];b=stops[after]['occurrence_interval_ns'];gap=graph['minimum_edge_gap_ns']
        edge_values.append('TRUE' if b[0]-a[1]>=gap else 'FALSE' if b[1]-a[0]<gap else 'UNKNOWN')
    values['graph_dependencies']=conjunction(edge_values)
    maintenance='TRUE';witness=None;unknown=False
    hold=graph['B_power_hold_lower_ns']
    if hold is not None:
        ref=refs[1]
        if ref is None:maintenance='UNKNOWN'
        else:
            lower=ref[0]+hold;upper=ref[1]+hold
            for row in rows:
                if ref[1]<row[0]<upper:
                    violated=abs(row[4])<=spec['speed_threshold'] or row[6]!=spec['drive_torque']
                    if violated and row[0]<lower:maintenance='FALSE';witness=row[0];break
                    if violated:unknown=True
            if maintenance!='FALSE':maintenance='UNKNOWN' if unknown or rows[-1][0]<upper else 'TRUE'
    values['B_sampled_power_and_motion_maintenance']=maintenance
    return {'original_references':refs,'actual_references':current_refs,'stop_events':stops,
            **values,'joint_original_contract':conjunction(list(values.values())),
            'maintenance_failure_witness_ns':witness,'sampled_not_continuous':True,
            'chemical_certified':0,'robot_task_certified':0}
