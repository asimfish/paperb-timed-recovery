"""Independent command/state reintegration plus raw-only contract recomputation."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import mujoco
from plant import model_for
from referee_graph import read_rows, evaluate, validate

HERE=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def integrate(p,commands):
    m=model_for(p['private_A_setting'],p['private_B_setting']);d=mujoco.MjData(m)
    d.qpos[:]=p['initial_state']['qpos'];d.qvel[:]=p['initial_state']['qvel'];d.ctrl[:]=p['drive_torque'];mujoco.mj_forward(m,d)
    applied=set();rows=[]
    for k in range(p['horizon_ns']//p['dt_ns']+1):
        now=round(float(d.time)*1e9);assert now==k*p['dt_ns']
        for command in commands:
            if command['ack_ns']<=now and command['seq'] not in applied:
                applied.add(command['seq'])
                if command['target']=='global':d.ctrl[:]=0
                else:d.ctrl[0 if command['target']=='A' else 1]=0
        rows.append([now,float(d.qpos[0]),float(d.qvel[0]),float(d.qpos[1]),float(d.qvel[1]),float(d.ctrl[0]),float(d.ctrl[1])])
        if k<p['horizon_ns']//p['dt_ns']:mujoco.mj_step(m,d);mujoco.mj_forward(m,d)
    return rows,applied
def verify_channel(commands,p):
    free=0;previous_request=-1
    services={('A','initial_A'):p['first_A_delay_ns'],('B','selective_B'):p['selective_B_delay_ns'],('global','relay'):p['relay_delay_ns']}
    for seq,c in enumerate(commands):
        assert c['seq']==seq and c['request_ns']>=previous_request
        assert c['request_ns']%p['dt_ns']==0
        previous_request=c['request_ns'];start=c['request_ns'] if c['target']=='global' else max(c['request_ns'],free)
        assert c['service_start_ns']==start and c['ack_ns']==start+services[c['target'],c['tag']]
        if c['target']!='global':free=c['ack_ns']
def compare(a,b):
    assert len(a)==len(b)
    assert all(x[0]==y[0] for x,y in zip(a,b))
    return max(abs(x[i]-y[i]) for x,y in zip(a,b) for i in range(1,7))
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    release=load(HERE/'EXECUTION_RELEASE.json');assert all(digest(HERE/n)==h for n,h in release['files'].items())
    p=load(HERE/'PROTOCOL.json');results=load(args.out/'results.json');reference,unused=integrate(p,[])
    assert compare(read_rows(args.out/'original_fullpower_reference.csv'),reference)==0
    expected=[(x['id'],a) for x in p['main_cases'] for a in p['arms']]+[(x['id'],x['arm']) for x in p['sentinel_cases']]
    assert [(x['case_id'],x['arm']) for x in results['slots']]==expected
    checks=[]
    for slot in results['slots']:
        root=args.out/slot['episode_id'];commands=load(root/'commands.json');verify_channel(commands,p)
        reconstructed,applied=integrate(p,commands);measured=read_rows(root/'independent_samples.csv');validate(measured,p)
        maximum=compare(measured,reconstructed);assert maximum==0
        v=evaluate(measured,reference,p['graphs'][slot['graph_id']],p)
        assert v==load(root/'independent_verdict.json') and v['joint_original_contract']==slot['joint_original_contract']
        private=load(root/'private_plant_effects.json');assert {x['seq'] for x in private}==applied
        assert all(x['actual_apply_ns']==x['scheduled_ack_ns'] and x['applied_to_plant'] for x in private)
        deliveries=load(root/'public_deliveries.json');assert all(x['arrival_ns']==x['capture_ns']+p['public_delivery_delay_ns'] for x in deliveries)
        for x in deliveries:
            k=x['capture_ns']//p['dt_ns'];row=measured[k]
            assert x['positions']==[row[1],row[3]] and x['velocities']==[row[2],row[4]]
            prior_drive=[p['drive_torque'],p['drive_torque']] if k==0 else [measured[k-1][5],measured[k-1][6]]
            assert x['powered']==[bool(u) for u in prior_drive]
        for x in load(root/'public_actor_inputs.json'):
            assert x['latest_arrival_ns'] is None or x['latest_arrival_ns']<=x['consumer_now_ns']
        with (root/'independent_samples.csv').open() as f:
            assert all(round(float(x['native_time_s'])*1e9)==int(x['sim_ns']) and int(x['epoch_id'])==0 for x in csv.DictReader(f))
        checks.append({'episode_id':slot['episode_id'],'raw_native_reintegration_error':maximum,'raw_verdict_equal':True,'channel_valid':True,'public_delivery_boundary_valid':True,'raw_artifacts':{q.name:digest(q) for q in sorted(root.iterdir()) if q.is_file()}})
    main_slots=[s for s in results['slots'] if s['role']=='main_component'];sent=[s for s in results['slots'] if s['role']!='main_component']
    assert len(main_slots)==12 and len(sent)==2
    assert next(x for x in sent if x['role']=='feasible_witness_native')['joint_original_contract']=='TRUE'
    assert next(x for x in sent if x['role']=='infeasible_native_refusal')['commands']==0
    report={'schema':'task-graph-independent-native-audit-v1','status':'PASS_COMPONENT_NATIVE_REPLAY','main_rollouts':12,'sentinel_rollouts':2,'controlled_native_samples':14014,'reference_oracle_integrations':1,'reference_oracle_samples':1001,'preflight_native_steps':100,'main_by_arm':{a:{v:sum(s['joint_original_contract']==v for s in main_slots if s['arm']==a) for v in ['TRUE','FALSE','UNKNOWN']} for a in p['arms']},'sentinels':sent,'checks':checks,'physics_or_source_errors':0,'new_weights':0,'original_A_B_C_robot_or_chemistry_credit':0,'results_sha256':digest(args.out/'results.json'),'original_reference_sha256':digest(args.out/'original_fullpower_reference.csv')}
    with (args.out/'AUDIT.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['checks','sentinels']}))
if __name__=='__main__':main()
