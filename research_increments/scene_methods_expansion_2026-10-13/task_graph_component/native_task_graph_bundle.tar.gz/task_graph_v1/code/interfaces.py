"""Public controller values contain no true response or hidden fault identity."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Interval:
    lo: int
    hi: int

    def __post_init__(self):
        if type(self.lo) is not int or type(self.hi) is not int or not 0 <= self.lo <= self.hi:
            raise ValueError('nonnegative ordered integer nanoseconds required')


@dataclass(frozen=True)
class Packet:
    capture_ns: int
    arrival_ns: int
    positions: tuple
    velocities: tuple
    powered: tuple

    def __post_init__(self):
        Interval(self.capture_ns, self.arrival_ns)
        if any(len(x) != 2 for x in [self.positions, self.velocities, self.powered]):
            raise ValueError('two process readings required')


@dataclass(frozen=True)
class Reservation:
    seq: int
    target: str
    tag: str
    request_ns: int
    service_start_ns: int
    ack_ns: int


class Channel:
    """Fixed public service schedule; plant effects and faults are elsewhere."""
    def __init__(self, services):
        self.services = services
        self.reservations = []
        self.free_at_ns = 0

    def submit(self, now, target, tag):
        Interval(now, now)
        if (target, tag) not in self.services:
            raise ValueError('unsupported action interface')
        start = now if target == 'global' else max(now, self.free_at_ns)
        end = start + self.services[target, tag]
        r = Reservation(len(self.reservations), target, tag, now, start, end)
        self.reservations.append(r)
        if target != 'global':
            self.free_at_ns = end
        return r


class Observer:
    def __init__(self, hold_ns, threshold):
        self.hold_ns, self.threshold = hold_ns, threshold
        self.latest = self.previous = None
        self.references = [None, None]
        self.pending_low = [None, None]
        self.effects = [None, None]

    def deliver(self, packet, now):
        if packet.arrival_ns > now:
            raise ValueError('future packet cannot enter controller history')
        if self.latest is not None and packet.capture_ns <= self.latest.capture_ns:
            raise ValueError('capture sequence must advance')
        previous = self.latest
        for i in range(2):
            if previous is not None and self.references[i] is None and previous.positions[i] < 2 <= packet.positions[i]:
                self.references[i] = Interval(previous.capture_ns, packet.capture_ns)
            if self.references[i] is not None and self.effects[i] is None:
                if packet.velocities[i] <= self.threshold:
                    if self.pending_low[i] is None:
                        self.pending_low[i] = (Interval(previous.capture_ns, packet.capture_ns), packet.capture_ns)
                    if packet.capture_ns - self.pending_low[i][1] >= self.hold_ns:
                        self.effects[i] = self.pending_low[i][0]
                else:
                    self.pending_low[i] = None
        self.previous, self.latest = previous, packet
