"""Four public stateful controllers. No private plant/referee/getter imports."""
from dataclasses import asdict
import time
from typing import Protocol
from controller_contract import Contract,PublicFrame,plain
from initial_public_math import Budget
from request_ledger import RequestLedger
from temporal_facts import PublicFacts
from schedule_model import initial_candidates,remaining_candidates

METHODS=('strong_batch','guarded_hsm_retry','event_resource_edf','joint_interval_mpc')


class StatefulActor(Protocol):
    def advance(self,frame):...
    def snapshot(self):...


class PublicController:
    method=None
    def __init__(self,contract,strategy_config=None):
        if type(contract) is not Contract or type(contract.public_json) is not str or type(contract.resource_json) is not str:
            raise TypeError('validated exact public contract, never wrapper/getter')
        if len(contract.public_json)+len(contract.resource_json)>65536:raise ValueError('bounded canonical contract text')
        rebuilt=Contract.create(contract.epoch,contract.public,contract.resource,contract.dt_ns,contract.sensor_period_ns,contract.sensor_lag_ns)
        if contract!=rebuilt:raise ValueError('noncanonical or invalid direct contract construction')
        self.strategy_config=dict(mpc_min_replan_interval_ns=100_000_000)
        if strategy_config is not None:
            if type(strategy_config) is not dict or set(strategy_config)!={'mpc_min_replan_interval_ns'}:raise ValueError('known public strategy config only')
            plain(strategy_config);self.strategy_config.update(strategy_config)
        interval=self.strategy_config['mpc_min_replan_interval_ns']
        if type(interval) is not int or interval<contract.charged_decision_ns or interval%(2*contract.dt_ns):raise ValueError('replan cadence must respect common paid decision grid')
        self.contract=contract;self.ledger=RequestLedger(contract);self.facts=PublicFacts(contract)
        p=contract.public;self.budget=Budget(p['maximum_candidates_per_decision'],p['maximum_candidates_epoch'])
        self.phase='WAIT_ANCHOR';self.transactions=[];self.pending=None;self.initial_committed=False
        self.last_decision_ns=-10**18;self.last_signature=None;self.last_resource_signature=None
        self.needs_after_stale=False;self.decisions=[];self.saved_full_plan=None
        self.protocol_failure=None

    def signature(self):
        power=tuple(sorted((t,x['mode'],x['ACK_seq']) for t,x in self.facts.power_evidence.items()))
        resource=tuple(sorted((r.seq,r.target,r.request_ns,r.service_start_ns,r.ack_ns) for r in self.ledger.reservations.values()))
        events=tuple(sorted((t,tuple(x['bounds_ns'])) for t,x in self.facts.stops.items()))
        return resource,power,events

    def actions_still_needed(self):
        p=self.facts.latest
        if p is None:return False
        A_needed='A' not in self.facts.stops and p.torques[0]>0 and self.ledger.counts['A']<2
        C_needed='C' not in self.facts.stops and p.torques[2]>0 and self.ledger.counts['C']<1
        return A_needed or C_needed

    def should_decide(self,frame):raise NotImplementedError

    def choose(self,plans,frame):raise NotImplementedError

    def make_plan(self,frame):
        if not self.initial_committed:return initial_candidates(self.contract,frame,self.facts,self.ledger,self.budget)
        return remaining_candidates(self.contract,frame,self.facts,self.ledger,self.budget)

    def prefix_only(self):return False

    def advance(self,frame):
        """Called on public ticks. Returns legal selective command requests only.

        Observation/ledger transport is shared bookkeeping. Every strategy
        decision is logged and charged2 ticks; its replacement commits only at
        ready_ns. Previously committed intentions can dispatch in that span.
        """
        if self.protocol_failure is not None:raise ValueError('sticky public protocol failure: no further action emission in this epoch')
        if type(frame) is not PublicFrame:
            self.protocol_failure={'type':'TypeError','reason':'NONPLAIN_FRAME_REJECTED_BEFORE_CALLBACK'}
            raise TypeError('exact public data frame required before callbacks or getters')
        try:
            frame.validate(self.contract);self.ledger.ingest(frame);self.facts.observe(frame,self.ledger)
        except Exception as e:
            self.protocol_failure={'type':type(e).__name__,'reason':str(e)}
            raise
        now=frame.now_ns
        if self.pending is not None and now>=self.pending['ready_ns']:
            transaction=self.pending;self.pending=None
            unchanged=transaction['issued_tokens_before']==tuple(self.ledger.emitted) and transaction['resource_before']==self.signature()[0]
            if not unchanged:
                self.transactions.append({'event':'STALE_PAID_TRANSACTION_DISCARDED_ISSUED_REQUESTS_AND_CURRENT_CALENDAR_PRESERVED','created_ns':transaction['created_ns'],'ready_ns':transaction['ready_ns']})
                self.needs_after_stale=True
            elif transaction['plan'] is not None:
                self.ledger.install(transaction['plan']['actions'],now,replace=True,prefix_only=self.prefix_only(),mode=transaction['mode'])
                self.saved_full_plan=transaction['plan'];self.initial_committed=True;self.phase=transaction['commit_phase']
                self.transactions.append({'event':'PAID_PROGRAM_COMMITTED','created_ns':transaction['created_ns'],'ready_ns':now,'prefix_only':self.prefix_only(),'method':self.method})
            else:
                # A failed bounded search does not revoke the safe previous
                # committed program or become an all-policy impossibility.
                self.transactions.append({'event':'BOUNDED_SEARCH_NO_REPLACEMENT_PRIOR_PROGRAM_RETAINED','created_ns':transaction['created_ns'],'ready_ns':now})
        verdict=self.facts.verdict()
        if verdict['status']=='PASS_CONDITIONAL_PUBLIC_SAMPLED_PROTOCOL':self.phase='DONE_PUBLIC_CONDITIONAL'
        if self.phase=='DONE_PUBLIC_CONDITIONAL':return []
        if now%(2*self.contract.dt_ns)==0 and self.pending is None and self.facts.reference is not None and self.should_decide(frame):
            self._paid_decision(frame)
        emitted=self.ledger.emit_due(now)
        if any(i.status=='BLOCKED_UNSENT' for i in self.ledger.intents.values()):self.needs_after_stale=True
        return emitted

    def _paid_decision(self,frame):
        self.budget.begin();started=time.perf_counter_ns();plans,account=self.make_plan(frame);chosen=self.choose(plans,frame) if plans else None
        mode='feedback_retry' if chosen and chosen.get('feedback_retry_slot') else 'blind'
        ready=frame.now_ns+self.contract.charged_decision_ns
        self.pending={'created_ns':frame.now_ns,'ready_ns':ready,'issued_tokens_before':tuple(self.ledger.emitted),'resource_before':self.signature()[0],
            'plan':chosen,'mode':mode,'commit_phase':self.commit_phase(chosen)}
        self.decisions.append({'method':self.method,'created_ns':frame.now_ns,'ready_ns':ready,'charged_decision_ns':self.contract.charged_decision_ns,
            'measured_host_compute_ns':time.perf_counter_ns()-started,'budget':account,'selected_plan':chosen,
            'original_B':asdict(self.facts.original_B),'reference':asdict(self.facts.reference),'ledger_before':self.ledger.snapshot(),
            'public_power_evidence':dict(self.facts.power_evidence),'private_fault_read':False,'new_native_episode':False})
        self.last_decision_ns=frame.now_ns;self.last_signature=self.signature();self.needs_after_stale=False

    def commit_phase(self,plan):return 'EXECUTE_AND_VERIFY'

    def snapshot(self):
        return {'method':self.method,'phase':self.phase,'ledger':self.ledger.snapshot(),'facts':self.facts.snapshot(),
            'decisions':self.decisions,'transactions':self.transactions,'candidate_budget_epoch':self.budget.epoch,
            'charged_decision_time_ns':len(self.decisions)*self.contract.charged_decision_ns,'native_referee_score_read':False,'protocol_failure':self.protocol_failure}


class BatchController(PublicController):
    method='strong_batch'
    def should_decide(self,frame):return not self.initial_committed and (not self.decisions or self.needs_after_stale)
    def choose(self,plans,frame):return min(plans,key=lambda p:(p['C_midpoint_error_twice_ns'],max(a['ACK_ns'] for a in p['actions'])))
    def commit_phase(self,plan):return 'IMMUTABLE_STRONG_BATCH_PROGRAM'


class HSMController(PublicController):
    method='guarded_hsm_retry'
    def make_plan(self,frame):
        if not self.initial_committed:
            return initial_candidates(self.contract,frame,self.facts,self.ledger,self.budget,adaptive=True)
        evidence=self.facts.power_evidence.get('A');queued=self.ledger.unsent()
        if evidence and evidence['mode']=='POWER_OFF_AFTER_SERVICE_NOT_TASK_SUCCESS':
            # Recompile remaining C with A's physically observed power-off
            # model. This removes only an unissued redundant retry.
            return remaining_candidates(self.contract,frame,self.facts,self.ledger,self.budget)
        # Recovery is causally enabled, but predeclared safe retry times and
        # blind fallback remain valid; a fresh power observation is not a
        # hidden fault bit and does not spend a third A request.
        if evidence and evidence['mode']=='POWERED_AFTER_SERVICE' and any(i.mode=='feedback_retry' for i in queued):
            self.phase='RECOVER_PUBLIC_POWERED_AFTER_SERVICE'
            return remaining_candidates(self.contract,frame,self.facts,self.ledger,self.budget)
        return [],{'status':'VERIFY_WITH_NO_NEW_RECOVERY_ACTION','candidate_evaluations':self.budget.current,'cumulative_candidate_evaluations':self.budget.epoch}
    def should_decide(self,frame):
        if not self.initial_committed:return not self.decisions or self.needs_after_stale
        if not self.ledger.unsent():return False
        return self.needs_after_stale or (self.signature()!=self.last_signature and 'A' in self.facts.power_evidence)
    def choose(self,plans,frame):
        return min(plans,key=lambda p:(min([a['ACK_ns'] for a in p['actions']]+[10**30]),p['C_midpoint_error_twice_ns']))
    def commit_phase(self,plan):return 'EXECUTE_GUARDED_FEEDBACK_RETRY' if plan and plan.get('feedback_retry_slot') else 'EXECUTE_STRONG_BLIND_FALLBACK_OR_REMAINING'


class EDFController(PublicController):
    method='event_resource_edf'
    def should_decide(self,frame):
        if not self.initial_committed:return not self.decisions or self.needs_after_stale
        return self.actions_still_needed() and (self.needs_after_stale or self.signature()!=self.last_signature)
    def choose(self,plans,frame):
        p=self.contract.public;ref=self.facts.reference
        deadline={'A':ref.lower_ns+p['A_window_ns'][1],'C':ref.lower_ns+p['D_C_ns']+p['eps_C_ns']}
        for x,y in p['graph_edges']:deadline[x]=min(deadline[x],deadline[y]-p['minimum_edge_gap_ns'])
        def key(plan):
            order=sorted(plan['actions'],key=lambda a:(deadline[a['target']],a['submit_ns']))
            return tuple((deadline[a['target']],a['ACK_ns']) for a in order),plan['C_midpoint_error_twice_ns']
        return min(plans,key=key)
    def commit_phase(self,plan):return 'EVENT_RESOURCE_REPLAN_UNSENT_ONLY'


class IntervalMPCController(PublicController):
    method='joint_interval_mpc'
    def prefix_only(self):return True
    def should_decide(self,frame):
        if not self.initial_committed:return not self.decisions or self.needs_after_stale
        if not self.actions_still_needed():return False
        trigger=self.needs_after_stale or self.signature()!=self.last_signature
        rolling=frame.now_ns-self.last_decision_ns>=self.strategy_config['mpc_min_replan_interval_ns'] and self.facts.latest is not None
        return trigger or rolling or not self.ledger.unsent()
    def choose(self,plans,frame):
        # Same remaining action/branch set and budget as EDF, but a joint
        # interval objective and one committed prefix instead of full program.
        return min(plans,key=lambda p:(p['C_midpoint_error_twice_ns'],len(p['actions']),max([a['ACK_ns'] for a in p['actions']]+[0])))
    def commit_phase(self,plan):return 'RECEDING_JOINT_INTERVAL_PREFIX'


REGISTRY={c.method:c for c in (BatchController,HSMController,EDFController,IntervalMPCController)}


def make_controller(method,contract,strategy_config=None):
    if method not in REGISTRY:raise ValueError('unknown controller method')
    return REGISTRY[method](contract,strategy_config)
