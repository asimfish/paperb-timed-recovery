"""Pure public decision prototypes, NOT four formal native controller arms.

Same packets, ACKs, calendar, contract and prior for every method. No plant,
private case, referee, native getter, file/IO access or oracle mode is imported.
Stateful dispatch/cancellation and referee integration remain separate gates.
"""
from dataclasses import dataclass,asdict
import math
import time
from public_types import Packet,Ack,Reservation,ObservedEvent,ReservedChannel

METHODS=('sameinfo_calibrated_batch_joint','sameinfo_robust_hsm',
         'sameinfo_edf_event_replanner','sameinfo_joint_interval_mpc')


@dataclass(frozen=True)
class PublicContext:
    now_ns:int
    latest:Packet
    original_B_coarse:ObservedEvent
    reference:ObservedEvent
    acks:tuple
    reservations:tuple
    public:dict
    resource:dict
    dt_ns:int=10_000_000
    charged_decision_ns:int=20_000_000

    def __post_init__(self):
        if type(self.public) is not dict or type(self.resource) is not dict:
            raise TypeError('plain public maps only, no native model wrapper/getter')
        allowed_public={'D_C_ns','eps_C_ns','A_window_ns','graph_edges','minimum_edge_gap_ns','public_nominal_model',
            'maximum_candidates_per_decision','maximum_candidates_epoch','max_requests_A_C','max_requests_per_rotor',
            'calibrated_prediction_residual_ns','original_B_angle','moving_threshold','stop_hold_ns',
            'B_maintenance_ns','model_scope','initial_torque','public_fault_support'}
        if set(self.public)-allowed_public or set(self.resource)-{'capacity','services_ns','B_reservation'}:
            raise ValueError('unknown/private producer fields are not part of public actor ABI')
        if type(self.latest) is not Packet or type(self.original_B_coarse) is not ObservedEvent or type(self.reference) is not ObservedEvent:
            raise TypeError('exact public data-only DTOs required')
        if self.latest.arrival_ns>self.now_ns or self.dt_ns<=0 or self.charged_decision_ns!=2*self.dt_ns:
            raise ValueError('causal public packet and common2-tick charge required')
        if any(type(x) is not Ack or x.ack_ns>self.now_ns for x in self.acks):raise ValueError('public past ACK DTO required')
        if any(type(x) is not Reservation for x in self.reservations):raise TypeError('public reservation DTO required')
        model=self.public['public_nominal_model']
        if type(model) is not dict or set(model)!= {'inertia','damping'} or any(type(model[k]) not in (int,float) or not math.isfinite(model[k]) or model[k]<=0 for k in model):
            raise ValueError('public scalar prior only, no hidden model/getter')
        forbidden={'private_plant','private_parameters','current_fault','true_inertia','referee','NativePlant','getter','oracle'}
        if forbidden.intersection(self.public) or forbidden.intersection(self.resource):raise ValueError('private field forbidden')
        if not (self.original_B_coarse.lower_ns<=self.reference.lower_ns<=self.reference.upper_ns<=self.original_B_coarse.upper_ns):
            raise ValueError('only refinement of immutable original event, never reanchoring')
        if self.reference.kind not in ('B_PUBLIC_OBSERVED_FIRST_Q2','B_SAME_EVENT_CONDITIONAL_PUBLIC_MODEL'):
            raise ValueError('private RAW event or unsupported anchor kind is forbidden')
        if self.reference.first_arrival_ns>self.now_ns:raise ValueError('future event information')
        if self.resource['capacity']!=1:raise ValueError('prototype nonpreemptive one-server scope')
        if type(self.resource['services_ns']) is not dict or type(self.resource['B_reservation']) is not dict:
            raise TypeError('public resource fields must be plain data, never callable getters')
        if set(self.resource['services_ns'])!={'A_stop','C_stop'} or any(type(x) is not int or x<=0 for x in self.resource['services_ns'].values()):
            raise ValueError('declared positive public service durations required')
        if any(type(vector) is not tuple or any(type(x) not in (int,float) or not math.isfinite(x) for x in vector)
               for vector in (self.latest.positions,self.latest.velocities,self.latest.torques)):
            raise ValueError('finite public packet required')


class Budget:
    def __init__(self,per_decision=1000,per_epoch=10000):
        self.per_decision,self.per_epoch=per_decision,per_epoch;self.epoch=0;self.current=0
    def begin(self):self.current=0
    def consume(self):
        if self.current>=self.per_decision or self.epoch>=self.per_epoch:return False
        self.current+=1;self.epoch+=1;return True


def conditional_original_event(old,new,coarse,model,dt,tolerance=1e-9):
    """Same-event model refinement from two legal public packets only."""
    if type(old) is not Packet or type(new) is not Packet:raise TypeError('public packet only')
    if old.capture_ns!=coarse.lower_ns or new.capture_ns!=coarse.upper_ns:
        raise ValueError('model interpolation must cover original coarse bracket')
    q,v=old.positions[1],old.velocities[1];steady=old.torques[1]/model['damping']
    decay=model['inertia']/(model['inertia']+dt/1e9*model['damping']);cross=None
    trace=[]
    for t in range(old.capture_ns+dt,new.capture_ns+dt,dt):
        prev=q;v=steady+(v-steady)*decay;q+=v*dt/1e9;trace.append([t,q,v])
        if cross is None and prev<2.<=q:cross=[t-dt,t]
    residual=[abs(q-new.positions[1]),abs(v-new.velocities[1])]
    compatible=old.torques[1]==new.torques[1] and max(residual)<=tolerance
    refined=ObservedEvent(*cross,new.arrival_ns,'B_SAME_EVENT_CONDITIONAL_PUBLIC_MODEL') if compatible and cross else coarse
    return refined,dict(coarse_identity_preserved=asdict(coarse),reference=asdict(refined),public_model=model,
        source_packets=[asdict(old),asdict(new)],forward_trace=trace,residual=residual,tolerance=tolerance,
        conditional_on_public_model=True,model_fitted=False,not_information_theoretic_lower_bound=True)


def powered_after_ACK(ctx,target):
    axis={'A':0,'C':2}[target];past=[a for a in ctx.acks if a.target==target]
    if not past:return False
    latest=max(past,key=lambda x:x.ack_ns)
    # Capture is pre-ACK at the same tick, so same-tick positive torque cannot
    # diagnose a drop. This is physical power observation, not ACK success.
    return ctx.latest.capture_ns>=latest.ack_ns+ctx.dt_ns and ctx.latest.torques[axis]>0


def ceilgrid(t,dt):return ((t+dt-1)//dt)*dt


def stop_box(packet,axis,ack,model,dt,error=(0,0)):
    damping=model['damping'];decay=model['inertia']/(model['inertia']+dt/1e9*damping)
    v=packet.velocities[axis];steady=packet.torques[axis]/damping
    v=steady+(v-steady)*decay**max(0,(ack-packet.capture_ns)//dt)
    if v<=.1:return [ack+error[0],ack+error[1]]
    k=max(1,math.ceil(math.log(.1/v)/math.log(decay)))
    while v*decay**k>.1:k+=1
    while k>1 and v*decay**(k-1)<=.1:k-=1
    return [ack+(k-1)*dt+error[0],ack+k*dt+error[1]]


def envelope(boxes):return [min(b[0] for b in boxes),max(b[1] for b in boxes)]


def fits(ref,box,window):return box[0]-ref.upper_ns>=window[0] and box[1]-ref.lower_ns<=window[1]


def request_ACK(ack,target,earliest,ctx,reservations):
    duration=ctx.resource['services_ns'][target+'_stop'];req=ack-duration
    if req<earliest:return None
    start,end=ReservedChannel.earliest_service(req,duration,reservations)
    if end!=ack:return None
    return dict(submit_ns=req,target=target,tag=target+'_stop',service_start_ns=start,ACK_ns=end)


def reserved(actions):
    return [Reservation(10000+i,a['target'],a['tag'],a['submit_ns'],a['service_start_ns'],a['ACK_ns']) for i,a in enumerate(actions)]


def earliest_action(request,target,ctx,reservations):
    start,end=ReservedChannel.earliest_service(request,ctx.resource['services_ns'][target+'_stop'],reservations)
    return dict(submit_ns=request,target=target,tag=target+'_stop',service_start_ns=start,ACK_ns=end)


def candidate_pool(ctx,budget):
    """Bounded public schedule family, not exhaustive all-policy feasibility.

    All grid proposals, including resource rejection, consume identical tokens.
    One token is an ACK-grid alternative evaluated with the common full branch
    and fixed calibration-residual box; lower-level arithmetic is also logged.
    """
    p=ctx.public;ref=ctx.reference;minimum=ceilgrid(ctx.now_ns+ctx.charged_decision_ns,ctx.dt_ns)
    if p.get('max_requests_A_C',4)<3 or p.get('max_requests_per_rotor',2)<2:
        return [],dict(candidate_evaluations=0,cumulative_candidate_evaluations=budget.epoch,
            prediction_calls=0,budget_exhausted=False,action_budget_refused=True,
            search_refusal_is_not_physical_infeasibility=True)
    D,eps,gap=p['D_C_ns'],p['eps_C_ns'],p['minimum_edge_gap_ns'];model=p['public_nominal_model']
    error=tuple(p.get('calibrated_prediction_residual_ns',[0,0]))
    if len(error)!=2 or error[0]>error[1]:raise ValueError('ordered public calibrated residual box')
    edge=p['graph_edges'][0] if p['graph_edges'] else None
    orders=[edge] if edge else [['A','C'],['C','A']]
    result=[];budget_exhausted=False;prediction_calls=0
    stages=dict(resource_feasible_A_proposals=0,resource_feasible_C_proposals=0,
        A_window_feasible_proposals=0,C_window_feasible_proposals=0,graph_gap_feasible_proposals=0)
    for order in orders:
        base=list(ctx.reservations);initial=[]
        if order==['A','C']:
            # A earliest-feasible search is common strong HSM/batch primitive.
            # Its restriction is disclosed; this pool is not a global oracle.
            for ack in range(minimum,ref.lower_ns+p['A_window_ns'][1]+ctx.dt_ns,ctx.dt_ns):
                if not budget.consume():budget_exhausted=True;break
                a1=request_ACK(ack,'A',minimum,ctx,base)
                if a1 is None:continue
                stages['resource_feasible_A_proposals']+=1
                a2=earliest_action(ack,'A',ctx,base+reserved([a1]))
                A=envelope([stop_box(ctx.latest,0,a['ACK_ns'],model,ctx.dt_ns,error) for a in (a1,a2)]);prediction_calls+=2
                if fits(ref,A,p['A_window_ns']):
                    stages['A_window_feasible_proposals']+=1;initial=[a1,a2];break
            if not initial:continue
            used=base+reserved(initial)
        else:used=base
        for ack in range(minimum,ref.lower_ns+D+eps+ctx.dt_ns,ctx.dt_ns):
            if not budget.consume():budget_exhausted=True;break
            c=request_ACK(ack,'C',minimum,ctx,used)
            if c is None:continue
            stages['resource_feasible_C_proposals']+=1
            C=stop_box(ctx.latest,2,ack,model,ctx.dt_ns,error);prediction_calls+=1
            if order==['A','C']:
                if c['service_start_ns']<initial[-1]['ACK_ns']:continue
                actions=initial+[c]
                A=envelope([stop_box(ctx.latest,0,a['ACK_ns'],model,ctx.dt_ns,error) for a in initial]);prediction_calls+=2
                graph=C[0]-A[1]>=gap
            else:
                a1=earliest_action(ack,'A',ctx,base+reserved([c]))
                a2=earliest_action(a1['ACK_ns'],'A',ctx,base+reserved([c,a1]));actions=[c,a1,a2]
                A=envelope([stop_box(ctx.latest,0,a['ACK_ns'],model,ctx.dt_ns,error) for a in (a1,a2)]);prediction_calls+=2
                graph=A[0]-C[1]>=gap
            if not ctx.public['graph_edges']:graph=True
            C_ok=fits(ref,C,[D-eps,D+eps]);A_ok=fits(ref,A,p['A_window_ns'])
            stages['C_window_feasible_proposals']+=C_ok
            stages['A_window_feasible_proposals']+=A_ok
            stages['graph_gap_feasible_proposals']+=graph
            valid=C_ok and A_ok and graph
            if valid:
                midpoint_error=abs(C[0]+C[1]-ref.lower_ns-ref.upper_ns-2*D)
                result.append(dict(actions=actions,A_box_ns=A,C_box_ns=C,C_midpoint_error_twice_ns=midpoint_error,
                    branch_scope='CONDITIONAL_NONE_OR_SINGLE_A_DROP; PERSISTENT_DROP_NOT_GUARANTEED',
                    blind_A_redundancy_available_to_all=True,resource_calendar_feasible=True,deadline_and_graph_box_feasible=True))
        if budget_exhausted:break
    return result,dict(candidate_evaluations=budget.current,cumulative_candidate_evaluations=budget.epoch,
        prediction_calls=prediction_calls,budget_exhausted=budget_exhausted,
        component_stage_counts=stages,
        search_family='EARLIEST_FEASIBLE_A_PREFIX_THEN_C_OR_C_THEN_TWO_A; NOT_ALL_POLICIES',
        search_refusal_is_not_physical_infeasibility=True)


class PublicDecisionAdapter:
    """One-decision policy prototypes; full closed-loop arm integration pending."""
    def __init__(self,method,per_decision=1000,per_epoch=10000):
        if method not in METHODS:raise ValueError('unknown method')
        self.method=method;self.budget=Budget(per_decision,per_epoch)
    def decide(self,ctx):
        if type(ctx) is not PublicContext:raise TypeError('sanitized public context required')
        accepted_actor_requests=tuple(r for r in ctx.reservations if not r.external and r.target in ('A','C'))
        if ctx.acks or accepted_actor_requests:
            return dict(status='INITIAL_DECISION_ADAPTER_ONLY_FEEDBACK_LIFECYCLE_SPEC_PENDING',proposed_program=None,
                public_post_ACK_powered_A=powered_after_ACK(ctx,'A'),ACK_is_effect_success=False,
                accepted_actor_requests=len(accepted_actor_requests),
                pending_accepted_actor_requests=sum(r.ack_ns>ctx.now_ns for r in accepted_actor_requests),
                lifecycle_guard='ACK_OR_ANY_ACCEPTED_NONEXTERNAL_A_C_RESERVATION',
                full_stateful_HSM_EDF_MPC_native_arm_implemented=False,new_native_episodes=0)
        self.budget.per_decision=min(self.budget.per_decision,ctx.public.get('maximum_candidates_per_decision',1000))
        self.budget.per_epoch=min(self.budget.per_epoch,ctx.public.get('maximum_candidates_epoch',10000))
        started=time.perf_counter_ns();self.budget.begin();plans,account=candidate_pool(ctx,self.budget)
        if self.method in ('sameinfo_calibrated_batch_joint','sameinfo_joint_interval_mpc'):
            key=lambda x:(x['C_midpoint_error_twice_ns'],max(a['ACK_ns'] for a in x['actions']),x['actions'][0]['submit_ns'])
        elif self.method=='sameinfo_robust_hsm':
            key=lambda x:(x['actions'][0]['ACK_ns'],x['C_midpoint_error_twice_ns'])
        else:
            # Dependency-ready EDF; predecessor inherits successor deadline.
            def key(x):
                deadline={'A':ctx.reference.lower_ns+ctx.public['A_window_ns'][1],
                    'C':ctx.reference.lower_ns+ctx.public['D_C_ns']+ctx.public['eps_C_ns']}
                return deadline[x['actions'][0]['target']],x['actions'][0]['ACK_ns'],x['C_midpoint_error_twice_ns']
        chosen=min(plans,key=key) if plans else None
        return dict(status='FEASIBLE_PUBLIC_CONDITIONAL_DECISION' if chosen else 'NO_FEASIBLE_PLAN_IN_BOUNDED_PUBLIC_SEARCH',
            method=self.method,proposed_program=chosen,budget=account,charged_decision_ns=ctx.charged_decision_ns,
            measured_host_compute_ns=time.perf_counter_ns()-started,host_compute_advances_physics_in_this_CPU_test=False,
            public_post_ACK_powered_A=powered_after_ACK(ctx,'A'),ACK_is_effect_success=False,
            original_B_coarse=asdict(ctx.original_B_coarse),reference=asdict(ctx.reference),
            full_stateful_HSM_EDF_MPC_native_arm_implemented=False,new_native_episodes=0,
            extra_oracle_or_teacher_calls=0,current_private_fault_read=False,physical_or_information_infeasibility_claim=False)
