"""Synthetic scalar-model software fixture, NOT a native physics simulator.

Fault generation is confined here. Controllers receive only PublicFrame and a
public Contract; they cannot import this module. Used for software lifecycle
assertions, not robot/chemical performance or heldout generalization.
"""
from dataclasses import asdict
import json
from pathlib import Path
from controller_contract import Contract,PublicFrame
from public_types import Packet,Ack,Reservation,ReservedChannel
from stateful_controllers import make_controller


def build_contract(protocol,case,epoch='software-fixture'):
    public=dict(protocol['public']);public.update(D_C_ns=case['D_C_ns'],A_window_ns=case['A_window_ns'],graph_edges=case['graph_edges'])
    public['calibrated_prediction_residual_ns']=[0,0]
    resource=json.loads(json.dumps(protocol['resource']));b=resource['B_reservation'];b['service_end_ns']=b['service_start_ns']+case['B_service_ns']
    return Contract.create(epoch,public,resource,protocol['dt_ns'],protocol['dt_ns']*protocol['sensor_period_ticks'],protocol['sensor_lag_ns'])


def run_fixture(protocol,case,method,fault='first_A_stop_drop',extra_resource=False,horizon_ns=12_000_000_000,unsupported_B_torque=None):
    contract=build_contract(protocol,case);controller=make_controller(method,contract);channel=ReservedChannel(contract.resource)
    q=[0.,0.,0.];v=[0.,0.,0.];torque=[.06,.06,.06];dt=contract.dt_ns;model=contract.public['public_nominal_model']
    decay=model['inertia']/(model['inertia']+dt/1e9*model['damping'])
    sensor=[];latest=None;acks=[];serviced=set();A_attempts=0;commands=[];inputs=[];truth_B=None;truth_stop={}
    ledger_snapshots=[];error=None
    for tick in range(horizon_ns//dt+1):
        now=tick*dt
        # Match the source ordering: capture is pre-ACK on a same clock tick.
        if now%contract.sensor_period_ns==0:sensor.append(Packet(now,now+contract.sensor_lag_ns,tuple(q),tuple(v),tuple(torque)))
        if extra_resource and now==900_000_000:
            channel.reservations.append(Reservation(len(channel.reservations),'B','CPU_ONLY_EXTRA_PUBLIC_CALENDAR',now,1_400_000_000,1_500_000_000,True))
        for r in channel.reservations:
            if r.seq in serviced or r.ack_ns!=now:continue
            serviced.add(r.seq);acks.append(Ack(r.seq,r.target,r.tag,now))
            if r.target=='B':torque[1]=.045 if unsupported_B_torque is None else unsupported_B_torque
            elif r.target=='A':
                A_attempts+=1
                if not ((fault=='first_A_stop_drop' and A_attempts==1) or fault=='persistent_A_power'):torque[0]=0.
            else:torque[2]=0.
        for p in sensor:
            if p.arrival_ns==now:latest=p
        frame=PublicFrame(contract.epoch,now,latest,tuple(acks),channel.public_snapshot())
        try:actions=controller.advance(frame)
        except Exception as e:
            error={'type':type(e).__name__,'message':str(e),'tick':tick};break
        for a in actions:
            r=channel.submit(now,a['target'],a['tag']);commands.append({'request':a,'accepted':asdict(r)})
        inputs.append({'now_ns':now,'latest':asdict(latest) if latest else None,'ACKs':[asdict(a) for a in acks],
            'reservations':[asdict(r) for r in channel.reservations]})
        ledger_snapshots.append({'now_ns':now,'counts':controller.ledger.counts,'candidate_epoch':controller.budget.epoch})
        if tick==horizon_ns//dt:break
        previous_q=list(q);previous_v=list(v)
        for i in range(3):v[i]=decay*(v[i]+dt/1e9*torque[i]/model['inertia']);q[i]+=v[i]*dt/1e9
        if truth_B is None and previous_q[1]<2.<=q[1]:truth_B=[now,now+dt]
        for i,target in ((0,'A'),(2,'C')):
            if target not in truth_stop and previous_v[i]>.1>=v[i] and torque[i]==0:truth_stop[target]=[now,now+dt]
    snapshot=controller.snapshot();p=contract.public;truth_pass=False
    if truth_B and set(truth_stop)=={'A','C'}:
        B=truth_B;A=truth_stop['A'];C=truth_stop['C'];edge=p['graph_edges'][0]
        truth_pass=A[0]-B[1]>=p['A_window_ns'][0] and A[1]-B[0]<=p['A_window_ns'][1] and C[0]-B[1]>=p['D_C_ns']-p['eps_C_ns'] and C[1]-B[0]<=p['D_C_ns']+p['eps_C_ns'] and truth_stop[edge[1]][0]-truth_stop[edge[0]][1]>=p['minimum_edge_gap_ns']
    return {'role':'SYNTHETIC_PUBLIC_SOFTWARE_LIFECYCLE_FIXTURE_NOT_NATIVE_OR_FORMAL32','method':method,'case_id':case['id'],
        'fixture_fault':fault,'fixture_fault_is_not_an_actor_input':True,'CPU_extra_resource_stress_not_canonical_scenario':extra_resource,
        'CPU_unsupported_B_torque_not_canonical_scenario':unsupported_B_torque,
        'error':error,'commands':commands,'controller':snapshot,'inputs':inputs,'ledger_snapshots':ledger_snapshots,
        'synthetic_model_contract_pass':truth_pass,'fixture_stop_brackets':truth_stop,'fixture_B_bracket':truth_B,
        'new_native_episodes':0,'GPU':0,'fit':0,'heldout':False}


def load_protocol():
    return json.loads((Path(__file__).parents[1]/'source_inputs/scenario_PROTOCOL_V2.json').read_text())
