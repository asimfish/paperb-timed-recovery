"""Shared bounded public conditional predictor, initial and remaining schedules."""
from initial_public_math import PublicContext,candidate_pool,ceilgrid,stop_box,envelope,fits,request_ACK,earliest_action,reserved
from public_types import ReservedChannel
from controller_contract import legacy_public


def context(contract,frame,facts,ledger):
    return PublicContext(frame.now_ns,facts.latest,facts.original_B,facts.reference,(),
        tuple(ledger.reservations.values()),legacy_public(contract),contract.resource,contract.dt_ns,contract.charged_decision_ns)


def effect_box(target,actions,contract,facts,ledger):
    if target in facts.stops:return facts.stops[target]['bounds_ns']
    packet=facts.latest;axis={'A':0,'C':2}[target];model=contract.public['public_nominal_model'];dt=contract.dt_ns
    error=tuple(contract.public.get('calibrated_prediction_residual_ns',[0,0]))
    if packet.velocities[axis]<0:return None
    if packet.torques[axis]==0:
        if packet.velocities[axis]<=contract.public['moving_threshold']:return None  # no known original crossing
        return stop_box(packet,axis,packet.capture_ns,model,dt,error)
    if packet.torques[axis]!=contract.public['initial_torque']:return None  # unsupported public control profile, no nominal branch certificate
    previous=ledger.public_commands(target)
    commands=sorted([{'ACK_ns':r.ack_ns,'request_ns':r.request_ns} for r in previous]+
        [{'ACK_ns':a['ACK_ns'],'request_ns':a['submit_ns']} for a in actions if a['target']==target],key=lambda x:x['request_ns'])
    if not commands:return None
    if target=='C':
        ack=commands[0]['ACK_ns']
        if packet.capture_ns>=ack+dt:return None  # powered after nominally reliable C service: unsupported, not success
        return stop_box(packet,axis,ack,model,dt,error)
    # Under the common declared prior, either first A works or exactly first A
    # is dropped. A positive fresh post-ACK packet removes the first branch.
    first=commands[0]['ACK_ns'];boxes=[]
    first_ambiguous=packet.capture_ns<first+dt
    if first_ambiguous:boxes.append(stop_box(packet,axis,first,model,dt,error))
    if len(commands)<2:return None  # retain drop branch with no future effect
    second=commands[1]['ACK_ns']
    if packet.capture_ns>=second+dt:return None  # persistent/out-of-support power
    boxes.append(stop_box(packet,axis,second,model,dt,error))
    return envelope(boxes)


def calendar_valid(actions,ctx):
    calendar=list(ctx.reservations)
    for a in sorted(actions,key=lambda a:(a['submit_ns'],a['target'])):
        start,end=ReservedChannel.earliest_service(a['submit_ns'],ctx.resource['services_ns'][a['tag']],calendar)
        if (start,end)!=(a['service_start_ns'],a['ACK_ns']):return False
        calendar.extend(reserved([a]))
    return True


def assess(actions,contract,frame,facts,ledger):
    ctx=context(contract,frame,facts,ledger);p=contract.public;ref=facts.reference
    A=effect_box('A',actions,contract,facts,ledger);C=effect_box('C',actions,contract,facts,ledger)
    if A is None or C is None:return None
    graph=all(({'A':A,'C':C}[y][0]-{'A':A,'C':C}[x][1]>=p['minimum_edge_gap_ns']) for x,y in p['graph_edges'])
    if not calendar_valid(actions,ctx) or not fits(ref,A,p['A_window_ns']) or not fits(ref,C,[p['D_C_ns']-p['eps_C_ns'],p['D_C_ns']+p['eps_C_ns']]) or not graph:return None
    return {'actions':actions,'A_box_ns':A,'C_box_ns':C,'C_midpoint_error_twice_ns':abs(C[0]+C[1]-ref.lower_ns-ref.upper_ns-2*p['D_C_ns']),
        'conditional_none_or_first_A_drop_only':True,'calendar_feasible':True,'original_event_not_reanchored':True}


def initial_candidates(contract,frame,facts,ledger,budget,adaptive=False):
    ctx=context(contract,frame,facts,ledger);plans,account=candidate_pool(ctx,budget)
    if not adaptive:return plans,account
    delay=contract.sensor_period_ns+contract.sensor_lag_ns+contract.charged_decision_ns
    adapted=[]
    for plan in plans:
        if not budget.consume():break
        actions=[dict(a) for a in plan['actions']];As=[a for a in actions if a['target']=='A']
        if len(As)!=2:continue
        first,second=As;request=ceilgrid(first['ACK_ns']+delay,contract.dt_ns)
        replacement=earliest_action(request,'A',ctx,list(ctx.reservations)+reserved([first]))
        replacement['feedback_retry_slot']=True
        actions=[replacement if a is second else a for a in actions]
        checked=assess(actions,contract,frame,facts,ledger)
        if checked:
            checked['feedback_retry_slot']=True;checked['blind_fallback_if_feedback_missing']=True;adapted.append(checked)
    # Adaptation search shares the same per-decision/epoch budget. The original
    # strong blind candidates remain available; no baseline ability is removed.
    account.update(candidate_evaluations=budget.current,cumulative_candidate_evaluations=budget.epoch,
        adaptive_candidates=len(adapted),blind_candidates_available=len(plans),adaptation_trials_included_in_budget=True)
    return adapted or plans,account


def remaining_candidates(contract,frame,facts,ledger,budget):
    """Bounded earliest-A-prefix / C-first family, not all-policy oracle."""
    ctx=context(contract,frame,facts,ledger);p=contract.public;ref=facts.reference;dt=contract.dt_ns
    if any(i.status=='EMITTED' for i in ledger.intents.values()):
        return [],{'status':'PUBLIC_SUBMISSION_RECEIPT_PENDING','candidate_evaluations':budget.current,'cumulative_candidate_evaluations':budget.epoch}
    counts=ledger.counts;packet=facts.latest
    A_done='A' in facts.stops or packet.torques[0]==0
    C_done='C' in facts.stops or packet.torques[2]==0 or counts['C']>=1
    An=0 if A_done else max(0,2-counts['A']);Cn=0 if C_done else 1
    if An>ledger.remaining()['A'] or Cn>ledger.remaining()['C'] or An+Cn+sum(counts.values())>p['max_requests_A_C']:
        return [],{'status':'CUMULATIVE_ACTION_BUDGET_REFUSED','candidate_evaluations':budget.current,'cumulative_candidate_evaluations':budget.epoch}
    minimum=ceilgrid(frame.now_ns+contract.charged_decision_ns,dt);base=list(ctx.reservations);plans=[]
    edge=p['graph_edges'][0] if p['graph_edges'] else ['A','C']
    def A_prefix(first,calendar):
        result=[first]
        if An==2:result.append(earliest_action(first['ACK_ns'],'A',ctx,calendar+reserved([first])))
        return result
    if edge==['A','C']:
        initial=[]
        if An:
            for ack in range(minimum,ref.lower_ns+p['A_window_ns'][1]+dt,dt):
                if not budget.consume():break
                first=request_ACK(ack,'A',minimum,ctx,base)
                if first is None:continue
                actions=A_prefix(first,base);A=effect_box('A',actions,contract,facts,ledger)
                if A is not None and fits(ref,A,p['A_window_ns']):initial=actions;break
            if not initial:return [],{'status':'NO_A_PREFIX_IN_BOUNDED_SEARCH','candidate_evaluations':budget.current,'cumulative_candidate_evaluations':budget.epoch}
        used=base+reserved(initial)
        values=range(minimum,ref.lower_ns+p['D_C_ns']+p['eps_C_ns']+dt,dt) if Cn else [None]
        for ack in values:
            if not budget.consume():break
            c=request_ACK(ack,'C',minimum,ctx,used) if Cn else None
            if Cn and c is None:continue
            actions=initial+([c] if c else []);plan=assess(actions,contract,frame,facts,ledger)
            if plan:plans.append(plan)
    else:
        values=range(minimum,ref.lower_ns+p['D_C_ns']+p['eps_C_ns']+dt,dt) if Cn else [None]
        for ack in values:
            if not budget.consume():break
            c=request_ACK(ack,'C',minimum,ctx,base) if Cn else None
            if Cn and c is None:continue
            actions=[c] if c else [];calendar=base+reserved(actions)
            if An:
                start=max(minimum,c['ACK_ns'] if c else max([r.ack_ns for r in ledger.public_commands('C')]+[minimum]))
                first=earliest_action(start,'A',ctx,calendar);actions+=A_prefix(first,calendar)
            plan=assess(actions,contract,frame,facts,ledger)
            if plan:plans.append(plan)
    return plans,{'status':'REMAINING_PUBLIC_CANDIDATES','candidate_evaluations':budget.current,'cumulative_candidate_evaluations':budget.epoch,
        'budget_exhausted':budget.current>=budget.per_decision or budget.epoch>=budget.per_epoch,
        'search_refusal_is_not_physical_infeasibility':True,'remaining_A_requests_planned':An,'remaining_C_requests_planned':Cn}
