"""Epoch-lifetime request accounting. Receipt, ACK and effect are distinct."""
from dataclasses import dataclass,asdict
from public_types import ReservedChannel,Reservation


@dataclass
class Intent:
    token:str
    target:str
    submit_ns:int
    service_start_ns:int
    ACK_ns:int
    mode:str='blind'
    status:str='UNSENT'
    emitted_ns:int|None=None
    seq:int|None=None


class RequestLedger:
    def __init__(self,contract):
        self.contract=contract;self.intents={};self.reservations={};self.acks={};self.version=0
        self.emitted={};self.unclaimed={};self.history=[]

    @property
    def counts(self):
        rows=list(self.emitted.values())+list(self.unclaimed.values())
        return {t:sum(x['target']==t for x in rows) for t in ('A','C')}

    def ingest(self,frame):
        changed=False
        for r in frame.reservations:
            if r.seq in self.reservations:
                if self.reservations[r.seq]!=r:raise ValueError('accepted reservation cannot be altered/revoked')
                continue
            self.reservations[r.seq]=r;changed=True
            if not r.external:
                matches=[i for i in self.intents.values() if i.status in ('EMITTED','ACCEPTED','ACKED') and i.target==r.target and i.emitted_ns==r.request_ns]
                if len(matches)>1:raise ValueError('ambiguous own request receipt')
                if matches:
                    i=matches[0]
                    if i.seq is not None and i.seq!=r.seq:
                        self.unclaimed[r.seq]={'target':r.target,'request_ns':r.request_ns,'reason':'DUPLICATE_SERVER_IDENTITY_FOR_ONE_EMITTED_TOKEN'}
                        raise ValueError('one emitted client token cannot bind two accepted server identities')
                    i.seq=r.seq;i.status='ACCEPTED'
                    if i.ACK_ns!=r.ack_ns or i.service_start_ns!=r.service_start_ns:
                        self.history.append({'event':'PUBLIC_SERVICE_TIME_DIFFERS_FROM_PLAN','token':i.token,'actual':asdict(r)})
                else:self.unclaimed[r.seq]={'target':r.target,'request_ns':r.request_ns,'reason':'ACCEPTED_BEFORE_LOCAL_EMIT_LEDGER'}
        for a in frame.acks:
            if a.seq in self.acks:
                if self.acks[a.seq]!=a:raise ValueError('conflicting duplicate ACK')
                continue
            r=self.reservations.get(a.seq)
            if r is None or (r.target,r.tag,r.ack_ns)!=(a.target,a.tag,a.ack_ns):raise ValueError('ACK does not match public service receipt')
            self.acks[a.seq]=a;changed=True
            for i in self.intents.values():
                if i.seq==a.seq:i.status='ACKED'
            self.history.append({'event':'ACK_RECEIVED_NOT_EFFECT_SUCCESS','ack':asdict(a)})
        if sum(self.counts.values())>self.contract.public['max_requests_A_C'] or max(self.counts.values())>self.contract.public['max_requests_per_rotor']:
            raise ValueError('public accepted history already exceeds actor action budget')
        return changed

    def remaining(self):
        p=self.contract.public;c=self.counts
        return {t:min(p['max_requests_per_rotor']-c[t],p['max_requests_A_C']-sum(c.values())) for t in ('A','C')}

    def unsent(self):return sorted((i for i in self.intents.values() if i.status in ('UNSENT','BLOCKED_UNSENT')),key=lambda i:(i.submit_ns,i.token))

    def install(self,actions,ready_ns,replace=True,prefix_only=False,mode='blind'):
        if any(a['submit_ns']<ready_ns for a in actions):raise ValueError('decision cannot retroactively dispatch an action')
        if len({(a['target'],a['submit_ns']) for a in actions})!=len(actions):raise ValueError('one target/request time identifies at most one emitted token')
        requested={t:sum(a['target']==t for a in actions) for t in ('A','C')};spent=self.counts;p=self.contract.public
        if any(spent[t]+requested[t]>p['max_requests_per_rotor'] for t in ('A','C')) or sum(spent.values())+len(actions)>p['max_requests_A_C']:
            raise ValueError('pending/accepted actions are included in cumulative budget')
        if replace:
            for i in self.unsent():i.status='CANCELLED_UNSENT';self.history.append({'event':'CANCEL_UNSENT_INTENT','token':i.token})
        self.version+=1
        selected=sorted(actions,key=lambda a:(a['submit_ns'],a['target']))
        if prefix_only:selected=selected[:1]
        for j,a in enumerate(selected):
            token=f'{self.contract.epoch}/{self.version}/{a["target"]}/{j}'
            self.intents[token]=Intent(token,a['target'],a['submit_ns'],a['service_start_ns'],a['ACK_ns'],mode)
        self.history.append({'event':'INSTALL_UNSENT_PROGRAM','version':self.version,'installed':len(selected),'prefix_only':prefix_only})

    def cancel(self,tokens):
        for token in tokens:
            i=self.intents[token]
            if i.status not in ('UNSENT','BLOCKED_UNSENT'):raise ValueError('emitted/accepted/pending/ACKED requests are never cancellable')
            i.status='CANCELLED_UNSENT';self.history.append({'event':'CANCEL_UNSENT_INTENT','token':token})

    def emit_due(self,now):
        due=[i for i in self.unsent() if i.status=='UNSENT' and i.submit_ns<=now]
        if any(i.submit_ns<now for i in due):raise ValueError('missed dispatch tick, retain rather than silently shift')
        actions=[]
        calendar=list(self.reservations.values())
        for i in due:
            if self.remaining()[i.target]<=0:raise ValueError('no remaining epoch action budget')
            start,end=ReservedChannel.earliest_service(now,self.contract.resource['services_ns'][i.target+'_stop'],calendar)
            if (start,end)!=(i.service_start_ns,i.ACK_ns):
                i.status='BLOCKED_UNSENT'
                self.history.append({'event':'CURRENT_PUBLIC_CALENDAR_BLOCKS_OLD_UNSENT_INTENT','token':i.token,'now_ns':now,'actual_public_service_ns':[start,end]})
                continue
            i.status='EMITTED';i.emitted_ns=now
            # Two legal same-tick requests share the same one-server forecast.
            # This is a temporary prediction, never a fabricated receipt.
            calendar.append(Reservation(100000+len(actions),i.target,i.target+'_stop',now,start,end))
            self.emitted[i.token]={'target':i.target,'request_ns':now}
            action={'client_token':i.token,'target':i.target,'tag':i.target+'_stop','request_ns':now}
            actions.append(action);self.history.append({'event':'EMIT_COUNTS_ONCE_PENDING_RECEIPT','action':action})
        return actions

    def public_commands(self,target):
        return sorted((r for r in self.reservations.values() if r.target==target and not r.external),key=lambda r:(r.request_ns,r.seq))

    def snapshot(self):
        return {'counts':self.counts,'remaining':self.remaining(),'intents':[asdict(i) for i in self.intents.values()],
            'accepted_reservations':[asdict(r) for r in self.reservations.values()],'ACKs':[asdict(a) for a in self.acks.values()],
            'unclaimed_accepted_requests':list(self.unclaimed.values()),'history':list(self.history),'ACK_is_effect_success':False}
