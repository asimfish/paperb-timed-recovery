"""Behavioral public-boundary tests; synthetic data, no native environment."""
import ast
import copy
from pathlib import Path
import unittest
from controller_contract import Contract, PublicFrame
from public_types import Packet, Ack, Reservation, ObservedEvent
from initial_public_math import Budget
from request_ledger import RequestLedger
from temporal_facts import PublicFacts
from stateful_controllers import METHODS, make_controller
from cpu_public_fixture import load_protocol, build_contract, run_fixture


PROTO=load_protocol()
CASE=PROTO['cases'][0]


def contract():return build_contract(PROTO,CASE)


def frame(c,now,p=None,acks=(),reservations=()):return PublicFrame(c.epoch,now,p,tuple(acks),tuple(reservations))


def packet(capture,A=.2,C=.2,Bv=1.,Bq=1.,torques=(0.,.06,0.)):
    return Packet(capture,capture+100_000_000,(0.,Bq,0.),(A,Bv,C),torques)


def action(target,submit,start=None,end=None):
    start=submit if start is None else start
    end=start+{'A':50_000_000,'C':450_000_000}[target] if end is None else end
    return dict(target=target,tag=target+'_stop',submit_ns=submit,service_start_ns=start,ACK_ns=end)


def decode_input(c,row):
    p=row['latest']
    p=None if p is None else Packet(p['capture_ns'],p['arrival_ns'],tuple(p['positions']),tuple(p['velocities']),tuple(p['torques']))
    return frame(c,row['now_ns'],p,[Ack(**a) for a in row['ACKs']],[Reservation(**r) for r in row['reservations']])


class BoundaryTests(unittest.TestCase):
    def test_actor_dependency_closure_has_no_environment_reader(self):
        owned={'stateful_controllers','controller_contract','public_types','initial_public_math','request_ledger','temporal_facts','schedule_model'}
        allowed=owned|{'dataclasses','json','math','time','typing'}
        for name in owned:
            tree=ast.parse((Path(__file__).parent/(name+'.py')).read_text())
            imports=set()
            for n in ast.walk(tree):
                if isinstance(n,ast.Import):imports.update(x.name.split('.')[0] for x in n.names)
                elif isinstance(n,ast.ImportFrom):imports.add(n.module.split('.')[0])
                if isinstance(n,ast.Call) and isinstance(n.func,ast.Name):self.assertNotIn(n.func.id,('open','eval','exec','getattr','__import__'))
            self.assertLessEqual(imports,allowed)

    def test_wrapper_rejected_before_callback_and_sticky(self):
        touched=[]
        class Wrapper:
            def validate(self,*a):touched.append(True)
        actor=make_controller('strong_batch',contract())
        with self.assertRaises(TypeError):actor.advance(Wrapper())
        self.assertEqual(touched,[])
        with self.assertRaises(ValueError):actor.advance(frame(actor.contract,0))

    def test_packet_time_type_rejected_before_callbacks(self):
        touched=[]
        class Clock:
            def __lt__(self,o):touched.append('lt');return False
            def __gt__(self,o):touched.append('gt');return False
        p=object.__new__(Packet)
        for k,v in dict(capture_ns=Clock(),arrival_ns=Clock(),positions=(0.,0.,0.),velocities=(0.,0.,0.),torques=(.06,.06,.06)).items():object.__setattr__(p,k,v)
        with self.assertRaises(ValueError):make_controller('strong_batch',contract()).advance(frame(contract(),0,p))
        self.assertEqual(touched,[])

    def test_epoch_type_rejected_before_comparison(self):
        touched=[]
        class Epoch:
            def __eq__(self,o):touched.append(True);return True
        f=PublicFrame(Epoch(),0,None,(),())
        with self.assertRaises(TypeError):make_controller('strong_batch',contract()).advance(f)
        self.assertEqual(touched,[])

    def test_private_nested_primitive_metadata_rejected(self):
        c=contract();r=c.resource;r['B_reservation']['current_private_fault']='FAKE_PRIVATE_LABEL'
        with self.assertRaises(ValueError):Contract.create(c.epoch,c.public,r)

    def test_extra_dto_metadata_rejected(self):
        c=contract();p=packet(0);object.__setattr__(p,'private_truth',False)
        with self.assertRaises(ValueError):frame(c,100_000_000,p).validate(c)

    def test_future_epoch_and_rewind_cannot_reset_anchor_or_budget(self):
        c=contract();actor=make_controller('strong_batch',c)
        actor.advance(frame(c,100_000_000,packet(0)))
        with self.assertRaises(ValueError):actor.advance(frame(c,90_000_000,packet(0)))
        self.assertIsNotNone(actor.protocol_failure)
        with self.assertRaises(ValueError):make_controller('strong_batch',c).advance(PublicFrame('new',0,None,(),()))
        with self.assertRaises(ValueError):frame(c,0,packet(0)).validate(c)

    def test_bypassed_packet_constructor_shape_and_chronology_rejected(self):
        c=contract()
        for updates in ({'positions':(0.,0.)},{'arrival_ns':-1},{'capture_ns':200_000_000,'arrival_ns':100_000_000}):
            p=packet(0)
            for k,v in updates.items():object.__setattr__(p,k,v)
            with self.assertRaises(ValueError):frame(c,300_000_000,p).validate(c)

    def test_same_capture_identity_cannot_be_rewritten(self):
        c=contract();a=make_controller('strong_batch',c);a.advance(frame(c,100_000_000,packet(0)))
        with self.assertRaises(ValueError):a.advance(frame(c,110_000_000,packet(0,A=.3)))


class LedgerTests(unittest.TestCase):
    def setUp(self):self.c=contract();self.l=RequestLedger(self.c)

    def emitted(self):
        self.l.install([action('A',560_000_000)],560_000_000)
        return self.l.emit_due(560_000_000)[0]

    def test_pending_charged_once_and_repeat_receipt_ACK_idempotent(self):
        self.emitted();self.assertEqual(self.l.counts,{'A':1,'C':0})
        r=Reservation(1,'A','A_stop',560_000_000,560_000_000,610_000_000)
        f=frame(self.c,610_000_000,acks=[Ack(1,'A','A_stop',610_000_000)],reservations=[r])
        self.l.ingest(f);self.l.ingest(f)
        self.assertEqual(self.l.counts,{'A':1,'C':0});self.assertEqual(len(self.l.acks),1)
        self.assertFalse(self.l.snapshot()['ACK_is_effect_success'])

    def test_one_token_cannot_bind_two_server_ids_conservative_count(self):
        self.emitted();rs=[Reservation(i,'A','A_stop',560_000_000,560_000_000,610_000_000) for i in (1,2)]
        with self.assertRaises(ValueError):self.l.ingest(frame(self.c,560_000_000,reservations=rs))
        self.assertEqual(self.l.counts['A'],2);self.assertEqual(next(iter(self.l.intents.values())).seq,1)
        self.assertEqual(self.l.unclaimed[2]['reason'],'DUPLICATE_SERVER_IDENTITY_FOR_ONE_EMITTED_TOKEN')

    def test_transport_protocol_failure_stops_future_actor_emission(self):
        a=make_controller('strong_batch',self.c);a.ledger=self.l;self.emitted()
        rs=[Reservation(i,'A','A_stop',560_000_000,560_000_000,610_000_000) for i in (1,2)]
        with self.assertRaises(ValueError):a.advance(frame(self.c,560_000_000,reservations=rs))
        with self.assertRaises(ValueError):a.advance(frame(self.c,580_000_000))
        self.assertEqual(len(a.ledger.emitted),1)

    def test_only_unissued_requests_cancel_and_no_refund(self):
        self.l.install([action('A',560_000_000),action('C',1_100_000_000)],560_000_000)
        self.l.emit_due(560_000_000);tokens=list(self.l.intents)
        with self.assertRaises(ValueError):self.l.cancel([tokens[0]])
        self.l.cancel([tokens[1]]);self.assertEqual(self.l.counts,{'A':1,'C':0})

    def test_existing_pending_reservations_spend_same_caps(self):
        rs=[Reservation(i,'A','A_stop',0,i*50_000_000,(i+1)*50_000_000) for i in (1,2)]
        self.l.ingest(frame(self.c,0,reservations=rs))
        with self.assertRaises(ValueError):self.l.install([action('A',300_000_000)],300_000_000)
        self.assertEqual(self.l.remaining()['A'],0)

    def test_conflicting_receipt_or_ACK_rejected(self):
        r=Reservation(1,'A','A_stop',0,0,50_000_000);self.l.ingest(frame(self.c,0,reservations=[r]))
        with self.assertRaises(ValueError):self.l.ingest(frame(self.c,0,reservations=[Reservation(1,'A','A_stop',0,0,60_000_000)]))
        with self.assertRaises(ValueError):self.l.ingest(frame(self.c,50_000_000,acks=[Ack(1,'C','C_stop',50_000_000)]))

    def test_current_calendar_blocks_unsent_without_action_charge(self):
        self.l.install([action('A',560_000_000)],540_000_000)
        r=Reservation(0,'B','public_new_busy',0,550_000_000,800_000_000,True)
        self.l.ingest(frame(self.c,550_000_000,reservations=[r]))
        self.assertEqual(self.l.emit_due(560_000_000),[]);self.assertEqual(self.l.counts['A'],0)
        self.assertEqual(self.l.unsent()[0].status,'BLOCKED_UNSENT')

    def test_same_tick_requests_forecast_real_single_server_order(self):
        self.l.install([action('A',1_100_000_000),action('C',1_100_000_000,1_150_000_000,1_600_000_000)],1_100_000_000)
        actions=self.l.emit_due(1_100_000_000)
        self.assertEqual([x['target'] for x in actions],['A','C']);self.assertEqual(self.l.counts,{'A':1,'C':1})

    def test_missed_dispatch_is_not_silently_retimed(self):
        self.l.install([action('A',560_000_000)],540_000_000)
        with self.assertRaises(ValueError):self.l.emit_due(570_000_000)
        self.assertEqual(self.l.counts['A'],0)

    def test_candidate_budget_consumes_before_evaluation_and_no_overrun(self):
        b=Budget(1000,10000);b.begin()
        for i in range(1000):self.assertTrue(b.consume())
        self.assertFalse(b.consume());self.assertEqual(b.current,1000);self.assertEqual(b.epoch,1000)
        for j in range(9):
            b.begin()
            for i in range(1000):self.assertTrue(b.consume())
        b.begin();self.assertFalse(b.consume());self.assertEqual(b.epoch,10000)


class FactsTests(unittest.TestCase):
    def setUp(self):self.c=contract();self.l=RequestLedger(self.c);self.f=PublicFacts(self.c)
    def observe(self,p):self.f.observe(frame(self.c,p.arrival_ns,p),self.l)

    def test_first_anchor_immutable_and_refinement_same_identity(self):
        self.observe(packet(400_000_000,Bq=1.9));self.observe(packet(450_000_000,Bq=2.1))
        original=self.f.original_B;self.observe(packet(500_000_000,Bq=1.9));self.observe(packet(550_000_000,Bq=2.1))
        self.assertEqual(self.f.original_B,original);self.assertEqual([original.lower_ns,original.upper_ns],[400_000_000,450_000_000])

    def test_short_low_speed_candidate_does_not_destroy_later_confirmed_first_stop(self):
        for t,v in [(100,.2),(150,.05),(200,.2),(250,.05),(300,.03),(350,.02),(400,.015),(450,.01)]:
            self.observe(packet(t*1_000_000,A=v))
        self.assertEqual(self.f.stops['A']['bounds_ns'],[200_000_000,250_000_000])
        self.assertEqual(self.f.confirmed['A']['confirmation_capture_ns'],450_000_000)
        self.assertEqual(len([x for x in self.f.failed_stop_candidates if x['target']=='A']),1)

    def test_confirmation_is_later_than_onset_and_missing_sample_is_unresolved(self):
        self.observe(packet(100_000_000,A=.2));self.observe(packet(150_000_000,A=.05))
        self.assertNotIn('A',self.f.confirmed)
        for t in (200,300,350,400):self.observe(packet(t*1_000_000,A=.01))
        self.assertNotIn('A',self.f.confirmed);self.assertFalse(self.f.covered(150_000_000,350_000_000))

    def test_same_tick_pre_ACK_packet_not_effect_diagnosis(self):
        r=Reservation(1,'A','A_stop',0,0,50_000_000)
        self.l.ingest(frame(self.c,50_000_000,acks=[Ack(1,'A','A_stop',50_000_000)],reservations=[r]))
        self.observe(packet(50_000_000,torques=(.06,.06,0.)));self.assertNotIn('A',self.f.power_evidence)
        self.observe(packet(100_000_000,torques=(0.,.06,0.)))
        self.assertEqual(self.f.power_evidence['A']['mode'],'POWER_OFF_AFTER_SERVICE_NOT_TASK_SUCCESS')
        self.assertNotIn('A',self.f.confirmed)

    def test_unsupported_negative_torque_is_not_power_off(self):
        r=Reservation(1,'A','A_stop',0,0,50_000_000)
        self.l.ingest(frame(self.c,50_000_000,acks=[Ack(1,'A','A_stop',50_000_000)],reservations=[r]))
        self.observe(packet(100_000_000,torques=(-.01,.06,0.)))
        self.assertEqual(self.f.power_evidence['A']['mode'],'UNSUPPORTED_PUBLIC_CONTROL_AFTER_SERVICE')

    def anchor_for_tail(self):
        self.f.original_B=ObservedEvent(400_000_000,450_000_000,550_000_000);self.f.reference=self.f.original_B
        self.f.stops={'A':{'bounds_ns':[2_300_000_000,2_350_000_000]},'C':{'bounds_ns':[3_200_000_000,3_250_000_000]}}
        self.f.confirmed={'A':{},'C':{}}

    def test_B_unsupported_control_definite_inner_failure(self):
        self.anchor_for_tail();self.observe(packet(1_000_000_000,torques=(0.,.04,0.)))
        self.assertEqual(self.f.verdict()['B_maintenance_verdict'],'FALSE')
        self.assertFalse(self.f.verdict()['B_public_control_profile'])

    def test_B_ambiguous_tail_not_definite_failure(self):
        self.anchor_for_tail();self.observe(packet(6_450_000_000,torques=(0.,.04,0.)))
        self.assertEqual(self.f.verdict()['B_maintenance_verdict'],'UNKNOWN')
        self.assertFalse(self.f.verdict()['B_sampled_maintenance'])

    def test_B_after_contract_tail_does_not_invalidate_original_interval(self):
        self.anchor_for_tail();self.observe(packet(6_500_000_000,torques=(0.,.04,0.)))
        self.assertTrue(self.f.B_control_samples);self.assertEqual(self.f.B_public_failures,[])


class LifecycleTests(unittest.TestCase):
    def test_paid_ready_rejects_changed_public_calendar_all_four(self):
        short=run_fixture(PROTO,CASE,'strong_batch',horizon_ns=560_000_000)
        for method in METHODS:
            a=make_controller(method,contract())
            for row in short['inputs']:a.advance(decode_input(a.contract,row))
            self.assertIsNotNone(a.pending);self.assertEqual(a.pending['ready_ns'],580_000_000)
            old=decode_input(a.contract,short['inputs'][-1]);new=Reservation(99,'B','public_new_busy',570_000_000,700_000_000,1_600_000_000,True)
            a.advance(frame(a.contract,570_000_000,old.latest,reservations=old.reservations+(new,)))
            a.advance(frame(a.contract,580_000_000,old.latest,reservations=old.reservations+(new,)))
            self.assertFalse(a.initial_committed)
            self.assertTrue(any('STALE_PAID' in t['event'] for t in a.transactions))
            self.assertEqual(a.ledger.counts,{'A':0,'C':0})

    def test_hsm_same_prior_removes_only_unissued_retry_and_persistent_no_third(self):
        case=PROTO['cases'][2]
        for fault,want in [('none',1),('first_A_stop_drop',2),('persistent_A_power',2)]:
            r=run_fixture(PROTO,case,'guarded_hsm_retry',fault)
            self.assertIsNone(r['error']);self.assertEqual(sum(x['request']['target']=='A' for x in r['commands']),want)
            if fault=='persistent_A_power':self.assertNotEqual(r['controller']['phase'],'DONE_PUBLIC_CONDITIONAL')

    def test_actual_lifecycles_differ_without_weakening_batch(self):
        case=PROTO['cases'][3];runs={m:run_fixture(PROTO,case,m,'none',extra_resource=True) for m in METHODS}
        for r in runs.values():self.assertIsNone(r['error']);self.assertTrue(r['synthetic_model_contract_pass'])
        batch=runs['strong_batch']['controller'];self.assertEqual(len(batch['decisions']),1)
        edf=runs['event_resource_edf'];initial=next(a['submit_ns'] for a in edf['controller']['decisions'][0]['selected_plan']['actions'] if a['target']=='C')
        actual=next(x['request']['request_ns'] for x in edf['commands'] if x['request']['target']=='C')
        self.assertNotEqual(initial,actual)
        mpc=runs['joint_interval_mpc']['controller']
        self.assertTrue(all(x['prefix_only'] for x in mpc['transactions'] if x['event']=='PAID_PROGRAM_COMMITTED'))
        self.assertGreater(len(mpc['decisions']),1)

    def test_B_unsupported_control_visible_negative_software_trace(self):
        r=run_fixture(PROTO,CASE,'strong_batch',unsupported_B_torque=.04)
        self.assertIsNone(r['error']);self.assertNotEqual(r['controller']['phase'],'DONE_PUBLIC_CONDITIONAL')
        self.assertEqual(r['controller']['facts']['public_verdict']['B_maintenance_verdict'],'FALSE')


if __name__=='__main__':unittest.main()
