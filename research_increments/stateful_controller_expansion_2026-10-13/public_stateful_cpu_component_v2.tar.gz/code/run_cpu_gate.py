"""Write-once terminal CPU artifacts, all denominators retained; no native run."""
import argparse
from dataclasses import asdict
import gzip
import hashlib
import io
import json
from pathlib import Path
import platform
import tarfile
import time
import unittest
from controller_contract import PublicFrame
from public_types import Packet
from request_ledger import RequestLedger
from temporal_facts import PublicFacts
from stateful_controllers import METHODS
from cpu_public_fixture import load_protocol, build_contract, run_fixture

ROOT=Path(__file__).resolve().parents[1]


def sha(data):return hashlib.sha256(data).hexdigest()


def save(path,value):
    data=(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(data)
    return {'path':str(path.relative_to(ROOT)),'bytes':len(data),'sha256':sha(data)}


def save_gzip(path,value):
    raw=(json.dumps(value,sort_keys=True,allow_nan=False,separators=(',',':'))+'\n').encode()
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:
        with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as g:g.write(raw)
    data=path.read_bytes()
    if gzip.decompress(data)!=raw:raise AssertionError('gzip reopen byte mismatch')
    return {'path':str(path.relative_to(ROOT)),'bytes':len(data),'sha256':sha(data),'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(raw),'reopen_exact':True}


def validate_pin(path):
    pin=json.loads(path.read_text())
    for name,expected in pin['files'].items():
        if sha((ROOT/name).read_bytes())!=expected:raise ValueError('source pin mismatch: '+name)
    return sha(path.read_bytes())


def software_matrix(out,protocol):
    rows=[]
    for case in protocol['cases']:
        for method in METHODS:
            for fault in ('none','first_A_stop_drop'):
                case_id=case['id']+'__'+method+'__'+fault
                start=time.perf_counter_ns()
                try:r=run_fixture(protocol,case,method,fault)
                except Exception as e:
                    r={'case_id':case['id'],'method':method,'fixture_fault':fault,'error':{'type':type(e).__name__,'message':str(e)},
                       'role':'SYNTHETIC_PUBLIC_SOFTWARE_LIFECYCLE_FIXTURE_NOT_NATIVE_OR_FORMAL32','new_native_episodes':0}
                artifact=save_gzip(out/'software_matrix'/(case_id+'.json.gz'),r)
                c=r.get('controller',{});ledger=c.get('ledger',{});counts=ledger.get('counts',{})
                budget=c.get('candidate_budget_epoch',0);per=[x['budget']['candidate_evaluations'] for x in c.get('decisions',[])]
                legal=r.get('error') is None and sum(counts.values())<=4 and all(v<=2 for v in counts.values()) and budget<=10000 and max(per or [0])<=1000
                row={'fixture_id':case_id,'case_id':case['id'],'method':method,'counterfactual_software_fault':fault,
                     'all_denominators_retained':True,'error':r.get('error'),'synthetic_model_contract_pass':r.get('synthetic_model_contract_pass',False),
                     'public_sampled_conditional_pass':c.get('phase')=='DONE_PUBLIC_CONDITIONAL','action_caps_and_candidate_budgets_pass':legal,
                     'requests':counts,'decisions':len(c.get('decisions',[])),'candidate_evaluations':budget,'max_decision_candidates':max(per or [0]),
                     'charged_decision_ns':c.get('charged_decision_time_ns',0),'measured_fixture_host_wall_ns':time.perf_counter_ns()-start,'trace':artifact,
                     'new_native_episodes':0,'real_robot_episodes':0,'chemical_endpoints':0,'source_referee_full_recovery_joint_inferred':False}
                rows.append(row)
    return rows


def public_replay(out,protocol,bundle,expected_sha):
    data=bundle.read_bytes()
    if sha(data)!=expected_sha:raise ValueError('recorded source bundle sha mismatch')
    rows=[];cases={c['id']:c for c in protocol['cases']}
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
        members=sorted(x for x in t.getnames() if x.endswith('/public_deliveries.json'))
        if len(members)!=8:raise ValueError('retain exact eight recorded public packet members')
        for name in members:
            # The only opened archive members are public_deliveries.json.
            raw=t.extractfile(name).read();packets=json.loads(raw);case_id=Path(name).parent.name
            c=build_contract(protocol,cases[case_id]);facts=PublicFacts(c);ledger=RequestLedger(c);error=None
            for p in packets:
                try:
                    if set(p)!={'capture_ns','arrival_ns','positions','velocities','torques'}:raise ValueError('recorded public schema')
                    p=Packet(p['capture_ns'],p['arrival_ns'],tuple(p['positions']),tuple(p['velocities']),tuple(p['torques']))
                    frame=PublicFrame(c.epoch,p.arrival_ns,p,(),());frame.validate(c);facts.observe(frame,ledger)
                except Exception as e:error={'type':type(e).__name__,'message':str(e)};break
            snapshot=facts.snapshot()
            record={'role':'COPY_ONLY_RECORDED_PUBLIC_OBSERVER_CONFORMANCE_NOT_NEW_CLOSED_LOOP_POLICY',
                'case_id':case_id,'source_bundle_sha256':expected_sha,'source_member':name,'source_member_sha256':sha(raw),
                'packet_count':len(packets),'public_packets':packets,'error':error,'facts':snapshot,
                'new_policy_actions_executed':0,'new_native_episodes':0,'GPU':0,'fit':0,'private_scores_or_effects_read':False}
            artifact=save_gzip(out/'recorded_public_replay'/(case_id+'.json.gz'),record)
            rows.append({'case_id':case_id,'packet_count':len(packets),'error':error,'original_B':snapshot['original_B'],
                'reference':snapshot['reference'],'public_sampled_conditional_pass':snapshot['public_verdict']['status']=='PASS_CONDITIONAL_PUBLIC_SAMPLED_PROTOCOL',
                'source_member_sha256':sha(raw),'trace':artifact,'new_native_episodes':0,'new_policy_actions_executed':0})
    return rows


def software_stress(out,protocol):
    specs=[('calendar_change',protocol['cases'][3],m,'none',{'extra_resource':True}) for m in METHODS]
    specs += [('persistent_A_power',protocol['cases'][2],m,'persistent_A_power',{}) for m in METHODS]
    specs += [('B_control_unsupported',protocol['cases'][0],m,'first_A_stop_drop',{'unsupported_B_torque':.04}) for m in METHODS]
    rows=[]
    for kind,case,method,fault,kwargs in specs:
        try:r=run_fixture(protocol,case,method,fault,**kwargs)
        except Exception as e:r={'error':{'type':type(e).__name__,'message':str(e)},'case_id':case['id'],'method':method,'new_native_episodes':0}
        artifact=save_gzip(out/'software_stress'/(kind+'__'+method+'.json.gz'),r)
        c=r.get('controller',{});counts=c.get('ledger',{}).get('counts',{})
        want=(c.get('phase')=='DONE_PUBLIC_CONDITIONAL') if kind=='calendar_change' else (c.get('phase')!='DONE_PUBLIC_CONDITIONAL')
        rows.append({'kind':kind,'method':method,'case_id':case['id'],'error':r['error'],'expected_behavior_pass':r['error'] is None and want and counts.get('A',0)<=2 and counts.get('C',0)<=2 and sum(counts.values())<=4,
            'phase':c.get('phase'),'requests':counts,'candidate_evaluations':c.get('candidate_budget_epoch',0),'trace':artifact,'canonical_scenario_changed':False,'new_native_episodes':0})
    return rows


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--pin',required=True)
    p.add_argument('--recorded-public-bundle',required=True);p.add_argument('--recorded-public-bundle-sha256',required=True);args=p.parse_args()
    out=Path(args.output).resolve()
    if out.exists():raise FileExistsError('write-once gate output already exists')
    out.relative_to(ROOT/'cpu_outputs');pin_sha=validate_pin(Path(args.pin));out.mkdir(parents=True)
    start=time.perf_counter_ns();stream=io.StringIO();suite=unittest.defaultTestLoader.discover(str(ROOT/'code'),pattern='test_stateful_lifecycle.py')
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    save(out/'UNIT_TESTS.json',{'tests_run':result.testsRun,'failures':[{'test':str(t),'traceback':s} for t,s in result.failures],
        'errors':[{'test':str(t),'traceback':s} for t,s in result.errors],'pass':result.wasSuccessful(),'output':stream.getvalue(),'new_native_episodes':0})
    protocol=load_protocol();matrix=software_matrix(out,protocol);replay=public_replay(out,protocol,Path(args.recorded_public_bundle),args.recorded_public_bundle_sha256)
    stress=software_stress(out,protocol)
    bymethod=[]
    for method in METHODS:
        rows=[r for r in matrix if r['method']==method]
        bymethod.append({'method':method,'software_fixture_denominator':len(rows),'errors':sum(r['error'] is not None for r in rows),
            'synthetic_model_contract_pass':sum(r['synthetic_model_contract_pass'] for r in rows),
            'public_sampled_conditional_pass':sum(r['public_sampled_conditional_pass'] for r in rows),
            'budget_and_action_caps_pass':sum(r['action_caps_and_candidate_budgets_pass'] for r in rows),
            'candidate_evaluations_range':[min(r['candidate_evaluations'] for r in rows),max(r['candidate_evaluations'] for r in rows)],
            'decisions_range':[min(r['decisions'] for r in rows),max(r['decisions'] for r in rows)],
            'requests_A_range':[min(r['requests'].get('A',0) for r in rows),max(r['requests'].get('A',0) for r in rows)]})
    success=result.wasSuccessful() and len(matrix)==64 and all(r['synthetic_model_contract_pass'] and r['public_sampled_conditional_pass'] and r['action_caps_and_candidate_budgets_pass'] for r in matrix)
    success=success and len(replay)==8 and all(r['error'] is None and r['public_sampled_conditional_pass'] for r in replay) and all(r['expected_behavior_pass'] for r in stress)
    if validate_pin(Path(args.pin))!=pin_sha:raise AssertionError('source changed during gate')
    save(out/'FULL_ROSTER_RESULTS.json',{'software_matrix':matrix,'recorded_public_replay':replay,'software_stress':stress,'all_failures_retained':True,'formal32':0,'new_native_episodes':0})
    summary={'schema':'paperb-public-stateful-cpu-gate-v1','status':'PASS_CPU_COMPONENT_ONLY' if success else 'FAIL_CPU_COMPONENT_RETAINED',
        'source_pin_sha256':pin_sha,'python':platform.python_version(),'unit_tests':result.testsRun,'unit_tests_pass':result.wasSuccessful(),
        'software_matrix_denominator':len(matrix),'software_matrix':bymethod,'recorded_public_observer_replays':len(replay),
        'recorded_public_observer_pass':sum(r['error'] is None and r['public_sampled_conditional_pass'] for r in replay),
        'software_stress_denominator':len(stress),'software_stress_expected_behavior_pass':sum(r['expected_behavior_pass'] for r in stress),
        'all_cases_retained':True,'strong_batch_already_solves_all_software_cases':all(r['synthetic_model_contract_pass'] for r in matrix if r['method']=='strong_batch'),
        'agentic_necessity_or_advantage_supported':False,'measured_gate_host_wall_ns':time.perf_counter_ns()-start,
        'scope':{'new_native_episodes':0,'GPU':0,'fit':0,'new_weights':0,'formal_native32':0,'real_robot_episodes':0,'chemical_endpoints':0,'heldout':False,'old_sources_modified':False,
            'public_replay_is_new_policy_closed_loop':False,'software_none_branch_is_full_source_referee_joint':False,'conditional_model_is_true_support':False}}
    save(out/'CPU_GATE.json',summary)
    artifacts={str(x.relative_to(out)):sha(x.read_bytes()) for x in sorted(out.rglob('*')) if x.is_file()}
    save(out/'ARTIFACT_MANIFEST.json',{'schema':'paperb-stateful-cpu-artifact-manifest-v1','files':artifacts,'source_pin_sha256':pin_sha,'all_readback_sha256_verified':True})
    print(json.dumps(summary,indent=2));return 0 if success else 1


if __name__=='__main__':raise SystemExit(main())
