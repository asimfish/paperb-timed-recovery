"""Data-only public ABI. No scene, fault instance, referee or getter enters."""
from dataclasses import dataclass
import json
import math
from public_types import Packet,Ack,Reservation


def plain(value,depth=0,counter=None):
    if counter is None:counter=[0]
    counter[0]+=1
    if depth>8 or counter[0]>4096:raise ValueError('bounded public data depth/size')
    if type(value) is str:
        if len(value)>4096:raise ValueError('bounded public string')
        return
    if type(value) in (int,bool,type(None)):return
    if type(value) is float:
        if not math.isfinite(value):raise ValueError('nonfinite public value')
        return
    if type(value) in (tuple,list):
        for x in value:plain(x,depth+1,counter)
        return
    if type(value) is dict:
        for k,v in value.items():
            if type(k) is not str:raise TypeError('public keys are strings')
            plain(v,depth+1,counter)
        return
    raise TypeError('plain data only, never native wrappers/getters')


@dataclass(frozen=True)
class Contract:
    epoch:str
    dt_ns:int
    charged_decision_ns:int
    sensor_period_ns:int
    sensor_lag_ns:int
    public_json:str
    resource_json:str

    @classmethod
    def create(cls,epoch,public,resource,dt_ns=10_000_000,sensor_period_ns=50_000_000,sensor_lag_ns=100_000_000):
        if type(public) is not dict or type(resource) is not dict:raise TypeError('plain public maps only')
        plain(public);plain(resource)
        allowed={'D_C_ns','eps_C_ns','A_window_ns','graph_edges','minimum_edge_gap_ns','public_nominal_model',
            'maximum_candidates_per_decision','maximum_candidates_epoch','max_requests_A_C','max_requests_per_rotor',
            'calibrated_prediction_residual_ns','original_B_angle','moving_threshold','stop_hold_ns','B_maintenance_ns',
            'model_scope','initial_torque','recoverable_fault_hypotheses','current_private_fault_given_to_actor','blind_redundant_stop_allowed_all_arms'}
        if set(public)-allowed or set(resource)-{'capacity','services_ns','B_reservation'}:raise ValueError('unknown/private actor input')
        if public.get('current_private_fault_given_to_actor',False):raise ValueError('current private fault is forbidden')
        if public.get('recoverable_fault_hypotheses',['none','first_A_stop_drop'])!=['none','first_A_stop_drop']:
            raise ValueError('this conditional prototype implements the declared none/single-first-A-drop prior')
        for m in (public['public_nominal_model'],resource['services_ns'],resource['B_reservation']):
            if type(m) is not dict:raise TypeError('no nested getters/native wrappers')
        b=resource['B_reservation']
        if set(b)!={'request_ns','service_start_ns','service_end_ns','tag','torque_after_ACK'}:raise ValueError('exact public B reservation fields; private metadata forbidden')
        if any(type(b[k]) is not int for k in ('request_ns','service_start_ns','service_end_ns')) or type(b['tag']) is not str:
            raise ValueError('plain public B reservation')
        if public['initial_torque']!=.06 or b['torque_after_ACK']!=.045:raise ValueError('unchanged declared B public control profile')
        model=public['public_nominal_model']
        if set(model)!={'inertia','damping'} or any(type(x) not in (int,float) or not math.isfinite(x) or x<=0 for x in model.values()):raise ValueError('public scalar model only')
        if resource['capacity']!=1 or set(resource['services_ns'])!={'A_stop','C_stop'}:raise ValueError('one nonpreemptive public server')
        if any(type(x) is not int or x<=0 for x in resource['services_ns'].values()):raise ValueError('positive service durations')
        if type(epoch) is not str or not epoch or type(dt_ns) is not int or dt_ns<=0:raise ValueError('public episode identity/grid')
        if type(sensor_period_ns) is not int or type(sensor_lag_ns) is not int or sensor_period_ns<=0 or sensor_lag_ns<0 or sensor_period_ns%dt_ns:raise ValueError('public sensor schedule')
        if public['moving_threshold']!=.1 or public['original_B_angle']!=2.:raise ValueError('unchanged scalar predictor threshold scope')
        if public['maximum_candidates_per_decision']!=1000 or public['maximum_candidates_epoch']!=10000 or public['max_requests_A_C']!=4 or public['max_requests_per_rotor']!=2:
            raise ValueError('the common frozen candidate/action budgets are not tunable here')
        if not (0<=b['request_ns']<=b['service_start_ns']<b['service_end_ns']) or b['tag']!='B_reserved_drive_change':raise ValueError('public B service chronology/profile')
        for key in ('D_C_ns','eps_C_ns','minimum_edge_gap_ns','stop_hold_ns','B_maintenance_ns'):
            if type(public[key]) is not int or public[key]<0:raise ValueError('integer nonnegative public time')
        if public['stop_hold_ns']!=200_000_000 or public['B_maintenance_ns']!=6_000_000_000:raise ValueError('unchanged confirmation/maintenance contract')
        window=public['A_window_ns'];error=public.get('calibrated_prediction_residual_ns',[0,0])
        for bounds in (window,error):
            if type(bounds) not in (list,tuple) or len(bounds)!=2 or any(type(x) is not int for x in bounds) or bounds[0]>bounds[1]:raise ValueError('ordered public nanosecond pair')
        if type(public['graph_edges']) not in (list,tuple) or list(map(list,public['graph_edges'])) not in ([['A','C']],[['C','A']]):raise ValueError('one declared public temporal edge')
        p=json.dumps(public,sort_keys=True,allow_nan=False);r=json.dumps(resource,sort_keys=True,allow_nan=False)
        return cls(epoch,dt_ns,2*dt_ns,sensor_period_ns,sensor_lag_ns,p,r)

    @property
    def public(self):return json.loads(self.public_json)

    @property
    def resource(self):return json.loads(self.resource_json)


@dataclass(frozen=True)
class PublicFrame:
    epoch:str
    now_ns:int
    latest:Packet|None
    acks:tuple
    reservations:tuple

    def validate(self,contract):
        if set(vars(self))!={'epoch','now_ns','latest','acks','reservations'}:raise ValueError('unknown frame metadata')
        if type(self.epoch) is not str:raise TypeError('plain epoch identity before comparison')
        if self.epoch!=contract.epoch:raise ValueError('epoch change cannot reset an actor or its original anchor')
        if type(self.now_ns) is not int or self.now_ns<0 or type(self.acks) is not tuple or type(self.reservations) is not tuple:raise TypeError('plain public frame')
        if self.latest is not None:
            if type(self.latest) is not Packet or set(vars(self.latest))!={'capture_ns','arrival_ns','positions','velocities','torques'}:raise ValueError('exact packet fields')
            if type(self.latest) is not Packet or type(self.latest.capture_ns) is not int or type(self.latest.arrival_ns) is not int or not (0<=self.latest.capture_ns<=self.latest.arrival_ns<=self.now_ns):raise ValueError('causal exact public Packet')
            for vector in (self.latest.positions,self.latest.velocities,self.latest.torques):
                if type(vector) is not tuple or len(vector)!=3 or any(type(x) not in (int,float) or not math.isfinite(x) for x in vector):raise ValueError('finite three-axis packet data only')
        if len(self.acks)>128 or len(self.reservations)>128:raise ValueError('bounded public transport history')
        for a in self.acks:
            if type(a) is not Ack or set(vars(a))!={'seq','target','tag','ack_ns'}:raise ValueError('unknown ACK metadata')
            if type(a) is not Ack or any(type(x) is not int for x in (a.seq,a.ack_ns)) or type(a.target) is not str or type(a.tag) is not str or not (a.seq>=0 and 0<=a.ack_ns<=self.now_ns) or a.target not in ('A','B','C'):raise ValueError('plain ACK has not arrived')
        for r in self.reservations:
            if type(r) is not Reservation or set(vars(r))!={'seq','target','tag','request_ns','service_start_ns','ack_ns','external'}:raise ValueError('unknown reservation metadata')
            if type(r) is not Reservation or any(type(x) is not int for x in (r.seq,r.request_ns,r.service_start_ns,r.ack_ns)) or type(r.target) is not str or type(r.tag) is not str or type(r.external) is not bool:
                raise TypeError('plain reservation data')
            if r.seq<0 or r.request_ns>self.now_ns or not (0<=r.request_ns<=r.service_start_ns<=r.ack_ns):raise ValueError('causal accepted reservation')
            if r.target not in ('A','B','C') or (r.external!=(r.target=='B')):raise ValueError('only B is an external reservation in this ABI')


def legacy_public(contract):
    """Only the public fields supported by the unchanged initial math module."""
    keys={'D_C_ns','eps_C_ns','A_window_ns','graph_edges','minimum_edge_gap_ns','public_nominal_model',
        'maximum_candidates_per_decision','maximum_candidates_epoch','max_requests_A_C','max_requests_per_rotor',
        'calibrated_prediction_residual_ns','original_B_angle','moving_threshold','stop_hold_ns','B_maintenance_ns','model_scope','initial_torque'}
    return {k:v for k,v in contract.public.items() if k in keys}
