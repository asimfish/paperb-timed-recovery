"""Causal public facts, immutable first B event, onset versus confirmation."""
from dataclasses import asdict
import math
from public_types import ObservedEvent
from initial_public_math import conditional_original_event


class PublicFacts:
    def __init__(self,contract):
        self.contract=contract;self.latest=None;self.previous=None;self.original_B=None;self.reference=None
        self.refinement=None;self.stops={};self.confirmed={};self.public_history=[];self.revision=0
        self.B_moving_samples=True;self.last_now=-1;self.power_evidence={};self.model_residuals=[]

    def observe(self,frame,ledger):
        if frame.now_ns<self.last_now:raise ValueError('actor time cannot rewind')
        self.last_now=frame.now_ns;p=frame.latest
        if p is None:return False
        if self.latest is not None and p.capture_ns==self.latest.capture_ns:
            if p!=self.latest:raise ValueError('same capture identity changed')
            return self._power_evidence(ledger)
        if self.latest is not None and p.capture_ns<self.latest.capture_ns:raise ValueError('late older capture cannot replace history')
        previous=self.latest;self.previous=previous;self.latest=p;self.public_history.append(p);self.revision+=1
        cfg=self.contract.public;dt=self.contract.dt_ns
        if previous is not None:
            if self.original_B is None and previous.positions[1]<cfg['original_B_angle']<=p.positions[1] and abs(previous.velocities[1])>cfg['moving_threshold']:
                self.original_B=ObservedEvent(previous.capture_ns,p.capture_ns,p.arrival_ns)
                self.reference,self.refinement=conditional_original_event(previous,p,self.original_B,cfg['public_nominal_model'],dt)
            for axis,target in ((0,'A'),(2,'C')):
                if target not in self.stops and abs(previous.velocities[axis])>cfg['moving_threshold']>=abs(p.velocities[axis]) and p.torques[axis]==0:
                    bounds=[previous.capture_ns,p.capture_ns];kind='PUBLIC_SAMPLED_STOP_CROSSING'
                    if previous.torques[axis]==0:
                        model=cfg['public_nominal_model'];decay=model['inertia']/(model['inertia']+dt/1e9*model['damping'])
                        q,v=previous.positions[axis],previous.velocities[axis];cross=None
                        for t in range(previous.capture_ns+dt,p.capture_ns+dt,dt):
                            old=v;v*=decay;q+=v*dt/1e9
                            if cross is None and abs(old)>cfg['moving_threshold']>=abs(v):cross=[t-dt,t]
                        residual=max(abs(v-p.velocities[axis]),abs(q-p.positions[axis]));self.model_residuals.append(residual)
                        if residual<=1e-9 and cross:bounds=cross;kind='SAME_STOP_CONDITIONAL_PUBLIC_MODEL'
                    self.stops[target]={'bounds_ns':bounds,'kind':kind,'first_arrival_ns':p.arrival_ns,'source_capture_bounds_ns':[previous.capture_ns,p.capture_ns]}
                if target in self.stops:
                    if abs(p.velocities[axis])>cfg['moving_threshold'] or p.torques[axis]!=0:
                        # Retain the original observation; never silently choose
                        # a later successful stop event after a violated hold.
                        self.stops[target]['sampled_hold_violated']=True
                    elif p.capture_ns>=self.stops[target]['bounds_ns'][1]+cfg['stop_hold_ns'] and not self.stops[target].get('sampled_hold_violated'):
                        self.confirmed.setdefault(target,{'confirmation_capture_ns':p.capture_ns,'confirmation_arrival_ns':p.arrival_ns,
                            'onset':self.stops[target],'continuous_native_hold_independently_verified':False})
        if self.original_B is not None and p.capture_ns>=self.original_B.upper_ns and abs(p.velocities[1])<=cfg['moving_threshold']:
            self.B_moving_samples=False
        self._power_evidence(ledger)
        return True

    def _power_evidence(self,ledger):
        changed=False
        if self.latest is None:return False
        for target,axis in (('A',0),('C',2)):
            acks=[a for a in ledger.acks.values() if a.target==target]
            if not acks:continue
            a=max(acks,key=lambda a:a.ack_ns)
            if self.latest.capture_ns<a.ack_ns+self.contract.dt_ns:continue
            mode='POWERED_AFTER_SERVICE' if self.latest.torques[axis]>0 else 'POWER_OFF_AFTER_SERVICE_NOT_TASK_SUCCESS'
            record={'mode':mode,'ACK_seq':a.seq,'ACK_ns':a.ack_ns,'packet_capture_ns':self.latest.capture_ns,'packet_arrival_ns':self.latest.arrival_ns}
            previous=self.power_evidence.get(target)
            if previous is None or (previous['mode'],previous['ACK_seq'])!=(mode,a.seq):changed=True
            self.power_evidence[target]=record
        return changed

    def verdict(self):
        cfg=self.contract.public;ref=self.reference
        if ref is None or set(self.confirmed)!={'A','C'}:return {'status':'PUBLIC_EFFECTS_OR_CONFIRMATION_PENDING','raw_referee_acceptance_inferred':False}
        A=self.stops['A']['bounds_ns'];C=self.stops['C']['bounds_ns'];D=cfg['D_C_ns'];eps=cfg['eps_C_ns']
        fits=lambda b,w:b[0]-ref.upper_ns>=w[0] and b[1]-ref.lower_ns<=w[1]
        graph=all((self.stops[y]['bounds_ns'][0]-self.stops[x]['bounds_ns'][1]>=cfg['minimum_edge_gap_ns']) for x,y in cfg['graph_edges'])
        maintenance=self.latest.capture_ns>=ref.upper_ns+cfg['B_maintenance_ns'] and self.B_moving_samples
        timing=fits(A,cfg['A_window_ns']) and fits(C,[D-eps,D+eps]) and graph
        return {'status':'PASS_CONDITIONAL_PUBLIC_SAMPLED_PROTOCOL' if timing and maintenance else 'PUBLIC_TIMING_OR_MAINTENANCE_UNRESOLVED_OR_FALSE',
            'A_window':fits(A,cfg['A_window_ns']),'C_window':fits(C,[D-eps,D+eps]),'graph_gap':graph,
            'B_sampled_maintenance':maintenance,'raw_referee_acceptance_inferred':False,'original_B_identity':asdict(self.original_B),
            'reference':asdict(ref),'original_onset_not_confirmation_used':True,'conditional_model_not_true_support':True}

    def snapshot(self):
        return {'original_B':asdict(self.original_B) if self.original_B else None,'reference':asdict(self.reference) if self.reference else None,
            'refinement':self.refinement,'stops':self.stops,'confirmed':self.confirmed,'power_evidence':self.power_evidence,
            'public_verdict':self.verdict(),'revision':self.revision}
