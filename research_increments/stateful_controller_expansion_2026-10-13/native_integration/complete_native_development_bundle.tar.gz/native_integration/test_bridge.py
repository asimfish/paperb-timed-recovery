"""Pure bridge/public-contract tests. No MuJoCo import, model or epoch."""
import ast
import json
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace
import bridge


class FakeVector:
    def __init__(self,values):self.values=values
    def copy(self):return FakeVector(list(self.values))
    def tolist(self):return list(self.values)
    def __getitem__(self,i):return self.values[i]


class BridgeTests(unittest.TestCase):
    def spec(self):return bridge.configure_fixed_case()

    def test_exact_original_files_and_parent_pin_are_preserved(self):
        p=bridge.read_json(bridge.HERE/'PROTOCOL.json')
        for name,want in p['unchanged_origins'].items():self.assertEqual(bridge.sha(bridge.HERE/'origin_exact'/name),want)
        self.assertEqual(bridge.sha(bridge.ROOT/'SOURCE_RELEASE_CANDIDATE_V2.json'),bridge.CPU_SHA)
        for name,want in bridge.read_json(bridge.ROOT/'SOURCE_RELEASE_CANDIDATE_V2.json')['files'].items():self.assertEqual(bridge.sha(bridge.ROOT/name),want)

    def test_fixed_private_case_and_public_input_separation(self):
        spec=self.spec();p=bridge.read_json(bridge.HERE/'PROTOCOL.json');c=bridge.public_contract(spec,p)
        self.assertEqual(spec['case_id'],bridge.CASE_ID);self.assertEqual(spec['private_plant']['fault'],'first_A_stop_drop')
        self.assertEqual(c.public['recoverable_fault_hypotheses'],['none','first_A_stop_drop'])
        self.assertNotIn('private_plant',c.public);self.assertNotIn('fault',c.public)
        self.assertFalse(c.public['current_private_fault_given_to_actor']);self.assertEqual(c.charged_decision_ns,20_000_000)
        self.assertEqual(c.resource['B_reservation']['service_end_ns'],1_100_000_000)

    def admission(self):
        sha='a'*64
        return {'schema':'paperb-single-native-root-admission-v1','approved':True,'bridge_release_sha256':sha,
            'cpu_source_pin_sha256':bridge.CPU_SHA,'case_id':bridge.CASE_ID,'method':bridge.METHOD,
            'maximum_controlled_native_epochs':1,'GPU':0,'formal_native32':0}, {
            'status':'PASS_NATIVE_BRIDGE_SOURCE_REVIEW','bridge_release_sha256':sha,'cpu_source_pin_sha256':bridge.CPU_SHA},sha

    def test_same_source_exact_root_and_independent_receipts_required(self):
        a,r,h=self.admission();bridge.validate_admission(a,r,h)
        for k,v in [('approved',False),('maximum_controlled_native_epochs',2),('maximum_controlled_native_epochs',True),('GPU',1),('formal_native32',32),('case_id','different'),('method','joint_interval_mpc'),('bridge_release_sha256','b'*64)]:
            bad=dict(a);bad[k]=v
            with self.assertRaises(ValueError):bridge.validate_admission(bad,r,h)
        for k,v in [('status','PENDING'),('bridge_release_sha256','b'*64),('cpu_source_pin_sha256','b'*64)]:
            bad=dict(r);bad[k]=v
            with self.assertRaises(ValueError):bridge.validate_admission(a,bad,h)

    def test_actual_native_clock_not_nominal_clock_substitution(self):
        self.assertEqual(bridge.native_now(SimpleNamespace(time=.010000000000000001),1,10_000_000),(10_000_000,.010000000000000001))
        with self.assertRaises(RuntimeError):bridge.native_now(SimpleNamespace(time=.009),1,10_000_000)

    def test_public_sensor_dto_copies_actual_values_not_driver_wrapper(self):
        data=SimpleNamespace(qpos=FakeVector([1.,2.,3.]),qvel=FakeVector([4.,5.,6.]),ctrl=FakeVector([.06,.045,0.]))
        packet=bridge.capture_packet(data,500_000_000,100_000_000)
        self.assertEqual(packet.capture_ns,500_000_000);self.assertEqual(packet.arrival_ns,600_000_000)
        self.assertEqual(packet.positions,(1.,2.,3.));data.qpos.values[0]=99
        self.assertEqual(packet.positions,(1.,2.,3.));self.assertEqual(set(vars(packet)),{'capture_ns','arrival_ns','positions','velocities','torques'})

    def test_dense_raw_sample_keeps_measured_clock_and_actual_controls(self):
        data=SimpleNamespace(qpos=[1.,2.,3.],qvel=[4.,5.,6.],ctrl=[.06,.045,0.])
        row=bridge.raw_sample(data,500_000_000,.50000000001)
        self.assertEqual(row['native_time_s'],.50000000001);self.assertEqual(row['B_ctrl_next'],.045);self.assertEqual(row['epoch'],0)

    def test_actual_server_and_action_budget_audit_not_actor_flags(self):
        external=dict(seq=0,target='B',external=True,service_start_ns=650_000_000,ack_ns=1_100_000_000)
        commands=[external,dict(seq=1,target='A',external=False,service_start_ns=550_000_000,ack_ns=600_000_000)]
        self.assertEqual(bridge.audit_commands(commands),{'A':1,'C':0})
        overlap=commands+[dict(seq=2,target='C',external=False,service_start_ns=700_000_000,ack_ns=1_150_000_000)]
        with self.assertRaises(RuntimeError):bridge.audit_commands(overlap)
        oversend=[dict(seq=i,target='A',external=False,service_start_ns=i*50_000_000,ack_ns=(i+1)*50_000_000) for i in range(3)]
        with self.assertRaises(RuntimeError):bridge.audit_commands(oversend)

    def test_partial_streams_flush_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d);stream=bridge.Streams(path);stream.append('inputs.jsonl',{'now_ns':0});stream.sample({'sim_ns':0,'native_time_s':0.})
            self.assertEqual(json.loads((path/'inputs.jsonl').read_text()),{'now_ns':0});self.assertIn('0,0.0',(path/'independent_samples.csv').read_text())
            stream.close();self.assertEqual(stream.counts,{'inputs.jsonl':1,'independent_samples.csv':1})
            with self.assertRaises(FileExistsError):bridge.Streams(path).append('inputs.jsonl',{'now_ns':1})

    def test_native_import_and_step_only_inside_explicit_admitted_run(self):
        tree=ast.parse((bridge.HERE/'bridge.py').read_text());functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
        for n in tree.body:
            if isinstance(n,ast.Import):self.assertNotIn('mujoco',[x.name for x in n.names])
            if isinstance(n,ast.ImportFrom):self.assertNotIn(n.module,('plant','referee'))
        for name,f in functions.items():
            if name=='run':continue
            for n in ast.walk(f):
                if isinstance(n,ast.Import):self.assertNotIn('mujoco',[x.name for x in n.names])
                if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute):self.assertNotIn(n.func.attr,('mj_step','mj_forward'))
        text=(bridge.HERE/'bridge.py').read_text();self.assertLess(text.index('validate_admission(admission,review,release_sha)'),text.index('import mujoco'))
        self.assertEqual(text.count('model,data=create('),1)
        for n in ast.walk(tree):
            if isinstance(n,ast.Subscript) and isinstance(n.ctx,ast.Store) and isinstance(n.value,ast.Attribute):self.assertNotIn(n.value.attr,('qpos','qvel'))


if __name__=='__main__':unittest.main()
