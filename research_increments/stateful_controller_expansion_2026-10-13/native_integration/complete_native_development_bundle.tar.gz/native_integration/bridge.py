"""Single admitted development driver. Private native data stays in this file.

Import/check/test paths do not import or run MuJoCo. Execution requires the
sealed source hashes, an independent source-review receipt and root admission.
No CLI chooses a new case, controller, fault, epoch or output directory.
"""
import argparse
import csv
from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import signal
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'code'))
from controller_contract import Contract, PublicFrame
from public_types import Packet, Ack, ReservedChannel
from stateful_controllers import make_controller

CASE_ID='v2_diag-A_then_C-B45-D2p8'
METHOD='guarded_hsm_retry'
CPU_SHA='ea39d01ac8a884e9e8fb135a8a7e4bd5b9a7958d67fff4f4031dcef7bad0d800'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):return json.loads(path.read_text())


def write_json(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')


def verify_sources():
    cpu=ROOT/'SOURCE_RELEASE_CANDIDATE_V2.json'
    if sha(cpu)!=CPU_SHA:raise ValueError('wrong fixed public CPU source pin')
    for name,expected in read_json(cpu)['files'].items():
        if sha(ROOT/name)!=expected:raise ValueError('public CPU source changed: '+name)
    release=HERE/'SOURCE_RELEASE.json';manifest=read_json(release)
    for name,expected in manifest['files'].items():
        if sha(HERE/name)!=expected:raise ValueError('bridge source changed: '+name)
    p=read_json(HERE/'PROTOCOL.json')
    if p['case_id']!=CASE_ID or p['method']!=METHOD or p['maximum_controlled_native_epochs']!=1 or p['source_cpu_pin_sha256']!=CPU_SHA:
        raise ValueError('fixed one-case development protocol mismatch')
    for name,expected in p['unchanged_origins'].items():
        if sha(HERE/'origin_exact'/name)!=expected:raise ValueError('original native source changed')
    return sha(release),p


def configure_fixed_case():
    """Driver-only extraction. Private spec is never handed to the actor."""
    source=read_json(ROOT/'source_inputs/scenario_PROTOCOL_V2.json')
    cases=[c for c in source['cases'] if c['id']==CASE_ID]
    if len(cases)!=1:raise ValueError('one exact existing development case')
    case=cases[0];p=json.loads(json.dumps(source))
    p['case_id']=CASE_ID;p['public'].update(D_C_ns=case['D_C_ns'],A_window_ns=case['A_window_ns'],graph_edges=case['graph_edges'])
    p['public']['calibrated_prediction_residual_ns']=[0,0]
    b=p['resource']['B_reservation'];b['service_end_ns']=b['service_start_ns']+case['B_service_ns']
    if p['private_plant']!={'inertia':.002,'damping':.006,'fault':'first_A_stop_drop'}:raise ValueError('unchanged private native plant')
    if p['dt_ns']!=10_000_000 or p['horizon_ns']!=12_000_000_000 or p['charged_decision_ns']!=20_000_000:
        raise ValueError('unchanged native clock/charge')
    if p['public']['D_C_ns']!=2_800_000_000 or p['public']['graph_edges']!=[['A','C']] or case['B_service_ns']!=450_000_000:
        raise ValueError('fixed graph/resource/deadline, no selection')
    return p


def public_contract(spec,p):
    return Contract.create(p['public_epoch_identity'],spec['public'],spec['resource'],spec['dt_ns'],
        spec['dt_ns']*spec['sensor_period_ticks'],spec['sensor_lag_ns'])


def validate_admission(admission,review,release_sha):
    if type(admission) is not dict or type(review) is not dict:raise TypeError('plain admission/review receipts')
    required={'schema':'paperb-single-native-root-admission-v1','approved':True,'bridge_release_sha256':release_sha,
        'cpu_source_pin_sha256':CPU_SHA,'case_id':CASE_ID,'method':METHOD,'maximum_controlled_native_epochs':1,'GPU':0,'formal_native32':0}
    for k,v in required.items():
        if type(admission.get(k)) is not type(v) or admission[k]!=v:raise ValueError('root admission mismatch: '+k)
    if review.get('status')!='PASS_NATIVE_BRIDGE_SOURCE_REVIEW' or review.get('bridge_release_sha256')!=release_sha or review.get('cpu_source_pin_sha256')!=CPU_SHA:
        raise ValueError('independent bridge source review not passed for this release')


def native_now(data,tick,dt_ns):
    seconds=float(data.time);now=round(seconds*1e9)
    if not math.isfinite(seconds) or now!=tick*dt_ns:raise RuntimeError('measured native clock differs from public grid')
    return now,seconds


def capture_packet(data,now,lag):
    # Driver reads actual native tensors; actor receives only these public DTOs.
    return Packet(now,now+lag,tuple(data.qpos.copy().tolist()),tuple(data.qvel.copy().tolist()),tuple(data.ctrl.copy().tolist()))


def raw_sample(data,now,seconds):
    return {'sim_ns':now,'native_time_s':seconds,'epoch':0,**{
        target+'_'+field:float(value) for target,i in [('A',0),('B',1),('C',2)]
        for field,value in [('q',data.qpos[i]),('v',data.qvel[i]),('ctrl_next',data.ctrl[i])]}}


def audit_commands(commands):
    actor=[r for r in commands if not r['external']]
    counts={t:sum(r['target']==t for r in actor) for t in ('A','C')}
    if len(actor)>4 or any(x>2 for x in counts.values()):raise RuntimeError('actual native action budget exceeded')
    ordered=sorted(commands,key=lambda r:(r['service_start_ns'],r['seq']))
    if any(a['ack_ns']>b['service_start_ns'] for a,b in zip(ordered,ordered[1:])):raise RuntimeError('actual native shared server overlap')
    return counts


class Streams:
    def __init__(self,out):
        self.files={};self.counts={};self.raw_writer=None;self.out=out
    def append(self,name,value):
        if name not in self.files:self.files[name]=(self.out/name).open('x')
        f=self.files[name];f.write(json.dumps(value,sort_keys=True,allow_nan=False)+'\n');f.flush()
        self.counts[name]=self.counts.get(name,0)+1
    def sample(self,row):
        name='independent_samples.csv'
        if self.raw_writer is None:
            self.files[name]=(self.out/name).open('x',newline='');self.raw_writer=csv.DictWriter(self.files[name],fieldnames=list(row));self.raw_writer.writeheader()
        self.raw_writer.writerow(row);self.files[name].flush();self.counts[name]=self.counts.get(name,0)+1
    def close(self):
        for f in self.files.values():f.flush();f.close()


def run(admission_path,review_path):
    release_sha,p=verify_sources();admission=read_json(admission_path);review=read_json(review_path)
    validate_admission(admission,review,release_sha)
    if admission.get('independent_review_receipt_sha256')!=sha(review_path):raise ValueError('review receipt byte binding mismatch')
    out=HERE/'development_output';out.mkdir(exist_ok=False)
    # This fixed path and exclusive claim are also retained on setup failure:
    # an exception cannot silently become a fresh controlled epoch elsewhere.
    write_json(out/'NATIVE_EPOCH_CLAIM.json',{'case_id':CASE_ID,'method':METHOD,'maximum_controlled_native_epochs':1,
        'bridge_release_sha256':release_sha,'cpu_source_pin_sha256':CPU_SHA,'root_admission':admission,'independent_review_receipt_sha256':sha(review_path)})
    streams=Streams(out);start=time.monotonic_ns();error=None;controller=None;channel=None;applied=set();acks=[];raw=[]
    epoch_created=False;epoch_started=False;native_steps=0;last_tick=None;native_version=None;model=None;data=None
    old_signal=signal.getsignal(signal.SIGTERM)
    def own_timeout(signum,frame):raise TimeoutError('root-owned bridge received SIGTERM; partial outputs retained')
    signal.signal(signal.SIGTERM,own_timeout)
    try:
        # No native import occurs during preparation, source checks or unit tests.
        sys.path.insert(0,str(HERE/'origin_exact'))
        import mujoco
        from plant import create,Effects
        from referee import evaluate
        spec=configure_fixed_case();contract=public_contract(spec,p)
        controller=make_controller(METHOD,contract)
        model,data=create(spec['private_plant'],spec['initial_state']);epoch_created=True;native_version=mujoco.__version__
        if model.nq!=3 or model.nv!=3 or model.nu!=3 or round(float(model.opt.timestep)*1e9)!=p['dt_ns']:
            raise ValueError('native model dimension/grid mismatch')
        if float(data.time)!=0 or data.qpos.tolist()!=spec['initial_state']['qpos'] or data.qvel.tolist()!=spec['initial_state']['qvel'] or data.ctrl.tolist()!=spec['initial_state']['torque']:
            raise ValueError('original initial native state mismatch')
        effects=Effects(spec['private_plant'],spec['resource']['B_reservation']['torque_after_ACK']);channel=ReservedChannel(spec['resource'])
        write_json(out/'SETUP.json',{'role':p['role'],'spec_driver_only_private_fields':spec,'public_contract':asdict(contract),
            'active_native_model_readback':{'nq':model.nq,'nv':model.nv,'nu':model.nu,'dt_s':float(model.opt.timestep),
                'dof_damping':model.dof_damping.tolist(),'body_inertia':model.body_inertia.tolist(),'initial_qpos':data.qpos.tolist(),'initial_qvel':data.qvel.tolist(),'initial_ctrl':data.ctrl.tolist()},
            'bridge_release_sha256':release_sha,'cpu_source_pin_sha256':CPU_SHA,'admission_sha256':sha(admission_path),
            'review_sha256':sha(review_path),'mujoco_version':native_version,'source_mapped_private_fields_into_actor':False,
            'host_computation_steps_physics':False,'paid_decision_ns':contract.charged_decision_ns,'GPU':0,'formal_native32':0})
        pending=[];latest=None
        for tick in range(p['expected_raw_samples']):
            last_tick=tick
            if time.monotonic_ns()-start>p['maximum_host_wall_s']*1_000_000_000:raise TimeoutError('predeclared owned bridge wall cap')
            now,seconds=native_now(data,tick,p['dt_ns'])
            if now%p['sensor_period_ns']==0:
                packet=capture_packet(data,now,p['sensor_lag_ns']);pending.append(packet);streams.append('public_captures.jsonl',asdict(packet))
            while pending and pending[0].arrival_ns<=now:
                latest=pending.pop(0);streams.append('public_deliveries.jsonl',asdict(latest))
            for r in channel.reservations:
                if r.ack_ns==now and r.seq not in applied:
                    effect=effects.apply(data,r)
                    if effect['actual_ACK_ns']!=now:raise RuntimeError('effect write native time mismatch')
                    applied.add(r.seq);ack=Ack(r.seq,r.target,r.tag,now);acks.append(ack)
                    streams.append('private_effects.jsonl',effect);streams.append('ACKs.jsonl',asdict(ack))
            row=raw_sample(data,now,seconds);raw.append(row);streams.sample(row)
            frame=PublicFrame(contract.epoch,now,latest,tuple(acks),channel.public_snapshot());frame.validate(contract)
            streams.append('public_actor_inputs.jsonl',asdict(frame))
            before=time.perf_counter_ns();actions=controller.advance(frame);host_compute=time.perf_counter_ns()-before
            for action in actions:
                if set(action)!={'client_token','target','tag','request_ns'} or action['request_ns']!=now:raise ValueError('bridge accepts exact current selective request only')
                if action['target'] not in ('A','C') or action['tag']!=action['target']+'_stop':raise ValueError('illegal actor actuation')
                prior_commands=[asdict(x) for x in channel.reservations];prior_counts=audit_commands(prior_commands)
                if prior_counts[action['target']]>=2 or sum(prior_counts.values())>=4:raise RuntimeError('driver cumulative action cap before submission')
                receipt=channel.submit(now,action['target'],action['tag'])
                streams.append('submissions.jsonl',{'request':action,'actual_accepted_reservation':asdict(receipt),'actual_native_time_s':seconds})
            audit_commands([asdict(x) for x in channel.reservations])
            streams.append('controller_ticks.jsonl',{'now_ns':now,'native_time_s':seconds,'phase':controller.phase,
                'actual_new_submissions':actions,'ledger_counts':controller.ledger.counts,'candidate_epoch':controller.budget.epoch,
                'pending_paid_decision_ready_ns':None if controller.pending is None else controller.pending['ready_ns'],
                'decision_count':len(controller.decisions),'measured_advance_host_ns':host_compute,
                'public_protocol_failure':controller.protocol_failure,'native_epoch':0})
            if tick<p['expected_native_steps']:
                before_s=float(data.time);mujoco.mj_step(model,data);epoch_started=True;native_steps+=1;mujoco.mj_forward(model,data)
                streams.append('native_steps.jsonl',{'step_index':native_steps,'epoch':0,'before_time_s':before_s,'after_time_s':float(data.time),
                    'before_native_ns':round(before_s*1e9),'after_native_ns':round(float(data.time)*1e9),'mj_step_calls':1,'mj_forward_calls':1})
        commands=[asdict(r) for r in channel.reservations];counts=audit_commands(commands)
        if any(r.seq not in applied for r in channel.reservations):raise RuntimeError('terminal pending actual native reservation retained')
        if controller.ledger.counts!=counts:raise RuntimeError('terminal actual submission count disagrees with public cumulative ledger')
        for d in controller.decisions:
            if d['charged_decision_ns']!=p['paid_decision_ns'] or d['ready_ns']-d['created_ns']!=p['paid_decision_ns']:raise RuntimeError('uncharged native decision')
            if d['budget']['candidate_evaluations']>1000:raise RuntimeError('native decision candidate cap')
        if controller.budget.epoch>10000:raise RuntimeError('native epoch candidate cap')
        write_json(out/'raw_verdict.json',evaluate([{k:str(v) for k,v in r.items()} for r in raw],commands,spec))
        if verify_sources()[0]!=release_sha:raise RuntimeError('source changed during native development')
    except BaseException as e:
        error={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'last_tick':last_tick}
        write_json(out/'EXCEPTION.json',error)
    finally:
        signal.signal(signal.SIGTERM,old_signal);streams.close()
        commands=[] if channel is None else [asdict(r) for r in channel.reservations]
        write_json(out/'commands.json',commands)
        write_json(out/'public_decisions.json',[] if controller is None else controller.decisions)
        write_json(out/'public_final_snapshot.json',None if controller is None else controller.snapshot())
        if not (out/'raw_verdict.json').exists():write_json(out/'raw_verdict.json',{'status':'NOT_FULLY_RECORDED_EXCEPTION','joint':'UNKNOWN','raw_samples_retained':len(raw),'controller_internal_flags_used':False})
        result={'schema':'paperb-single-stateful-native-development-result-v1','case_id':CASE_ID,'method':METHOD,
            'status':'RECORDED_NATIVE_DEVELOPMENT_PENDING_INDEPENDENT_RAW_ACCEPTANCE' if error is None else 'FAILED_NATIVE_ATTEMPT_RETAINED',
            'error':error,'source_bridge_release_sha256':release_sha,'cpu_source_pin_sha256':CPU_SHA,
            'controlled_native_epoch_created':epoch_created,'controlled_native_epoch_started':epoch_started,
            'controlled_native_episode_count':int(epoch_started),'native_steps':native_steps,'raw_samples':len(raw),'epoch_count_upper_bound':1,
            'last_measured_native_time_s':None if data is None or not math.isfinite(float(data.time)) else float(data.time),'mujoco_version':native_version,
            'actual_actor_request_counts':{t:sum(r['target']==t and not r['external'] for r in commands) for t in ('A','C')},
            'pending_actual_reservation_ids':[r['seq'] for r in commands if r['seq'] not in applied],
            'stream_row_counts':streams.counts,'measured_attempt_host_wall_ns':time.monotonic_ns()-start,
            'state_pose_or_velocity_writes_during_epoch':0,'actuator_control_effects_only_at_service_ACK':True,
            'GPU':0,'LLM':0,'fit':0,'new_weights':0,'formal_native32':0,'heldout':False,'real_robot_episodes':0,'chemical_endpoints':0,
            'source_referee_joint_is_independent_acceptance':False,'exit0_is_independent_acceptance':False,'agentic_advantage_or_necessity_supported':False}
        write_json(out/'NATIVE_DEV_RESULT.json',result)
        manifest={str(x.relative_to(out)):sha(x) for x in sorted(out.rglob('*')) if x.is_file()}
        write_json(out/'ARTIFACT_MANIFEST.json',{'schema':'paperb-single-development-artifact-manifest-v1','files':manifest,'source_bridge_release_sha256':release_sha,'all_readback_hashes_retained':True})
    print(json.dumps(result,indent=2));return 0 if error is None else 1


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');parser.add_argument('--admission',type=Path);parser.add_argument('--review',type=Path)
    args=parser.parse_args();release,p=verify_sources()
    if not args.execute:
        print(json.dumps({'status':'SOURCE_HASH_PRECHECK_ONLY_NO_NATIVE_IMPORT_OR_EPOCH','bridge_release_sha256':release,
            'case_id':CASE_ID,'method':METHOD,'new_native_episodes':0,'GPU':0,'formal_native32':0},indent=2));return 0
    if args.admission is None or args.review is None:parser.error('execution needs exact root admission and independent source review receipts')
    return run(args.admission,args.review)


if __name__=='__main__':raise SystemExit(main())
