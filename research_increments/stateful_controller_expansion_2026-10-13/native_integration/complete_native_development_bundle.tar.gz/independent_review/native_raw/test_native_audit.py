"""Synthetic CPU denial fixtures only; never import MuJoCo, actor or referee."""
import copy
from itertools import product
import json
from pathlib import Path
import sys
import tempfile
import unittest

import audit_native as a
from event_referee import first_confirmed_stop, joint, score_interval, service_capacity, evaluate


def clock_fixture():
    p={"dt_ns":10_000_000,"horizon_ns":12_000_000_000,"native_epoch":0,
       "expected_raw_samples":1201,"expected_native_steps":1200,"sensor_period_ns":50_000_000,
       "sensor_lag_ns":100_000_000,"public_epoch_identity":"e","paid_decision_ns":20_000_000}
    raw=[{"sim_ns":i*p["dt_ns"],"native_time_s":i*.01,"epoch":0,
          **{axis+"_"+field:(.06 if field=="ctrl_next" else .5 if field=="v" else i*.005)
             for axis in ("A","B","C") for field in ("q","v","ctrl_next")}} for i in range(1201)]
    steps=[{"step_index":i+1,"epoch":0,"before_time_s":raw[i]["native_time_s"],"after_time_s":raw[i+1]["native_time_s"],
            "before_native_ns":i*p["dt_ns"],"after_native_ns":(i+1)*p["dt_ns"],"mj_step_calls":1,"mj_forward_calls":1} for i in range(1200)]
    return raw,steps,p


def public_fixture():
    raw,steps,p=clock_fixture()
    commands=[{"seq":0,"target":"B","tag":"B_reserved_drive_change","request_ns":0,"service_start_ns":650_000_000,"ack_ns":1_100_000_000,"external":True}]
    acks=[{"seq":0,"target":"B","tag":"B_reserved_drive_change","ack_ns":1_100_000_000}]
    for row in raw:
        if row["sim_ns"]>=1_100_000_000:row["B_ctrl_next"]=.045
    captures=[]
    for row in raw[::5]:
        control=[row[x+"_ctrl_next"] for x in ("A","B","C")]
        if row["sim_ns"]==1_100_000_000:control[1]=.06
        captures.append({"capture_ns":row["sim_ns"],"arrival_ns":row["sim_ns"]+p["sensor_lag_ns"],
                         "positions":[row[x+"_q"] for x in ("A","B","C")],"velocities":[row[x+"_v"] for x in ("A","B","C")],"torques":control})
    delivered=captures[:-2]
    frames=[]
    for row in raw:
        packets=[x for x in delivered if x["arrival_ns"]<=row["sim_ns"]]
        frames.append({"epoch":"e","now_ns":row["sim_ns"],"latest":packets[-1] if packets else None,
                       "acks":[x for x in acks if x["ack_ns"]<=row["sim_ns"]],"reservations":commands})
    return raw,captures,delivered,frames,commands,acks,{1_100_000_000:[.06,.06,.06]},p


class NativeAuditCPU(unittest.TestCase):
    def test_no_native_or_actor_import_during_preparation(self):
        self.assertNotIn("mujoco",sys.modules);self.assertNotIn("stateful_controllers",sys.modules);self.assertNotIn("referee",sys.modules)

    def test_all_three_value_vectors(self):
        for v in product(("TRUE","FALSE","UNKNOWN"),repeat=3):
            self.assertEqual(joint(list(v)),"FALSE" if "FALSE" in v else "UNKNOWN" if "UNKNOWN" in v else "TRUE")

    def test_clock_complete_counts(self):
        a.check_native_clock(*clock_fixture())

    def test_short_raw_or_step_denominator_rejected(self):
        raw,steps,p=clock_fixture()
        with self.assertRaises(ValueError):a.check_native_clock(raw[:-1],steps,p)
        with self.assertRaises(ValueError):a.check_native_clock(raw,steps[:-1],p)

    def test_cross_epoch_rejected(self):
        raw,steps,p=clock_fixture();raw[100]["epoch"]=1
        with self.assertRaises(ValueError):a.check_native_clock(raw,steps,p)

    def test_native_step_skip_pause_duplicate_call_rejected(self):
        for key,value in (("after_native_ns",0),("mj_step_calls",0),("mj_step_calls",2)):
            raw,steps,p=clock_fixture();steps[56][key]=value
            with self.assertRaises(ValueError):a.check_native_clock(raw,steps,p)

    def test_nonfinite_or_fake_native_time_rejected(self):
        for key,value in (("native_time_s",.99),("A_v",float("nan"))):
            raw,steps,p=clock_fixture();raw[10][key]=value
            with self.assertRaises(ValueError):a.check_native_clock(raw,steps,p)

    def test_241capture_239delivery_1201frames(self):
        a.check_public(*public_fixture())

    def test_same_tick_postACK_capture_rejected(self):
        f=list(public_fixture());f[1][22]["torques"][1]=.045
        with self.assertRaisesRegex(ValueError,"PRE_ACK"):a.check_public(*f)

    def test_future_delivery_and_missing_capture_rejected(self):
        f=list(public_fixture());f[3][0]["latest"]=f[2][0]
        with self.assertRaises(ValueError):a.check_public(*f)
        f=list(public_fixture());f[1].pop(20)
        with self.assertRaises(ValueError):a.check_public(*f)

    def test_private_field_in_actor_or_packet_rejected(self):
        f=list(public_fixture());f[3][40]["private_fault"]=True
        with self.assertRaises(ValueError):a.check_public(*f)
        f=list(public_fixture());f[1][20]["referee"]=True
        with self.assertRaises(ValueError):a.check_public(*f)

    def test_repeated_latest_identity_must_not_change(self):
        f=list(public_fixture());f[3][11]["latest"]=copy.deepcopy(f[3][11]["latest"]);f[3][11]["latest"]["positions"][0]+=1
        with self.assertRaises(ValueError):a.check_public(*f)

    def test_service_wait_does_not_remove_elapsed_queue_time(self):
        self.assertEqual(a.service_slot(690_000_000,450_000_000,[{"service_start_ns":650_000_000,"ack_ns":1_100_000_000}]),(1_100_000_000,1_550_000_000))

    def test_overlapping_resource_rejected_not_reset(self):
        self.assertFalse(service_capacity([{"seq":0,"service_start_ns":0,"ack_ns":10},{"seq":1,"service_start_ns":9,"ack_ns":20}]))
        self.assertTrue(service_capacity([{"seq":0,"service_start_ns":0,"ack_ns":10},{"seq":1,"service_start_ns":10,"ack_ns":20}]))

    def test_initial_static_not_stop_event(self):
        raw=[{"sim_ns":i*10_000_000,"A_v":0.} for i in range(30)]
        self.assertIsNone(first_confirmed_stop(raw,"A",.1,200_000_000,10_000_000))

    def test_20points190ms_not_21points200ms(self):
        raw=[{"sim_ns":0,"A_v":1.}]+[{"sim_ns":i*10_000_000,"A_v":0.} for i in range(1,22)]
        self.assertIsNone(first_confirmed_stop(raw[:-1],"A",.1,200_000_000,10_000_000))
        event=first_confirmed_stop(raw,"A",.1,200_000_000,10_000_000)
        self.assertEqual(event["interval_ns"],[0,10_000_000]);self.assertEqual(event["confirmation_ns"],210_000_000);self.assertEqual(event["confirmation_positive_samples"],21)

    def test_gapped_samples_cannot_confirm_hold(self):
        raw=[{"sim_ns":0,"A_v":1.}]+[{"sim_ns":i*10_000_000,"A_v":0.} for i in range(1,23) if i!=10]
        self.assertIsNone(first_confirmed_stop(raw,"A",.1,200_000_000,10_000_000))

    def test_transient_stop_candidate_not_first_confirmed(self):
        raw=[{"sim_ns":i*10_000_000,"A_v":1. if i in (0,10) else 0.} for i in range(35)]
        event=first_confirmed_stop(raw,"A",.1,200_000_000,10_000_000)
        self.assertEqual(event["interval_ns"],[100_000_000,110_000_000])

    def test_timing_unknown_keeps_original_onset_not_confirmation(self):
        event={"interval_ns":[200,210],"confirmation_ns":410}
        self.assertEqual(score_interval([100,110],event,[95,105])["verdict"],"UNKNOWN")
        self.assertEqual(score_interval([100,110],event,[80,120])["duration_interval_ns"],[90,110])
        self.assertEqual(score_interval(None,event,[80,120])["verdict"],"UNKNOWN")

    def test_manifest_all16_and_mutation_rejected(self):
        with tempfile.TemporaryDirectory(dir=a.HERE) as tmp:
            out=Path(tmp);names=["f"+str(i)+".json" for i in range(15)]+["ARTIFACT_MANIFEST.json"]
            for n in names[:-1]:(out/n).write_text("{}")
            (out/"ARTIFACT_MANIFEST.json").write_text(json.dumps({"files":{n:a.sha(out/n) for n in names[:-1]},"source_bridge_release_sha256":"s"}))
            self.assertEqual(len(a.check_manifest(out,{"required_outputs":names},{"bridge_release_sha256":"s"})),16)
            (out/names[0]).write_text('{"tampered":1}')
            with self.assertRaises(ValueError):a.check_manifest(out,{"required_outputs":names},{"bridge_release_sha256":"s"})

    def test_all_frozen_source_inputs_exact_before_execution(self):
        pin,bridge,_=a.verify_sources()
        self.assertEqual(pin["bridge_release_sha256"],"fb0f660cf1b8fc0058c626c4b717f5d93e0731ca1824b1b028be671f1a688ab6")
        self.assertFalse((bridge/"development_output").exists())


if __name__=="__main__":unittest.main(verbosity=2)
