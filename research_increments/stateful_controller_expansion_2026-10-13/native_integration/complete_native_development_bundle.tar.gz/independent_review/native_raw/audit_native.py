"""Prospectively frozen single native RAW auditor. Native import only in authorized replay."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET
from fractions import Fraction

from event_referee import evaluate, service_capacity

HERE=Path(__file__).resolve().parent
RAW_FIELDS={"sim_ns","native_time_s","epoch"}|{a+"_"+k for a in ("A","B","C") for k in ("q","v","ctrl_next")}
PACKET_FIELDS={"capture_ns","arrival_ns","positions","velocities","torques"}
RESERVATION_FIELDS={"seq","target","tag","request_ns","service_start_ns","ack_ns","external"}
ACK_FIELDS={"seq","target","tag","ack_ns"}


def check(value,reason):
    if not value: raise ValueError(reason)


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def js(p): return json.loads(Path(p).read_text())
def lines(p): return [json.loads(x) for x in Path(p).read_text().splitlines() if x]


def verify_sources():
    pin=js(HERE/"INPUT_PIN.json");root=Path(pin["root"]);bridge=Path(pin["bridge_root"])
    if (HERE/"AUDITOR_RELEASE.json").exists():
        for n,h in js(HERE/"AUDITOR_RELEASE.json")["files"].items():
            check(sha(HERE/n)==h,"PROSPECTIVE_AUDITOR_SOURCE_CHANGED:"+n)
    check(sha(bridge/"SOURCE_RELEASE.json")==pin["bridge_release_sha256"],"BRIDGE_RELEASE_CHANGED")
    check(sha(root/"SOURCE_RELEASE_CANDIDATE_V2.json")==pin["cpu30_release_sha256"],"CPU30_RELEASE_CHANGED")
    for base,files in ((bridge,pin["bridge_files"]),(root,pin["public30_files"])):
        for n,h in files.items():check(not(base/n).is_symlink() and sha(base/n)==h,"SOURCE_CHANGED:"+n)
    return pin,bridge,js(bridge/"PROTOCOL.json")


def parse_raw(path):
    with Path(path).open() as f:
        rows=list(csv.DictReader(f))
    check(rows and set(rows[0])==RAW_FIELDS,"RAW_FIELDS")
    return [{k:int(v) if k in {"sim_ns","epoch"} else float(v) for k,v in r.items()} for r in rows]


def check_manifest(out,p,pin):
    manifest=js(out/"ARTIFACT_MANIFEST.json")
    hashes={n:sha(out/n) for n in p["required_outputs"] if (out/n).is_file()}
    check(len(hashes)==16,"MISSING_REQUIRED_OUTPUTS")
    for n,h in hashes.items():
        check(not(out/n).is_symlink(),"REQUIRED_MEMBER_SYMLINK")
        if n!="ARTIFACT_MANIFEST.json":check(manifest["files"].get(n)==h,"RAW_ARTIFACT_SHA:"+n)
    for n,h in manifest["files"].items():
        check(Path(n).name==n and not(out/n).is_symlink() and sha(out/n)==h,"EXTRA_MANIFEST_MEMBER_INVALID")
    check(manifest["source_bridge_release_sha256"]==pin["bridge_release_sha256"],"MANIFEST_SOURCE")
    return hashes


def fixed_spec(pin,p):
    source=js(Path(pin["root"])/"source_inputs/scenario_PROTOCOL_V2.json")
    cases=[x for x in source["cases"] if x["id"]==p["case_id"]];check(len(cases)==1,"ORIGINAL_CASE_IDENTITY")
    c=cases[0];source["case_id"]=c["id"]
    source["public"].update(D_C_ns=c["D_C_ns"],A_window_ns=c["A_window_ns"],graph_edges=c["graph_edges"],calibrated_prediction_residual_ns=[0,0])
    b=source["resource"]["B_reservation"];b["service_end_ns"]=b["service_start_ns"]+c["B_service_ns"]
    return source


def check_setup(setup,spec,p,pin):
    check(setup["spec_driver_only_private_fields"]==spec,"SETUP_NOT_FROZEN_ORIGINAL_SPEC")
    contract=setup["public_contract"]
    check(set(contract)=={"epoch","dt_ns","charged_decision_ns","sensor_period_ns","sensor_lag_ns","public_json","resource_json"},"PUBLIC_CONTRACT_EXTRA_PRIVATE_KEYS")
    check(json.loads(contract["public_json"])==spec["public"] and json.loads(contract["resource_json"])==spec["resource"],"PUBLIC_CONTRACT_NOT_EXACT_ALLOWED_ORIGIN")
    check(contract["epoch"]==p["public_epoch_identity"] and contract["dt_ns"]==p["dt_ns"] and contract["charged_decision_ns"]==p["paid_decision_ns"],"PUBLIC_CONTRACT_CLOCK")
    active=setup["active_native_model_readback"];I=spec["private_plant"]["inertia"]
    check((active["nq"],active["nv"],active["nu"],active["dt_s"])==(3,3,3,p["dt_ns"]/1e9),"ACTIVE_MODEL_DIMENSION_CLOCK")
    check(active["dof_damping"]==[spec["private_plant"]["damping"]]*3 and active["body_inertia"]==[[0.,0.,0.]]+[[I/2,I/2,I]]*3,"ACTIVE_MODEL_INSTALLATION")
    check(all(active["initial_"+k]==spec["initial_state"][target] for k,target in (("qpos","qpos"),("qvel","qvel"),("ctrl","torque"))),"ACTIVE_INITIAL_STATE")
    check(setup["bridge_release_sha256"]==pin["bridge_release_sha256"] and setup["cpu_source_pin_sha256"]==pin["cpu30_release_sha256"],"SETUP_SOURCE_IDENTITIES")
    check(setup["source_mapped_private_fields_into_actor"] is False and setup["host_computation_steps_physics"] is False,"PRIVATE_ACTOR_INPUT_OR_HOST_PHYSICS_DECLARED")


def check_native_clock(raw,steps,p):
    check(len(raw)==p["expected_raw_samples"] and len(steps)==p["expected_native_steps"],"NATIVE_COUNTS")
    for i,r in enumerate(raw):
        check(r["epoch"]==p["native_epoch"] and r["sim_ns"]==i*p["dt_ns"],"RAW_EPOCH_OR_GRID")
        check(math.isfinite(r["native_time_s"]) and round(r["native_time_s"]*1e9)==r["sim_ns"],"ACTUAL_NATIVE_TIME")
        check(all(math.isfinite(r[k]) for k in RAW_FIELDS-{ "sim_ns","epoch"}),"NONFINITE_RAW")
    for i,s in enumerate(steps):
        check(s["step_index"]==i+1 and s["epoch"]==p["native_epoch"],"STEP_IDENTITY")
        check(s["mj_step_calls"]==1 and s["mj_forward_calls"]==1,"STEP_CALL_COUNTS")
        check(s["before_native_ns"]==i*p["dt_ns"] and s["after_native_ns"]==(i+1)*p["dt_ns"],"STEP_GRID_SKIP_OR_PAUSE")
        check(s["before_time_s"]==raw[i]["native_time_s"] and s["after_time_s"]==raw[i+1]["native_time_s"],"STEP_RAW_CLOCK_MISMATCH")


def service_slot(now,duration,calendar):
    start=now
    for a,b in sorted((r["service_start_ns"],r["ack_ns"]) for r in calendar):
        if start+duration<=a:break
        if start<b and start+duration>a:start=b
    return start,start+duration


def check_commands(commands,submissions,acks,effects,raw,spec):
    resource=spec["resource"];external=resource["B_reservation"]
    check(commands and commands[0]=={"seq":0,"target":"B","tag":external["tag"],"request_ns":external["request_ns"],
        "service_start_ns":external["service_start_ns"],"ack_ns":external["service_end_ns"],"external":True},"ORIGINAL_EXTERNAL_B_RESERVATION")
    check(len(commands)==len(submissions)+1 and service_capacity(commands),"COMMAND_DENOMINATOR_OR_CAPACITY")
    cumulative={"A":0,"C":0};tokens=set();calendar=[commands[0]]
    for i,s in enumerate(submissions):
        request,r=s["request"],s["actual_accepted_reservation"]
        check(set(request)=={"client_token","target","tag","request_ns"} and set(r)==RESERVATION_FIELDS,"SUBMISSION_FIELDS")
        check(request["client_token"] not in tokens,"DUPLICATE_EMITTED_TOKEN");tokens.add(request["client_token"])
        check(r==commands[i+1] and r["seq"]==i+1 and not r["external"],"ACTUAL_ACCEPTED_IDENTITY")
        check(r["target"] in cumulative and request["target"]==r["target"] and request["tag"]==r["tag"]==r["target"]+"_stop","LEGAL_REQUEST")
        now=request["request_ns"];check(now==r["request_ns"] and round(s["actual_native_time_s"]*1e9)==now,"SUBMIT_ACTUAL_CLOCK")
        start,end=service_slot(now,resource["services_ns"][r["tag"]],calendar)
        check((start,end)==(r["service_start_ns"],r["ack_ns"]),"ACCEPTANCE_IS_NOT_FORECAST; FIFO_SERVICE_SLOT")
        cumulative[r["target"]]+=1;check(max(cumulative.values())<=2 and sum(cumulative.values())<=4,"CUMULATIVE_ACTION_BUDGET")
        calendar.append(r)
    check(len(acks)==len(commands)==len(effects),"ACK_EFFECT_DENOMINATOR")
    ack_by={r["seq"]:r for r in acks};effect_by={r["seq"]:r for r in effects}
    check(len(ack_by)==len(acks) and len(effect_by)==len(effects),"DUPLICATE_ACK_OR_EFFECT")
    ctrl=list(spec["initial_state"]["torque"]);A_count=0;expected_pre={}
    for r in sorted(commands,key=lambda r:(r["ack_ns"],r["seq"])):
        ack=ack_by[r["seq"]];effect=effect_by[r["seq"]]
        check(set(ack)==ACK_FIELDS and ack=={k:r[k] for k in ACK_FIELDS},"ACTUAL_ACK_IDENTITY")
        check(effect["seq"]==r["seq"] and effect["target"]==r["target"] and effect["actual_ACK_ns"]==r["ack_ns"],"PRIVATE_EFFECT_IDENTITY")
        check(effect["torque_before"]==ctrl,"EFFECT_PREIMAGE")
        expected_pre[r["ack_ns"]]=list(ctrl)
        if r["target"]=="B":ctrl[1]=external["torque_after_ACK"]
        elif r["target"]=="A":
            A_count+=1
            if not(A_count==1 and spec["private_plant"]["fault"]=="first_A_stop_drop"):ctrl[0]=0.
        else:ctrl[2]=0.
        check(effect["torque_after"]==ctrl,"EFFECT_NOT_ACK_SUCCESS_FLAG")
        check([raw[r["ack_ns"]//spec["dt_ns"]][a+"_ctrl_next"] for a in ("A","B","C")]==ctrl,"POST_EFFECT_RAW_CTRL")
    current=list(spec["initial_state"]["torque"])
    for r in raw:
        at=[x for x in effects if x["actual_ACK_ns"]==r["sim_ns"]]
        if at:current=at[-1]["torque_after"]
        check([r[a+"_ctrl_next"] for a in ("A","B","C")]==current,"CTRL_CHANGE_WITHOUT_ACTUAL_ACK")
    return cumulative,expected_pre


def check_public(raw,captures,delivered,frames,commands,acks,expected_pre,p):
    raw_by={r["sim_ns"]:r for r in raw}
    expected_capture=list(range(0,p["horizon_ns"]+1,p["sensor_period_ns"]))
    check([x["capture_ns"] for x in captures]==expected_capture,"CAPTURE_COVERAGE")
    for packet in captures:
        check(set(packet)==PACKET_FIELDS,"PRIVATE_FIELD_IN_PUBLIC_PACKET")
        t=packet["capture_ns"];row=raw_by[t]
        check(packet["arrival_ns"]==t+p["sensor_lag_ns"],"PUBLIC_DELIVERY_LAG")
        check(packet["positions"]==[row[a+"_q"] for a in ("A","B","C")] and packet["velocities"]==[row[a+"_v"] for a in ("A","B","C")],"PUBLIC_Q_V_RAW")
        control=expected_pre.get(t,[row[a+"_ctrl_next"] for a in ("A","B","C")])
        check(packet["torques"]==control,"SAME_TICK_CAPTURE_MUST_BE_PRE_ACK")
    eligible=[x for x in captures if x["arrival_ns"]<=p["horizon_ns"]]
    check(delivered==eligible and len(delivered)==239,"DELIVERED_CAUSAL_COVERAGE")
    check(len(frames)==len(raw),"ACTOR_PUBLIC_FRAME_COUNTS")
    last=None;index=0
    for frame,row in zip(frames,raw):
        t=row["sim_ns"]
        check(set(frame)=={"epoch","now_ns","latest","acks","reservations"},"PRIVATE_FIELD_IN_ACTOR_FRAME")
        check(frame["epoch"]==p["public_epoch_identity"] and frame["now_ns"]==t,"ACTOR_FRAME_NATIVE_EPOCH_CLOCK")
        while index<len(delivered) and delivered[index]["arrival_ns"]<=t:last=delivered[index];index+=1
        check(frame["latest"]==last,"ACTOR_OBSERVATION_NOT_CAUSAL_OR_REPEATED_LATEST_WRONG")
        check(frame["acks"]==[x for x in acks if x["ack_ns"]<=t],"ACK_DELIVERY_SEQUENCE")
        check(frame["reservations"]==[x for x in commands if x["external"] or x["request_ns"]<t],"PRE_CURRENT_REQUEST_PUBLIC_CALENDAR")


def check_controller(ticks,decisions,snapshot,submissions,raw,p):
    check(len(ticks)==len(raw),"CONTROLLER_TICK_COUNTS")
    counts={"A":0,"C":0};prior_candidates=0
    for tick,row in zip(ticks,raw):
        t=row["sim_ns"];check(tick["now_ns"]==t and tick["native_time_s"]==row["native_time_s"] and tick["native_epoch"]==0,"CONTROLLER_NATIVE_CLOCK")
        requests=[s["request"] for s in submissions if s["request"]["request_ns"]==t]
        check(tick["actual_new_submissions"]==requests,"ALL_EMITTED_ACTIONS_ACTUALLY_ACCEPTED")
        for a in requests:counts[a["target"]]+=1
        check(tick["ledger_counts"]==counts,"LEDGER_ACTUAL_COUNT_NO_REFUND")
        check(prior_candidates<=tick["candidate_epoch"]<=10000,"CANDIDATE_EPOCH_BUDGET_MONOTONE");prior_candidates=tick["candidate_epoch"]
        check(tick["decision_count"]==sum(d["created_ns"]<=t for d in decisions),"DECISION_COUNT")
        check(tick["measured_advance_host_ns"]>=0 and tick["public_protocol_failure"] is None,"HOST_MEASUREMENT_OR_PUBLIC_PROTOCOL_FAILURE")
    for d in decisions:
        check(d["ready_ns"]-d["created_ns"]==d["charged_decision_ns"]==p["paid_decision_ns"],"DECISION_UNPAID_OR_EARLY_READY")
        check(d["private_fault_read"] is False and d["new_native_episode"] is False,"PRIVATE_READ_OR_RESET_DECLARED")
        check(d["budget"]["candidate_evaluations"]<=1000,"DECISION_CANDIDATE_CAP")
        check(d["created_ns"]%p["dt_ns"]==0 and d["ready_ns"]%p["dt_ns"]==0,"DECISION_GRID")
        # All RAW intervals during the charge already passed actual-time/mj_step checks.
        for t in range(d["created_ns"],min(d["ready_ns"],p["horizon_ns"]),p["dt_ns"]):
            check(raw[t//p["dt_ns"]+1]["sim_ns"]==t+p["dt_ns"],"PHYSICS_SKIPPED_DURING_PAID_DECISION")
    check(snapshot["ledger"]["counts"]==counts and snapshot["candidate_budget_epoch"]==prior_candidates,"FINAL_LEDGER_BUDGET")
    check(snapshot["decisions"]==decisions and snapshot["charged_decision_time_ns"]==len(decisions)*p["paid_decision_ns"],"FINAL_PAID_DECISIONS")
    check(snapshot["native_referee_score_read"] is False and snapshot["protocol_failure"] is None,"REFEREE_AS_ACTOR_INPUT_OR_PROTOCOL_FAILURE")
    committed=[x for x in snapshot["transactions"] if x["event"]=="PAID_PROGRAM_COMMITTED"]
    check(all(x["ready_ns"]-x["created_ns"]==p["paid_decision_ns"] for x in committed),"EARLY_COMMIT")
    actual_tokens={s["request"]["client_token"]:s for s in submissions}
    intents={i["token"]:i for i in snapshot["ledger"]["intents"]}
    for token,s in actual_tokens.items():
        i=intents[token];r=s["actual_accepted_reservation"]
        check(i["status"] in {"ACKED","ACCEPTED","EMITTED"} and i["emitted_ns"]==r["request_ns"] and i["seq"]==r["seq"],"EMITTED_ACCEPTED_INTENT_CANCELLED_OR_IDENTITY_CHANGED")
    return {"decisions":len(decisions),"charged_virtual_decision_ns":len(decisions)*p["paid_decision_ns"],"candidate_evaluations":prior_candidates,"actual_requests":counts}


def check_original_public_anchor(delivered,decisions,snapshot,spec,p):
    coarse=None;before=cross=None
    threshold=spec["public"]["original_B_angle"]
    for a,b in zip(delivered,delivered[1:]):
        if a["positions"][1]<threshold<=b["positions"][1] and abs(a["velocities"][1])>spec["public"]["moving_threshold"]:
            coarse={"lower_ns":a["capture_ns"],"upper_ns":b["capture_ns"],"first_arrival_ns":b["arrival_ns"],"kind":"B_PUBLIC_OBSERVED_FIRST_Q2"}
            before,cross=a,b;break
    check(snapshot["facts"]["original_B"]==coarse,"ORIGINAL_PUBLIC_B_REPLACED_BY_NEW_ANCHOR")
    reference=coarse;residual=None
    if coarse:
        model=spec["public"]["public_nominal_model"];dt=Fraction(p["dt_ns"],1_000_000_000)
        I,D=Fraction(str(model["inertia"])),Fraction(str(model["damping"]))
        q,v,u=map(lambda x:Fraction(str(x)),(before["positions"][1],before["velocities"][1],before["torques"][1]))
        bracket=None
        for t in range(before["capture_ns"]+p["dt_ns"],cross["capture_ns"]+p["dt_ns"],p["dt_ns"]):
            old=q;v=(I*v+dt*u)/(I+dt*D);q+=dt*v
            if bracket is None and old<Fraction(str(threshold))<=q:bracket=[t-p["dt_ns"],t]
        residual=[abs(float(q)-cross["positions"][1]),abs(float(v)-cross["velocities"][1])]
        if bracket is not None and before["torques"][1]==cross["torques"][1] and max(residual)<=1e-9:
            reference={"lower_ns":bracket[0],"upper_ns":bracket[1],"first_arrival_ns":cross["arrival_ns"],"kind":"B_SAME_EVENT_CONDITIONAL_PUBLIC_MODEL"}
        check(snapshot["facts"]["reference"]==reference,"CONDITIONAL_PUBLIC_MODEL_REFERENCE_NOT_SAME_ORIGINAL_EVENT")
        for d in decisions:
            check(d["created_ns"]>=coarse["first_arrival_ns"] and d["original_B"]==coarse and d["reference"]==reference,"DECISION_USING_FUTURE_OR_REPLACED_B")
            for target,evidence in d["public_power_evidence"].items():
                check(evidence["packet_capture_ns"]>=evidence["ACK_ns"]+p["dt_ns"] and evidence["packet_arrival_ns"]<=d["created_ns"],"PRE_ACK_OR_FUTURE_POWER_EVIDENCE")
    return {"original_public_B_coarse":coarse,"public_model_same_event_reference":reference,
            "Fraction_public_model_forward_residual":residual,"conditional_model_not_true_support_or_privileged_event":True}


def reintegrate(raw,commands,spec,xml_path,expected_version,receipt):
    """One independent diagnostic epoch, only after root result authorization."""
    import mujoco
    check(mujoco.__version__==expected_version,"REPLAY_MUJOCO_VERSION_MISMATCH")
    xml=ET.fromstring(Path(xml_path).read_text());private=spec["private_plant"]
    for axis in ("A","B","C"):
        body=xml.find('./worldbody/body[@name="'+axis+'"]');inertia=private["inertia"]
        body.find("inertial").set("diaginertia",str(inertia/2)+" "+str(inertia/2)+" "+str(inertia))
        body.find("joint").set("damping",str(private["damping"]))
    model=mujoco.MjModel.from_xml_string(ET.tostring(xml,encoding="unicode"));data=mujoco.MjData(model)
    receipt["diagnostic_reintegration_epochs"]=1
    receipt["diagnostic_reintegration"]={"status":"STARTED","diagnostic_native_epochs":1,"diagnostic_native_steps_completed":0,"diagnostic_samples_checked":0}
    data.qpos[:]=spec["initial_state"]["qpos"];data.qvel[:]=spec["initial_state"]["qvel"];data.ctrl[:]=spec["initial_state"]["torque"];mujoco.mj_forward(model,data)
    A_count=0;max_error=0.;time_error=0.
    for i,row in enumerate(raw):
        now=round(data.time*1e9)
        for r in commands:
            if r["ack_ns"]!=now:continue
            if r["target"]=="B":data.ctrl[1]=spec["resource"]["B_reservation"]["torque_after_ACK"]
            elif r["target"]=="C":data.ctrl[2]=0.
            else:
                A_count+=1
                if not(A_count==1 and private["fault"]=="first_A_stop_drop"):data.ctrl[0]=0.
        for j,a in enumerate(("A","B","C")):
            max_error=max(max_error,abs(float(data.qpos[j])-row[a+"_q"]),abs(float(data.qvel[j])-row[a+"_v"]),abs(float(data.ctrl[j])-row[a+"_ctrl_next"]))
        time_error=max(time_error,abs(float(data.time)-row["native_time_s"]))
        receipt["diagnostic_reintegration"]["diagnostic_samples_checked"]=i+1
        if i<len(raw)-1:
            mujoco.mj_step(model,data);mujoco.mj_forward(model,data)
            receipt["diagnostic_reintegration"]["diagnostic_native_steps_completed"]=i+1
    check(max_error==0. and time_error==0.,"INDEPENDENT_COMMAND_REINTEGRATION_NOT_EXACT")
    return {"diagnostic_native_epochs":1,"diagnostic_native_steps":len(raw)-1,"diagnostic_samples":len(raw),
            "state_max_absolute_error":max_error,"native_time_max_absolute_error":time_error,
            "inputs_are_original_XML_declared_private_plant_and_actual_commands_not_actor_success_or_RAW_controls":True}


def audit(notification):
    pin,bridge,p=verify_sources();out=bridge/"development_output"
    check(notification["root_authorized_completed_result_audit"] is True,"ROOT_RESULT_NOTIFICATION_REQUIRED")
    check(notification["bridge_release_sha256"]==pin["bridge_release_sha256"],"ROOT_RESULT_SOURCE_MISMATCH")
    check(notification["audit_release_sha256"]==sha(HERE/"AUDITOR_RELEASE.json"),"ROOT_RESULT_AUDITOR_MISMATCH")
    result_path=out/"NATIVE_DEV_RESULT.json"
    observed_result_sha=sha(result_path) if result_path.is_file() else None
    check(observed_result_sha==notification["result_sha256"],"ROOT_RESULT_BYTE_MISMATCH")
    result=js(result_path) if result_path.is_file() else {"controlled_native_epoch_started":(out/"native_steps.jsonl").is_file() and (out/"native_steps.jsonl").stat().st_size>0}
    hashes={n:sha(out/n) for n in p["required_outputs"] if (out/n).is_file()}
    receipt={"schema":"PaperBNativeRAWIndependentAudit/0.1","created_at_utc":datetime.now(timezone.utc).isoformat(),
        "status":"PENDING","case_id":p["case_id"],"method":p["method"],"primary_attempt_denominator":1,
        "primary_controlled_native_episodes":int(bool(result["controlled_native_epoch_started"])),
        "required16_artifact_sha256":hashes,"source_bridge_release_sha256":pin["bridge_release_sha256"],
        "source_CPU30_sha256":pin["cpu30_release_sha256"],"audit_release_sha256":sha(HERE/"AUDITOR_RELEASE.json"),
        "RAW_integrity":"UNKNOWN","independent_task_verdict":"UNKNOWN","diagnostic_reintegration_epochs":0,
        "formal32":0,"heldout":False,"GPU":0,"weights":0,"chemical_endpoints":0,"real_robot_episodes":0}
    try:
        check_manifest(out,p,pin)
        check(result.get("case_id")==p["case_id"] and result.get("method")==p["method"],"RESULT_CASE_METHOD_IDENTITY")
        check(result["status"]=="RECORDED_NATIVE_DEVELOPMENT_PENDING_INDEPENDENT_RAW_ACCEPTANCE" and result["error"] is None,"FAILED_NATIVE_ATTEMPT_RETAINED")
        setup=js(out/"SETUP.json");spec=fixed_spec(pin,p);check_setup(setup,spec,p,pin)
        raw=parse_raw(out/"independent_samples.csv");steps=lines(out/"native_steps.jsonl")
        check_native_clock(raw,steps,p)
        check(result["native_steps"]==len(steps) and result["raw_samples"]==len(raw) and result["controlled_native_epoch_started"] is True and result["controlled_native_epoch_created"] is True,"RESULT_EXECUTED_DENOMINATOR")
        commands=js(out/"commands.json");submissions=lines(out/"submissions.jsonl");acks=lines(out/"ACKs.jsonl");effects=lines(out/"private_effects.jsonl")
        counts,pre=check_commands(commands,submissions,acks,effects,raw,spec)
        captures=lines(out/"public_captures.jsonl");delivered=lines(out/"public_deliveries.jsonl");frames=lines(out/"public_actor_inputs.jsonl")
        check_public(raw,captures,delivered,frames,commands,acks,pre,p)
        ticks=lines(out/"controller_ticks.jsonl");decisions=js(out/"public_decisions.json");snapshot=js(out/"public_final_snapshot.json")
        controller=check_controller(ticks,decisions,snapshot,submissions,raw,p)
        anchor=check_original_public_anchor(delivered,decisions,snapshot,spec,p)
        independent=evaluate(raw,commands,spec)
        original=js(out/"raw_verdict.json");check(independent==original,"INDEPENDENT_REFEREE_DIFFERS_FROM_PRESERVED_SOURCE_OUTPUT")
        receipt.update(RAW_integrity="PASS",independent_task_verdict=independent["joint"],independent_RAW_referee=independent,
            controller=controller,public_anchor=anchor,counts={"RAW_samples":len(raw),"actual_native_step_records":len(steps),"public_captures":len(captures),
                "public_delivered_packets":len(delivered),"public_actor_frames":len(frames),"accepted_A_C":counts},
            preACK_capture_independently_reconstructed=True,ACK_is_not_physical_stop=True,
            physical_continuity_between_samples_proven=False,model_refinement_does_not_replace_original_B=True)
        replay=reintegrate(raw,commands,spec,bridge/"origin_exact/three_rotors.xml",result["mujoco_version"],receipt)
        receipt.update(diagnostic_reintegration_epochs=1,diagnostic_reintegration=replay,status="PASS_NATIVE_DEVELOPMENT_RAW_AUDIT")
        verify_sources()
    except Exception as e:
        receipt.update(status="REJECTED_OR_UNRESOLVED_ATTEMPT_RETAINED",audit_error={"type":type(e).__name__,"reason":str(e)})
    with (HERE/"NATIVE_RAW_AUDIT.json").open("x") as f:json.dump(receipt,f,indent=2,sort_keys=True,allow_nan=False);f.write("\n")
    print(json.dumps({k:receipt[k] for k in ("status","RAW_integrity","independent_task_verdict","primary_attempt_denominator","diagnostic_reintegration_epochs")},sort_keys=True))
    return receipt


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--verify-only",action="store_true");parser.add_argument("--root-result-notification",type=Path)
    args=parser.parse_args()
    if args.verify_only:
        pin,_,_=verify_sources();print(json.dumps({"status":"PASS_SOURCE_INPUT_PIN_ONLY","new_native_epochs":0,"bridge_release_sha256":pin["bridge_release_sha256"]}))
    elif args.root_result_notification: audit(js(args.root_result_notification))
    else:parser.error("use verify-only or root completed-result notification; no native replay during preflight")
