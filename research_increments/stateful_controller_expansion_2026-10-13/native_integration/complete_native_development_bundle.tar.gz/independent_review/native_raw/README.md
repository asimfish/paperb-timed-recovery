# Prospective independent native RAW gate

This auditor is frozen before the one admitted development integration. Preparation imports no MuJoCo or actor, launches no native epoch and changes no prior source/data. The frozen bridge8 and public30 source closures are checked explicitly. `event_referee.py` is a third sampled-event implementation; the original referee is read as a semantic specification and its eventual output is compared, never called as the oracle.

Primary counts are one controlled development epoch, 1201 RAW samples and 1200 actual native step records. Public observations have 241 capture packets, 239 delivered packets and 1201 actor PublicFrames, including repeated/None latest. All16 required artifacts are hashed; manifest itself has an externally recorded digest, and the extra epoch claim is preserved. Actual native time, pre-ACK capture, causal deliveries, accepted server reservations, FIFO/service capacity, cumulative action/candidate budgets and 20ms paid-decision intervals are independently checked. Native physics continues during queue and virtual decision waits; measured host time is separate.

The score preserves the first actual B event, A/C onset intervals and later 200ms/21point confirmations. Sampled B motion/control, temporal graph and actual dropped-first-A/recovered torque are separate predicates. Public model interpolation refines the same public B identity using delivered q/v/torque and the public nominal model; it is not a private oracle or model-support guarantee. Neither RAW integration nor sampled velocity/control certifies chemical or continuous-time effects.

Root must notify that execution is terminal before the diagnostic command replay. The notification JSON contains `root_authorized_completed_result_audit: true`, `bridge_release_sha256`, `audit_release_sha256` and exact `result_sha256`. It authorizes one separately counted replay epoch; it never authorizes a new primary attempt. The independent replay derives effects from declared plant plus actual commands, not success labels/RAW controls. All1201 state/time errors must be exactly zero. A replay that starts and fails remains counted.

```sh
/usr/bin/python3 -B audit_native.py --verify-only
/usr/bin/python3 -B audit_native.py --root-result-notification /absolute/root/completed_result_notification.json
```

Use the same MuJoCo version as the executed bridge; the auditor checks it before creating replay data. CPU preflight is `/usr/bin/python3 -B -m unittest test_native_audit -v`. Its final source-pin test asserts execution has not begun, so it is intentionally a prospective preparation check, not an after-execution acceptance rerun. Runtime write-once receipt is `NATIVE_RAW_AUDIT.json`, status `PASS_NATIVE_DEVELOPMENT_RAW_AUDIT` only when RAW and independent replay pass. Task truth is a separate TRUE/FALSE/UNKNOWN field: successful RAW audit does not imply task success or method rate. Exceptions and missing rows stay in denominator1.

Later four-method × eight paired experiments need their own frozen wrapper/roster/protocol/admission, retaining failed/missing attempts in32. These eight conditions remain already seen, not task-space generalization. No GPU, fit, weights, original robot, chemical endpoint or agentic-necessity claim belongs to this gate. Existing VerifiedReplay19 and the old604 increment are not modified.
