"""Third implementation of sampled RAW event semantics. No actor/original referee imports."""
import math


def joint(values):
    if not values or any(x not in {"TRUE", "FALSE", "UNKNOWN"} for x in values):
        raise ValueError("nonempty three-valued evidence required")
    return "FALSE" if "FALSE" in values else "TRUE" if all(x == "TRUE" for x in values) else "UNKNOWN"


def first_crossing(raw, axis, threshold, moving):
    pairs = zip(raw, raw[1:])
    for before, after in pairs:
        if before[axis+"_q"] < threshold <= after[axis+"_q"] and abs(before[axis+"_v"]) > moving:
            return [before["sim_ns"], after["sim_ns"]]
    return None


def first_confirmed_stop(raw, axis, moving_threshold, hold_ns, dt_ns):
    had_motion = False
    low_run = []
    previous = None
    for row in raw:
        if previous is not None and row["sim_ns"]-previous["sim_ns"] != dt_ns:
            return None
        if abs(row[axis+"_v"]) > moving_threshold:
            had_motion = True
            low_run = []
        elif had_motion:
            low_run.append(row)
            if row["sim_ns"]-low_run[0]["sim_ns"] >= hold_ns:
                return {"interval_ns": [low_run[0]["sim_ns"]-dt_ns, low_run[0]["sim_ns"]],
                        "confirmation_ns": row["sim_ns"], "confirmation_positive_samples": len(low_run),
                        "had_prior_moving_sample": True}
        previous = row
    return None


def score_interval(anchor, event, window):
    if anchor is None or event is None:
        return {"verdict": "UNKNOWN", "duration_interval_ns": None}
    lo, hi = event["interval_ns"][0]-anchor[1], event["interval_ns"][1]-anchor[0]
    verdict = "TRUE" if window[0] <= lo and hi <= window[1] else "FALSE" if hi < window[0] or lo > window[1] else "UNKNOWN"
    return {"verdict": verdict, "duration_interval_ns": [lo, hi]}


def service_capacity(commands):
    intervals = sorted((r["service_start_ns"], r["ack_ns"], r["seq"]) for r in commands)
    return all(start <= end for start,end,_ in intervals) and all(a[1] <= b[0] for a,b in zip(intervals,intervals[1:]))


def evaluate(raw, commands, spec):
    dt, horizon, public = spec["dt_ns"], spec["horizon_ns"], spec["public"]
    valid = len(raw) == horizon//dt+1 and all(r["sim_ns"] == i*dt and r["epoch"] == 0 for i,r in enumerate(raw))
    finite = all(math.isfinite(r[a+"_"+k]) for r in raw for a in ("A","B","C") for k in ("q","v","ctrl_next"))
    if not valid or not finite:
        return {"values":{"raw_one_epoch":"FALSE"},"joint":"FALSE","original_B_raw_interval_ns":None,
                "stop_events":{},"time_scores":{},"maintenance_failure_ticks_ns":[],
                "physical_continuity_between_ticks_proven":False,"controller_internal_flags_used":False,"chemical_or_original_robot_credit":0}
    anchor=first_crossing(raw,"B",public["original_B_angle"],public["moving_threshold"])
    stops={a:first_confirmed_stop(raw,a,public["moving_threshold"],public["stop_hold_ns"],dt) for a in ("A","C")}
    times={"A":score_interval(anchor,stops["A"],public["A_window_ns"]),
           "C":score_interval(anchor,stops["C"],[public["D_C_ns"]-public["eps_C_ns"],public["D_C_ns"]+public["eps_C_ns"]])}
    maintenance="UNKNOWN" if anchor is None else "TRUE"
    violations=[]
    if anchor:
        certain_end,possible_end=anchor[0]+public["B_maintenance_ns"],anchor[1]+public["B_maintenance_ns"]
        for r in raw:
            if anchor[1]<r["sim_ns"]<=possible_end and (r["B_ctrl_next"] not in (.06,.045) or abs(r["B_v"])<=public["moving_threshold"]):
                violations.append(r["sim_ns"])
                if r["sim_ns"]<=certain_end: maintenance="FALSE";break
                maintenance="UNKNOWN"
    monotone=all(b["B_q"]>=a["B_q"] and a["B_ctrl_next"]>=0 for a,b in zip(raw,raw[1:]))
    A=[r for r in commands if r["target"]=="A"]
    drop=recovery=anchor_before=False
    if A:
        r=raw[A[0]["ack_ns"]//dt]
        drop=r["A_ctrl_next"]>0 and abs(r["A_v"])>public["moving_threshold"]
        anchor_before=anchor is not None and anchor[1]<A[0]["ack_ns"]
        recovery=any(raw[a["ack_ns"]//dt]["A_ctrl_next"]==0 for a in A[1:])
    graph=[]
    for before,after in public["graph_edges"]:
        if stops[before] is None or stops[after] is None: graph.append("UNKNOWN");continue
        lo=stops[after]["interval_ns"][0]-stops[before]["interval_ns"][1]
        hi=stops[after]["interval_ns"][1]-stops[before]["interval_ns"][0]
        graph.append("TRUE" if lo>=public["minimum_edge_gap_ns"] else "FALSE" if hi<public["minimum_edge_gap_ns"] else "UNKNOWN")
    values={"raw_one_epoch":"TRUE","actual_B_original_anchor":"TRUE" if anchor else "UNKNOWN",
            "irreversible_B_angle":"TRUE" if monotone else "FALSE","A_original_time":times["A"]["verdict"],"C_original_time":times["C"]["verdict"],
            "B_sampled_maintenance":maintenance,"service_capacity":"TRUE" if service_capacity(commands) else "FALSE",
            "original_anchor_before_failure":"TRUE" if anchor_before else "FALSE","actual_drop_and_effective_recovery":"TRUE" if drop and recovery else "FALSE","graph":joint(graph)}
    return {"values":values,"joint":joint(list(values.values())),"original_B_raw_interval_ns":anchor,"stop_events":stops,
            "time_scores":times,"maintenance_failure_ticks_ns":violations,"physical_continuity_between_ticks_proven":False,
            "controller_internal_flags_used":False,"chemical_or_original_robot_credit":0}
