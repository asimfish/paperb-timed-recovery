"""Terminal CPU check: focused contract tests and exact metadata replay transform.

The temporary replay is JSON/dispatch transformation only, not native reintegration.
"""
from contextlib import redirect_stdout
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import platform
import tempfile
import unittest

import jsonschema
import metadata_adapter
import test_verified_replay

OWN = Path(__file__).resolve().parent


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    source_names = ["verified_replay.py", "metadata_adapter.py", "test_verified_replay.py",
                    "run_cpu_acceptance.py", "VerifiedReplay.schema.json",
                    "VerifiedReplayCausalCandidate.schema.json", "INPUT_PIN.json"]
    source_hashes = {name: digest(OWN/name) for name in source_names}
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromModule(test_verified_replay))
    if not result.wasSuccessful():
        (OWN/"CPU_ACCEPTANCE_FAILED.log").write_text(stream.getvalue())
        raise SystemExit("CPU admission contract failed; negative output retained")
    with tempfile.TemporaryDirectory(prefix="owned_metadata_roundtrip_",dir=OWN) as temporary:
        output=Path(temporary)/"replay"
        with redirect_stdout(io.StringIO()): metadata_adapter.run(output)
        comparisons={name:digest(output/name)==digest(OWN/"metadata_v1"/name)
                     for name in ["EPISODE_RECORDS.jsonl","CAUSAL_CANDIDATES.jsonl"]}
        if not all(comparisons.values()):
            raise SystemExit("Pinned metadata transformation is not exact")
    if {name:digest(OWN/name) for name in source_names} != source_hashes:
        raise SystemExit("CPU source changed during acceptance")
    receipt={"schema":"VerifiedReplayCPUGate/0.1","status":"PASS_METADATA_ONLY_NOT_TRAINING",
        "created_at_utc":datetime.now(timezone.utc).isoformat(),"test_count":result.testsRun,
        "python_version":platform.python_version(),"jsonschema_version":jsonschema.__version__,
        "tests_failures":len(result.failures),"tests_errors":len(result.errors),
        "all_28_episode_and_852_candidate_Draft7_schema_and_crossfield_checks":True,
        "exact_pinned_metadata_transform_roundtrip":comparisons,
        "source_sha256":source_hashes,"weights_training_GPU_new_native_or_reintegration_epochs":0,
        "student_tensors_large_frame_copies_dataset_migrations":0,
        "old_source_score_contracts_calibration_and_sealed604_increment_edited":False,
        "gate_created_after_old_results_available_not_prospective_for_old_experiments":True,
        "training_not_admitted":True,"future_legacy_training_not_permanently_forbidden":True}
    with (OWN/"CPU_ACCEPTANCE.log").open("x") as f: f.write(stream.getvalue())
    with (OWN/"CPU_ACCEPTANCE.json").open("x") as f: json.dump(receipt,f,indent=2,sort_keys=True);f.write("\n")
    print(json.dumps(receipt,sort_keys=True))


if __name__ == "__main__": main()
