"""Metadata-only verified replay contract; no tensor loading or training entry point."""
from __future__ import annotations

from decimal import Decimal
from typing import Protocol

TRI = {"TRUE", "FALSE", "UNKNOWN"}
ROLES = {"calibration", "test", "development_witness", "future_collection"}
PRIVATE_KEYS = {
    "object_pose", "private_state", "private_effects", "referee", "fault",
    "fault_id", "known_drop_oracle", "ground_truth", "contact_rows",
    "installed_properties", "reward", "success", "event_truth", "labels",
}
FEATURE_KEYS = {"instruction", "public_contract", "public_installation_metadata",
                "public_packet", "public_ack", "public_reservations", "proprioception",
                "image_reference", "depth_reference", "clock", "history"}


class MetadataAdapter(Protocol):
    def episode_records(self) -> list[dict]: ...
    def causal_candidates(self) -> list[dict]: ...


def tri_joint(values: list[str]) -> str:
    if not values or any(v not in TRI for v in values):
        raise ValueError("NONEMPTY_THREE_VALUED_VECTOR_REQUIRED")
    return "FALSE" if "FALSE" in values else "UNKNOWN" if "UNKNOWN" in values else "TRUE"


def verdict_to_tri(verdict: str) -> str:
    if verdict in {"PASS", "TRUE"}:
        return "TRUE"
    if verdict in {"EARLY", "LATE", "FALSE", "REFUSED"}:
        return "FALSE"
    if verdict in {"INDETERMINATE", "UNKNOWN", "UNAVAILABLE", "MISSING", "INVALID"}:
        return "UNKNOWN"
    raise ValueError("UNKNOWN_VERDICT_TOKEN:" + verdict)


def _plain(value):
    if type(value) is dict:
        for key, nested in value.items():
            if type(key) is not str or key.lower() in PRIVATE_KEYS or key.lower().startswith("private_"):
                raise ValueError("PRIVATE_OR_NONSTRING_FEATURE_KEY")
            _plain(nested)
    elif type(value) is list:
        for item in value:
            _plain(item)
    elif value is None or type(value) in (str, bool, int):
        pass
    elif type(value) is float:
        if not Decimal(str(value)).is_finite():
            raise ValueError("NONFINITE_FEATURE")
    else:
        raise ValueError("NONPLAIN_FEATURE_OR_NATIVE_GETTER")


def validate_student_features(features: dict) -> None:
    """Trusted typed-data boundary, not a hostile-Python sandbox or truth detector.

    Producer provenance still has to prove each accepted feature is public. A
    renamed privileged numeric value cannot be identified from key names alone.
    """
    if type(features) is not dict or set(features) - FEATURE_KEYS:
        raise ValueError("UNKNOWN_STUDENT_FEATURE_CHANNEL")
    _plain(features)


def validate_event(event: dict, clock_id: str) -> None:
    if event["clock_id"] != clock_id:
        raise ValueError("CROSS_EPOCH_EVENT")
    if event["unit"] not in {"s", "ns"} or not event["event_id"].startswith(clock_id + ":") or not event["kind"]:
        raise ValueError("EVENT_IDENTITY_OR_UNIT_MISSING")
    lower, upper = map(lambda x: Decimal(str(x)), event["onset_interval"])
    if not lower.is_finite() or not upper.is_finite() or lower > upper:
        raise ValueError("INVALID_ONSET_INTERVAL")
    confirm = event.get("confirmation_time")
    if confirm is not None and Decimal(str(confirm)) < upper:
        raise ValueError("CONFIRMATION_PRECEDES_ONSET")
    if event.get("physical_continuity_proven") is not False:
        raise ValueError("SAMPLED_RAW_CANNOT_PROVE_CONTINUITY")


def validate_record(record: dict) -> None:
    if record["schema"] != "VerifiedReplayEpisode/0.1":
        raise ValueError("SCHEMA_VERSION")
    if record["original_role"] not in ROLES:
        raise ValueError("ORIGINAL_ROLE")
    if record["split"]["original_role"] != record["original_role"]:
        raise ValueError("ROLE_MUTATION")
    if record["origin"]["seen_before_design"]:
        if record["split"]["pool"] != "LEGACY_SEEN_METADATA" or record["split"]["future_heldout_eligible"]:
            raise ValueError("SEEN_EPISODE_RELABELED_HELDOUT")
    for v in record["labels"]["objectives"].values():
        if v["value"] not in TRI:
            raise ValueError("THREE_VALUES_REQUIRED")
    for event in record["audit_only"]["events"]:
        validate_event(event, record["clock"]["clock_id"])
        if event["unit"] != record["clock"].get("unit", event["unit"]):
            raise ValueError("EVENT_CLOCK_UNIT_MISMATCH")
    ids = [e["event_id"] for e in record["audit_only"]["events"]]
    if len(ids) != len(set(ids)):
        raise ValueError("EVENT_IDENTITY_REUSED_OR_REPLACED")
    validate_student_features(record["student_input"]["materialized_features"])
    if record["student_input"]["status"] != "NOT_MATERIALIZED_METADATA_ONLY":
        raise ValueError("CURRENT_PROTOTYPE_DOES_NOT_MATERIALIZE_STUDENT_INPUT")
    if record["training_admission"] is not False:
        raise ValueError("NO_TRAINING_AUTHORIZATION_IN_THIS_COMPONENT")
    if record["dataset_kind"] == "robot_timing_legacy":
        obj = record["labels"]["objectives"]
        expected = tri_joint([obj["mechanical"]["value"], obj["primary_timed_joint"]["value"],
                              obj["strict_sampled_bilateral_hold"]["value"]])
        if obj["full_timed_and_hold"]["value"] != expected:
            raise ValueError("FULL_SUCCESS_CANNOT_DROP_HOLD")


def assign_episode_splits(records: list[dict], requested: dict[str, str], *,
                          allow_future_legacy_training: bool = False) -> dict[str, str]:
    """Episode keys, not frames/contracts; duplicate groups cannot straddle pools."""
    by_id = {r["episode_id"]: r for r in records}
    if len(by_id) != len(records) or set(requested) != set(by_id):
        raise ValueError("UNIQUE_COMPLETE_EPISODE_ASSIGNMENT_REQUIRED")
    groups = {}
    for key, pool in requested.items():
        if pool not in {"LEGACY_SEEN_METADATA", "LEGACY_SEEN_TRAIN", "FUTURE_TRAIN", "FUTURE_VALIDATION", "FUTURE_HELDOUT"}:
            raise ValueError("UNKNOWN_SPLIT_POOL")
        record = by_id[key]
        if record["origin"]["seen_before_design"] and pool != "LEGACY_SEEN_METADATA":
            if not (pool == "LEGACY_SEEN_TRAIN" and allow_future_legacy_training):
                raise ValueError("SEEN_NOT_HELDOUT; FUTURE_LEGACY_TRAIN_REQUIRES_SEPARATE_AUTHORIZATION")
        if pool == "FUTURE_HELDOUT":
            if record["original_role"] != "future_collection" or not record["split"]["prospective_split_frozen"]:
                raise ValueError("FUTURE_HELDOUT_REQUIRES_PRECOLLECTION_SPLIT")
        group = record["split"]["duplicate_or_scenario_group"]
        if pool != "LEGACY_SEEN_METADATA":
            if group in groups and groups[group] != pool:
                raise ValueError("RELATED_EPISODE_LEAKAGE_ACROSS_SPLITS")
            groups[group] = pool
    return dict(requested)


def causal_admission(candidate: dict) -> dict:
    """Check post-step observation -> next submission. Never relabel apply/effect."""
    observation, action = candidate["observation"], candidate["action_label"]
    if action is None:
        return {"status": "REJECTED", "reasons": ["NO_FUTURE_SUBMISSION_RECORDED"],
                "training_admitted": False, "physical_effect_is_not_submission": True,
                "temporal_pair_is_not_evidence_actor_saw_image": True}
    reasons = []
    if observation["clock_id"] != action["clock_id"]:
        reasons.append("CROSS_EPOCH_PAIR")
    if action["semantic"] != "FUTURE_SUBMITTED_TARGET":
        reasons.append("APPLIED_TARGET_OR_EFFECT_IS_NOT_NEXT_ACTION_LABEL")
    if observation["unit"] != action["unit"]:
        reasons.append("CLOCK_UNIT_MISMATCH")
    capture = Decimal(str(observation["capture_time"]))
    submit = Decimal(str(action["submission_time"]))
    if not capture.is_finite() or not submit.is_finite() or submit < capture:
        reasons.append("ACTION_ALREADY_SUBMITTED_BEFORE_CAPTURE")
    elif submit == capture and candidate["same_time_source_order"] != "CAPTURE_BEFORE_SUBMISSION":
        reasons.append("SAME_TIMESTAMP_ORDER_UNPROVEN")
    if action["submission_tick"] < observation["next_submission_tick"]:
        reasons.append("POSTSTEP_IMAGE_USED_FOR_PRIOR_SUBMISSION")
    delivery = observation.get("policy_delivery_time")
    if observation.get("policy_delivery_clock_id") not in (None, observation["clock_id"]):
        reasons.append("POLICY_DELIVERY_CROSS_EPOCH")
    if delivery is None:
        reasons.append("POLICY_IMAGE_DELIVERY_TIME_UNKNOWN")
    else:
        delivered = Decimal(str(delivery))
        if not delivered.is_finite():
            reasons.append("POLICY_DELIVERY_NONFINITE")
        elif delivered < capture or delivered > submit:
            reasons.append("POLICY_DELIVERY_NOT_BETWEEN_CAPTURE_AND_SUBMISSION")
    applied = action.get("actual_application")
    if applied is not None:
        if applied["clock_id"] != action["clock_id"]:
            reasons.append("APPLICATION_CROSS_EPOCH")
        if Decimal(str(applied["apply_time"])) < submit:
            reasons.append("APPLICATION_PRECEDES_SUBMISSION")
    if reasons:
        status = "UNKNOWN" if reasons == ["POLICY_IMAGE_DELIVERY_TIME_UNKNOWN"] else "REJECTED"
    else:
        status = "PASS_TEMPORAL_PAIR_ONLY"
    return {"status": status, "reasons": reasons,
            "training_admitted": False,
            "physical_effect_is_not_submission": True,
            "temporal_pair_is_not_evidence_actor_saw_image": True}


def objective_admission(record: dict, objective: str) -> dict:
    if record["origin"].get("RAW_integrity") not in {"COMPLETE_RAW_AUDIT", "INDEPENDENTLY_RECOMPUTED_DEVELOPMENT_ONLY"}:
        return {"status": "QUARANTINE_RAW_MISSING_OR_INVALID", "training_admitted": False,
                "original_label_retained_not_reverified": True}
    labels = record["labels"]["objectives"]
    if objective not in labels:
        return {"status": "QUARANTINE_OBJECTIVE_NOT_VERIFIED", "training_admitted": False}
    value = labels[objective]["value"]
    if objective == "full_timed_and_hold":
        status = "NOT_SUCCESS_DEMO" if value == "FALSE" else "QUARANTINE_UNKNOWN" if value == "UNKNOWN" else "QUARANTINE_CAUSAL_AND_COLLECTION_ADMISSION_REQUIRED"
    elif objective == "mechanical" and value == "TRUE":
        status = "PARTIAL_MECHANICAL_PRIOR_METADATA_ONLY"
    elif value == "FALSE":
        status = "VERIFIED_OBJECTIVE_FAILURE_METADATA_ONLY"
    elif value == "UNKNOWN":
        status = "UNRESOLVED_OBJECTIVE_METADATA_ONLY"
    else:
        status = "SCOPED_OBJECTIVE_SUCCESS_METADATA_ONLY"
    return {"status": status, "objective": objective, "value": value,
            "training_admitted": False, "full_success_demo_admitted": False}


def summarize_robot(records: list[dict]) -> dict:
    robot = [r for r in records if r["dataset_kind"] == "robot_timing_legacy"]
    tests = [r for r in robot if r["original_role"] == "test"]
    counts = {k: sum(r["labels"]["objectives"]["primary_timed_joint"]["value"] == k for r in tests) for k in TRI}
    return {"robot_episodes": len(robot), "original_test_denominator": len(tests),
            "original_calibration_separate": len(robot) - len(tests), "primary_test_T_F_U": counts,
            "strict_test_TRUE": sum(r["labels"]["objectives"]["strict_sampled_bilateral_hold"]["value"] == "TRUE" for r in tests),
            "full_timed_and_hold_success_demo_episodes": sum(r["labels"]["objectives"]["full_timed_and_hold"]["value"] == "TRUE" for r in robot),
            "training_admitted": 0, "policy_weights_or_native_epochs_created": 0}
