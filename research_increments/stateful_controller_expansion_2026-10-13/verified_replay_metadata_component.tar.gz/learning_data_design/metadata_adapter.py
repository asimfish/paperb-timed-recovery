"""Read hash-bound small audits and stream dispatch; write only replay metadata.

No image/depth arrays, physics, SDK, private pose, student tensors or weights.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

from verified_replay import (assign_episode_splits, causal_admission, objective_admission,
                             summarize_robot, tri_joint, validate_record, verdict_to_tri)

OWN = Path(__file__).resolve().parent


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path, expected):
    path = Path(path)
    if path.is_symlink() or sha(path) != expected:
        raise ValueError("INPUT_SHA_OR_REGULAR_FILE_MISMATCH:" + path.name)
    return json.loads(path.read_text())


def objective(value, scope):
    return {"value": value, "scope": scope}


def event_record(name, x, clock):
    if x["event"] is None:
        return None
    return {"event_id": clock + ":" + name, "kind": name, "clock_id": clock,
            "unit": "s", "onset_interval": x["event"]["bounds_s"],
            "confirmation_time": x["confirmation_time_s"],
            "onset_sample_index": x["onset_sample_index"],
            "confirmation_sample_index": x["confirmation_sample_index"],
            "confirmation_samples": x["confirmation_count"], "physical_continuity_proven": False}


def empty_student_input():
    return {"status": "NOT_MATERIALIZED_METADATA_ONLY", "materialized_features": {},
            "actual_VLA_observation": "UNKNOWN_NOT_LOGGED",
            "private_referee_values_allowed_as_student_inputs": False}


def robot_record(case, audit_sha, protocol, package):
    clock = case["native"]["epoch"]
    contracts = {c["name"]: {"original_verdict": c["verdict"], "value": verdict_to_tri(c["verdict"]),
                             "error_interval_s": case["timing_scores"][c["name"]]["error_interval_s"]}
                 for c in case["contracts"]}
    mechanical = "TRUE" if case["task_mechanism_pass"] else "FALSE"
    primary = tri_joint([mechanical] + [x["value"] for x in contracts.values()] +
                        (["FALSE"] if case["prospective_schedule_audit"]["schedule_refused"] else []))
    hold = "TRUE" if case["strict_sampled_hold"]["pass"] else "FALSE"
    cid = case["case_id"]
    public_case = next(c for c in protocol["cases"] if c["id"] == cid)
    events = [event_record(k, x, clock) for k, x in case["events"].items()]
    record = {"schema": "VerifiedReplayEpisode/0.1", "episode_id": cid,
        "dataset_kind": "robot_timing_legacy", "original_role": case["role"],
        "origin": {"seen_before_design": True, "actor_kind": "SCRIPTED_RULE_NPZ_SKILL",
                   "neural_expert": False, "student_rollout": False, "audit_sha256": audit_sha,
                   "source_release_sha256": package["source_release_sha256"],
                   "public_archive_available": False, "RAW_integrity": case["status"]},
        "split": {"original_role": case["role"], "pool": "LEGACY_SEEN_METADATA",
                  "duplicate_or_scenario_group": "scripted_fixed_robot_scene_and_NPZ_policy",
                  "future_heldout_eligible": False, "prospective_split_frozen": False,
                  "future_authorized_legacy_train_allowed": True,
                  "training_would_invalidate_untouched_test_reuse": True},
        "clock": {"clock_id": clock, "original_epoch": clock, "unit": "s",
                  "task_origin": case["controller_origin"]["task_origin_native_s"],
                  "samples": case["native"]["samples"], "dt_s": case["native"]["dt_s"]},
        "labels": {"contracts": contracts, "objectives": {
            "mechanical": objective(mechanical, "original_mechanical_prerequisite_not_full_scientific_or_training_admission"),
            "primary_timed_joint": objective(primary, "mechanical_and_three_timing_contracts_without_strict_hold"),
            "strict_sampled_bilateral_hold": objective(hold, "bilateral_samples_to_composite_release_onset_not_continuous_physics"),
            "full_timed_and_hold": objective(tri_joint([mechanical, primary, hold]), "mechanical_primary_and_strict_sampled_hold")}},
        "public_contract_reference": {"public_case": public_case,
                                      "clocked_instruction_delivery": "task/public_cue.json; not assumed available at task start"},
        "audit_only": {"events": [e for e in events if e is not None],
                       "original_primary_certified_boolean": case["primary_joint_pass"],
                       "strict_missing_bilateral_sample_indices": case["strict_sampled_hold"]["missing_bilateral_sample_indices"],
                       "applied_event_commands": case["applied_commands"],
                       "audit_role_scientific_admission": case["scientific_admission"],
                       "audit_role_training_admission": case["training_admission"],
                       "recovery_evidence": "NOT_COLLECTED; REGRASP_IS_SCRIPTED_STAGE_NOT_FAILURE_TRIGGERED_REPAIR"},
        "student_input": empty_student_input(), "training_admission": False}
    record["objective_admissions"] = {name: objective_admission(record, name) for name in record["labels"]["objectives"]}
    validate_record(record)
    return record


def robot_pairs(case, capture_receipt, native, manifest):
    capture_frames = capture_receipt["observed_capture_frames"]
    indices = {r["command_index"] for r in capture_frames}
    path = native / "cases" / case["case_id"] / "task/dispatch.jsonl"
    rel = "native/" + str(path.relative_to(native))
    expected = manifest["members"][rel]["sha256"]
    selected, applied_by_id = {}, {}
    h = hashlib.sha256()
    with path.open("rb") as f:
        for line in f:
            h.update(line)
            row = json.loads(line)
            if row["tick"] in indices:
                selected[row["tick"]] = row
            if row["applied"] is not None:
                x = row["applied"]
                applied_by_id[x["command_id"]] = {"apply_time": x["apply_time_s"], "apply_tick": x["apply_tick"],
                    "clock_id": x["native_epoch"], "semantic": "ACTUAL_FIFO_APPLICATION_NOT_PHYSICAL_EVENT"}
    if h.hexdigest() != expected:
        raise ValueError("DISPATCH_SHA_MISMATCH:" + case["case_id"])
    results = []
    for frame in capture_frames:
        i = frame["command_index"]
        row = selected.get(i)
        submitted = row["submitted"] if row is not None else None
        action = None
        if submitted is not None:
            action = {"command_id": submitted["command_id"], "source_index": submitted["source_index"],
                      "submission_tick": submitted["enqueue_tick"], "submission_time": submitted["enqueue_time_s"],
                      "clock_id": submitted["native_epoch"], "unit": "s", "semantic": "FUTURE_SUBMITTED_TARGET",
                      "arm_target": submitted["arm_target"], "grip_target": submitted["grip_target"],
                      "actual_application": applied_by_id.get(submitted["command_id"]),
                      "physical_effect_time": None, "effect_not_assumed_from_FIFO_ACK": True}
        record = {"schema": "VerifiedReplayCausalCandidate/0.1", "episode_id": case["case_id"],
            "observation": {"capture_index": i, "camera_frame": frame["camera_frame"],
                "capture_phase": "TASK_ORIGIN_PRE_FIRST_SUBMISSION" if i == 0 else "POSTSTEP_PRE_NEXT_SUBMISSION",
                "capture_time": frame["native_time_s"], "clock_id": frame["native_epoch"], "unit": "s",
                "next_submission_tick": i, "policy_delivery_time": None, "policy_delivery_clock_id": None,
                "JPEG_sha256": frame["image_sha256"], "depth_sha256": frame["depth_sha256"],
                "reference_scope": "PRIVATE_FRAME_REFERENCE_ONLY_NO_FRAME_COPY",
                "uncompressed_RGB_digest_not_recovered_from_lossy_JPEG": True},
            "same_time_source_order": "CAPTURE_BEFORE_SUBMISSION",
            "source_order_evidence": "native_probe.py:render before next FIFO step; exact frozen source SHA in INPUT_PIN",
            "action_label": action, "source_dispatch_sha256": expected,
            "input_materialized": False, "scripted_actor_observed_image": False}
        record["admission"] = causal_admission(record)
        results.append(record)
    return results


def witness_record(row, audit_sha, release_sha):
    cid = row["case_id"]
    clock = release_sha + ":" + cid + ":original_raw_epoch_0"
    events = [{"event_id": clock + ":B_FIRST_ACTUAL_Q2", "kind": "B_FIRST_ACTUAL_Q2",
               "clock_id": clock, "unit": "ns", "onset_interval": row["raw_first_B_event_ns"],
               "confirmation_time": None, "physical_continuity_proven": False}]
    for name, event in row["stop_events"].items():
        events.append({"event_id": clock + ":" + name + "_FIRST_CONFIRMED_STOP", "kind": name + "_FIRST_CONFIRMED_STOP",
            "clock_id": clock, "unit": "ns", "onset_interval": event["interval_ns"],
            "confirmation_time": event["confirmation_ns"], "confirmation_samples": event["confirmation_positive_samples"],
            "physical_continuity_proven": False})
    record = {"schema": "VerifiedReplayEpisode/0.1", "episode_id": cid,
        "dataset_kind": "CPU_rotor_development_seen", "original_role": "development_witness",
        "origin": {"seen_before_design": True, "actor_kind": "PUBLIC_KNOWN_MODEL_RULE_BATCH",
                   "neural_expert": False, "student_rollout": False, "audit_sha256": audit_sha,
                   "source_release_sha256": release_sha, "RAW_integrity": "INDEPENDENTLY_RECOMPUTED_DEVELOPMENT_ONLY"},
        "split": {"original_role": "development_witness", "pool": "LEGACY_SEEN_METADATA",
                  "duplicate_or_scenario_group": "known_model_three_rotor_eight_seen_configs",
                  "future_heldout_eligible": False, "prospective_split_frozen": False,
                  "future_authorized_legacy_train_allowed": True},
        "clock": {"clock_id": clock, "original_epoch": 0, "unit": "ns", "samples": row["raw_samples"], "dt_ns": 10000000},
        "labels": {"contracts": {k: {"value": v, "original_verdict": v} for k, v in row["values"].items()},
            "objectives": {"rotor_graph_sampled_joint": objective(row["joint"], "known_model_three_rotor_development_only"),
                           "robot_full_timed_and_hold": objective("UNKNOWN", "NOT_APPLICABLE_NO_ROBOT_OR_RGB"),
                           "feedback_triggered_recovery": objective("FALSE", "two_A_blind_redundancy_planned_before_drop")}},
        "audit_only": {"events": events, "original_public_B_coarse": row["original_public_coarse"],
            "conditional_same_event_B_public_model": row["conditional_same_event_public_model"],
            "B_event_identity_not_replaced_by_refinement": True, "recovery_kind": row["recovery_kind"],
            "B_sampled_maintenance_checked_samples": row["B_sampled_maintenance_checked_samples"],
            "independent_reintegration_epochs_are_not_primary_episodes": True},
        "student_input": empty_student_input(), "training_admission": False}
    record["objective_admissions"] = {name: objective_admission(record, name) for name in record["labels"]["objectives"]}
    validate_record(record)
    return record


def run(output):
    pin = json.loads((OWN / "INPUT_PIN.json").read_text())
    inputs = {k: read_json(v["path"], v["sha256"]) for k, v in pin["inputs"].items()}
    manifest = inputs["package_manifest"]
    native = Path(pin["native_root"])
    if sha(native / pin["frozen_native_order_source"]["path"]) != pin["frozen_native_order_source"]["sha256"]:
        raise ValueError("FROZEN_CAPTURE_SUBMISSION_ORDER_SOURCE_CHANGED")
    protocol = inputs["protocol"]
    records, pairs = [], []
    capture_by_id = {x["case_id"]: x for x in inputs["capture_audit"]["captures"]}
    for role in ("calibration_audit", "test_audit"):
        audit = inputs[role]
        for case in audit["cases"]:
            records.append(robot_record(case, pin["inputs"][role]["sha256"], protocol, pin))
            pairs.extend(robot_pairs(case, capture_by_id[case["case_id"]], native, manifest))
    witness = inputs["witness_audit"]
    for row in witness["case_rows"]:
        records.append(witness_record(row, pin["inputs"]["witness_audit"]["sha256"], witness["source_release_sha256"]))
    assign_episode_splits(records, {r["episode_id"]: "LEGACY_SEEN_METADATA" for r in records})
    summary = {"status": "PASS_METADATA_CAUSAL_ADMISSION_PROTOTYPE_NOT_TRAINING", "created_at_utc": datetime.now(timezone.utc).isoformat(),
        **summarize_robot(records), "records": len(records), "CPU_development_seen_records": 8,
        "causal_candidate_records": len(pairs), "causal_statuses": dict(Counter(p["admission"]["status"] for p in pairs)),
        "actual_VLA_image_delivery_evidence": "UNKNOWN_NOT_LOGGED",
        "student_inputs_materialized": 0, "full_DP_success_rows_admitted": 0,
        "offline_RL_rows_admitted": 0, "OPD_student_state_teacher_labels_admitted": 0,
        "metadata_records_are_not_28_independent_robot_tests": True,
        "weights_training_GPU_new_native_frame_copy": 0,
        "all_old_roles_and_event_identities_preserved": True,
        "input_pin_sha256": sha(OWN / "INPUT_PIN.json")}
    if output.exists():
        raise FileExistsError("REFUSE_TO_OVERWRITE_METADATA_OUTPUT")
    output.mkdir()
    for name, rows in (("EPISODE_RECORDS.jsonl", records), ("CAUSAL_CANDIDATES.jsonl", pairs)):
        with (output / name).open("x") as f:
            for row in rows:
                f.write(json.dumps(row, sort_keys=True, allow_nan=False) + "\n")
    (output / "SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.resolve().parent != OWN:
        raise SystemExit("output must be a new directory inside owned learning_data_design")
    run(args.output)
