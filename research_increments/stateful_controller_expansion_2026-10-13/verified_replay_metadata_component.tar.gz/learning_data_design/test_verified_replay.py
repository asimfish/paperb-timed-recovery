"""CPU contract negatives; legacy receipt totals are evidence, not synthetic rates."""
import copy
from itertools import product
import json
from pathlib import Path
import unittest

from verified_replay import (assign_episode_splits, causal_admission, objective_admission,
    summarize_robot, tri_joint, validate_event, validate_record, validate_student_features, verdict_to_tri)

OWN = Path(__file__).resolve().parent


def candidate():
    return {"observation": {"clock_id": "e", "unit": "s", "capture_time": 1.0,
        "next_submission_tick": 10, "policy_delivery_time": 1.0, "policy_delivery_clock_id": "e"},
        "action_label": {"clock_id": "e", "unit": "s", "submission_time": 1.0,
            "submission_tick": 10, "semantic": "FUTURE_SUBMITTED_TARGET", "actual_application": None},
        "same_time_source_order": "CAPTURE_BEFORE_SUBMISSION"}


def record():
    return {"schema": "VerifiedReplayEpisode/0.1", "episode_id": "old-test", "dataset_kind": "robot_timing_legacy",
        "original_role": "test", "origin": {"seen_before_design": True, "RAW_integrity": "COMPLETE_RAW_AUDIT"},
        "split": {"original_role": "test", "pool": "LEGACY_SEEN_METADATA", "future_heldout_eligible": False,
                  "duplicate_or_scenario_group": "scene", "prospective_split_frozen": False},
        "clock": {"clock_id": "e"}, "labels": {"objectives": {
            "mechanical": {"value": "TRUE"}, "primary_timed_joint": {"value": "TRUE"},
            "strict_sampled_bilateral_hold": {"value": "FALSE"}, "full_timed_and_hold": {"value": "FALSE"}}},
        "audit_only": {"events": []}, "student_input": {"status": "NOT_MATERIALIZED_METADATA_ONLY", "materialized_features": {}},
        "training_admission": False}


class AdmissionTests(unittest.TestCase):
    def test_three_values_all_27_vectors(self):
        for v in product(("TRUE", "FALSE", "UNKNOWN"), repeat=3):
            expected = "FALSE" if any(x == "FALSE" for x in v) else "TRUE" if all(x == "TRUE" for x in v) else "UNKNOWN"
            self.assertEqual(tri_joint(list(v)), expected)

    def test_unknown_not_false(self):
        self.assertEqual(verdict_to_tri("INDETERMINATE"), "UNKNOWN")
        self.assertEqual(verdict_to_tri("UNAVAILABLE"), "UNKNOWN")

    def test_unknown_token_rejected(self):
        with self.assertRaises(ValueError): verdict_to_tri("almost_pass")

    def test_empty_joint_rejected(self):
        with self.assertRaises(ValueError): tri_joint([])

    def test_mechanical_success_not_full_demo(self):
        self.assertEqual(objective_admission(record(), "mechanical")["status"], "PARTIAL_MECHANICAL_PRIOR_METADATA_ONLY")
        self.assertFalse(objective_admission(record(), "full_timed_and_hold")["full_success_demo_admitted"])

    def test_false_hold_cannot_be_removed(self):
        r = record(); r["labels"]["objectives"]["full_timed_and_hold"]["value"] = "TRUE"
        with self.assertRaises(ValueError): validate_record(r)

    def test_objective_unknown_is_quarantined(self):
        r = record(); r["labels"]["objectives"]["primary_timed_joint"]["value"] = "UNKNOWN"
        self.assertEqual(objective_admission(r, "primary_timed_joint")["status"], "UNRESOLVED_OBJECTIVE_METADATA_ONLY")

    def test_unknown_objective_no_invented_label(self):
        self.assertEqual(objective_admission(record(), "chemical_yield")["status"], "QUARANTINE_OBJECTIVE_NOT_VERIFIED")

    def test_missing_raw_quarantined_without_dropping_denominator(self):
        r=record(); r["origin"]["RAW_integrity"]="MISSING"
        self.assertEqual(objective_admission(r,"mechanical")["status"], "QUARANTINE_RAW_MISSING_OR_INVALID")
        self.assertEqual(summarize_robot([r])["original_test_denominator"],1)

    def test_legacy_training_subset_can_leave_other_metadata_untrained(self):
        a,b=record(),record();b["episode_id"]="old-cal";b["original_role"]="calibration"
        self.assertEqual(assign_episode_splits([a,b], {"old-test":"LEGACY_SEEN_TRAIN","old-cal":"LEGACY_SEEN_METADATA"}, allow_future_legacy_training=True)["old-test"],"LEGACY_SEEN_TRAIN")

    def test_unknown_split_pool_rejected(self):
        with self.assertRaises(ValueError): assign_episode_splits([record()],{"old-test":"random"})

    def test_role_mutation_rejected(self):
        r = record(); r["split"]["original_role"] = "calibration"
        with self.assertRaises(ValueError): validate_record(r)

    def test_seen_cannot_be_future_heldout(self):
        with self.assertRaises(ValueError): assign_episode_splits([record()], {"old-test": "FUTURE_HELDOUT"})

    def test_future_legacy_training_requires_separate_authorization(self):
        with self.assertRaises(ValueError): assign_episode_splits([record()], {"old-test": "LEGACY_SEEN_TRAIN"})
        self.assertEqual(assign_episode_splits([record()], {"old-test": "LEGACY_SEEN_TRAIN"}, allow_future_legacy_training=True), {"old-test": "LEGACY_SEEN_TRAIN"})
        self.assertEqual(record()["original_role"], "test")

    def test_duplicate_or_partial_episode_split_rejected(self):
        with self.assertRaises(ValueError): assign_episode_splits([record(), record()], {"old-test": "LEGACY_SEEN_METADATA"})
        with self.assertRaises(ValueError): assign_episode_splits([record()], {"old-test:frame1": "LEGACY_SEEN_METADATA"})

    def test_related_future_groups_cannot_straddle_splits(self):
        a, b = record(), record(); b["episode_id"] = "new-b"
        for r in (a,b):
            r["origin"]["seen_before_design"] = False; r["original_role"] = "future_collection"; r["split"]["prospective_split_frozen"] = True
        with self.assertRaises(ValueError): assign_episode_splits([a,b], {"old-test": "FUTURE_TRAIN", "new-b": "FUTURE_HELDOUT"})

    def test_current_prototype_rejects_training_enable(self):
        r=record(); r["training_admission"]=True
        with self.assertRaises(ValueError): validate_record(r)

    def test_private_pose_nested_rejected(self):
        with self.assertRaises(ValueError): validate_student_features({"history": [{"object_pose": [1,2,3]}]})

    def test_private_fault_and_referee_rejected(self):
        for key in ("fault", "referee", "known_drop_oracle", "reward", "private_effects"):
            with self.assertRaises(ValueError): validate_student_features({"public_packet": {key: 0}})

    def test_getter_or_tensor_not_plain_data(self):
        with self.assertRaises(ValueError): validate_student_features({"public_packet": {"opaque": object()}})

    def test_unknown_feature_channel_rejected(self):
        with self.assertRaises(ValueError): validate_student_features({"installed_properties": {}})

    def test_public_channels_allowed_but_not_provenance_by_name(self):
        validate_student_features({"instruction": "stop after 5s", "proprioception": {"q": [0.0]}, "history": []})

    def test_poststep_next_submission_known_delivery_temporal_only(self):
        x=causal_admission(candidate()); self.assertEqual(x["status"], "PASS_TEMPORAL_PAIR_ONLY"); self.assertFalse(x["training_admitted"])

    def test_unknown_image_delivery_cannot_be_assumed(self):
        c=candidate(); c["observation"]["policy_delivery_time"]=None
        self.assertEqual(causal_admission(c)["status"], "UNKNOWN")

    def test_same_timestamp_order_required(self):
        c=candidate(); c["same_time_source_order"]="UNKNOWN"
        self.assertEqual(causal_admission(c)["status"], "REJECTED")

    def test_previous_submission_and_past_tick_rejected(self):
        c=candidate(); c["action_label"]["submission_time"]=0.9; c["action_label"]["submission_tick"]=9
        self.assertEqual(causal_admission(c)["status"], "REJECTED")

    def test_delayed_applied_target_is_not_future_submission(self):
        c=candidate(); c["action_label"]["semantic"]="CURRENT_APPLIED_TARGET"
        self.assertEqual(causal_admission(c)["status"], "REJECTED")

    def test_cross_epoch_pair_or_delivery_rejected(self):
        for branch in ("action_label", "observation"):
            c=candidate()
            if branch=="action_label": c[branch]["clock_id"]="other"
            else: c[branch]["policy_delivery_clock_id"]="other"
            self.assertEqual(causal_admission(c)["status"], "REJECTED")

    def test_nonfinite_or_late_delivery_rejected(self):
        for value in (float("nan"), 1.1, 0.9):
            c=candidate();c["observation"]["policy_delivery_time"]=value
            self.assertEqual(causal_admission(c)["status"], "REJECTED")

    def test_no_future_submission_cannot_create_label(self):
        c=candidate();c["action_label"]=None
        self.assertEqual(causal_admission(c)["reasons"], ["NO_FUTURE_SUBMISSION_RECORDED"])

    def test_application_time_is_separate_and_after_submission(self):
        c=candidate();c["action_label"]["actual_application"]={"clock_id":"e", "apply_time":1.05}
        self.assertEqual(causal_admission(c)["status"], "PASS_TEMPORAL_PAIR_ONLY")
        c["action_label"]["actual_application"]["apply_time"]=0.9
        self.assertEqual(causal_admission(c)["status"], "REJECTED")

    def test_event_confirmation_and_epoch_not_conflated(self):
        e={"clock_id":"e", "event_id":"e:first", "kind":"stop", "unit":"ns", "onset_interval":[100,110], "confirmation_time":310, "physical_continuity_proven":False}
        validate_event(e,"e")
        with self.assertRaises(ValueError): validate_event(e,"other")
        e["confirmation_time"]=105
        with self.assertRaises(ValueError): validate_event(e,"e")

    def test_duplicate_event_or_wrong_unit_rejected(self):
        r=record();r["clock"]["unit"]="s"
        e={"clock_id":"e","event_id":"e:first","kind":"stop","unit":"s","onset_interval":[1,1.1],"confirmation_time":1.3,"physical_continuity_proven":False}
        r["audit_only"]["events"]=[e,copy.deepcopy(e)]
        with self.assertRaises(ValueError): validate_record(r)
        r["audit_only"]["events"]=[e];e["unit"]="ns"
        with self.assertRaises(ValueError): validate_record(r)

    def test_actual_legacy_metadata_totals_and_schema(self):
        records=[json.loads(x) for x in (OWN/"metadata_v1/EPISODE_RECORDS.jsonl").read_text().splitlines()]
        for r in records: validate_record(r)
        s=summarize_robot(records)
        self.assertEqual(len(records),28); self.assertEqual(s["original_test_denominator"],16)
        self.assertEqual(s["original_calibration_separate"],4)
        self.assertEqual(s["primary_test_T_F_U"], {"TRUE":8,"FALSE":2,"UNKNOWN":6})
        self.assertEqual(s["strict_test_TRUE"],0); self.assertEqual(s["full_timed_and_hold_success_demo_episodes"],0)
        try:
            import jsonschema
        except ImportError:
            self.fail("schema validator required for terminal CPU check")
        schema=json.loads((OWN/"VerifiedReplay.schema.json").read_text())
        for r in records: jsonschema.validate(r,schema)
        pairs=[json.loads(x) for x in (OWN/"metadata_v1/CAUSAL_CANDIDATES.jsonl").read_text().splitlines()]
        pair_schema=json.loads((OWN/"VerifiedReplayCausalCandidate.schema.json").read_text())
        self.assertEqual(len(pairs),852)
        for p in pairs:
            jsonschema.validate(p,pair_schema)
            self.assertEqual(causal_admission(p),p["admission"])
        self.assertEqual(sum(p["admission"]["status"]=="UNKNOWN" for p in pairs),832)
        self.assertEqual(sum(p["admission"]["status"]=="REJECTED" for p in pairs),20)


if __name__ == "__main__": unittest.main(verbosity=2)
