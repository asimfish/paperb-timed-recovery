"""GPU-free installation contract checks and source lineage verification."""
import ast
import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
import torch
from gain_installation import install,active_drives,verify_end
from expansion_protocol import dispatch_schedule

ROOT=Path(__file__).parent

class View:
    def __init__(self):
        self.k=torch.tensor([[60000.]*7+[800.,800.]])
        self.d=torch.tensor([[6000.]*7+[40.,40.]])
        self.e=torch.tensor([[87.]*4+[12.]*3+[100.,float('inf')]])
    def get_dof_stiffnesses(self):return self.k
    def get_dof_dampings(self):return self.d
    def get_dof_max_forces(self):return self.e
    def get_transforms(self):return torch.tensor([[0.,0.,0.,0.,0.,0.,1.]])
    def get_velocities(self):return torch.zeros(1,6)
    def get_root_transforms(self):return self.get_transforms()
    def get_root_velocities(self):return self.get_velocities()
    def get_dof_positions(self):return torch.zeros(1,9)
    def get_dof_velocities(self):return torch.zeros(1,9)

def robot_scene():
    data=SimpleNamespace(joint_pos=torch.zeros(1,9),joint_vel=torch.zeros(1,9),root_pos_w=torch.zeros(1,3),
        root_quat_w=torch.tensor([[1.,0.,0.,0.]]),root_lin_vel_w=torch.zeros(1,3),root_ang_vel_w=torch.zeros(1,3))
    robot=SimpleNamespace(root_physx_view=View(),joint_names=[f'fr3_joint{i}' for i in range(1,8)]+['fr3_finger_joint1','fr3_finger_joint2'],
        num_joints=9,data=data,actuators={'hand':SimpleNamespace(stiffness=torch.tensor([[800.,800.]]))})
    def setter(value,joint_ids):robot.root_physx_view.k[:,joint_ids]=value
    robot.write_joint_stiffness_to_sim=setter
    scene=SimpleNamespace(rigid_objects={'bottle':SimpleNamespace(data=data,root_physx_view=View())},articulations={'fr3_A':robot})
    return robot,scene,SimpleNamespace(current_time=5.133333333),dict(count=1230)

class Tests(unittest.TestCase):
    def test_predeclared_one_case_same_mass_targets_and_time_skill(self):
        p=json.loads((ROOT/'protocol.json').read_text());self.assertEqual(len(p['cases']),1)
        c=p['cases'][0];self.assertEqual(c['role'],'qualification');self.assertEqual(c['mass_factor'],1.2)
        self.assertEqual(c['public_transport_delay_ticks'],0)
        decision=dispatch_schedule(c,p)
        self.assertEqual(decision['source_indices'],list(range(13427)))
        self.assertEqual(decision['hold_before_close_ticks'],0);self.assertEqual(decision['hold_before_release_ticks'],0)
        self.assertEqual(p['qualification_actor_change']['candidate'],1600.)

    def test_original_inputs_and_frozen_helpers_are_exact(self):
        o=json.loads((ROOT/'SOURCE_ORIGIN.json').read_text())
        for n,h in o['copied_source_hashes'].items():
            if n.startswith(('code/','inputs/')) or n in ('plan.json','source_pins.json','gpu_mapping.py'):
                self.assertEqual(hashlib.sha256((ROOT/n).read_bytes()).hexdigest(),h,n)

    def test_parameter_install_changes_only_hand_gain_without_step(self):
        r,s,sim,c=robot_scene();receipt,expected=install(r,s,sim,c,dict(status='PASS'))
        self.assertEqual(receipt['baseline_active_stiffness'][0][-2:],[800.,800.])
        self.assertEqual(receipt['candidate_active_stiffness'][0][-2:],[1600.,1600.])
        self.assertEqual(receipt['active_damping'][0][-2:],[40.,40.])
        self.assertEqual(receipt['active_effort_limits'][0][-1],'POSITIVE_INFINITY')
        self.assertEqual(receipt['physics_callbacks_before'],receipt['physics_callbacks_after'])
        self.assertEqual(receipt['cached_scene_state_sha256_before'],receipt['cached_scene_state_sha256_after'])
        self.assertEqual(receipt['fresh_physics_view_state_sha256_before'],receipt['fresh_physics_view_state_sha256_after'])
        self.assertTrue(verify_end(r,expected)['unchanged_during_task'])

    def test_missing_baseline_acceptance_prevents_install(self):
        r,s,sim,c=robot_scene()
        with self.assertRaises(ValueError):install(r,s,sim,c,dict(status='FAIL'))
        self.assertEqual(r.root_physx_view.k[0,7].item(),800.)

    def test_wrong_active_baseline_prevents_install(self):
        r,s,sim,c=robot_scene();r.root_physx_view.k[:,7:]=60000.
        with self.assertRaises(ValueError):install(r,s,sim,c,dict(status='PASS'))

    def test_parameter_drift_during_task_is_rejected(self):
        r,s,sim,c=robot_scene();_,expected=install(r,s,sim,c,dict(status='PASS'))
        r.root_physx_view.k[:,7]=800.
        with self.assertRaises(ValueError):verify_end(r,expected)

    def test_setter_cannot_change_damping_or_native_state(self):
        r,s,sim,c=robot_scene();prior=r.write_joint_stiffness_to_sim
        def wrong(value,joint_ids):prior(value,joint_ids);r.root_physx_view.d[:,7]=50.
        r.write_joint_stiffness_to_sim=wrong
        with self.assertRaises(ValueError):install(r,s,sim,c,dict(status='PASS'))

    def test_integration_location_after_transient_pass_before_task(self):
        source=(ROOT/'native_probe.py').read_text()
        start=source.index("if verdict['status']!='PASS':raise RuntimeError('matched uninterrupted start gate failed')")
        installation=source.index('installation,gain_expected=install_declared_gain',start)
        task=source.index('result=run_task()',installation)
        self.assertLess(start,installation);self.assertLess(installation,task)
        tree=ast.parse(source)
        loop=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='run_task')
        setters=[n.func.attr for n in ast.walk(loop) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr.startswith('write_joint_')]
        self.assertFalse(setters)

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    if not result.wasSuccessful():raise SystemExit(1)
    if torch.cuda.is_initialized():raise RuntimeError('CPU gate unexpectedly initialized CUDA')
    with (ROOT/'CPU_PREFLIGHT.json').open('x') as f:
        json.dump(dict(status='PASS_GPU_FREE_QUALIFICATION_GATE',tests=result.testsRun,native_episode_count=0,
                       cuda_initialized=False,scope='FAKE_INTERFACE_CONTRACT_TESTS_AND_STATIC_LINEAGE; NOT_NATIVE_READBACK'),f,indent=2);f.write('\n')
