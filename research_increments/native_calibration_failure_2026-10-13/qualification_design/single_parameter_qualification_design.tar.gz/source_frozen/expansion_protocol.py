"""Pure CPU timing contracts, FIFO transport and independently sampled events.

The scheduler consumes a public contract and previously frozen calibration only.
It never consumes current episode object poses, contacts, or inferred mass.
"""
from collections import deque
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path

METHODS = ('nominal_prior', 'public_delay_prior', 'calibrated_interval', 'joint_interval_scheduler')


def finite(x):
    return type(x) in (int, float) and math.isfinite(x)


def score_gap(cue, effect, requested, tolerance):
    if not finite(requested) or not finite(tolerance) or tolerance < 0:
        raise ValueError('finite request and nonnegative tolerance required')
    if cue is None or effect is None:
        return dict(verdict='UNAVAILABLE', error_interval_s=None, timing_pass=False)
    if cue['clock_id'] != effect['clock_id']:
        raise ValueError('epoch mismatch')
    for item in (cue, effect):
        b = item['bounds_s']
        if len(b) != 2 or not all(finite(x) for x in b) or b[0] > b[1]:
            raise ValueError('finite ordered event bounds required')
    a, b = effect['bounds_s']; c, d = cue['bounds_s']
    lo, hi = a-d-requested, b-c-requested
    verdict = ('PASS' if lo >= -tolerance and hi <= tolerance else
               'EARLY' if hi < -tolerance else 'LATE' if lo > tolerance else 'INDETERMINATE')
    return dict(verdict=verdict, error_interval_s=[lo, hi], timing_pass=verdict == 'PASS')


def dispatch_schedule(case, protocol, calibration=None):
    dt = protocol['dt_s']
    nominal = protocol['nominal_mechanical_latency_s']
    delay = case['public_transport_delay_ticks'] * dt
    method = case['method']
    refused = False; joint_certificate = None
    if case['role'] in ('calibration','qualification'):
        close_latency, release_latency = 0., 0.
        close_extra, release_extra = 0, 0
    else:
        if method not in METHODS:
            raise ValueError('unknown method')
        close_latency, release_latency = nominal['contact'], nominal['release']
        if method == 'public_delay_prior':
            close_latency += delay; release_latency += delay
        elif method in ('calibrated_interval','joint_interval_scheduler'):
            if calibration is None or calibration['status'] != 'FROZEN_CALIBRATION':
                raise ValueError('test interval scheduler needs frozen calibration')
            close_latency = sum(calibration['mechanical_latency_intervals_s']['contact'])/2 + delay
            release_latency = sum(calibration['mechanical_latency_intervals_s']['release'])/2 + delay
        close_target = case['requested_contact_gap_s'] - close_latency
        original_close_gap = (protocol['first_close_source_index']-protocol['cue_source_index'])*dt
        close_extra = math.ceil((close_target-original_close_gap)/dt-1e-8)
        if close_extra < 0:
            raise ValueError('contact target requires moving approach earlier; outside this fixture')
        release_target = case['requested_contact_gap_s'] + case['requested_contact_to_release_s']-release_latency
        original_release_gap = (protocol['first_open_source_index']-protocol['cue_source_index'])*dt
        release_extra = math.ceil((release_target-original_release_gap)/dt-close_extra-1e-8)
        if release_extra < 0:
            raise ValueError('requested release precedes feasible source release stage')
        if method == 'joint_interval_scheduler':
            contact_interval=[x+delay for x in calibration['mechanical_latency_intervals_s']['contact']]
            release_interval=[x+delay for x in calibration['mechanical_latency_intervals_s']['release']]
            contact_gap=case['requested_contact_gap_s']; duration_gap=case['requested_contact_to_release_s']
            eps_a=case['contact_tolerance_s'];eps_b=protocol['primary_score_definition']['release_tolerance_s']
            eps_delta=case['duration_tolerance_s']
            a_bounds=[contact_gap-eps_a-contact_interval[0],contact_gap+eps_a-contact_interval[1]]
            b_bounds=[contact_gap+duration_gap-eps_b-release_interval[0],
                      contact_gap+duration_gap+eps_b-release_interval[1]]
            delta_bounds=[duration_gap-eps_delta-(release_interval[0]-contact_interval[1]),
                          duration_gap+eps_delta-(release_interval[1]-contact_interval[0])]
            candidates=[]
            min_stage_gap=(protocol['first_open_source_index']-protocol['first_close_source_index'])*dt
            for at in range(math.ceil(a_bounds[0]/dt-1e-9),math.floor(a_bounds[1]/dt+1e-9)+1):
                if at*dt < original_close_gap-1e-9:continue
                for bt in range(math.ceil(b_bounds[0]/dt-1e-9),math.floor(b_bounds[1]/dt+1e-9)+1):
                    delta=(bt-at)*dt
                    if delta >= min_stage_gap-1e-9 and delta_bounds[0]-1e-9 <= delta <= delta_bounds[1]+1e-9:
                        cost=(at*dt-(contact_gap-close_latency))**2+(bt*dt-(contact_gap+duration_gap-release_latency))**2
                        candidates.append((cost,at,bt))
            if candidates:
                _,at,bt=min(candidates)
                close_extra=at-(protocol['first_close_source_index']-protocol['cue_source_index'])
                release_extra=bt-(protocol['first_open_source_index']-protocol['cue_source_index'])-close_extra
            else:
                # Keep an entire unmodified skill as diagnostic fallback. Its
                # physical outcome cannot turn a refused schedule into success.
                close_extra=release_extra=0;refused=True
            joint_certificate=dict(contact_dispatch_bounds_s=a_bounds,release_dispatch_bounds_s=b_bounds,
                command_difference_bounds_s=delta_bounds,min_source_stage_gap_s=min_stage_gap,
                grid_feasible_candidates=len(candidates),refused=refused,
                interval_scope='FOUR_CALIBRATION_EMPIRICAL_ENVELOPE; NOT_TRUE_SUPPORT_OR_CONFIDENCE_GUARANTEE')
    close, release, total = (protocol[k] for k in ('first_close_source_index','first_open_source_index','total_commands'))
    source_indices = (list(range(close)) + [close-1]*close_extra + list(range(close, release))
                      + [release-1]*release_extra + list(range(release,total)))
    def shift(index):
        return index + (close_extra if index >= close else 0) + (release_extra if index >= release else 0)
    # Stages are saved after the corresponding final command has physically
    # passed the FIFO. The public cue remains at its *submission* tick.
    stage_plan = [dict(id=s['id'], start_tick=shift(s['start_tick']) + case['public_transport_delay_ticks'],
                       end_tick=shift(s['end_tick']) + case['public_transport_delay_ticks'])
                  for s in protocol['stage_plan']]
    stage_plan[0]['start_tick'] = 0
    return dict(source_indices=source_indices, stage_plan=stage_plan,
                hold_before_close_ticks=close_extra, hold_before_release_ticks=release_extra,
                planned_command_contact_gap_s=(close-protocol['cue_source_index']+close_extra)*dt,
                planned_command_release_gap_s=(release-protocol['cue_source_index']+close_extra+release_extra)*dt,
                expected_contact_transport_plus_mechanical_s=close_latency,
                expected_release_transport_plus_mechanical_s=release_latency,
                uses_current_test_contact_labels=False, uses_test_mass=False,
                schedule_refused=refused,joint_interval_certificate=joint_certificate,
                available_public_transport_delay_ticks=case['public_transport_delay_ticks'])


@dataclass(frozen=True)
class Packet:
    command_id: int
    source_index: int
    enqueue_tick: int
    ready_tick: int
    target: tuple


class FixedDelayFIFO:
    """At most one packet applies per real physics tick; no reset, reorder or drop."""
    def __init__(self, delay_ticks):
        if type(delay_ticks) is not int or not 0 <= delay_ticks <= 240:
            raise ValueError('bounded nonnegative integer transport delay required')
        self.delay_ticks = delay_ticks
        self.pending = deque()
        self.submitted = self.applied = 0
        self.last_tick = -1

    def step(self, tick, source_index=None, target=None):
        if tick != self.last_tick+1:
            raise ValueError('one FIFO invocation per consecutive native physics tick required')
        self.last_tick = tick
        submitted = None
        if source_index is not None:
            if target is None or not all(finite(float(v)) for v in target):
                raise ValueError('finite command target required')
            submitted = Packet(self.submitted, source_index, tick, tick+self.delay_ticks, tuple(map(float,target)))
            self.pending.append(submitted); self.submitted += 1
        applied = None
        if self.pending and self.pending[0].ready_tick <= tick:
            applied = self.pending.popleft()
            if applied.command_id != self.applied:
                raise ValueError('FIFO command sequence violation')
            self.applied += 1
        return submitted, applied


def has_prefix(path, prefix):
    return path == prefix or path.startswith(prefix+'/')


def contact_features(contact, object_prim, robot_prim, support_prefixes, impulse_min=1e-8):
    fingers = set(); support = False
    for c in contact['contacts']:
        paths = [c[k] for k in ('actor0','actor1','collider0','collider1')]
        if not any(has_prefix(p,object_prim) for p in paths):
            continue
        if sum(float(x)**2 for x in c['impulse']) <= impulse_min**2:
            continue
        for side in ('left','right'):
            if any(has_prefix(p,robot_prim) and side in p and 'finger' in p for p in paths):
                fingers.add(side)
        # Both actor and collider names originate in the same native contact
        # record. Only the declared dosing balance may establish support.
        if any(any(has_prefix(p,s) for s in support_prefixes) for p in paths):
            support = True
    return dict(bilateral=fingers == {'left','right'}, any_finger=bool(fingers), support=support)


def upright_tilt_deg(pose):
    w,x,y,z = map(float,pose[3:7]); norm=w*w+x*x+y*y+z*z
    if not math.isfinite(norm) or norm < 1e-12:
        raise ValueError('invalid actual object quaternion')
    zz = 1-2*(x*x+y*y)/norm
    return math.degrees(math.acos(max(-1.,min(1.,zz))))


def confirm_event(rows, values, count, epoch, kind, start_index=0, stability_m=None):
    run = []
    for i in range(start_index,len(rows)):
        if not values[i]:
            run=[]; continue
        run.append(i)
        if stability_m is not None:
            while run:
                origin=rows[run[0]]['object_pose'][:3]
                if all(math.dist(origin,rows[j]['object_pose'][:3]) <= stability_m for j in run):
                    break
                run.pop(0)
        if len(run) >= count:
            onset = run[-count]
            if onset == 0:
                return dict(status='LEFT_CENSORED',event=None,confirmation_time_s=rows[i]['native_after_s'],
                            confirmation_index=i,onset_index=0,confirmation_count=count,
                            continuous_dwell_established=False,left_censored=True,
                            first_true_sample_time_s=rows[0]['native_after_s'])
            return dict(status='DETECTED',event=dict(clock_id=epoch,
                         bounds_s=[rows[onset]['native_before_s'],rows[onset]['native_after_s']],
                         kind=kind,calibrated=False,endpoint_semantics='CONSERVATIVE_CLOSED_BOUNDS'),
                        confirmation_time_s=rows[i]['native_after_s'],confirmation_index=i,
                        onset_index=onset,confirmation_count=count,continuous_dwell_established=False)
    return dict(status='UNAVAILABLE',event=None,confirmation_time_s=None,confirmation_index=None,
                onset_index=None,confirmation_count=count,continuous_dwell_established=False)


def sampled_operation_events(rows, contacts, protocol, epoch):
    if not rows or len(rows) != len(contacts):
        raise ValueError('aligned nonempty native state and contact samples required')
    dt=protocol['dt_s']
    for i,(r,c) in enumerate(zip(rows,contacts)):
        if r['command_index'] != i or c['tick'] != i or r['native_epoch'] != epoch:
            raise ValueError('sample index or epoch mismatch')
        if abs(r['native_after_s']-r['native_before_s']-dt)>1e-7:
            raise ValueError('native sample duration mismatch')
        if i and abs(rows[i-1]['native_after_s']-r['native_before_s'])>1e-9:
            raise ValueError('clock discontinuity')
        if c['errors']:
            raise ValueError('contact parser error')
    feat=[contact_features(c,protocol['object_prim'],protocol['robot_prim'],
                           protocol['release_definition']['support_prim_prefixes']) for c in contacts]
    grasp=confirm_event(rows,[f['bilateral'] for f in feat],3,epoch,'bilateral_grasp')
    rel=protocol['release_definition']
    eligible=[]
    for i,(r,f) in enumerate(zip(rows,feat)):
        eligible.append(grasp['confirmation_index'] is not None and i>grasp['confirmation_index']
            and not f['any_finger'] and f['support'] and r['jaw_width_m'] >= rel['min_jaw_width_m']
            and upright_tilt_deg(r['object_pose']) <= rel['max_tilt_deg'])
    release=confirm_event(rows,eligible,rel['confirmation_count'],epoch,'verified_stable_release',
                          stability_m=rel['max_confirmation_displacement_m'])
    unloaded=confirm_event(rows,eligible,1,epoch,'raw_supported_unloaded_sample')
    hold=dict(status='UNAVAILABLE',sampled_contact_hold=False,continuous_contact_proven=False,
              missing_bilateral_sample_indices=[],scope='SAMPLED_CONTACT_ONLY_NOT_CONTINUOUS_CONTACT_PROOF')
    if grasp['event'] and release['event']:
        begin,end=grasp['onset_index'],release['onset_index']
        missing=[i for i in range(begin,end) if not feat[i]['bilateral']]
        hold.update(status='PASS' if not missing else 'INTERRUPTED',sampled_contact_hold=not missing,
                    missing_bilateral_sample_indices=missing)
    commands={}
    for key,source in [('contact',protocol['first_close_source_index']),('release',protocol['first_open_source_index'])]:
        matches=[r for r in rows if r['applied_source_command_index']==source]
        commands[key]=dict(clock_id=epoch,bounds_s=[matches[0]['native_before_s']]*2,kind=key+'_command_applied') if matches else None
    return dict(schema='paperb-native-sampled-events-v2',native_epoch=epoch,
                events=dict(bilateral_grasp=grasp,supported_release=release,raw_first_supported_unloaded=unloaded),applied_commands=commands,
                sampled_contact_hold=hold,event_calibration_pass=False,chemical_event_verified=False,
                scope='NATIVE_RIGID_BOTTLE_CONTACT_AND_SUPPORTED_RELEASE')


def calibration_model(root, protocol):
    """Four complete calibration episodes; no test output is opened."""
    root=Path(root);obs=[];sources={}
    for case in protocol['cases']:
        if case['role'] != 'calibration':
            continue
        p=root/'cases'/case['id']; result=json.loads((p/'RESULT.json').read_text())
        if result['status'] != 'BASELINE_COMMANDS_COMPLETED' or not result['task_mechanism_pass']:
            raise ValueError('all calibration outcomes retained; incomplete physical skill prevents fit: '+case['id'])
        ev=json.loads((p/'task/expanded_events.json').read_text())
        for key,name in [('contact','bilateral_grasp'),('release','supported_release')]:
            effect=ev['events'][name]['event']; command=ev['applied_commands'][key]
            if not effect or not command or effect['clock_id'] != command['clock_id']:
                raise ValueError('calibration lacks independent same-epoch event: '+case['id'])
            a,b=effect['bounds_s'];c,d=command['bounds_s']
            obs.append(dict(case_id=case['id'],kind=key,mechanical_interval_s=[a-d,b-c]))
        for n in ('RESULT.json','case.json','mass_parameter_readback.json','task/expanded_events.json','task/dispatch.jsonl','task/states.jsonl','task/contact_rows.jsonl'):
            f=p/n;sources[str(f.relative_to(root))]=hashlib.sha256(f.read_bytes()).hexdigest()
    if len(obs) != 8:
        raise ValueError('exactly four independently completed calibration episodes required')
    intervals={k:[min(o['mechanical_interval_s'][0] for o in obs if o['kind']==k),
                  max(o['mechanical_interval_s'][1] for o in obs if o['kind']==k)] for k in ('contact','release')}
    return dict(schema='paperb-independent-timing-calibration-v2',status='FROZEN_CALIBRATION',
                fitted_episode_ids=[c['id'] for c in protocol['cases'] if c['role']=='calibration'],
                mechanical_latency_intervals_s=intervals,observations=obs,sources=sources,
                uses_test_events=False,calibration_is_statistical_coverage_guarantee=False,
                method='MIN_MAX_SAMPLED_CALIBRATION_MECHANICAL_LATENCY; NO_ESTIMATED_MASS_AT_TEST')
