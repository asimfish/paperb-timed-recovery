"""C-21b passive XRD window articulation: damping only, no position/velocity drive."""
import math, os
from numbers import Real

def make_xrd_cfg(prim_path, usd_path, world_pose, rest_offset=0., contact_offset=.001):
    import isaaclab.sim as sim_utils
    from isaaclab.assets import ArticulationCfg
    from isaaclab.actuators import ImplicitActuatorCfg
    if not isinstance(prim_path,str) or not prim_path.startswith('/'):
        raise ValueError('absolute prim_path required')
    pose=tuple(world_pose)
    if len(pose)!=7 or not all(isinstance(v,Real) and math.isfinite(v) for v in pose):
        raise ValueError('finite 7-value pose required')
    # stiffness=0 means no position target force; this overlay retains damping only.
    return ArticulationCfg(
      prim_path=prim_path,
      spawn=sim_utils.UsdFileCfg(
        usd_path=str(usd_path),
        articulation_props=sim_utils.ArticulationRootPropertiesCfg(
          fix_root_link=True, articulation_enabled=True, enabled_self_collisions=True,
          solver_position_iteration_count=32, solver_velocity_iteration_count=4),
        rigid_props=sim_utils.RigidBodyPropertiesCfg(
          kinematic_enabled=False, max_depenetration_velocity=1.),
        collision_props=sim_utils.CollisionPropertiesCfg(rest_offset=rest_offset, contact_offset=contact_offset)),
      init_state=ArticulationCfg.InitialStateCfg(
        pos=tuple(pose[:3]), rot=tuple(pose[3:]),
        joint_pos={'Window_slide_joint':0.}, joint_vel={'.*':0.}),
      actuators={'window_passive':ImplicitActuatorCfg(
        joint_names_expr=['Window_slide_joint'], stiffness=0., damping=100.,
        effort_limit_sim=100., velocity_limit_sim=.2)})
