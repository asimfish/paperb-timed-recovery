"""Recompute task scores from measured arrays and raw PhysX contacts only.

No simulator, executor arrival flags, planner self-score, or stored score is used.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


def longest_run(mask):
    indices = np.flatnonzero(np.r_[True, np.diff(np.asarray(mask,dtype=np.int8))!=0, True])
    lengths = np.diff(indices)
    return int(max((n for i,n in zip(indices[:-1],lengths) if mask[i]),default=0)) if len(mask) else 0


def tilt(q):
    q=np.asarray(q,dtype=float);q=q/np.linalg.norm(q,axis=1,keepdims=True)
    return np.arccos(np.clip(1.-2.*(q[:,1]**2+q[:,2]**2),-1.,1.))


def first_run_end(mask, length):
    length=max(1,int(length))
    if len(mask)<length:return len(mask)
    run=np.convolve(np.asarray(mask,dtype=np.int32),np.ones(length,dtype=np.int32),'valid')
    hits=np.flatnonzero(run==length)
    return int(hits[0]+length-1) if len(hits) else len(mask)


def relative_position(tcp, xyz):
    """Measured object origin expressed in the measured TCP frame (wxyz)."""
    tcp=np.asarray(tcp);q=tcp[:,3:]/np.linalg.norm(tcp[:,3:],axis=1,keepdims=True)
    v=np.asarray(xyz)-tcp[:,:3];u=-q[:,1:]
    cross=2*np.cross(u,v)
    return v+q[:,:1]*cross+np.cross(u,cross)


def rescore(arrays, contract, contact_rows, coverage_verified=False):
    times=np.asarray(arrays['t']); n=len(times)
    if not n or not contract.get('phases'):
        return {'stage':0,'gate_pass':False,'reason':'empty trajectory' if not n else 'uninitialized task contract',
                'phases':[],'conditions':{'nonempty_measured_trajectory':False},
                'penetration_ticks':0,'penetration_tick_indices':[],
                'penetration_numerical_tolerance_m':contract.get('penetration_numerical_tolerance_m'),
                'raw_negative_separation_ticks':0,'below_minus_1mm_ticks':0,
                'minimum_relevant_separation_m':None,'contact_rows_n':0,'ticks_n':n,
                'contact_parse_errors':0,'raw_evidence_sufficient':False}
    required=['tcp','q','qd','jaw_width_m']
    if any(k not in arrays for k in required):return {'stage':0,'gate_pass':False,'reason':'missing measured channels'}
    finite=all(np.isfinite(v).all() for v in arrays.values() if np.issubdtype(np.asarray(v).dtype,np.number))
    dt=float(contract['dt_s']);origin_tick=int(contract.get('origin_tick',0))
    bilateral={p['object']:np.zeros(n,dtype=bool) for p in contract['phases']}
    finger_loaded={name:np.zeros(n,dtype=bool) for name in bilateral}
    seen_ticks=set();bad_ticks=set();negative_ticks=set();one_mm_ticks=set();minimum_separation=None;parse_errors=0;robot=contract['robot_prim']
    penetration_tolerance=contract['penetration_numerical_tolerance_m']
    for row in contact_rows:
        tick=int(row['tick'])-origin_tick
        if tick<0 or tick>=n:continue
        seen_ticks.add(tick);parse_errors+=len(row.get('errors',[]));sides={k:set() for k in bilateral}
        for point in row['contacts']:
            paths=[point[k] for k in ('actor0','actor1','collider0','collider1')]
            grasp_pair=False
            for name in bilateral:
                prefix=contract['object_prims'][name]
                if not any(p.startswith(prefix) for p in paths):continue
                for side in ('left','right'):
                    if any(p.startswith(robot) and side in p and ('finger' in p or 'fingertip' in p) for p in paths):
                        grasp_pair=True
                        if np.linalg.norm(point['impulse'])>1e-8:sides[name].add(side)
            relevant=any(p.startswith(robot) for p in paths) or any(p.startswith(tuple(contract['object_prims'].values())) for p in paths)
            if relevant:
                separation=point['separation_m']
                minimum_separation=separation if minimum_separation is None else min(minimum_separation,separation)
                if separation<0:negative_ticks.add(tick)
                if separation<-.001:one_mm_ticks.add(tick)
                if separation < -penetration_tolerance:bad_ticks.add(tick)
        for name in bilateral:
            bilateral[name][tick]=sides[name]=={'left','right'}
            finger_loaded[name][tick]=bool(sides[name])
    phases=[];cursor=0;overall=0
    for phase in contract['phases']:
        name=phase['object'];key='obj_'+name
        if key not in arrays:phases.append({'object':name,'stage':0,'reason':'missing object pose'});break
        pose=np.asarray(arrays[key]);upright=tilt(pose[:,3:]);goal=np.asarray(phase['goal_root_xyz'])
        poserr=np.linalg.norm(pose[:,:3]-goal,axis=1)
        contacts=bilateral[name].copy();contacts[:cursor]=False
        grasp=longest_run(contacts)>=3
        firstgrasp=first_run_end(contacts,3)
        lifted=(pose[:,2] >= phase['initial_root_xyz'][2]+.03)
        lifted[:firstgrasp]=False
        lift=longest_run(lifted)>=max(3,round(.15/dt))
        firstlift=first_run_end(lifted,max(3,round(.15/dt)))
        stage=2 if lift else (1 if grasp else 0)
        if phase.get('dosing_root_xyz'):
            dosing=np.linalg.norm(pose[:,:3]-np.asarray(phase['dosing_root_xyz']),axis=1)<=.02
            dosing &= upright<=.25;dosing[:firstlift]=False
            target_above=longest_run(dosing)>=3
            target_reached=longest_run(dosing)>=round(phase['dosing_hold_s']/dt)
            target_tick=first_run_end(dosing,round(phase['dosing_hold_s']/dt))
        else:
            above=(np.linalg.norm(pose[:,:2]-goal[:2],axis=1)<=.05)&(pose[:,2]>=goal[2]-.005)&(pose[:,2]<=goal[2]+.15)
            above[:firstlift]=False;target_reached=longest_run(above)>=3;target_above=target_reached
            target_tick=first_run_end(above,3)
        if lift and target_above:stage=3
        released=(np.asarray(arrays['jaw_width_m'])>=phase['grasp_width_m']+.003)&~finger_loaded[name]
        release_search=released.copy();release_search[:firstgrasp]=False
        release_end=first_run_end(release_search,3)
        carry_end=max(firstgrasp,min(n,release_end-2 if release_end<n else n))
        relative=relative_position(arrays['tcp'],pose[:,:3])
        relative_error=None;contact_fraction=None
        if carry_end>firstgrasp:
            reference=np.median(relative[firstgrasp:min(carry_end,firstgrasp+10)],axis=0)
            relative_error=float(np.linalg.norm(relative[firstgrasp:carry_end]-reference,axis=1).max())
            contact_fraction=float(bilateral[name][firstgrasp:carry_end].mean())
        speed=np.r_[np.inf,np.linalg.norm(np.diff(pose[:,:3],axis=0),axis=1)/dt]
        stable=(poserr<=.02)&(upright<=.25)&released&(speed<=.02)
        yaw_error=None
        if phase.get('goal_yaw_deg') is not None:
            q=pose[:,3:];yaw=np.arctan2(2*(q[:,0]*q[:,3]+q[:,1]*q[:,2]),1-2*(q[:,2]**2+q[:,3]**2))
            delta=yaw-np.radians(phase['goal_yaw_deg']);yaw_error=np.abs(np.arctan2(np.sin(delta),np.cos(delta)))
            stable &= yaw_error<=.25
        stable[:target_tick]=False
        final_stable=longest_run(stable)>=max(3,round(.5/dt))
        if stage==3 and final_stable and poserr[-1]<=.02 and upright[-1]<=.25 and speed[-1]<=.02 and not finger_loaded[name][-1] and (yaw_error is None or yaw_error[-1]<=.25):stage=4
        carrying=upright[firstgrasp:] if firstgrasp<n else np.asarray([])
        result={'object':name,'stage':stage,'grasp_confirmed':grasp,'lift_confirmed':lift,
                'target_operation_completed':target_reached,'placement_stable':final_stable,
                'transport_max_relative_displacement_m':relative_error,'transport_bilateral_contact_fraction':contact_fraction,
                'final_position_error_mm':float(poserr[-1]*1000),'minimum_position_error_mm':float(poserr.min()*1000),
                'final_tilt_rad':float(upright[-1]),'transport_max_tilt_rad':float(carrying.max()) if len(carrying) else None}
        if yaw_error is not None:result['final_yaw_error_rad']=float(yaw_error[-1])
        phases.append(result)
        if stage<4:
            overall=max(stage,3 if len(phases)>1 else 0);break
        cursor=first_run_end(stable,max(3,round(.5/dt)))
        overall=4 if len(phases)==len(contract['phases']) else 3
    joint_violation=bool(np.any(np.asarray(arrays.get('joint_limit_margin',[0]))<-.15))
    all_joint_check={'required':bool(contract.get('robot_state_bounds')),'evaluated':False}
    if all_joint_check['required']:
        bounds=contract['robot_state_bounds'];count=len(bounds['joint_names'])
        positions=np.asarray(arrays.get('q_all',[]));velocities=np.asarray(arrays.get('qd_all',[]))
        limits=np.asarray(bounds['position_limits']);tolerance=np.asarray(bounds['position_tolerance'])
        speed_limit=np.asarray(bounds['velocity_limit'])
        shape_ok=(positions.shape==(n,count) and velocities.shape==(n,count) and limits.shape==(count,2)
                  and tolerance.shape==(count,) and speed_limit.shape==(count,))
        if shape_ok:
            limit_bad=(positions<limits[:,0]-tolerance)|(positions>limits[:,1]+tolerance)
            speed_bad=abs(velocities)>speed_limit
            bad=limit_bad|speed_bad
            all_joint_check.update(evaluated=True,position_violation_ticks=int(np.any(limit_bad,axis=1).sum()),
                velocity_violation_ticks=int(np.any(speed_bad,axis=1).sum()),
                violating_joint_names=[name for name,bad_joint in zip(bounds['joint_names'],bad.any(axis=0)) if bad_joint])
            joint_violation=joint_violation or bool(bad.any())
        else:
            all_joint_check['reason']='missing or malformed full-joint measurements/bounds';joint_violation=True
    conditions={'all_phases_complete':len(phases)==len(contract['phases']) and all(p['stage']==4 for p in phases),
        'physical_grasp':contract['grasp_mode']=='physical','not_diagnostic':not contract['diagnostic'],
        'finite_trajectory':finite,'joint_state_valid':not joint_violation,
        'contact_rows_complete':len(seen_ticks)==n,'contact_parse_errors_zero':parse_errors==0,
        'contact_coverage_verified':bool(coverage_verified),'penetration_ticks_zero':not bad_ticks,
        'transport_relative_pose_ok':all(p.get('transport_max_relative_displacement_m') is not None and p['transport_max_relative_displacement_m']<=.02 for p in phases),
        'transport_contact_continuity_ok':all(p.get('transport_bilateral_contact_fraction') is not None and p['transport_bilateral_contact_fraction']>=.8 for p in phases),
        'transport_tilt_ok':all(p.get('transport_max_tilt_rad') is not None and p['transport_max_tilt_rad']<=.25 for p in phases)}
    door=contract.get('required_closed_door')
    if door:
        values=arrays.get('door_'+door['asset'])
        conditions['door_closed']=values is not None and abs(float(np.asarray(values)[-1,door['joint_index']]))<=.05
        axis=door['retreat_axis'];direction=door['retreat_direction'];threshold=door['retreat_plane']
        conditions['gripper_retreated']=float(arrays['tcp'][-1,axis]-threshold)*direction >= .15
    retreat=contract.get('required_retreat')
    if retreat:
        conditions['gripper_retreated']=float(arrays['tcp'][-1,retreat['axis']]-retreat['plane'])*retreat['direction']>=.15
    contents=contract.get('transported_contents',[])
    if contents:
        tray=np.asarray(arrays['obj_'+contract['phases'][0]['object']])
        q=tray[-1,3:];yaw=np.arctan2(2*(q[0]*q[3]+q[1]*q[2]),1-2*(q[2]**2+q[3]**2))
        rotation=np.array([[np.cos(yaw),np.sin(yaw)],[-np.sin(yaw),np.cos(yaw)]])
        retained=[]
        for name in contents:
            obj=arrays.get('obj_'+name)
            if obj is None:retained.append(False);continue
            local=rotation@(np.asarray(obj)[-1,:2]-tray[-1,:2]);height=float(np.asarray(obj)[-1,2]-tray[-1,2])
            retained.append(bool(abs(local[0])<=.14 and abs(local[1])<=.07 and 0.<height<.12 and tilt(np.asarray(obj)[-1:,3:])[0]<=.25))
        conditions['loaded_crucibles_retained']=all(retained)
    return {'stage':overall,'gate_pass':all(conditions.values()),'phases':phases,'conditions':conditions,
            'penetration_ticks':len(bad_ticks),'penetration_tick_indices':sorted(bad_ticks),
            'penetration_numerical_tolerance_m':penetration_tolerance,
            'raw_negative_separation_ticks':len(negative_ticks),'below_minus_1mm_ticks':len(one_mm_ticks),
            'minimum_relevant_separation_m':minimum_separation,
            'contact_rows_n':len(seen_ticks),'ticks_n':n,'contact_parse_errors':parse_errors,
            'all_joint_state_check':all_joint_check}


def audit_episode(path):
    path=Path(path);meta=json.loads((path/'meta.json').read_text())
    with np.load(path/'steps.npz',allow_pickle=False) as raw:arrays={k:raw[k] for k in raw.files}
    digest=hashlib.sha256()
    for key in sorted(arrays):
        digest.update(key.encode());digest.update(str(arrays[key].shape).encode());digest.update(arrays[key].tobytes())
    geometry_path=path/'jaw_geometry.json'
    geometry_audit={'available':geometry_path.exists(),'required':meta['contract'].get('jaw_geometry_required',False)}
    if geometry_audit['required'] and not geometry_path.exists():
        raise ValueError('required jaw geometry missing: '+str(path))
    if geometry_path.exists() and len(arrays['t']):
        from jaw_geometry_audit import measure
        geometry=json.loads(geometry_path.read_text())
        corrected,midpoint=measure(arrays,meta['metrics']['all_body_names'],geometry)
        logged=np.asarray(arrays['jaw_width_m'],dtype=float)
        geometry_audit.update(frames=len(corrected),method='independent raw body_pose_w and source pad vertices',
            geometry_sha256=hashlib.sha256(geometry_path.read_bytes()).hexdigest(),
            max_absolute_logged_gap_difference_m=float(np.max(np.abs(corrected-logged))),
            logged_minus_recomputed_gap_range_m=[float(np.min(logged-corrected)),float(np.max(logged-corrected))],
            max_tcp_midpoint_difference_m=float(np.max(np.linalg.norm(midpoint-arrays['tcp'][:,:3],axis=1))),
            raw_arrays_unchanged=True)
        arrays=dict(arrays);arrays['jaw_width_m']=corrected
    from contact_io import read_contacts
    result=rescore(arrays,meta['contract'],read_contacts(path),meta['metrics'].get('contact_coverage_verified',False))
    result['jaw_geometry_audit']=geometry_audit
    result['trajectory_sha256']=digest.hexdigest()
    (path/'independent_audit.json').write_text(json.dumps(result,indent=2))
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('episodes',nargs='+');args=p.parse_args()
    for episode in args.episodes:print(episode,json.dumps(audit_episode(episode)))
