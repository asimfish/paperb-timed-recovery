"""Pad geometry attached to measured PhysX rigid bodies, independent of USD pose updates."""
import itertools
import numpy as np


def pad_frames(robot, prim_path, stage=None):
    from pxr import UsdGeom, UsdPhysics
    if stage is None:
        import omni.usd
        stage = omni.usd.get_context().get_stage()
    cache = UsdGeom.XformCache()
    # FR3 contact pads are invisible collision primitives, including guide
    # purpose. Visibility affects rendering, never the physical TCP geometry.
    bbox = UsdGeom.BBoxCache(0, ['default', 'render','proxy','guide'], False, True)
    pads = []
    for prim in stage.Traverse():
        is_franka_pad=prim.GetName()=='mesh_3' and any(name in str(prim.GetPath()) for name in ('fr3_leftfinger/collisions/','fr3_rightfinger/collisions/'))
        if not str(prim.GetPath()).startswith(prim_path) or not (prim.IsA(UsdGeom.Mesh) or is_franka_pad):
            continue
        if 'fingertipsstep' not in str(prim.GetPath()) and not is_franka_pad:
            continue
        body = prim
        while body and not body.HasAPI(UsdPhysics.RigidBodyAPI):
            body = body.GetParent()
        if not body:
            continue
        indices = robot.find_bodies(body.GetName())[0]
        if len(indices) != 1:
            raise ValueError('ambiguous finger rigid body')
        if is_franka_pad and prim.IsA(UsdGeom.Cube):
            # This asset's authored extent already contains its dimensions.
            # Build size-defined vertices and apply each scale exactly once,
            # relative to the proper rigid-body frame used by PhysX.
            size = float(UsdGeom.Cube(prim).GetSizeAttr().Get())
            points = np.array(list(itertools.product((-size/2, size/2), repeat=3)))
            body_world = np.asarray(cache.GetLocalToWorldTransform(body)).T
            u, _, vt = np.linalg.svd(body_world[:3, :3])
            proper = np.eye(4); proper[:3, :3] = u @ vt; proper[:3, 3] = body_world[:3, 3]
            if np.linalg.det(proper[:3, :3]) < 0:
                raise ValueError('reflected rigid-body frame')
            transform = np.linalg.inv(proper) @ np.asarray(cache.GetLocalToWorldTransform(prim)).T
            vertices = points @ transform[:3, :3].T + transform[:3, 3]
            corners = vertices.tolist(); centre = vertices.mean(axis=0)
            method = 'Cube.size vertices; full affine to proper rigid-body frame'
        else:
            bound = bbox.ComputeRelativeBound(prim, body).ComputeAlignedRange()
            if bound.IsEmpty():
                raise ValueError('empty fingertip geometry')
            lo, hi = np.asarray(bound.GetMin()), np.asarray(bound.GetMax())
            corners = [np.where(bits, hi, lo).tolist() for bits in itertools.product((0, 1), repeat=3)]
            centre = (lo+hi)/2
            method = 'Mesh relative aligned bound; unchanged UR calibration'
        pads.append({'path': str(prim.GetPath()), 'body': body.GetName(), 'body_id': indices[0],
                     'local_centre': centre.tolist(), 'corners': corners, 'geometry_method': method})
    if len(pads) != 2:
        raise ValueError(f'expected two opposing finger pads, found {len(pads)}')
    return pads
