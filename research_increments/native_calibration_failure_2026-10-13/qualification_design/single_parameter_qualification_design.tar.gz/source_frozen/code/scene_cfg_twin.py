"""A-Lab scene config driven by the selected plan's robots, fixtures and cameras.

ALAB_PLAN_PATH selects the v3 derivative (A FR3, B/C UR5e); the default remains v2.
Exposes GOAI_SCENE_CFG for the Isaac Lab launcher.
"""
import json
import math
import os
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg, RigidObjectCfg
from isaaclab.actuators import ImplicitActuatorCfg
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sensors import CameraCfg
from isaaclab.utils import configclass

OUT = Path(__file__).resolve().parent
PLAN_PATH = Path(os.environ.get('ALAB_PLAN_PATH', str(OUT / 'placement_plan.json'))).resolve()
PLAN = json.loads(PLAN_PATH.read_text())
CONTACTS = json.loads((OUT / 'contact_calibration.json').read_text())['rest_offsets_m']
PSILAB = '/mnt/nas/data/safelab/retreat/lyf-back/chembench/psilab/assets'
ROBOT_USD = {'franka_fr3': PSILAB + '/usd/robots/fr3/fr3/fr3_with_cameras.usd', 'ur5e_2f85': PSILAB + '/usd/robots/ur5/ur5/ur5e_2f85_real_jointstable_soft.usd'}
UR5E_HOME = {'shoulder_pan_joint': 0., 'shoulder_lift_joint': -1.9, 'elbow_joint': 1.9, 'wrist_1_joint': -1.57, 'wrist_2_joint': -1.57, 'wrist_3_joint': 0., 'finger_joint': 0., '(left|right)_.*': 0.}
FR3_HOME = {'fr3_joint1': 0., 'fr3_joint2': -.785, 'fr3_joint3': 0., 'fr3_joint4': -2.356, 'fr3_joint5': 0., 'fr3_joint6': 1.571, 'fr3_joint7': .785, 'fr3_finger_joint.*': .04}
BASE = [PLAN['robots'][0]['base'][0], PLAN['robots'][0]['base'][1], PLAN['robots'][0]['base'][2], 1., 0., 0., 0.]   # compatibility for build_scene reach checks


def yaw_quat(deg):
    r = math.radians(deg); return (math.cos(r / 2), 0., 0., math.sin(r / 2))


def camera_quat(eye, target):
    forward = np.asarray(target) - np.asarray(eye); forward /= np.linalg.norm(forward)
    reference_up = [0., 1., 0.] if abs(forward[2]) > .9999 else [0., 0., 1.]
    left = np.cross(reference_up, forward); left /= np.linalg.norm(left); up = np.cross(forward, left)
    q = Rotation.from_matrix(np.stack([forward, left, up], axis=1)).as_quat(); return tuple(q[[3, 0, 1, 2]])


def camera(path, eye, target, focal=16.):
    data_types=['rgb', 'distance_to_image_plane']
    if os.environ.get('ALAB_ACCEPTANCE_SEGMENTATION')=='1':data_types.append('instance_id_segmentation_fast')
    return CameraCfg(prim_path=path, width=1280, height=800, update_period=0., data_types=data_types,colorize_instance_id_segmentation=False,
        spawn=sim_utils.PinholeCameraCfg(focal_length=focal, horizontal_aperture=24., clipping_range=(.05, 40.)),
        offset=CameraCfg.OffsetCfg(pos=tuple(eye), rot=camera_quat(eye, target), convention='world'))


def wrist_camera_rotation(offset):
    forward = np.array([0.,0.,.17])-np.asarray(offset); forward /= np.linalg.norm(forward)
    right = np.cross(forward,[0.,-1.,0.]); right /= np.linalg.norm(right)
    down = np.cross(forward,right)
    q = Rotation.from_matrix(np.stack([right,down,forward],axis=1)).as_quat()
    return tuple(q[[3,0,1,2]])


@configclass
class GOAI_SCENE_CFG(InteractiveSceneCfg):
    room = AssetBaseCfg(prim_path='/World/Room', spawn=sim_utils.UsdFileCfg(usd_path=PLAN['room_usd']), init_state=AssetBaseCfg.InitialStateCfg(pos=(0., 0., 0.)))
    light = AssetBaseCfg(prim_path='/World/Light', spawn=sim_utils.DomeLightCfg(intensity=1400., color=(1., .99, .97)))
    fill = AssetBaseCfg(prim_path='/World/Fill', spawn=sim_utils.DistantLightCfg(intensity=1200., color=(1., .97, .92), angle=3.), init_state=AssetBaseCfg.InitialStateCfg(rot=(.92, .27, .27, 0.)))
    # ceiling panel lights over each station (lab_clean's own lights are unlit fixtures)
    lamp_a = AssetBaseCfg(prim_path='/World/Lamps/A', spawn=sim_utils.SphereLightCfg(intensity=60000., radius=.25, color=(1., .98, .95)), init_state=AssetBaseCfg.InitialStateCfg(pos=(-7.7, 1.5, 2.6)))
    lamp_b = AssetBaseCfg(prim_path='/World/Lamps/B', spawn=sim_utils.SphereLightCfg(intensity=60000., radius=.25, color=(1., .98, .95)), init_state=AssetBaseCfg.InitialStateCfg(pos=(-7.7, -1.3, 2.6)))
    lamp_c = AssetBaseCfg(prim_path='/World/Lamps/C', spawn=sim_utils.SphereLightCfg(intensity=60000., radius=.25, color=(1., .98, .95)), init_state=AssetBaseCfg.InitialStateCfg(pos=(-5.8, 3.2, 2.6)))
    lamp_d = AssetBaseCfg(prim_path='/World/Lamps/D', spawn=sim_utils.SphereLightCfg(intensity=40000., radius=.25, color=(1., .98, .95)), init_state=AssetBaseCfg.InitialStateCfg(pos=(-3.0, 0.5, 2.6)))

    def __post_init__(self):
        self.replicate_physics = False
        for letter in ('A','B','C'):
            robot = next(r for r in PLAN['robots'] if r.get('station')==letter)
            getattr(self,'lamp_'+letter.lower()).init_state.pos = (robot['base'][0],robot['base'][1],2.7)
        for i, cam in enumerate(PLAN['cameras']):
            eye=cam['eye'];target=cam['target']
            if cam['name']=='b_front' and any(r.get('station')=='C' and r['type']=='ur5e_2f85' for r in PLAN['robots']):
                # The manifest front camera sees the rail/rack across the tray.
                # Raise and move its optical point toward the task side.
                eye=[-1.05,-1.25,2.10];target=[-1.315,-2.65,1.20]
            setattr(self, f"{cam['name']}_camera", camera(f"/World/Cameras/{cam['name']}", eye, target, focal=cam.get('focal', 16.)))
        for r in PLAN['robots']:
            name = r['prim_path'].split('/')[-1]
            if r['type'] == 'franka_fr3':
                cfg = ArticulationCfg(prim_path=r['prim_path'], spawn=sim_utils.UsdFileCfg(usd_path=r.get('usd') or ROBOT_USD['franka_fr3'],
                        articulation_props=sim_utils.ArticulationRootPropertiesCfg(fix_root_link=True, enabled_self_collisions=True)),
                    init_state=ArticulationCfg.InitialStateCfg(pos=tuple(r['base']), rot=yaw_quat(r.get('yaw_deg', 0.)), joint_pos=FR3_HOME),
                    actuators={'arm': ImplicitActuatorCfg(joint_names_expr=['fr3_joint[1-7]'], stiffness=None, damping=None),
                               'hand': ImplicitActuatorCfg(joint_names_expr=['fr3_finger_joint.*'], stiffness=800., damping=40.)})
            else:
                cfg = ArticulationCfg(prim_path=r['prim_path'], spawn=sim_utils.UsdFileCfg(usd_path=r.get('usd') or ROBOT_USD['ur5e_2f85'],
                        articulation_props=sim_utils.ArticulationRootPropertiesCfg(fix_root_link=None, enabled_self_collisions=True, solver_position_iteration_count=32, solver_velocity_iteration_count=4),
                        rigid_props=sim_utils.RigidBodyPropertiesCfg(max_depenetration_velocity=1.0)),
                    init_state=ArticulationCfg.InitialStateCfg(pos=tuple(r['base']), rot=yaw_quat(r.get('yaw_deg', 0.)), joint_pos=UR5E_HOME),
                    actuators={'arm': ImplicitActuatorCfg(joint_names_expr=['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint'], stiffness=800., damping=80., effort_limit_sim=150.),
                               'hand': ImplicitActuatorCfg(joint_names_expr=['finger_joint'], stiffness=170., damping=34., armature=0.005, effort_limit_sim=95.),
                               # The Robotiq mimic links are passive PhysX DOFs.
                               # A small physical armature and higher damping
                               # suppress the measured first-close impulse
                               # without disabling self-collision or relaxing
                               # the joint-state guard.
                               'hand_passive': ImplicitActuatorCfg(joint_names_expr=['(left|right)_.*'], stiffness=0., damping=20., armature=0.005, effort_limit_sim=35.)})
            setattr(self, name, cfg)
            # wrist camera (RoboCurve-style observation): under the hand/wrist link, looking along the tool axis; ROS optical convention (z forward)
            link, off = ('fr3_hand', (.065,0.,.075)) if r['type']=='franka_fr3' else ('wrist_3_link', (0.,.065,.075))
            if name=='ur5e_B':off=(0.,-.065,.075)
            rot = wrist_camera_rotation(off)
            setattr(self, f'{name}_wrist_camera', CameraCfg(prim_path=f"{r['prim_path']}/{link}/wrist_cam", width=640, height=400, update_period=0., data_types=['rgb'],
                spawn=sim_utils.PinholeCameraCfg(focal_length=12., horizontal_aperture=24., clipping_range=(.02, 10.)), offset=CameraCfg.OffsetCfg(pos=off, rot=rot, convention='ros')))
        for p in PLAN['prims']:
            if p['name']=='xrd' and PLAN.get('xrd_window_joint'):
                if PLAN.get('xrd_window_passive'):
                    from xrd_window_passive_cfg import make_xrd_cfg
                else:
                    from xrd_window_cfg import make_xrd_cfg
                setattr(self,'xrd',make_xrd_cfg(p['prim_path'],p['prepared_usd'],p['world_pose']))
                continue
            common = dict(prim_path=p['prim_path'], spawn=sim_utils.UsdFileCfg(usd_path=p['prepared_usd'],
                rigid_props=sim_utils.RigidBodyPropertiesCfg(solver_position_iteration_count=16, solver_velocity_iteration_count=2,
                    linear_damping=1. if p['kind'] == 'object' else None, angular_damping=5. if p['kind'] == 'object' else None, sleep_threshold=.005 if p['kind'] == 'object' else None),
                collision_props=sim_utils.CollisionPropertiesCfg(contact_offset=CONTACTS.get(p['name'], 0.) + .001, rest_offset=CONTACTS.get(p['name'], 0.))))
            if p['articulated']:
                # v4 instruments expose only Door_joint/Window_slide_joint; one catch-all
                # actuator group avoids Isaac Lab's unmatched-regex ValueError.
                actuators={'doors': ImplicitActuatorCfg(joint_names_expr=['.*'], stiffness=200., damping=20., effort_limit_sim=PLAN.get('door_effort_limit_Nm') if p['name'] in [*[f'furnace_{i}' for i in range(1,5)],'drying_oven'] else None)}
                cfg = ArticulationCfg(**common, init_state=ArticulationCfg.InitialStateCfg(pos=tuple(p['world_pose'][:3]), rot=tuple(p['world_pose'][3:]), joint_pos={'.*': 0.}),
                    actuators=actuators)
            else:
                cfg = RigidObjectCfg(**common, init_state=RigidObjectCfg.InitialStateCfg(pos=tuple(p['world_pose'][:3]), rot=tuple(p['world_pose'][3:])))
            setattr(self, p['name'], cfg)
