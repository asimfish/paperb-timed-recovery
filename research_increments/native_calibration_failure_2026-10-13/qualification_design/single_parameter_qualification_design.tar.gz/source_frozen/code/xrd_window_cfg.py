"""Import-safe exact registration helper for the installed IsaacLab API."""
import math
import os
from numbers import Real

def make_xrd_cfg(prim_path,usd_path,world_pose,rest_offset=0.,contact_offset=.001):
 """Register as scene['xrd'] BEFORE generic plan rigid-object handling.

Geometry is baked: do not apply target_size/uniform_scale again. Offset defaults
are explicit mechanism contact settings (zero rest gap at sliding frame tangencies),
not a claim of tuned PhysX dynamics. Override only with recorded calibration.
"""
 if not isinstance(prim_path,str) or not prim_path.startswith('/') or prim_path=='/' or not prim_path.strip():raise ValueError('absolute nonroot prim_path required')
 try: usd_path=os.fspath(usd_path)
 except TypeError as exc: raise ValueError('usd_path must be a nonempty path string') from exc
 if not isinstance(usd_path,str) or not usd_path.strip():raise ValueError('usd_path must be a nonempty path string')
 if isinstance(world_pose,(str,bytes)):raise ValueError('world_pose must be a7-value sequence')
 try: world_pose=tuple(world_pose)
 except TypeError as exc:raise ValueError('world_pose must be a7-value sequence') from exc
 def finite_real(v):return not isinstance(v,bool) and isinstance(v,Real) and math.isfinite(v)
 if len(world_pose)!=7 or not all(finite_real(v) for v in world_pose):raise ValueError('world_pose must be xyz+wxyz finite real scalars')
 if abs(sum(v*v for v in world_pose[3:])-1)>1e-5:raise ValueError('quaternion must be normalized wxyz')
 if not finite_real(rest_offset) or not finite_real(contact_offset) or not (0<=rest_offset<contact_offset):raise ValueError('finite offsets require0<=rest_offset<contact_offset')
 import isaaclab.sim as sim_utils
 from isaaclab.assets import ArticulationCfg
 from isaaclab.actuators import ImplicitActuatorCfg
 return ArticulationCfg(
  prim_path=prim_path,
  spawn=sim_utils.UsdFileCfg(
   usd_path=str(usd_path),
   articulation_props=sim_utils.ArticulationRootPropertiesCfg(
    fix_root_link=True,articulation_enabled=True,enabled_self_collisions=True,
    solver_position_iteration_count=32,solver_velocity_iteration_count=4),
   rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=False,max_depenetration_velocity=1.),
   collision_props=sim_utils.CollisionPropertiesCfg(rest_offset=rest_offset,contact_offset=contact_offset)),
  init_state=ArticulationCfg.InitialStateCfg(pos=tuple(world_pose[:3]),rot=tuple(world_pose[3:]),joint_pos={'Window_slide_joint':0.},joint_vel={'.*':0.}),
  actuators={'window':ImplicitActuatorCfg(joint_names_expr=['Window_slide_joint'],stiffness=2000.,damping=100.,effort_limit_sim=100.,velocity_limit_sim=.2)})

# In GOAI_SCENE_CFG.__post_init__, before the existing generic plan-prims branch:
# if p['name'] == 'xrd':
#     setattr(self, 'xrd', make_xrd_cfg(p['prim_path'], ARTICULATION_USD, p['world_pose']))
#     continue
# This replaces xrd's RigidObjectCfg registration; never register both at one path.
