"""PhysX contact points, recorded before any user-controlled object intervention."""
import json
import math
import gzip
from pathlib import Path


class ContactTelemetry:
    def __init__(self, stage, path):
        import carb
        from pxr import Usd, UsdPhysics, PhysxSchema
        from omni.physx import get_physx_simulation_interface
        # Isaac Lab SimulationContext disables CPU contact reports by default.
        # Set after context construction and before sim.reset()/the first step.
        carb.settings.get_settings().set_bool('/physics/disableContactProcessing', False)
        self.file = gzip.open(path,'xt',encoding='utf-8',compresslevel=3) if Path(path).suffix=='.gz' else open(path, 'x', buffering=1)
        self.tick = -1
        self.points = []
        self.friction_anchors = []
        self.errors = []
        self.callbacks = 0
        self.prefixes = ()
        self.body_paths = []
        for prim in Usd.PrimRange(stage.GetPseudoRoot()):
            if prim.HasAPI(UsdPhysics.RigidBodyAPI) and UsdPhysics.RigidBodyAPI(prim).GetRigidBodyEnabledAttr().Get():
                PhysxSchema.PhysxContactReportAPI.Apply(prim).CreateThresholdAttr().Set(0.)
                self.body_paths.append(str(prim.GetPath()))
        interface=get_physx_simulation_interface()
        self.friction_reporting_enabled=hasattr(interface,'subscribe_full_contact_report_events')
        subscribe=interface.subscribe_full_contact_report_events if self.friction_reporting_enabled else interface.subscribe_contact_report_events
        self.sub = subscribe(self._on_contacts)
        self.file.write(json.dumps({'type': 'configuration', 'reported_bodies': self.body_paths,
            'threshold': 0., 'scope': 'enabled PhysX bodies; filtered contacts and static-static pairs are not reported',
            'coverage_certified': False,'friction_anchors_requested':self.friction_reporting_enabled}) + '\n')

    def begin(self, tick, prefixes=()):
        self.tick = tick
        self.prefixes = tuple(prefixes)
        self.points = []
        self.friction_anchors = []
        self.errors = []
        self.callbacks = 0

    def _on_contacts(self, headers, data, friction_anchors=None):
        from pxr import PhysicsSchemaTools
        self.callbacks += 1
        try:
            for header in headers:
                pair = {k: str(PhysicsSchemaTools.intToSdfPath(getattr(header, k)))
                        for k in ('actor0', 'actor1', 'collider0', 'collider1')}
                if self.prefixes and not any(p.startswith(self.prefixes) for p in pair.values()):
                    continue
                for i in range(header.contact_data_offset, header.contact_data_offset + header.num_contact_data):
                    c = data[i]
                    point = {**pair, 'event': str(header.type), 'separation_m': float(c.separation),
                             'position_m': list(c.position), 'normal': list(c.normal), 'impulse': list(c.impulse)}
                    if not all(math.isfinite(v) for v in [point['separation_m'], *point['position_m'], *point['normal'], *point['impulse']]):
                        raise ValueError('nonfinite PhysX contact')
                    self.points.append(point)
                if friction_anchors is not None and header.num_friction_anchors_data:
                    first=header.friction_anchors_offset;end=first+header.num_friction_anchors_data
                    if not 0<=first<=end<=len(friction_anchors):raise ValueError('invalid friction-anchor range')
                    for index in range(first,end):
                        anchor=friction_anchors[index]
                        point={**pair,'position_m':list(anchor.position),'impulse':list(anchor.impulse)}
                        if not all(math.isfinite(v) for v in [*point['position_m'],*point['impulse']]):
                            raise ValueError('nonfinite PhysX friction anchor')
                        self.friction_anchors.append(point)
        except Exception as exc:
            self.errors.append(type(exc).__name__)

    def end(self):
        row = {'type': 'tick', 'tick': self.tick, 'callbacks': self.callbacks,
               'contacts': self.points, 'errors': self.errors,
               'friction_anchors':self.friction_anchors,'friction_anchors_requested':self.friction_reporting_enabled}
        self.file.write(json.dumps(row) + '\n')
        return row

    def close(self):
        self.sub = None
        self.file.close()
