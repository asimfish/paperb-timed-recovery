"""Canonical task-program schema for closed/compositional/open evaluation.

This module deliberately has no simulator, policy, or YAML dependency.  A task
program is the stable boundary between a generator, an environment, a policy,
and a read-only verifier.  It describes *what* must be achieved; an environment
owns how that program is instantiated and executed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import json
from typing import Any, Mapping


NOVELTY_AXES = frozenset({
    "environment",
    "object",
    "count",
    "goal",
    "composition",
    "dependency",
    "topology",
})
SPLITS = frozenset({"closed", "compositional-held-out", "open"})


@dataclass(frozen=True)
class GoalStep:
    """One node in a task's goal program.

    ``action`` is a semantic operation understood by the environment registry;
    it is not a policy action or a hidden simulator command.  Preconditions and
    effects belong in the public task specification so the verifier can audit
    them independently.
    """

    id: str
    action: str
    requires: tuple[str, ...] = ()
    parameters: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.id or not self.id.strip():
            raise ValueError("goal step id must be non-empty")
        if not self.action or not self.action.strip():
            raise ValueError(f"goal step {self.id!r} has an empty action")
        if self.id in self.requires:
            raise ValueError(f"goal step {self.id!r} cannot require itself")
        object.__setattr__(self, "requires", tuple(self.requires))
        object.__setattr__(self, "parameters", dict(self.parameters))

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "action": self.action,
            "requires": list(self.requires),
            "parameters": dict(self.parameters),
        }


@dataclass(frozen=True)
class TaskProgram:
    """Serializable ``tau=(E,O,N,G)`` plus split and provenance metadata."""

    task_id: str
    split: str
    environment: Mapping[str, Any]
    objects: tuple[Mapping[str, Any], ...]
    counts: Mapping[str, int]
    goals: tuple[GoalStep, ...]
    seed: int
    novelty_axes: frozenset[str] = frozenset()
    public_spec_version: str = "1"
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.task_id or not self.task_id.strip():
            raise ValueError("task_id must be non-empty")
        if self.split not in SPLITS:
            raise ValueError(f"unknown split {self.split!r}; expected one of {sorted(SPLITS)}")
        bad_axes = set(self.novelty_axes) - NOVELTY_AXES
        if bad_axes:
            raise ValueError(f"unknown novelty axes: {sorted(bad_axes)}")
        if not self.goals:
            raise ValueError("task program must contain at least one goal step")
        if any(int(v) < 0 for v in self.counts.values()):
            raise ValueError("object counts must be non-negative")
        ids = [step.id for step in self.goals]
        if len(ids) != len(set(ids)):
            raise ValueError("goal step ids must be unique")
        known = set(ids)
        for step in self.goals:
            missing = set(step.requires) - known
            if missing:
                raise ValueError(f"goal step {step.id!r} requires unknown steps {sorted(missing)}")
        self._assert_acyclic()
        object.__setattr__(self, "objects", tuple(dict(x) for x in self.objects))
        object.__setattr__(self, "counts", dict(self.counts))
        object.__setattr__(self, "novelty_axes", frozenset(self.novelty_axes))
        object.__setattr__(self, "environment", dict(self.environment))
        object.__setattr__(self, "metadata", dict(self.metadata))

    def _assert_acyclic(self) -> None:
        deps = {step.id: set(step.requires) for step in self.goals}
        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(node: str) -> None:
            if node in visiting:
                raise ValueError("goal dependency graph must be acyclic")
            if node in visited:
                return
            visiting.add(node)
            for parent in deps[node]:
                visit(parent)
            visiting.remove(node)
            visited.add(node)

        for node in deps:
            visit(node)

    def to_dict(self) -> dict[str, Any]:
        """Return canonical JSON-compatible data for manifests and hashing."""
        return {
            "task_id": self.task_id,
            "split": self.split,
            "environment": dict(self.environment),
            "objects": [dict(obj) for obj in self.objects],
            "counts": dict(self.counts),
            "goals": [step.to_dict() for step in self.goals],
            "seed": int(self.seed),
            "novelty_axes": sorted(self.novelty_axes),
            "public_spec_version": self.public_spec_version,
            "metadata": dict(self.metadata),
        }

    def canonical_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":"))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "TaskProgram":
        goals = tuple(
            GoalStep(
                id=item["id"],
                action=item["action"],
                requires=tuple(item.get("requires", ())),
                parameters=item.get("parameters", {}),
            )
            for item in data["goals"]
        )
        return cls(
            task_id=data["task_id"],
            split=data["split"],
            environment=data.get("environment", {}),
            objects=tuple(data.get("objects", ())),
            counts=data.get("counts", {}),
            goals=goals,
            seed=int(data["seed"]),
            novelty_axes=frozenset(data.get("novelty_axes", ())),
            public_spec_version=data.get("public_spec_version", "1"),
            metadata=data.get("metadata", {}),
        )
