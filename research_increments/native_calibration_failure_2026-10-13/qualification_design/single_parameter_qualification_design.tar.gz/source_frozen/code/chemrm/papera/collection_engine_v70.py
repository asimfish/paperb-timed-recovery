"""Development evidence catalog and single-host, bounded collection queue.

Stage views preserve sealed bytes and absolute clocks. They do not create new
trials, restore a simulator, or grant scientific/training admission. Immutable
event files are authoritative; index.jsonl is an exported, replaceable view.
The SQLite queue is local to one host; its owner holds a POSIX lock throughout
execution. It is not a distributed NAS scheduler.
"""
from contextlib import contextmanager
import fcntl
import json
import math
import os
from pathlib import Path
import re
import sqlite3
from uuid import uuid4

from chemrm.papera.staged_collection import digest, safe_payload, sync_directory, verify_prefix


def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)+'\n').encode()


def identity(value):
    from hashlib import sha256
    return sha256(encoded(value)).hexdigest()


def publish(path, data):
    """Publish only after complete write+fsync, within an owned writer lock."""
    temporary = path.with_name('.'+path.name+'.'+uuid4().hex)
    with temporary.open('xb') as file:
        file.write(data)
        file.flush()
        os.fsync(file.fileno())
    if path.exists():
        raise FileExistsError(path)
    os.rename(temporary, path)
    sync_directory(path.parent)


@contextmanager
def locked(path):
    with path.open('a+b') as file:
        fcntl.flock(file, fcntl.LOCK_EX)
        yield


class StageCatalog:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        for name in ('events', 'views'):
            (self.root/name).mkdir(exist_ok=True)

    def _events(self):
        events = []
        previous = None
        for number, path in enumerate(sorted((self.root/'events').glob('*.json'))):
            event = json.loads(safe_payload(self.root, str(path.relative_to(self.root))).read_bytes())
            if path.name != f'{number:08d}.json' or event['sequence'] != number or event['previous_sha256'] != previous:
                raise ValueError('catalog event sequence/hash chain mismatch')
            events.append(event)
            previous = digest(path)
        return events, previous

    def _append(self, kind, data):
        events, previous = self._events()
        event = dict(sequence=len(events), previous_sha256=previous, kind=kind, data=data)
        publish(self.root/'events'/f'{len(events):08d}.json', encoded(event))

    def _snapshot(self):
        events, _ = self._events()
        rows = {}
        for event in events:
            if event['kind'] == 'REGISTER':
                for row in event['data']:
                    if row['segment_id'] in rows:
                        raise ValueError('duplicate authoritative segment registration')
                    rows[row['segment_id']] = dict(row)
            elif event['kind'] == 'REVOKE':
                item = event['data']
                rows[item['segment_id']].update(status='REVOKED', revocation_reason=item['reason'])
            else:
                raise ValueError('unknown catalog event')
        values = list(rows.values())
        return dict(schema='chemrm-development-stage-catalog-v70', segments=values,
            registered_segments=len(values), active_segments=sum(r['status']!='REVOKED' for r in values),
            independent_parent_episodes=len({r['parent_key'] for r in values}),
            new_native_trials=0, training_admitted_segments=0, verified_failure_replay_segments=0)

    def snapshot(self):
        with locked(self.root/'catalog.lock'):
            return self._snapshot()

    def _verify_view(self, row):
        directory = self.root/row['view_directory']
        manifest_path = safe_payload(self.root, str((directory/'manifest.json').relative_to(self.root)))
        if digest(manifest_path) != row['view_manifest_sha256']:
            raise ValueError('derived view manifest changed')
        manifest = json.loads(manifest_path.read_bytes())
        marker = safe_payload(self.root, str((directory/'COMMITTED.json').relative_to(self.root)))
        if json.loads(marker.read_bytes()) != {'manifest_sha256':row['view_manifest_sha256']}:
            raise ValueError('derived view commit mismatch')
        for item in manifest['files']:
            path = safe_payload(self.root, str((directory/item['path']).relative_to(self.root)))
            if digest(path) != item['sha256']:
                raise ValueError('derived view payload changed')

    def _make_view(self, raw, stage, segment_id):
        # Interrupted, unpublished attempts are retained, not overwritten.
        for attempt in range(1000):
            target = self.root/'views'/f'{segment_id}.attempt{attempt:03d}'
            if not target.exists():
                target.mkdir()
                break
        else:
            raise ValueError('too many incomplete derived view attempts')
        files = []
        for entry in stage['payloads']:
            if entry['path'] not in {'states.jsonl','captures.jsonl','liquid_samples.jsonl'}:
                continue
            source = safe_payload(raw, entry['path'])
            with source.open('rb') as file:
                file.seek(entry['offset'])
                data = file.read(entry['size'])
            if len(data) != entry['size']:
                raise ValueError('sealed source range truncated')
            if entry['path']=='states.jsonl':
                rows = [json.loads(line) for line in data.splitlines()]
                expected = list(range(stage['start_tick']+1,stage['end_tick']+1))
                if [r['tick'] for r in rows] != expected:
                    raise ValueError('dense parent state tick interval mismatch')
                times = [r['physics_time_s'] for r in rows]
                if any(type(t) not in (int,float) or not math.isfinite(t) for t in times) or not times:
                    raise ValueError('finite parent state clocks required')
                if times[0]<=stage['actual_start_s'] or times[-1]!=stage['actual_end_s'] or any(a>=b for a,b in zip(times,times[1:])):
                    raise ValueError('parent state clocks do not cover the declared stage')
            publish(target/entry['path'], data)
            files.append(dict(path=entry['path'], sha256=digest(target/entry['path']),
                              source_offset=entry['offset'], source_size=entry['size']))
        if not any(f['path']=='states.jsonl' for f in files):
            raise ValueError('dense parent states required for development stage view')
        manifest = dict(schema='chemrm-sealed-byte-view-v70', parent_raw=str(raw),
            stage_id=stage['stage_id'], parent_stage_manifest_sha256=digest(raw/'stages'/stage['stage_id']/'manifest.json'),
            start_tick=stage['start_tick'], end_tick=stage['end_tick'], tick_convention='(start_tick, end_tick]',
            actual_start_s=stage['actual_start_s'], actual_end_s=stage['actual_end_s'], files=files,
            remaining_payloads='references in immutable parent stage manifest',
            resets_or_teleports=0, new_native_trials=0, physical_restart_supported=False,
            training_admitted=False, verified_failure_replay_admitted=False)
        publish(target/'manifest.json', encoded(manifest))
        h = digest(target/'manifest.json')
        publish(target/'COMMITTED.json', encoded(dict(manifest_sha256=h)))
        return str(target.relative_to(self.root)), h

    def register(self, raw, audit_path=None):
        raw = Path(raw).resolve()
        with locked(self.root/'catalog.lock'):
            checked = verify_prefix(raw)
            header = json.loads((raw/'stages/episode.json').read_bytes())
            audit = None if audit_path is None else json.loads(Path(audit_path).read_bytes())
            checks = {} if audit is None else audit.get('scientific_admission_checks', {})
            if not isinstance(checks, dict) or any(v is not None and type(v) is not bool for v in checks.values()):
                raise ValueError('audit check must be true/false/null; no coercion')
            audit_status = 'FAIL' if any(v is False for v in checks.values()) else (
                'REPORTED_PASS_NOT_ADMISSION' if checks and all(v is True for v in checks.values()) else 'UNKNOWN')
            existing = {r['segment_id']:r for r in self._snapshot()['segments']}
            new = []
            parent_key = None
            for stage in checked['records']:
                stage_hash = digest(raw/'stages'/stage['stage_id']/'manifest.json')
                if parent_key is None:
                    parent_key = identity(dict(header_sha256=digest(raw/'stages/episode.json'), first_stage_sha256=stage_hash))
                segment_id = identity(dict(parent_key=parent_key, stage_sha256=stage_hash, schema='v70'))
                if segment_id in existing:
                    self._verify_view(existing[segment_id])
                    continue
                view, view_hash = self._make_view(raw, stage, segment_id)
                new.append(dict(segment_id=segment_id, parent_key=parent_key,
                    parent_episode_id=header['episode_id'], parent_raw=str(raw),
                    stage_id=stage['stage_id'], parent_stage_manifest_sha256=stage_hash,
                    actual_start_s=stage['actual_start_s'], actual_end_s=stage['actual_end_s'],
                    start_tick=stage['start_tick'], end_tick=stage['end_tick'], tick_convention='(start_tick, end_tick]',
                    view_directory=view, view_manifest_sha256=view_hash,
                    storage_status='COMMITTED_BYTE_RANGES_VERIFIED', status='RETAINED_DEVELOPMENT_ONLY',
                    parent_scientific_status=audit_status,
                    audit_sha256=None if audit_path is None else digest(audit_path),
                    segment_physics_status='NOT_INDEPENDENTLY_VERIFIED',
                    new_native_trials=0, new_simulation=False, training_admitted=False,
                    verified_failure_replay_admitted=False, physical_restart_supported=False))
            if new:
                self._append('REGISTER', new)
            return dict(new_segments=len(new), **{k:v for k,v in self._snapshot().items() if k!='segments'})

    def revoke(self, segment_id, reason):
        if not re.fullmatch(r'[A-Z0-9_]{1,96}', reason):
            raise ValueError('bounded reason code required')
        with locked(self.root/'catalog.lock'):
            rows = {r['segment_id']:r for r in self._snapshot()['segments']}
            if segment_id not in rows:
                raise ValueError('unknown segment')
            if rows[segment_id]['status'] != 'REVOKED':
                self._append('REVOKE', dict(segment_id=segment_id, reason=reason))

    def export(self, destination):
        """A fresh immutable export; subsequent corrections remain event records."""
        publish(Path(destination), b''.join(encoded(r) for r in self.snapshot()['segments']))


NATIVE_GATES = {'ORIGINAL_ASSET_CONTRACT', 'PARENT_PHYSICS', 'CALIBRATED_A'}


class CollectionQueue:
    def __init__(self, path, *, gpu_budget_seconds, same_failure_limit=3):
        if type(gpu_budget_seconds) not in (int,float) or not math.isfinite(gpu_budget_seconds) or gpu_budget_seconds < 0:
            raise ValueError('finite nonnegative GPU budget required')
        if type(same_failure_limit) is not int or same_failure_limit < 1:
            raise ValueError('positive typed failure limit required')
        self.path = Path(path)
        self.budget = float(gpu_budget_seconds)
        self.limit = same_failure_limit

    def __enter__(self):
        self.owner = self.path.with_suffix('.owner.lock').open('a+b')
        try:
            fcntl.flock(self.owner, fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            self.owner.close()
            raise ValueError('another queue owner is active') from None
        self.db = sqlite3.connect(self.path)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS config (singleton INTEGER PRIMARY KEY, budget REAL, failure_limit INTEGER);
            CREATE TABLE IF NOT EXISTS jobs (job_id TEXT PRIMARY KEY, spec TEXT, family TEXT, source_id TEXT,
                deps TEXT, status TEXT, reason TEXT, attempts INTEGER DEFAULT 0,
                reserved REAL DEFAULT 0, actual REAL DEFAULT 0, result TEXT);
            CREATE TABLE IF NOT EXISTS failures (job_id TEXT PRIMARY KEY, family TEXT, source_id TEXT, fingerprint TEXT);
        ''')
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO config VALUES(1,?,?)', (self.budget,self.limit))
            row = self.db.execute('SELECT * FROM config').fetchone()
            mismatch = (row['budget'],row['failure_limit']) != (self.budget,self.limit)
            recoverable = [] if mismatch else self.db.execute("SELECT * FROM jobs WHERE status='RUNNING'").fetchall()
            for job in recoverable:
                kind = json.loads(job['spec'])['kind']
                status = 'PENDING' if kind=='REGISTER_SEALED_PREFIX' else 'BLOCKED_ORPHANED_NATIVE'
                self.db.execute('UPDATE jobs SET status=?,reason=? WHERE job_id=?',
                    (status,'OWNER_EXIT_PHYSICAL_STATE_NOT_RESTORED',job['job_id']))
        if mismatch:
            self.db.close();self.owner.close()
            raise ValueError('queue budget/failure contract cannot change on reopen')
        return self

    def __exit__(self, *args):
        self.db.close()
        self.owner.close()

    def enqueue(self, spec, *, dependencies=(), required_gates=(), gates=None):
        fields = {'kind','source_id','contract_sha256','family','variant','estimated_gpu_seconds'}
        if set(spec) != fields or spec['kind'] not in {'REGISTER_SEALED_PREFIX','NATIVE_EXPERT_CANDIDATE'}:
            raise ValueError('typed collection job, not arbitrary command, required')
        for key in ('source_id','family','variant'):
            if not re.fullmatch(r'[A-Za-z0-9_-]{1,96}',spec[key]):
                raise ValueError('bounded job identity required')
        if not re.fullmatch(r'[a-f0-9]{64}', spec['contract_sha256']):
            raise ValueError('immutable contract digest required')
        estimate = spec['estimated_gpu_seconds']
        if type(estimate) not in (int,float) or not math.isfinite(estimate) or estimate<0:
            raise ValueError('finite nonnegative cost estimate required')
        if spec['kind']=='REGISTER_SEALED_PREFIX' and estimate!=0:
            raise ValueError('CPU registration cannot reserve GPU time')
        if spec['kind']=='NATIVE_EXPERT_CANDIDATE' and estimate==0:
            raise ValueError('native candidate needs a positive explicit cost reservation')
        requirements = set(required_gates)|(NATIVE_GATES if spec['kind']=='NATIVE_EXPERT_CANDIDATE' else set())
        provided = {} if gates is None else gates
        missing = sorted(g for g in requirements if provided.get(g)!='PASS')
        status = 'BLOCKED' if missing else 'PENDING'
        deps = sorted(set(dependencies))
        for dependency in deps:
            self.get(dependency)
        job_id = identity(dict(spec=spec, dependencies=deps, required_gates=sorted(requirements)))
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO jobs(job_id,spec,family,source_id,deps,status,reason) VALUES(?,?,?,?,?,?,?)',
                (job_id,encoded(spec).decode(),spec['family'],spec['source_id'],encoded(deps).decode(),status,
                 'MISSING_GATES:'+','.join(missing) if missing else ''))
        return job_id

    def get(self, job_id):
        row = self.db.execute('SELECT * FROM jobs WHERE job_id=?',(job_id,)).fetchone()
        if row is None:
            raise ValueError('unknown job dependency or identity')
        return dict(row)

    def claim(self):
        with self.db:
            for row in self.db.execute("SELECT * FROM jobs WHERE status='PENDING' ORDER BY rowid").fetchall():
                repeats = self.db.execute('SELECT COUNT(*) AS n FROM failures WHERE family=? AND source_id=? GROUP BY fingerprint',
                    (row['family'],row['source_id'])).fetchall()
                if any(r['n']>=self.limit for r in repeats):
                    self.db.execute("UPDATE jobs SET status='BLOCKED_REPEATED_FAILURE',reason='CAUSAL_REPAIR_REQUIRED' WHERE job_id=?",(row['job_id'],))
                    continue
                dependency_statuses = [self.get(d)['status'] for d in json.loads(row['deps'])]
                if any(s=='FAILED' or s.startswith('BLOCKED') for s in dependency_statuses):
                    self.db.execute("UPDATE jobs SET status='BLOCKED_DEPENDENCY',reason='DEPENDENCY_NOT_SUCCESSFUL' WHERE job_id=?",(row['job_id'],))
                    continue
                if any(s!='DONE' for s in dependency_statuses):
                    continue
                spec = json.loads(row['spec'])
                used = self.db.execute('SELECT COALESCE(SUM(MAX(reserved,actual)),0) AS n FROM jobs').fetchone()['n']
                cost = float(spec['estimated_gpu_seconds'])
                if used+cost>self.budget:
                    self.db.execute("UPDATE jobs SET status='BLOCKED_BUDGET',reason='NO_GPU_BUDGET' WHERE job_id=?",(row['job_id'],))
                    continue
                self.db.execute("UPDATE jobs SET status='RUNNING',attempts=attempts+1,reserved=reserved+? WHERE job_id=?",(cost,row['job_id']))
                return self.get(row['job_id'])
        return None

    def finish(self, job_id, result, *, actual_gpu_seconds):
        row = self.get(job_id)
        if row['status']!='RUNNING' or type(actual_gpu_seconds) not in (int,float) or not math.isfinite(actual_gpu_seconds) or actual_gpu_seconds<0:
            raise ValueError('running owned job and finite measured cost required')
        if json.loads(row['spec'])['kind']=='REGISTER_SEALED_PREFIX' and actual_gpu_seconds!=0:
            raise ValueError('CPU receipt cannot claim GPU execution')
        if json.loads(row['spec'])['kind']=='NATIVE_EXPERT_CANDIDATE' and actual_gpu_seconds==0:
            raise ValueError('native execution requires positive measured runtime evidence')
        with self.db:
            self.db.execute("UPDATE jobs SET status='DONE',result=?,actual=? WHERE job_id=?",(encoded(result).decode(),actual_gpu_seconds,job_id))

    def fail(self, job_id, code, fingerprint):
        row = self.get(job_id)
        if row['status']!='RUNNING' or not re.fullmatch(r'[A-Z0-9_]{1,96}',code) or not fingerprint:
            raise ValueError('owned running job and failure fingerprint required')
        with self.db:
            self.db.execute('INSERT INTO failures VALUES(?,?,?,?)',(job_id,row['family'],row['source_id'],identity(dict(code=code,cause=fingerprint))))
            self.db.execute("UPDATE jobs SET status='FAILED',reason=? WHERE job_id=?",(code,job_id))

    def summary(self):
        jobs = [dict(r) for r in self.db.execute('SELECT * FROM jobs ORDER BY rowid')]
        return dict(jobs=jobs, actual_gpu_seconds=sum(j['actual'] for j in jobs),
                    estimated_gpu_seconds_reserved=sum(j['reserved'] for j in jobs),
                    physical_restart_supported=False, cloud_training_jobs=0)
