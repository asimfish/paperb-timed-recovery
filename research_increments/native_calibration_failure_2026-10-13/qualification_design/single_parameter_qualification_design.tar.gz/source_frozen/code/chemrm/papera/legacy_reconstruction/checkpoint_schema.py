"""Versioned checkpoint container for the A-Lab twin.

The container is an NPZ with one canonical UTF-8 JSON member (``schema_json``).
Keeping the wire representation independent of torch/Isaac makes the file safe to
inspect and verify on a CPU-only host; runtime adapters convert the four state
layers to Isaac tensors at the simulation boundary.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import tempfile
from pathlib import Path
from typing import Any, Mapping

SCHEMA_NAME = "alab_twin.checkpoint"
SCHEMA_VERSION = 3
ROOT_STATE_WIDTH = 13
CONTACT_HISTORY_MIN = 6

_REQUIRED_IDENTITY = (
    "scene_id", "layout_version", "layout_plan_path", "input_manifest_sha256",
    "asset_sha256", "layout_plan_sha256", "executor_source_sha256", "isaac_version",
    "physx_version", "dt", "solver_profile", "device",
    "contact_offset", "rest_offset", "root_state_variant",
)


def _plain(value: Any) -> Any:
    """Convert numpy/torch scalar and tensor values to JSON values."""
    if hasattr(value, "detach"):
        value = value.detach().cpu()
    if hasattr(value, "tolist"):
        value = value.tolist()
    if isinstance(value, Mapping):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    if isinstance(value, (str, bool, int)) or value is None:
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("checkpoint contains a non-finite float")
        return value
    # numpy scalar types expose item().
    if hasattr(value, "item"):
        return _plain(value.item())
    raise TypeError(f"unsupported checkpoint value type: {type(value)!r}")


def _finite_numbers(value: Any, path: str = "") -> None:
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(f"non-finite value at {path}")
    if isinstance(value, list):
        for i, item in enumerate(value):
            _finite_numbers(item, f"{path}[{i}]")
    elif isinstance(value, dict):
        for key, item in value.items():
            _finite_numbers(item, f"{path}.{key}")


def _require(mapping: Mapping[str, Any], keys: tuple[str, ...], section: str) -> None:
    missing = [k for k in keys if k not in mapping]
    if missing:
        raise ValueError(f"{section} missing required fields: {', '.join(missing)}")


def _as_list(value: Any, path: str) -> list:
    value = _plain(value)
    if not isinstance(value, list):
        raise ValueError(f"{path} must be an array")
    return value


def validate_checkpoint(value: Mapping[str, Any]) -> dict[str, Any]:
    """Validate and return a canonical JSON-compatible checkpoint dictionary."""
    cp = _plain(value)
    if not isinstance(cp, dict):
        raise ValueError("checkpoint must be an object")
    if cp.get("schema") != SCHEMA_NAME or cp.get("schema_version") not in (1, 2, 3):
        raise ValueError(f"unsupported checkpoint schema: {cp.get('schema')} v{cp.get('schema_version')}")
    _require(cp, ("identity", "physics", "host", "randomness", "task"), "checkpoint")
    identity = cp["identity"]
    _require(identity, _REQUIRED_IDENTITY, "identity")
    if not isinstance(identity["scene_id"], str) or not identity["scene_id"].startswith("wf"):
        raise ValueError("identity.scene_id must be a workflow scene id such as wf03_xrd")
    label = identity["layout_version"]
    if cp['schema_version'] == 1:
        if not isinstance(label, str) or not label.startswith("layout_v"):
            raise ValueError("identity.layout_version must be a versioned layout_vN string")
    else:
        # Preserve authored A/B/C historical labels. Their exact plan digest, not
        # a fabricated layout_v alias, establishes scene identity in version 2.
        if not isinstance(label, str) or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,159}', label) is None:
            raise ValueError('version 2 requires a bounded authored layout label')
        if re.fullmatch(r'[a-f0-9]{64}', str(identity['layout_plan_sha256'])) is None:
            raise ValueError('version 2 authored layout requires the exact plan SHA-256')
    if identity["root_state_variant"] != "root_state":
        raise ValueError("root_state_variant must be root_state; link/com variants are not interchangeable")
    if float(identity["dt"]) <= 0:
        raise ValueError("identity.dt must be positive")

    physics = cp["physics"]
    _require(physics, ("bodies", "articulations", "doors_windows"), "physics")
    for i, body in enumerate(physics["bodies"]):
        _require(body, ("id", "prim_path", "root_state"), f"physics.bodies[{i}]")
        state = _as_list(body["root_state"], f"physics.bodies[{i}].root_state")
        if len(state) != ROOT_STATE_WIDTH:
            raise ValueError(f"physics.bodies[{i}].root_state must have 13 values")
    for i, art in enumerate(physics["articulations"]):
        _require(art, ("id", "prim_path", "joint_names", "joint_position", "joint_velocity",
                       "joint_position_target", "joint_velocity_target", "joint_effort_target",
                       "runtime_properties"), f"physics.articulations[{i}]")
        n = len(art["joint_names"])
        for field in ("joint_position", "joint_velocity", "joint_position_target",
                      "joint_velocity_target", "joint_effort_target"):
            arr = _as_list(art[field], f"physics.articulations[{i}].{field}")
            if len(arr) != n:
                raise ValueError(f"physics.articulations[{i}].{field} length != joint_names")
    for i, item in enumerate(physics["doors_windows"]):
        _require(item, ("id", "joint_name", "position", "velocity", "position_target",
                        "runtime_properties"), f"physics.doors_windows[{i}]")

    host = cp["host"]
    _require(host, ("kin", "pinned", "contact_frames", "tick", "metrics", "contract",
                    "arms"), "host")
    if not isinstance(host["contact_frames"], list):
        raise ValueError("host.contact_frames must be a list")
    if len(host["contact_frames"]) > 0 and len(host["contact_frames"]) < CONTACT_HISTORY_MIN:
        raise ValueError("non-empty host.contact_frames must retain at least the last 6 frames")
    carry_mode = cp.get("carry_mode", "none")
    if host["kin"] and carry_mode != "kinematic_after_verified_grasp":
        raise ValueError("non-empty host.kin requires carry_mode=kinematic_after_verified_grasp")
    if not host["kin"] and carry_mode not in ("none", "kinematic_after_verified_grasp"):
        raise ValueError(f"unknown carry_mode: {carry_mode}")

    randomness = cp["randomness"]
    _require(randomness, ("seed", "draw_count"), "randomness")
    if int(randomness["draw_count"]) < 0:
        raise ValueError("randomness.draw_count must be non-negative")
    _require(cp["task"], ("graph_position", "metrics"), "task")
    _finite_numbers(cp)
    return cp



def identity_fingerprint(identity: Mapping[str, Any]) -> dict[str, Any]:
    """Canonical cross-subsystem identity used by checkpoints and live geometry."""
    return {k: identity[k] for k in ("scene_id", "layout_version", "input_manifest_sha256",
                                     "layout_plan_sha256", "asset_sha256",
                                     "executor_source_sha256", "dt", "solver_profile",
                                     "contact_offset", "rest_offset")}

def identity_digest(identity: Mapping[str, Any]) -> str:
    return hashlib.sha256(json.dumps(identity_fingerprint(identity), sort_keys=True,
                                     separators=(",", ":")).encode("utf-8")).hexdigest()

def canonical_json(value: Mapping[str, Any]) -> bytes:
    cp = validate_checkpoint(value)
    return json.dumps(cp, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def save_checkpoint(path: str | os.PathLike[str], value: Mapping[str, Any]) -> str:
    """Atomically save a checkpoint and return its SHA-256 digest."""
    payload = canonical_json(value)
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    # numpy is deliberately imported only at file I/O time; validation stays pure stdlib.
    import numpy as np
    fd, tmp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".npz", dir=target.parent)
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        np.savez_compressed(tmp, schema_json=np.frombuffer(payload, dtype=np.uint8))
        os.replace(tmp, target)
    finally:
        tmp.unlink(missing_ok=True)
    return hashlib.sha256(payload).hexdigest()


def load_checkpoint(path: str | os.PathLike[str]) -> dict[str, Any]:
    import numpy as np
    p = Path(path)
    with np.load(p, allow_pickle=False) as data:
        if "schema_json" not in data:
            raise ValueError(f"{p} is missing schema_json")
        payload = data["schema_json"].astype(np.uint8, copy=False).tobytes()
    value = json.loads(payload.decode("utf-8"))
    validate_checkpoint(value)
    return value


def checkpoint_payload_sha256(path: str | os.PathLike[str]) -> str:
    cp = load_checkpoint(path)
    return hashlib.sha256(canonical_json(cp)).hexdigest()
