"""Minimal controlled worlds for the YAML tasks C5, C6 and C13.

These worlds are F0 contract backends.  They intentionally expose only task-relevant public
signals; the trigger times and event truth stay in the world event log for the read-only
verifier.  Their purpose is to exercise the same task/trace/verdict path before an Isaac/pixel
backend is available.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
import random
from typing import Any, Mapping

from chemrm.events import EventBus, SimClock
from chemrm.papera.runner import FrozenPolicy, ReadOnlyConstraintVerifier, WorldStep
from chemrm.papera.spec import BenchmarkTask, load_benchmark_task
from chemrm.task_program import TaskProgram


TASK_ROOT = Path(__file__).resolve().parents[1] / "tasks"


class C5EndpointWorld:
    """Color endpoint at 10 s; a stop action must follow within the declared 2 s."""

    def __init__(self, trigger_time: float = 10.0, dt: float = 1.0, horizon: float = 30.0):
        self.trigger_time = float(trigger_time)
        self.dt = float(dt)
        self.horizon = float(horizon)
        self.clock = SimClock()
        self.event_bus = EventBus(self.clock)

    def reset(self, _task: TaskProgram, _seed: int) -> Mapping[str, Any]:
        self.clock.reset()
        self.event_bus = EventBus(self.clock)
        self.triggered = False
        self.responded = False
        return {"trigger": None}

    def _emit_trigger_if_due(self) -> None:
        if not self.triggered and self.clock.now >= self.trigger_time:
            old = self.clock.now
            self.clock._t = self.trigger_time
            self.event_bus.emit("color_change", vessel="beaker_0")
            self.clock._t = old
            self.triggered = True

    def step(self, action: Mapping[str, Any]) -> WorldStep:
        self._emit_trigger_if_due()
        kind = action.get("kind", "wait")
        if kind == "add_stop":
            self.event_bus.emit("add_stop", vessel=action.get("vessel", "beaker_0"))
            if action.get("vessel", "beaker_0") == "beaker_0":
                self.event_bus.emit("titrate_to_endpoint", vessel="beaker_0")
            self.responded = True
            return WorldStep({"trigger": None}, True, "endpoint_stop")
        if kind != "wait":
            raise ValueError(f"unknown C5 action {kind!r}")
        self.clock.step(self.dt)
        self._emit_trigger_if_due()
        if self.clock.now >= self.horizon:
            return WorldStep({"trigger": None}, True, "horizon")
        return WorldStep({"trigger": "color_change" if self.triggered and not self.responded else None})


class C6StirringWorld:
    """A hidden 120 s stirring interval with no public clock signal."""

    def __init__(self, dt: float = 1.0, horizon: float = 150.0):
        self.dt = float(dt)
        self.horizon = float(horizon)
        self.clock = SimClock()
        self.event_bus = EventBus(self.clock)

    def reset(self, _task: TaskProgram, _seed: int) -> Mapping[str, Any]:
        self.clock.reset()
        self.event_bus = EventBus(self.clock)
        self.started = False
        self.stopped = False
        return {"instruction": "stir_then_sample"}

    def _next(self) -> WorldStep:
        self.clock.step(self.dt)
        if self.clock.now >= self.horizon:
            return WorldStep({"instruction": "stir_then_sample"}, True, "horizon")
        return WorldStep({"instruction": "stir_then_sample"})

    def step(self, action: Mapping[str, Any]) -> WorldStep:
        kind = action.get("kind", "wait")
        if kind == "stir_start":
            self.event_bus.emit("stir_start", vessel="beaker_0")
            self.started = True
            return self._next()
        if kind == "stir_stop":
            self.event_bus.emit("stir_stop", vessel="beaker_0")
            self.event_bus.emit("stir_then_sample", vessel="beaker_0")
            self.stopped = True
            return WorldStep({"instruction": "stir_then_sample"}, True, "stir_stop")
        if kind == "wait":
            return self._next()
        raise ValueError(f"unknown C6 action {kind!r}")


class C13MemoryTimeWorld:
    """Transient cue at a seeded time; the task instruction owns the requested gap."""

    def __init__(self, dt: float = 1.0, horizon: float = 140.0):
        self.dt = float(dt)
        self.horizon = float(horizon)
        self.clock = SimClock()
        self.event_bus = EventBus(self.clock)

    def reset(self, _task: TaskProgram, seed: int) -> Mapping[str, Any]:
        self.clock.reset()
        self.event_bus = EventBus(self.clock)
        self.t_add = float(5 + (int(seed) % 36))
        self.a_emitted = False
        self.cue_pending = False
        return {"cue": None}

    def _emit_a_if_due(self) -> None:
        if not self.a_emitted and self.clock.now >= self.t_add:
            old = self.clock.now
            self.clock._t = self.t_add
            self.event_bus.emit("add_reagent", reagent="A", vessel="flask_0")
            self.clock._t = old
            self.a_emitted = True
            self.cue_pending = True

    def step(self, action: Mapping[str, Any]) -> WorldStep:
        self._emit_a_if_due()
        kind = action.get("kind", "wait")
        if kind == "add_reagent":
            if action.get("reagent", "B") != "B":
                raise ValueError("C13 world accepts only reagent B as the policy action")
            self.event_bus.emit("add_reagent", reagent="B", vessel=action.get("vessel", "flask_0"))
            return WorldStep({"cue": None}, True, "add_reagent")
        if kind != "wait":
            raise ValueError(f"unknown C13 action {kind!r}")
        self.cue_pending = False
        self.clock.step(self.dt)
        self._emit_a_if_due()
        if self.clock.now >= self.horizon:
            return WorldStep({"cue": None}, True, "horizon")
        return WorldStep({"cue": {"reagent": "A", "vessel": "flask_0"} if self.cue_pending else None})


class C5EndpointPolicy:
    policy_id = "paper-a-c5-reference"
    policy_hash = "sha256:paper-a-c5-reference-v1"

    def reset(self, _task: TaskProgram, _seed: int) -> None:
        pass

    def act(self, observation: Mapping[str, Any]) -> Mapping[str, Any]:
        if observation.get("trigger") == "color_change":
            return {"kind": "add_stop", "vessel": "beaker_0"}
        return {"kind": "wait"}


class C6StirringPolicy:
    policy_id = "paper-a-c6-reference"
    policy_hash = "sha256:paper-a-c6-reference-v1"

    def reset(self, _task: TaskProgram, _seed: int) -> None:
        self.started = False
        self.elapsed_ticks = 0

    def act(self, _observation: Mapping[str, Any]) -> Mapping[str, Any]:
        if not self.started:
            self.started = True
            return {"kind": "stir_start"}
        self.elapsed_ticks += 1
        if self.elapsed_ticks >= 120:
            return {"kind": "stir_stop"}
        return {"kind": "wait"}


class C13MemoryTimePolicy:
    policy_id = "paper-a-c13-reference"
    policy_hash = "sha256:paper-a-c13-reference-v2"

    def reset(self, task: TaskProgram, _seed: int) -> None:
        self.seen_cue = False
        self.elapsed_ticks = 0
        self.wait_ticks = int(task.metadata["instruction"]["wait_D_s"])

    def act(self, observation: Mapping[str, Any]) -> Mapping[str, Any]:
        if observation.get("cue") is not None:
            self.seen_cue = True
            self.elapsed_ticks = 0
            return {"kind": "wait"}
        if self.seen_cue:
            self.elapsed_ticks += 1
            if self.elapsed_ticks >= self.wait_ticks:
                return {"kind": "add_reagent", "reagent": "B", "vessel": "flask_0"}
        return {"kind": "wait"}


@dataclass(frozen=True)
class TaskCase:
    name: str
    benchmark_task: BenchmarkTask
    world: Any
    policy: FrozenPolicy

    @property
    def task(self) -> TaskProgram:
        return self.benchmark_task.program

    def verifier(self) -> ReadOnlyConstraintVerifier:
        return ReadOnlyConstraintVerifier(self.benchmark_task.constraints, self.task.goals)


def load_f0_task(name: str, seed: int = 0, split: str = "closed") -> BenchmarkTask:
    """Instantiate public instructions and matching constraints without running a world."""
    key = name.upper()
    if key not in {"C5", "C6", "C13"}:
        raise ValueError(f"unknown YAML task {name!r}; expected C5, C6 or C13")
    loaded = load_benchmark_task(TASK_ROOT / {"C5": "c05_endpoint_stop.yaml",
                                               "C6": "c06_timed_stirring.yaml",
                                               "C13": "c13_memory_time_hero.yaml"}[key], seed=seed,
                                 split=split)
    if key == "C13":
        randomization = loaded.program.environment["randomization"]
        low, high = randomization["wait_D_s"]
        duration = float(random.Random(f"paper-a-c13-wait-v1:{seed}").randint(int(low), int(high)))
        epsilon = duration * float(randomization["eps_relative"])
        program = replace(loaded.program, metadata={
            **loaded.program.metadata, "instruction": {"wait_D_s": duration, "eps_s": epsilon},
        })
        loaded = replace(loaded, program=program, constraints=tuple(
            replace(c, duration=duration, eps=epsilon) for c in loaded.constraints
        ))
    return loaded


def make_task_case(name: str, seed: int = 0) -> TaskCase:
    key = name.upper()
    loaded = load_f0_task(key, seed)
    if key == "C5":
        return TaskCase(key, loaded, C5EndpointWorld(), C5EndpointPolicy())
    if key == "C6":
        return TaskCase(key, loaded, C6StirringWorld(), C6StirringPolicy())
    return TaskCase(key, loaded, C13MemoryTimeWorld(), C13MemoryTimePolicy())
