"""Run the deterministic F1 timing and frame-gate release check."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from chemrm.core_family import T_POUR
from chemrm.gate0.env import DT, N_STEPS, build_observations, cell_arrays, draw_episode_batch, make_tick_times
from chemrm.papera.release import run_f1_release_gate


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--out", required=True, help="JSON release-gate report")
    parser.add_argument("--seed", type=int, default=19)
    parser.add_argument("--episodes", type=int, default=24)
    parser.add_argument("--perturbation", choices=("none", "tick_jitter", "rate_error"), default="tick_jitter")
    parser.add_argument("--perturbation-level", type=float, default=None)
    args = parser.parse_args(argv)
    if args.episodes < 10:
        raise SystemExit("--episodes must be at least 10 for the five-fold frame probes")
    level = args.perturbation_level
    if level is None:
        level = {"none": 0.0, "tick_jitter": 0.4, "rate_error": 0.15}[args.perturbation]
    eps = draw_episode_batch(args.episodes, args.seed)
    ticks = make_tick_times(args.episodes, N_STEPS, args.perturbation, level, seed=args.seed + 777_000)
    transient, tight, _eta, identity_on, timing_on = cell_arrays(args.episodes, "M1_tight_0.15", "none")
    observations = build_observations(eps, transient, tight, identity_on, timing_on, False, tick_times=ticks)
    active = ticks >= (eps.t_a + T_POUR)[:, None]
    track_frames = observations[active]
    elapsed = (ticks - eps.t_a[:, None])[active]
    cue_mask = ((ticks >= eps.t_a[:, None]) & (ticks < (eps.t_a + T_POUR)[:, None])).reshape(-1)
    cue_frames = observations.reshape(-1, observations.shape[-1])
    cue_identity = np.repeat(eps.flask, N_STEPS)
    result = run_f1_release_gate(
        tick_times=ticks, perturbation=args.perturbation, perturbation_level=level,
        track_a_frames=track_frames, elapsed=elapsed, cue_frames=cue_frames,
        cue_mask=cue_mask, cue_identity=cue_identity, seed=args.seed,
    )
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"seed": args.seed, "episodes": args.episodes,
                               "result": result.to_dict()}, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                   encoding="utf-8")
    print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
