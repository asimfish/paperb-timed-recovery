"""Run the frozen native pilot or replay its evidence without Isaac.

CLI outputs are fresh directories. Policies are a closed audited registry.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
import importlib.metadata
import json
import os
from pathlib import Path
import random
import sys
import time
import traceback

from chemrm.papera.isaac_bridge_contract import Case, SCHEMA, TRACKS, actor_observation
from chemrm.papera.isaac_bridge_verify import sha256, verify_episode, check_bundle


SOURCES=('isaac_bridge_contract.py','isaac_bridge_policies.py','isaac_bridge_native.py',
         'isaac_bridge_verify.py','run_isaac_bridge.py')


def dump(path,data):
    path.write_text(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+'\n')


def load_bank(path):
    data=json.loads(Path(path).read_text())
    if data['schema']!=SCHEMA or data['latencies_s']!=[0.,.5,3.] or data['observation_interval_s']!=[.8,1.2]:
        raise ValueError('unsupported pilot bank')
    cases=[Case(**c) for c in data['cases']]
    ids=[c.case_id for c in cases]
    if len(ids)!=len(set(ids)): raise ValueError('duplicate case identifier')
    return data,cases


def summarize(rows):
    cells=defaultdict(lambda:{'n':0,'passed':0,'audit_failed':0,'execution_failed':0,'errors':0})
    for row in rows:
        k=f"{row['family']}/{row['policy']}/latency_{row['latency_s']:g}"
        c=cells[k]; c['n']+=1; c['passed']+=int(row['verdict']['valid'])
        c['audit_failed']+=int(not row['verdict']['audit'])
        c['execution_failed']+=int(not row['verdict']['execution'])
        c['errors']+=int(bool(row['verdict']['error']))
    for cell in cells.values(): cell['pass_fraction']=cell['passed']/cell['n']
    return dict(sorted(cells.items()))


def replay(root):
    root=Path(root).resolve(); ledger=json.loads((root/'run_manifest.json').read_text())
    rows=[]
    for row in ledger['episodes']:
        path=root/row['path']
        if not path.resolve().is_relative_to(root) or path.is_symlink():
            raise ValueError('unsafe episode path')
        if sha256(path/'manifest.json')!=row['manifest_sha256']:
            raise ValueError('episode manifest changed')
        checked=check_bundle(path)
        rows.append({**row,'verdict':checked['verdict']})
    summary=summarize(rows)
    if summary!=json.loads((root/'summary.json').read_text()):
        raise ValueError('summary replay mismatch')
    return {'status':'PASS','episodes':len(rows),'cells':len(summary),
            'policy_free':True,'isaac_loaded':any(x.startswith('isaacsim') for x in sys.modules)}


def run_episode(backend,case,policy_id,out):
    from PIL import Image
    from chemrm.papera.isaac_bridge_policies import ReferencePolicy, visual_features
    out.mkdir(parents=True,exist_ok=False); (out/'rgb').mkdir()
    policy=ReferencePolicy(policy_id); track=TRACKS[policy_id]
    rng=random.Random(case.seed+917)
    observations=[]; actions=[]; error=None
    limit=case.onset_s+case.wait_s+20 if case.family=='C13' else 35 if case.family=='C5' else 160
    start=time.perf_counter()
    try:
        backend.reset(case)
        while not backend.done and backend.now<limit:
            snapshot=backend.capture(); step=len(actions)
            actor=actor_observation(case,snapshot.rgb,snapshot.joints,snapshot.captured_at,track)
            image_name=f'rgb/{step:04d}.png'
            Image.fromarray(snapshot.rgb).save(out/image_name)
            observation={'step':step,'capture_t':snapshot.captured_at,'rgb_file':image_name,
                         'sensor_render_t':snapshot.rendered_at,
                         'rgb_sha256':sha256(out/image_name),'joints':snapshot.joints.tolist(),
                         'actor_fields':sorted(actor),'public_instruction':dict(actor['instruction']),
                         'diagnostic_visual_features':visual_features(snapshot.rgb)}
            if track in {'B','C'}: observation['actor_timestamp_s']=actor['timestamp_s']
            if track=='C': observation['actor_latency_budget_s']=actor['latency_budget_s']
            action=policy.act(actor)
            # Artificial inference replay. World, kinetics and robot continue during it.
            backend.advance(case.latency_s)
            actions.append({'step':step,'capture_t':snapshot.captured_at,
                            'dispatch_t':backend.now,'action':action.to_dict()})
            observations.append(observation)
            backend.submit(action,snapshot.captured_at,step)
            backend.advance(rng.uniform(.8,1.2))
        if not backend.done: backend.event('episode_timeout')
    except Exception as exc:
        error=f'{type(exc).__name__}: {exc}'
        traceback.print_exc()
    verdict=verify_episode(case,backend.events,error)
    dump(out/'task.json',case.to_dict())
    for name,records in [('observations',observations),('actions',actions),('events',backend.events)]:
        (out/f'{name}.jsonl').write_text(''.join(json.dumps(r,sort_keys=True,allow_nan=False)+'\n' for r in records))
    dump(out/'verdict.json',verdict)
    dump(out/'artifacts.json',{'schema':SCHEMA,'rgb_format':'PNG RGB uint8 320x320',
                              'frame_count':len(observations),'render_lag_bound_s':1/60,
                              'chemical_model':'uncalibrated first-order logistic-volume surrogate',
                              'robot_skill':'fixed Lula IK + PhysX joint drives; semantic transfer at measured arrival'})
    files={p.relative_to(out).as_posix():sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}
    dump(out/'manifest.json',{'schema':SCHEMA,'policy':policy_id,'track':track,
                             'error':error,'files':files})
    check_bundle(out)
    return verdict, time.perf_counter()-start


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--bank',type=Path)
    parser.add_argument('--freeze',type=Path,help='mandatory source/bank hash freeze for future evaluation')
    parser.add_argument('--split',choices=['dev','future'],default='dev')
    parser.add_argument('--out',type=Path)
    parser.add_argument('--asset',type=Path)
    parser.add_argument('--replay',type=Path)
    args=parser.parse_args()
    if args.replay:
        print(json.dumps(replay(args.replay),sort_keys=True)); return
    if not args.bank or not args.out or not args.asset: parser.error('bank, out and asset are required')
    data,cases=load_bank(args.bank)
    sources={name:sha256(Path(__file__).parent/name) for name in SOURCES}
    if args.split=='future':
        if not args.freeze: parser.error('future evaluation requires a freeze manifest')
        freeze=json.loads(args.freeze.read_text())
        if freeze['sources']!=sources or freeze['bank_sha256']!=sha256(args.bank):
            raise ValueError('frozen bank/source mismatch')
    if not args.asset.is_file(): raise ValueError('local licensed Franka USD not available')
    args.out.mkdir(parents=True,exist_ok=False)
    # Parse first, then keep CLI flags out of Kit's argument parsing.
    sys.argv=[sys.argv[0]]
    from isaacsim import SimulationApp
    app=SimulationApp({'headless':True,'active_gpu':0,'physics_gpu':0,'multi_gpu':False,
                       'width':320,'height':320,'renderer':'RayTracedLighting'})
    successful=False
    try:
        from chemrm.papera.isaac_bridge_native import IsaacBridge
        backend=IsaacBridge(str(args.asset.resolve()))
        rows=[]
        for base in cases:
            if base.split!=args.split: continue
            for latency in ([0.] if args.split=='dev' else data['latencies_s']):
                case=Case(**{**base.to_dict(),'latency_s':latency})
                for policy_id in TRACKS:
                    relative=f'episodes/{case.case_id}/L{latency:g}/{policy_id}'
                    verdict,seconds=run_episode(backend,case,policy_id,args.out/relative)
                    row={'path':relative,'case_id':case.case_id,'family':case.family,'policy':policy_id,
                         'latency_s':latency,'manifest_sha256':sha256(args.out/relative/'manifest.json'),
                         'verdict':verdict,'wall_seconds':seconds}
                    rows.append(row)
                    print('EPISODE '+json.dumps({k:row[k] for k in ('case_id','family','policy','latency_s','verdict','wall_seconds')}),flush=True)
                    dump(args.out/'progress.json',{'episodes':len(rows),'last':relative})
        dump(args.out/'summary.json',summarize(rows))
        dump(args.out/'run_manifest.json',{'schema':SCHEMA,'split':args.split,'sources':sources,
             'bank_sha256':sha256(args.bank),'freeze_sha256':sha256(args.freeze) if args.freeze else None,
             'runtime':{'python':sys.version,'isaacsim':importlib.metadata.version('isaacsim'),
                        'numpy':importlib.metadata.version('numpy'),'gpu':0},
             'asset_path':str(args.asset.resolve()),'asset_sha256':sha256(args.asset),
             'episodes':rows,'limits':'native engineering pilot; uncalibrated chemistry; hand-coded policies; injected latency'})
        dump(args.out/'replay_in_process.json',replay(args.out)); successful=True
    except Exception:
        traceback.print_exc(); sys.stdout.flush(); sys.stderr.flush()
        dump(args.out/'run_error.json',{'status':'ERROR','traceback':traceback.format_exc()})
    finally:
        # Isaac fastShutdown can mask Python exceptions with exit 0; a durable receipt is mandatory.
        if not successful: print('NATIVE_RUN_FAILED',flush=True)
        app.close()


if __name__=='__main__': main()
