"""Pinned A-Lab checkpoint adapter; local historical validation only."""
