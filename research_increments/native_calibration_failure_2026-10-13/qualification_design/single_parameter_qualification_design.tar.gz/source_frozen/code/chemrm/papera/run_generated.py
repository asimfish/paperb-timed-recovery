"""Execute verified frozen public task manifests through an explicit controlled backend."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from chemrm.papera.frozen_execution import build_manifest_cases
from chemrm.papera.generator import PublicGrammar, generate_public_tasks
from chemrm.papera.manifest import FrozenTaskManifest, ManifestTask, load_task_manifest
from chemrm.papera.runner import run_episode
from chemrm.papera.semantics import audit_semantic_grammar


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--manifest", help="frozen manifest directory; no generation occurs")
    source.add_argument("--grammar", help="legacy v1 generate-and-run graph diagnostic")
    parser.add_argument("--backend", choices=("graph-contract", "thermal-dose"), default="graph-contract")
    parser.add_argument("--split", choices=("closed", "compositional-held-out", "open"))
    parser.add_argument("--novelty-axis", action="append", default=[])
    parser.add_argument("--count", type=int)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--out", required=True, help="new parent evidence directory")
    parser.add_argument("--max-steps", type=int, default=1000)
    args = parser.parse_args(argv)
    if args.max_steps <= 0:
        parser.error("--max-steps must be positive")
    if args.manifest and any((args.split is not None, args.count is not None, args.seed is not None, args.novelty_axis)):
        parser.error("frozen manifest execution does not accept split/count/seed/axes overrides")
    try:
        if args.manifest:
            snapshot = load_task_manifest(args.manifest)
            binding = {"manifest_id": snapshot.manifest_id, "manifest_sha256": snapshot.manifest_sha256,
                       "task_index_sha256": snapshot.task_index_sha256}
        else:
            if args.split is None or args.backend != "graph-contract":
                parser.error("legacy grammar mode requires --split and graph-contract backend")
            data = json.loads(Path(args.grammar).read_text(encoding="utf-8"))
            if "schema_version" in data:
                parser.error("v2 grammar must be frozen with run_generate before execution")
            if args.count is not None and not 1 <= args.count <= 10000:
                parser.error("legacy --count must be in [1, 10000]")
            grammar = PublicGrammar.from_dict(data)
            tasks = generate_public_tasks(grammar, split=args.split, count=args.count if args.count is not None else 4,
                                          seed=args.seed if args.seed is not None else 19, novelty_axes=args.novelty_axis)
            snapshot = FrozenTaskManifest("legacy-unfrozen", "", "",
                                          tuple(ManifestTask(t, "grammar:" + grammar.grammar_id, grammar.sha256) for t in tasks), {})
            binding = None
        cases = build_manifest_cases(snapshot, args.backend)
    except (ValueError, TypeError, KeyError, OSError) as exc:
        parser.error(str(exc))
    root = Path(args.out)
    root.mkdir(parents=True, exist_ok=False)
    report = {"schema_version": "paper-a-frozen-execution-v1", "backend": args.backend, "manifest": binding,
              "evidence_scope": "goal-graph-contract" if args.backend == "graph-contract" else "process-model-diagnostic",
              "semantic_gate": audit_semantic_grammar(snapshot.semantic_grammar) if snapshot.semantic_grammar else None,
              "tasks": {}}
    for case in cases:
        task_hash = hashlib.sha256(case.task.canonical_json().encode()).hexdigest()
        name = "task-" + task_hash
        result = run_episode(case.task, case.world, case.policy, case.verifier,
                             seed=case.task.seed, max_steps=args.max_steps, out_dir=root / name)
        report["tasks"][case.task.task_id] = {"task_sha256": task_hash, "bundle": name,
                                           "pass_vector": dict(result.verdict.pass_vector),
                                           "failure_vector": list(result.verdict.failure_vector)}
    encoded = json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
    (root / "run.json").write_text(encoded, encoding="utf-8")
    print(encoded, end="")
    return 0 if all(row["pass_vector"].get("chem_ssr", False) for row in report["tasks"].values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
