"""Development-only native detectability, erasure and motion acceptance probe."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
import traceback

from chemrm.papera.isaac_bridge_contract import Case, Action
from chemrm.papera.run_isaac_bridge import load_bank,dump,SOURCES
from chemrm.papera.isaac_bridge_verify import sha256


def main():
    p=argparse.ArgumentParser();p.add_argument('--bank',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--asset',type=Path,required=True)
    args=p.parse_args();_,cases=load_bank(args.bank)
    base=next(c for c in cases if c.split=='dev' and c.family=='C13')
    args.out.mkdir(parents=True,exist_ok=False);sys.argv=[sys.argv[0]]
    from isaacsim import SimulationApp
    app=SimulationApp({'headless':True,'active_gpu':0,'physics_gpu':0,'multi_gpu':False,
                       'width':320,'height':320,'renderer':'RayTracedLighting'})
    try:
        from PIL import Image
        import numpy as np
        from chemrm.papera.isaac_bridge_native import IsaacBridge
        from chemrm.papera.isaac_bridge_policies import visual_features
        backend=IsaacBridge(str(args.asset)); rows=[]
        def record(name):
            snap=backend.capture();Image.fromarray(snap.rgb).save(args.out/f'{name}.png')
            return {'time':snap.captured_at,'sensor_render_time':snap.rendered_at,
                    'sensor_age_s':snap.captured_at-snap.rendered_at,**visual_features(snap.rgb)}
        for slot in range(5):
            case=Case(**{**base.to_dict(),'case_id':f'calibration_{slot}','target':slot,'onset_s':5.})
            backend.reset(case); before=record(f'slot{slot}_before')
            backend.advance(6.); cue=record(f'slot{slot}_cue')
            backend.advance(5.); after=record(f'slot{slot}_after')
            assert before['green_slot'] is None and not before['pink'] and not before['blue'],before
            assert cue['green_slot']==slot and cue['marker_count']==5,cue
            assert after['green_slot'] is None and after['green_pixels']<12,after
            reset=backend.events[0]
            for i,xyz in enumerate(reset['scene_marker_xyz']):
                assert np.linalg.norm(np.array(xyz)-np.array([case.scene_x,(2-i)*case.spacing,.06]))<1e-5
            rows.append({'slot':slot,'before':before,'cue':cue,'after':after,'native_reset':reset})
        c5=next(c for c in cases if c.split=='dev' and c.family=='C5')
        backend.reset(c5); blank=record('c5_before');backend.advance(12.);pink=record('c5_endpoint')
        assert not blank['pink'] and pink['pink'],(blank,pink)
        c6=next(c for c in cases if c.split=='dev' and c.family=='C6')
        backend.reset(c6);blank_stir=record('c6_before')
        backend.submit(Action('stir_start',0),backend.now,0);backend.advance(3.);blue=record('c6_stir')
        assert not blank_stir['blue'] and blue['blue'],(blank_stir,blue)
        start=next(e for e in backend.events if e['kind']=='stir_start')
        motion=next(e for e in backend.events if e['kind']=='stir_motion')
        assert abs(np.dot(start['rotor_quaternion'],motion['rotor_quaternion']))<.99
        assert np.linalg.norm(motion['angular_velocity'])>1.
        dump(args.out/'receipt.json',{'status':'PASS','purpose':'development-only finite sensor/skill gate',
             'scope':'five identity cues, erasure by this detector, endpoint/stir detectability, actual transforms/rotor motion',
             'not_proved':'universal aliasing, no learned clock, chemistry calibration, future generalization',
             'sources':{n:sha256(Path(__file__).parent/n) for n in SOURCES},
             'identity':rows,'c5':{'before':blank,'endpoint':pink},
             'c6':{'before':blank_stir,'stir':blue,'motion':motion}})
        print('NATIVE_CALIBRATION_PASS',flush=True)
    except Exception:
        traceback.print_exc();dump(args.out/'error.json',{'traceback':traceback.format_exc()})
        sys.stdout.flush();sys.stderr.flush()
    finally: app.close()


if __name__=='__main__':main()
