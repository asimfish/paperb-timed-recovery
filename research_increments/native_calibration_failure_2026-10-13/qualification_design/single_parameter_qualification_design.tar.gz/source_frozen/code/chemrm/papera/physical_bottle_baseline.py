"""Pinned command baseline and sampled event evidence for real rigid labware.

This module never reads an expert's measured object/robot poses as actions.
Every supplied action is a joint drive target. Event evidence belongs to one
identified native epoch; reconstruction does not establish a continuous clock.
"""
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path

import numpy as np

from .temporal_evidence_v74 import first_confirmed_rise, latency_interval, Interval


@dataclass(frozen=True)
class CommandPolicy:
    arm_targets: np.ndarray
    finger_targets: np.ndarray
    dt_s: float
    joint_names: tuple[str, ...]
    source_sha256: str

    def __len__(self):
        return len(self.arm_targets)


def load_commands(path, expected_sha256, expected_dt_s, expected_joint_names):
    path = Path(path)
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected_sha256:
        raise ValueError('command policy changed')
    with np.load(path, allow_pickle=False) as raw:
        if set(raw.files) != {'q_target', 'grip_target', 'metadata_json'}:
            raise ValueError('joint targets and metadata only; measured trajectories are not actions')
        metadata = json.loads(raw['metadata_json'].astype(np.uint8).tobytes().decode('utf-8'))
        arm, fingers = raw['q_target'].copy(), raw['grip_target'].copy()
    if (metadata.get('schema') != 'chemrm-bottle-command-policy-v1' or
            metadata.get('dt_s') != expected_dt_s or
            metadata.get('joint_names') != list(expected_joint_names) or
            metadata.get('uses_measured_state_as_action') is not False):
        raise ValueError('pinned command timing, joint order and action semantics required')
    if not (arm.ndim == fingers.ndim == 2 and arm.shape[1] == 7 and fingers.shape[1] == 2
            and arm.shape[0] == fingers.shape[0] and 0 < arm.shape[0] <= 20000):
        raise ValueError('bounded aligned seven-arm / two-finger drive targets required')
    if not all(a.dtype.kind == 'f' and np.isfinite(a).all() for a in (arm, fingers)):
        raise ValueError('finite floating point drive targets required')
    if np.any(fingers < 0) or np.any(fingers > .040001):
        raise ValueError('FR3 finger target outside the declared range')
    arm.flags.writeable = fingers.flags.writeable = False
    return CommandPolicy(arm, fingers, expected_dt_s, tuple(expected_joint_names), actual)


def bilateral_contact(row, object_prim, robot_prim):
    sides = set()
    for contact in row['contacts']:
        paths = [contact[key] for key in ('actor0', 'actor1', 'collider0', 'collider1')]
        if not any(p == object_prim or p.startswith(object_prim+'/') for p in paths):
            continue
        if np.linalg.norm(contact['impulse']) <= 1e-8:
            continue
        for side in ('left', 'right'):
            if any(p.startswith(robot_prim+'/') and side in p and 'finger' in p for p in paths):
                sides.add(side)
    return sides == {'left', 'right'}


def measured_events(rows, contact_rows, object_prim, robot_prim, dt_s, epoch):
    if not rows or len(rows) != len(contact_rows):
        raise ValueError('one measured state and contact row per integrated command required')
    for index, (state, contact) in enumerate(zip(rows, contact_rows)):
        if state['command_index'] != index or contact['tick'] != index:
            raise ValueError('contiguous actual state/contact evidence required')
        if abs(state['native_after_s']-state['native_before_s']-dt_s) > 1e-7:
            raise ValueError('unaccounted native integration interval')
        if index and abs(rows[index-1]['native_after_s']-state['native_before_s']) > 1e-9:
            raise ValueError('native clock gap or reset inside command execution')
    times = [r['native_after_s'] for r in rows]
    grip = [dict(t=t, value=int(bilateral_contact(c, object_prim, robot_prim)))
            for t,c in zip(times,contact_rows)]
    initial_height = rows[0]['object_pose'][2]
    lift = [dict(t=t,value=r['object_pose'][2]-initial_height) for t,r in zip(times,rows)]
    events = {}
    for name,samples,threshold,count in [
            ('bilateral_grasp',grip,1.,3),('bottle_lift_30mm',lift,.03,max(3,round(.15/dt_s)))]:
        value=first_confirmed_rise(samples,threshold,count,dt_s+1e-7,epoch,name,False)
        event=value.pop('event')
        value['event']=event.to_dict() if event else None
        events[name]=value
    closed=[i for i in range(1,len(rows))
            if rows[i]['grip_target'][0] < rows[i-1]['grip_target'][0]-1e-6]
    command=None
    if closed:
        command=Interval(rows[closed[0]]['native_before_s'],rows[closed[0]]['native_before_s'],
                         epoch,'first_finger_close_command',False)
    event=events['bilateral_grasp']['event']
    latency=None
    if command is not None and event is not None:
        effect=Interval(*event['bounds_s'],epoch,'bilateral_grasp',False)
        latency=latency_interval(command,effect)
    return dict(schema='chemrm-physical-bottle-events-v1',native_epoch=epoch,events=events,
        first_close_command=command.to_dict() if command else None,
        close_command_to_bilateral_grasp=latency,
        event_calibration_pass=False,chemical_event_verified=False,
        memory_task_evaluated=False,scientific_admission=False,
        scope='MEASURED_RIGID_BOTTLE_CONTACT_AND_LIFT; NO_CHEMICAL_EVENT_OR_MEMORY_CLAIM')
