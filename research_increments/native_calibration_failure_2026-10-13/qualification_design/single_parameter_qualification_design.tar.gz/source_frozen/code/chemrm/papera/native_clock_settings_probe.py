"""Exploratory matched development intervention on renderer settings, not release."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
import traceback

from chemrm.papera.native_leakage import dump, RidgeProbe, sensor_features
from chemrm.papera.isaac_bridge_contract import Case
from chemrm.papera.isaac_bridge_verify import sha256

KEYS = ['/rtx/rendermode', '/rtx/post/aa/op', '/rtx/post/histogram/enabled',
        '/rtx/rtpt/cached/enabled', '/rtx/rtpt/lightcache/cached/enabled',
        '/rtx/pathtracing/cached/enabled']


def main():
    parser = argparse.ArgumentParser()
    for field in ('bank', 'models', 'asset', 'out'):
        parser.add_argument('--'+field, type=Path, required=True)
    args = parser.parse_args()
    row = next(r for r in json.loads(args.bank.read_text())['cases']
               if r['split'] == 'train' and r['case']['target'] == 0)
    case = Case(**row['case'])
    args.out.mkdir(parents=True, exist_ok=False)
    model = RidgeProbe.load(args.models/'post_clock_rgb.npz')
    sys.argv = [sys.argv[0]]
    from isaacsim import SimulationApp
    app = SimulationApp({'headless': True, 'active_gpu': 0, 'physics_gpu': 0,
                         'multi_gpu': False, 'width': 320, 'height': 320,
                         'renderer': 'RayTracedLighting'})
    try:
        import carb
        import numpy as np
        from PIL import Image
        from chemrm.papera.isaac_bridge_native import IsaacBridge
        from chemrm.papera.isaac_bridge_policies import visual_features
        backend = IsaacBridge(str(args.asset))
        settings = carb.settings.get_settings()
        initial = {key: settings.get(key) for key in KEYS}
        conditions = [('inherited', []), ('auto_exposure_off', ['/rtx/post/histogram/enabled']),
                      ('rtpt_cache_off', ['/rtx/rtpt/cached/enabled', '/rtx/rtpt/lightcache/cached/enabled']),
                      ('both_off', ['/rtx/post/histogram/enabled', '/rtx/rtpt/cached/enabled', '/rtx/rtpt/lightcache/cached/enabled'])]
        results = []
        for name, changed in conditions:
            for key, value in initial.items():
                if value is not None:
                    settings.set(key, value)
            for key in changed:
                settings.set_bool(key, False)
            backend.reset(case)
            folder = args.out/name
            folder.mkdir()
            sampled = []
            for phase, query in [('before', case.onset_s-1.), ('cue', case.onset_s+1.),
                                 ('age_4', case.onset_s+4.), ('age_15', case.onset_s+15.),
                                 ('age_35', case.onset_s+35.), ('age_65', case.onset_s+65.)]:
                backend.advance(max(0., query-backend.now))
                snap = backend.capture()
                Image.fromarray(snap.rgb).save(folder/(phase+'.png'))
                sampled.append({'phase': phase, 'time': snap.captured_at,
                     'mean_rgb': snap.rgb.mean((0,1)).tolist(), 'detector': visual_features(snap.rgb),
                     'frozen_probe_prediction': float(model.predict(sensor_features(snap.rgb,snap.joints,'rgb')[None,:])[0])})
            t, joints = backend.now, backend.robot.get_joint_positions().copy()
            paused = []
            for i in range(65):
                if i:
                    backend.world.render()
                if i not in [0, 8, 16, 32, 64]:
                    continue
                rgb = np.asarray(backend.camera.get_rgba())[:,:,:3].copy()
                assert backend.now == t and np.array_equal(joints, backend.robot.get_joint_positions())
                Image.fromarray(rgb).save(folder/f'paused_{i}.png')
                paused.append({'extra_render_calls': i, 'physical_time': t,
                     'mean_rgb': rgb.mean((0,1)).tolist(),
                     'frozen_probe_prediction': float(model.predict(sensor_features(rgb,joints,'rgb')[None,:])[0])})
            results.append({'condition': name, 'changed_settings': changed,
                 'settings_after_reset': {key: settings.get(key) for key in KEYS},
                 'sampled': sampled, 'paused': paused})
        dump(args.out/'receipt.json', {'status': 'COMPLETE_EXPLORATORY_SETTINGS_PROBE',
             'purpose': 'development candidate selection after failed future gate; not independent repair acceptance',
             'initial_settings': initial, 'case': row, 'conditions': results,
             'source_sha256': sha256(Path(__file__)),
             'sealed_native_sha256': sha256(Path(__file__).parent/'isaac_bridge_native.py')})
        print('CLOCK_SETTINGS_PROBE_COMPLETE', flush=True)
    except Exception:
        traceback.print_exc()
        dump(args.out/'error.json', {'traceback': traceback.format_exc()})
        sys.stdout.flush()
        sys.stderr.flush()
    finally:
        app.close()


if __name__ == '__main__':
    main()
