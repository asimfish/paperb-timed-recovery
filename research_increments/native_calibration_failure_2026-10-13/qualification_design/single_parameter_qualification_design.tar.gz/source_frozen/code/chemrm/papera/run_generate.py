"""Generate public held-out/open TaskPrograms and freeze them in a Paper A manifest."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from chemrm.papera.generator import PublicGrammar, generate_public_tasks
from chemrm.papera.manifest import ManifestTask, _constant, _pairs, verify_task_manifest, write_task_manifest
from chemrm.papera.semantics import SCHEMA_VERSION, SemanticGrammar, audit_semantic_grammar, generate_semantic_tasks


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--grammar", required=True, help="public grammar JSON")
    parser.add_argument("--split", choices=("closed", "compositional-held-out", "open"), required=True)
    parser.add_argument("--novelty-axis", action="append", default=[])
    parser.add_argument("--count", type=int, default=8)
    parser.add_argument("--seed", type=int, default=19)
    parser.add_argument("--out", required=True)
    parser.add_argument("--manifest-id", required=True)
    args = parser.parse_args(argv)
    if not 1 <= args.count <= 10000:
        parser.error("--count must be in [1, 10000]")
    grammar_path = Path(args.grammar)
    if grammar_path.stat().st_size > 2 * 1024 * 1024:
        parser.error("grammar exceeds 2 MiB size limit")
    with grammar_path.open("rb") as handle:
        raw = handle.read(2 * 1024 * 1024 + 1)
    if len(raw) > 2 * 1024 * 1024:
        parser.error("grammar exceeds 2 MiB size limit")
    data = json.loads(raw.decode("utf-8"), object_pairs_hook=_pairs, parse_constant=_constant)
    if not isinstance(data, dict):
        parser.error("grammar must contain an object")
    if data.get("schema_version") == SCHEMA_VERSION:
        grammar = SemanticGrammar.from_dict(data)
        tasks = generate_semantic_tasks(grammar, split=args.split, count=args.count, seed=args.seed,
                                        novelty_axes=args.novelty_axis)
        provenance = {"kind": "public_semantic_grammar", "grammar_id": grammar.grammar_id,
                      "grammar_sha256": grammar.sha256, "grammar": grammar.to_dict()}
        semantic_gate = audit_semantic_grammar(grammar)
    elif "schema_version" not in data:
        grammar = PublicGrammar.from_dict(data)
        tasks = generate_public_tasks(grammar, split=args.split, count=args.count, seed=args.seed,
                                      novelty_axes=args.novelty_axis)
        provenance = {"kind": "public_grammar", "grammar_id": grammar.grammar_id, "grammar_sha256": grammar.sha256}
        semantic_gate = None
    else:
        parser.error("unsupported public grammar schema")
    entries = tuple(ManifestTask(task, f"grammar:{grammar.grammar_id}", grammar.sha256) for task in tasks)
    out = write_task_manifest(
        entries,
        args.out,
        manifest_id=args.manifest_id,
        provenance=provenance,
    )
    ok, errors = verify_task_manifest(out)
    print(json.dumps({"grammar_sha256": grammar.sha256, "manifest": str(out),
                      "task_count": len(tasks), "ok": ok, "errors": errors, "semantic_gate": semantic_gate},
                     ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
