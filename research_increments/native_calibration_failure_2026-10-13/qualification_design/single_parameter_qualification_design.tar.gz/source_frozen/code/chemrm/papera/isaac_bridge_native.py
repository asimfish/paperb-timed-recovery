"""Native RGB/Franka/PhysX provider; import only after SimulationApp starts.

Vessels are colored bench markers. Reagent transfer and color kinetics are
uncalibrated semantic/surrogate processes, explicitly separate from robot physics.
"""
from __future__ import annotations
import math
import numpy as np

from chemrm.papera.isaac_bridge_contract import Action, Case, Snapshot


class IsaacBridge:
    def __init__(self, asset_path: str):
        import omni.replicator.core as rep
        rep.settings.set_render_rtx_realtime(antialiasing='FXAA')
        from isaacsim.core.api import World
        from isaacsim.core.api.objects import VisualCuboid, DynamicCuboid
        from isaacsim.sensors.camera import Camera
        from isaacsim.core.utils.numpy.rotations import euler_angles_to_quats
        from isaacsim.robot.manipulators.examples.franka import Franka, KinematicsSolver
        from pxr import PhysxSchema
        self.world=World(stage_units_in_meters=1.,physics_dt=1/60,rendering_dt=1/60)
        self.world.scene.add_default_ground_plane()
        self.robot=self.world.scene.add(Franka('/World/robot',usd_path=asset_path,
                                               end_effector_prim_name='panda_hand'))
        self.markers=[self.world.scene.add(VisualCuboid(f'/World/vessel_{i}',name=f'vessel_{i}',
            position=np.array([.48,(2-i)*.15,.06]),scale=np.array([.08,.08,.05]),
            color=np.array([.9,.025,.025]))) for i in range(5)]
        self.status=self.world.scene.add(VisualCuboid('/World/stir_status',name='stir_status',
            position=np.array([.67,.3,.06]),scale=np.array([.07,.07,.02]),color=np.array([.25]*3)))
        self.rotor=self.world.scene.add(DynamicCuboid('/World/rotor',name='rotor',
            position=np.array([.48,.3,.13]),scale=np.array([.05,.008,.008]),mass=.01,
            color=np.array([.1]*3)))
        PhysxSchema.PhysxRigidBodyAPI.Apply(self.rotor.prim).CreateDisableGravityAttr(True)
        self.probe=self.world.scene.add(DynamicCuboid('/World/physics_probe',name='physics_probe',
            position=np.array([-1.,0.,.6]),scale=np.array([.06]*3),mass=.1))
        self.camera=Camera('/World/camera',position=np.array([.48,0,1.8]),frequency=60,
            resolution=(320,320),orientation=euler_angles_to_quats(np.array([0.,90.,0.]),degrees=True))
        self.world.reset(); self.camera.initialize(); self.camera.set_frequency(-1)
        self.solver=KinematicsSolver(self.robot,'panda_hand')
        self.origin=0.; self.events=[]; self.done=False; self.pending=None

    @property
    def now(self):
        return float(self.world.current_time-self.origin)

    def event(self,kind,**payload):
        self.events.append({'kind':kind,'t':self.now,**payload})

    def reset(self,case: Case):
        self.case=case
        self.world.reset()
        self.camera.post_reset()
        for i,marker in enumerate(self.markers):
            marker.set_world_pose(position=np.array([case.scene_x,(2-i)*case.spacing,.06]))
            marker.get_applied_visual_material().set_color(np.array([.9,.025,.025]))
        self.status.set_world_pose(position=np.array([case.scene_x+.19,2*case.spacing,.06]))
        self.status.get_applied_visual_material().set_color(np.array([.25]*3))
        self.camera.set_world_pose(position=np.array([case.scene_x,0,case.camera_height]))
        self.rotor.set_world_pose(position=np.array([case.scene_x,2*case.spacing,.13]),
                                  orientation=np.array([1.,0.,0.,0.]))
        self.rotor.set_linear_velocity(np.zeros(3)); self.rotor.set_angular_velocity(np.zeros(3))
        self.probe.set_world_pose(position=np.array([-1.,0.,.6])); self.probe.set_linear_velocity(np.zeros(3))
        home,ok=self.solver.compute_inverse_kinematics(np.array([.25,0,.35]),np.array([0.,1.,0.,0.]))
        if not ok: raise RuntimeError('home IK failed')
        self.robot.get_articulation_controller().apply_action(home)
        for _ in range(90): self.world.step(render=False)
        for _ in range(6): self.world.step(render=True)
        self.origin=float(self.world.current_time)
        self.events=[]; self.done=False; self.pending=None; self.cue=False; self.cue_ended=False
        self.color_fired=False; self.volume=0.; self.intensity=0.; self.flow=case.family=='C5'
        self.stirring=False; self.stir_started=False; self.first_B=False; self.motion_logged=False
        self.event('reset',physics_probe_z=float(self.probe.get_world_pose()[0][2]),
                   initial_tool_xyz=self.robot.end_effector.get_world_pose()[0].tolist(),
                   scene_marker_xyz=[m.get_world_pose()[0].tolist() for m in self.markers],
                   camera_xyz=self.camera.get_world_pose()[0].tolist())
        if abs(self.events[0]['physics_probe_z']-.03)>.01:
            raise RuntimeError('native gravity/contact gate failed')

    def tick(self,render=False):
        self.world.step(render=render)
        c=self.case; dt=1/60
        if c.family=='C13':
            if not self.cue and self.now>=c.onset_s-1e-6:
                self.cue=True
                self.markers[c.target].get_applied_visual_material().set_color(np.array([.025,.9,.025]))
                self.event('add_A',slot=c.target)
            if self.cue and not self.cue_ended and self.now>=c.onset_s+3.-1e-6:
                self.cue_ended=True
                self.markers[c.target].get_applied_visual_material().set_color(np.array([.9,.025,.025]))
                self.event('cue_end')
        elif c.family=='C5' and self.flow:
            self.volume+=dt
            drive=1/(1+math.exp(-(self.volume-c.equivalence_ml)/.3))
            self.intensity=drive+(self.intensity-drive)*math.exp(-dt/2.)
            if not self.color_fired and self.intensity>=.5:
                self.color_fired=True
                self.markers[0].get_applied_visual_material().set_color(np.array([.9,.025,.9]))
                self.event('color_change',intensity=self.intensity,added_ml=self.volume)
        if self.pending:
            pos=self.robot.end_effector.get_world_pose()[0]
            distance=float(np.linalg.norm(pos-self.pending['target']))
            if distance<=.015:
                pending=self.pending; self.pending=None
                self.event('tool_arrival',slot=pending['slot'],error_m=distance,
                           target_xyz=pending['target'].tolist(),actual_xyz=pos.tolist(),
                           action_seq=pending['action_seq'])
                if pending['kind']=='add_B':
                    self.event('add_B',slot=pending['slot'],action_seq=pending['action_seq'])
                    self.done=True
                else:
                    self.stirring=True; self.stir_started=True
                    self.rotor.set_angular_velocity(np.array([0.,0.,8.]))
                    self.status.get_applied_visual_material().set_color(np.array([.025,.025,.9]))
                    self.event('stir_start',rotor_quaternion=self.rotor.get_world_pose()[1].tolist())
                    self.stir_start_time=self.now
            elif self.now-self.pending['dispatch_t']>3.:
                self.event('execution_timeout',error_m=distance); self.pending=None; self.done=True
        if self.stirring:
            # Rotor is a native gravity-disabled rigid body; angular velocity is driven
            # by the fixed low-level stirring skill, not encoded in the actor input.
            self.rotor.set_linear_velocity(np.zeros(3))
            self.rotor.set_angular_velocity(np.array([0.,0.,8.]))
            if not self.motion_logged and self.now-self.stir_start_time>=.5:
                self.motion_logged=True
                self.event('stir_motion',rotor_quaternion=self.rotor.get_world_pose()[1].tolist(),
                           angular_velocity=self.rotor.get_angular_velocity().tolist())

    def advance(self,seconds):
        if not math.isfinite(seconds) or seconds<0: raise ValueError('invalid advance')
        for _ in range(int(round(seconds*60))):
            self.tick()

    def capture(self):
        import omni.usd
        omni.usd.get_context().reset_renderer_accumulation()
        # Two rendered physics ticks flush changes before recording the actual capture time.
        self.tick(render=True); self.tick(render=True)
        clock_before=self.now
        for _ in range(3): self.world.render()
        if abs(self.now-clock_before)>1e-9:
            raise RuntimeError('render flush unexpectedly advanced physics')
        rgba=self.camera.get_rgba()
        if rgba.shape!=(320,320,4): raise RuntimeError('native camera frame unavailable')
        rendered_at=float(self.camera.get_current_frame()['rendering_time']-self.origin)
        if not -1e-5<=self.now-rendered_at<=1/60+1e-5:
            raise RuntimeError(f'stale camera: physics={self.now}, sensor={rendered_at}')
        return Snapshot(rgba[:,:,:3].astype(np.uint8).copy(),self.robot.get_joint_positions().copy(),self.now,rendered_at)

    def submit(self,action: Action,capture_t: float,action_seq: int):
        self.event('command',kind_action=action.kind,slot=action.slot,capture_t=capture_t,
                   latency_s=self.case.latency_s,action_seq=action_seq)
        if action.kind=='wait': return
        expected={'C13':{'add_B'},'C5':{'add_stop'},'C6':{'stir_start','stir_stop'}}[self.case.family]
        if action.kind not in expected: raise ValueError('action incompatible with task')
        if action.kind in {'add_B','stir_start'}:
            if action.kind=='add_B':
                if self.first_B: return
                self.first_B=True
            elif self.stir_started or self.pending: return
            target=np.array(self.case.tool_target(action.slot))
            ik,ok=self.solver.compute_inverse_kinematics(target,np.array([0.,1.,0.,0.]))
            if not ok:
                self.event('ik_failure',slot=action.slot); self.done=True; return
            self.robot.get_articulation_controller().apply_action(ik)
            self.pending={'kind':action.kind,'slot':action.slot,'target':target,
                          'dispatch_t':self.now,'action_seq':action_seq}
        elif action.kind=='add_stop':
            self.flow=False; self.event('add_stop',added_ml=self.volume); self.done=True
        elif action.kind=='stir_stop':
            if self.stir_started:
                self.rotor.set_angular_velocity(np.zeros(3)); self.stirring=False
                self.status.get_applied_visual_material().set_color(np.array([.25]*3))
                self.event('stir_stop',rotor_quaternion=self.rotor.get_world_pose()[1].tolist())
            self.done=True
