"""Verified semantic-boundary reconstruction using the recovered A-Lab adapter.

This is separate from StageJournal's storage contract. Every reconstruction
creates a new attempt and a parent-checkpoint link; it cannot manufacture an
uninterrupted physical clock or restore hidden PhysX/PBD solver state.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
from typing import Protocol

from .legacy_reconstruction.checkpoint_schema import load_checkpoint, save_checkpoint, validate_checkpoint
from .legacy_reconstruction import checkpoint_runtime
from .staged_collection import digest, sync_directory, write_once, safe_payload, verify_prefix


@dataclass(frozen=True)
class RestoreLimits:
    position_m: float = 0.001
    orientation_rad: float = math.radians(0.5)
    joint_position_rad: float = 0.0001
    settle_ticks: int = 30

    def __post_init__(self):
        values = (self.position_m, self.orientation_rad, self.joint_position_rad)
        if any(isinstance(v, bool) or not math.isfinite(v) or v <= 0 for v in values):
            raise ValueError('positive finite reconstruction tolerances required')
        if type(self.settle_ticks) is not int or self.settle_ticks < 6:
            raise ValueError('at least six actual transient ticks required')


class ReconstructionAdapter(Protocol):
    """A provider owns scene loading, native sampling, stepping and controller state."""
    identity: dict

    def restore(self, checkpoint: dict) -> None: ...
    def sample(self) -> dict: ...
    def step_transient(self) -> None: ...
    def run_next(self) -> dict: ...


def compare_state(reference: dict, actual: dict, limits: RestoreLimits) -> dict:
    """Whole registered scene, including all door/robot joints; never a subset PASS."""
    reference, actual = validate_checkpoint(reference), validate_checkpoint(actual)
    errors, missing = [], []
    if reference['identity'] != actual['identity']:
        missing.append('identity')
    for section in ('bodies', 'articulations'):
        want = {r['id']: r for r in reference['physics'][section]}
        observed = {r['id']: r for r in actual['physics'][section]}
        if len(want) != len(reference['physics'][section]) or len(observed) != len(actual['physics'][section]):
            raise ValueError('duplicate entity identifiers')
        if set(want) != set(observed):
            missing.append(section + '_registry')
        for name in sorted(set(want) & set(observed)):
            a, b = want[name], observed[name]
            qa, qb = a['root_state'][3:7], b['root_state'][3:7]
            norms = math.sqrt(sum(x*x for x in qa) * sum(x*x for x in qb))
            if norms < 1e-12:
                raise ValueError('zero quaternion')
            angle = 2*math.acos(min(1.0, abs(sum(x*y for x,y in zip(qa,qb)))/norms))
            position = math.sqrt(sum((x-y)**2 for x,y in zip(a['root_state'][:3], b['root_state'][:3])))
            row = dict(id=name, position_m=position, orientation_rad=angle,
                       pass_pose=position <= limits.position_m and angle <= limits.orientation_rad)
            if section == 'articulations':
                same_order = a['joint_names'] == b['joint_names']
                row['joint_names_equal'] = same_order
                row['joint_error_rad'] = max((abs(x-y) for x,y in zip(a['joint_position'],b['joint_position'])), default=0)
                row['pass_pose'] &= same_order and row['joint_error_rad'] <= limits.joint_position_rad
                row['drive_state_equal'] = all(a[k] == b[k] for k in (
                    'joint_position_target','joint_velocity_target','joint_effort_target','runtime_properties'))
                row['pass_pose'] &= row['drive_state_equal']
            errors.append(row)
    # These define the current continuation contract; PhysX caches remain absent.
    host_checks = {key: reference['host'].get(key) == actual['host'].get(key)
                   for key in ('kin', 'kinematic_support', 'pinned', 'contract')}
    host_checks['task_graph_position'] = reference['task']['graph_position'] == actual['task']['graph_position']
    return dict(status='PASS' if not missing and all(r['pass_pose'] for r in errors) and all(host_checks.values()) else 'FAIL',
                registry_errors=missing, entity_errors=errors, host_checks=host_checks,
                expected_body_count=len(reference['physics']['bodies']),
                observed_body_count=len(actual['physics']['bodies']),
                hidden_solver_state_restored=False, scientific_admission=False)


def _verify_parent(root: Path, parent: Path, expected_digest: str, cp: dict, stage_id: str) -> None:
    """Verify the actual parent and its sealed byte ranges before native writes."""
    if not parent.is_relative_to(root):
        raise ValueError('parent stage must belong to the checkpoint episode directory')
    if digest(parent) != expected_digest:
        raise ValueError('parent stage manifest changed')
    marker = json.loads((parent.parent/'COMMITTED.json').read_text())
    record = json.loads(parent.read_text())
    if marker != {'manifest_sha256': expected_digest}:
        raise ValueError('parent stage is not committed')
    if (record.get('schema') != 'chemrm-stage-evidence-v1' or
            record.get('stage_id') != stage_id or
            record.get('end_tick') != cp['host']['tick'] or
            record.get('episode_id') != cp['chain_id']):
        raise ValueError('checkpoint is not the declared parent stage boundary')
    for row in record.get('payloads', []):
        path = safe_payload(root, row['path'])
        if digest(path, row['offset'], row['size']) != row['sha256']:
            raise ValueError('sealed parent stage payload changed')
    # The production journal has a full episode header and chain. Minimal
    # native diagnostic manifests have neither and make no journal claim.
    if parent.is_relative_to(root/'stages') and (root/'stages/episode.json').exists():
        verify_prefix(root)


def _check_boundary(cp: dict, expected_identity: dict) -> None:
    if cp['identity'] != expected_identity:
        raise ValueError('checkpoint identity mismatch before reconstruction')
    if cp.get('boundary_kind') != 'task_boundary' or cp['host']['kin'] or cp.get('resumed_mid_carry'):
        raise ValueError('continuation currently requires a released semantic task boundary')
    if cp.get('carry_mode') != 'none' or cp['identity']['root_state_variant'] != 'root_state':
        raise ValueError('unrecognized boundary semantics')
    if cp['randomness']['draw_count'] != 0:
        raise ValueError('legacy seed/counter alone cannot restore a drawn RNG stream')
    for body in cp['physics']['bodies'] + cp['physics']['articulations']:
        if len(body['root_state']) != 13:
            raise ValueError('complete root-state record required')
        if cp['schema_version']<3 and max(abs(v) for v in body['root_state'][7:]) > 0.001:
            raise ValueError('nonstationary boundary; zero-velocity restoration would discard motion')
    for art in cp['physics']['articulations']:
        if cp['schema_version']<3 and max((abs(v) for v in art['joint_velocity']), default=0) > 0.001:
            raise ValueError('nonstationary joint boundary')


def _observed_velocity_check(reference: dict, actual: dict) -> dict:
    """Version 3 may preserve servo motion, but must not silently zero it."""
    rows=[]
    for section in ('bodies','articulations'):
        observed={r['id']:r for r in actual['physics'][section]}
        for row in reference['physics'][section]:
            other=observed.get(row['id'])
            if other is None:
                rows.append(dict(id=row['id'],passed=False,reason='missing entity'))
                continue
            error=max(abs(a-b) for a,b in zip(row['root_state'][7:],other['root_state'][7:]))
            if section=='articulations':
                error=max(error,max((abs(a-b) for a,b in zip(row['joint_velocity'],other['joint_velocity'])),default=0))
            rows.append(dict(id=row['id'],velocity_error=error,passed=error<=1e-6))
    return dict(status='PASS' if all(r['passed'] for r in rows) else 'FAIL',entity_errors=rows,
                tolerance=1e-6,scope='INITIAL_ADAPTER_OBSERVED_VELOCITIES',hidden_solver_state_restored=False)


def seal_boundary(root, cp: dict, stage_id: str, *, parent_manifest_sha256: str,
                  parent_manifest_path, scene_has_particles: bool, expected_identity: dict) -> dict:
    """Save one immutable semantic checkpoint. Unsupported liquid worlds fail closed."""
    root = Path(root).resolve()
    cp = validate_checkpoint(cp)
    _check_boundary(cp, expected_identity)
    if scene_has_particles is not False:
        raise ValueError('PBD/fluid checkpoint backend unavailable; storage snapshots are not restart state')
    if not stage_id or not stage_id.replace('_','').isalnum():
        raise ValueError('simple semantic stage name required')
    if len(parent_manifest_sha256) != 64 or any(c not in '0123456789abcdef' for c in parent_manifest_sha256):
        raise ValueError('pinned parent stage manifest required')
    parent = Path(parent_manifest_path).resolve()
    if not parent.is_relative_to(root):
        raise ValueError('parent stage must belong to the checkpoint episode directory')
    if digest(parent) != parent_manifest_sha256:
        raise ValueError('parent stage manifest changed')
    parent_marker = json.loads((parent.parent/'COMMITTED.json').read_text())
    parent_record = json.loads(parent.read_text())
    if parent_marker != {'manifest_sha256': parent_manifest_sha256}:
        raise ValueError('parent stage is not committed')
    if (parent_record.get('schema') != 'chemrm-stage-evidence-v1' or
            parent_record.get('stage_id') != stage_id or
            parent_record.get('end_tick') != cp['host']['tick'] or
            parent_record.get('episode_id') != cp['chain_id']):
        raise ValueError('checkpoint is not the declared parent stage boundary')
    # Test fixtures and older diagnostic parents can have a directory label
    # differing from their stage id; exact stage_id was already checked above.
    for payload in parent_record.get('payloads', []):
        if digest(safe_payload(root, payload['path']), payload['offset'], payload['size']) != payload['sha256']:
            raise ValueError('sealed parent stage payload changed')
    directory = root / 'reconstruction' / stage_id
    directory.mkdir(parents=True, exist_ok=False)
    path = directory / 'checkpoint.npz'
    save_checkpoint(path, cp)
    with path.open('rb') as handle:
        __import__('os').fsync(handle.fileno())
    row = dict(schema='chemrm-semantic-checkpoint-v2', stage_id=stage_id,
               checkpoint_sha256=digest(path), parent_manifest_sha256=parent_manifest_sha256,
               parent_manifest_path=str(parent.relative_to(root)),
               velocity_restore_mode='observed' if cp['schema_version']>=3 else 'released_zero_velocity',
               identity_sha256=hashlib.sha256(json.dumps(cp['identity'],sort_keys=True).encode()).hexdigest(),
               scene_has_particles=False, reconstruction_adapter='alab_twin.checkpoint/v1',
               native_clock_continuous_across_rebuild=False, training_admitted=False)
    write_once(directory/'manifest.json', row)
    write_once(directory/'COMMITTED.json', {'manifest_sha256': digest(directory/'manifest.json')})
    return row


def continue_from_boundary(checkpoint_directory, attempt_directory, adapter: ReconstructionAdapter,
                           *, limits: RestoreLimits = RestoreLimits()) -> dict:
    """Rebuild, retain transient samples, verify every entity, then dispatch next stage.

    A process/factory may create the adapter in a new Isaac instance. That path
    requires its own native acceptance test; CPU doubles do not establish it.
    """
    source = Path(checkpoint_directory).resolve()
    marker = json.loads((source/'COMMITTED.json').read_text())
    manifest = json.loads((source/'manifest.json').read_text())
    if marker != {'manifest_sha256': digest(source/'manifest.json')}:
        raise ValueError('checkpoint commit marker mismatch')
    if manifest.get('schema') != 'chemrm-semantic-checkpoint-v2':
        raise ValueError('legacy semantic manifest lacks a parent path; reseal into a new episode directory')
    if manifest.get('scene_has_particles') is not False or manifest.get('training_admitted') is not False:
        raise ValueError('unsupported checkpoint admission')
    if digest(source/'checkpoint.npz') != manifest['checkpoint_sha256']:
        raise ValueError('checkpoint payload changed')
    cp = load_checkpoint(source/'checkpoint.npz')
    _check_boundary(cp, adapter.identity)
    episode_root = source.parent.parent
    parent = (episode_root/manifest['parent_manifest_path']).resolve()
    # Parent paths remain private; the child retains only their content digest.
    _verify_parent(episode_root, parent, manifest['parent_manifest_sha256'], cp, manifest['stage_id'])
    target = Path(attempt_directory).resolve()
    if target == source or target.is_relative_to(source):
        raise ValueError('new continuation attempt must not write into the sealed parent')
    target.mkdir(parents=True, exist_ok=False)
    link = dict(schema='chemrm-reconstruction-attempt-v1',
                parent_checkpoint_sha256=manifest['checkpoint_sha256'],
                parent_manifest_sha256=manifest['parent_manifest_sha256'],
                stage_id=manifest['stage_id'], transient_ticks=limits.settle_ticks,
                native_clock_continuous_across_rebuild=False, training_admitted=False)
    write_once(target/'parent.json',link)
    try:
        adapter.restore(copy.deepcopy(cp))
        actual = validate_checkpoint(adapter.sample())
        if cp['schema_version']>=3:
            initial=compare_state(cp,actual,limits)
            initial['velocities']=_observed_velocity_check(cp,actual)
            write_once(target/'initial_restore_verdict.json',initial)
            if initial['status']!='PASS' or initial['velocities']['status']!='PASS':
                result=dict(status='BLOCKED_INITIAL_RECONSTRUCTION_STATE',next_stage_started=False,
                            scientific_admission=False)
                write_once(target/'RESULT.json',result)
                sync_directory(target)
                return result
        # Preserve all actual transient states; they are separate from task data,
        # never quietly cut out of the authoritative timing record.
        with (target/'transient.jsonl').open('x') as handle:
            for i in range(limits.settle_ticks):
                adapter.step_transient()
                actual = validate_checkpoint(adapter.sample())
                handle.write(json.dumps(actual,allow_nan=False)+'\n')
            handle.flush()
            __import__('os').fsync(handle.fileno())
        check = compare_state(cp,actual,limits)
        write_once(target/'restore_verdict.json',check)
        if check['status'] != 'PASS':
            result = dict(status='BLOCKED_RECONSTRUCTION_DRIFT', next_stage_started=False,
                          scientific_admission=False)
        else:
            task = adapter.run_next()
            write_once(target/'next_stage.json',task)
            result = dict(status='DEVELOPMENT_NEXT_STAGE_EXECUTED', next_stage_started=True,
                          scientific_admission=False)
    except Exception:
        write_once(target/'FAILED.json', dict(status='RECONSTRUCTION_OR_CONTINUATION_FAILED',
                                             scientific_admission=False))
        raise
    write_once(target/'RESULT.json',result)
    sync_directory(target)
    return result


class LegacyTwinAdapter:
    """Reuse the pinned restore adapter in an already constructed A-Lab world."""
    def __init__(self, namespace, recorder, *, transient_step, next_stage):
        self.ns, self.rec = namespace, recorder
        self.identity = copy.deepcopy(namespace['CHECKPOINT_IDENTITY'])
        self._step, self._next = transient_step, next_stage
        if namespace['scene'].num_envs != 1:
            raise ValueError('legacy adapter supports one world only')

    def restore(self, checkpoint):
        checkpoint_runtime.restore(self.ns,self.rec,checkpoint)
        self.rec.task_graph_position = copy.deepcopy(checkpoint['task']['graph_position'])

    def sample(self):
        return checkpoint_runtime.capture(self.ns,self.rec, boundary_kind='task_boundary')

    def step_transient(self):
        self._step()

    def run_next(self):
        return self._next()
