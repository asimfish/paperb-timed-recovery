"""Versioned native renderer configuration; never edits a sensor image."""
from __future__ import annotations

from chemrm.papera.native_clock_repair_candidate import FixedLightCandidate
from chemrm.papera.clock_repair_v17 import LIGHT_INTENSITY, SETTINGS, REVISION


class FixedLightV17(FixedLightCandidate):
    def __init__(self, asset_path):
        super().__init__(asset_path, intensity=LIGHT_INTENSITY)

    def check_settings(self):
        actual = super().check_settings()
        import omni.usd
        stage = omni.usd.get_context().get_stage()
        prim = stage.GetPrimAtPath('/World/explicit_fixed_light')
        intensity = prim.GetAttribute('inputs:intensity').Get()
        angle = prim.GetAttribute('inputs:angle').Get()
        if actual != SETTINGS or intensity != LIGHT_INTENSITY or angle != 0.:
            raise RuntimeError('actual native fixed-light configuration differs')
        return actual

    def reset(self, case):
        super().reset(case)
        self.events[0]['renderer_revision'] = REVISION
        self.events[0]['actual_distant_light_angle'] = 0.
