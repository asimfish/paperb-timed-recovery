"""Fixed native render settling at unchanged physical state, no image filtering."""
from __future__ import annotations
import numpy as np
from chemrm.papera.fixed_light_native_v17 import FixedLightV17
from chemrm.papera.confirmation_v19 import SETTLING_RENDERS
from chemrm.papera.isaac_bridge_contract import Snapshot


class SettledCaptureV19(FixedLightV17):
    def reset(self,case):
        super().reset(case)
        self.events[0]['capture_settling_extra_calls']=SETTLING_RENDERS

    def capture(self):
        original=super().capture()
        before=self.now;joints=self.robot.get_joint_positions().copy()
        for _ in range(SETTLING_RENDERS):self.world.render()
        self.check_settings()
        if self.now!=before or not np.array_equal(joints,self.robot.get_joint_positions()):
            raise RuntimeError('settling render advanced physics/joints')
        rgb=self.camera.get_rgba()[:,:,:3].astype(np.uint8).copy()
        rendered=float(self.camera.get_current_frame()['rendering_time']-self.origin)
        if not -1e-5<=self.now-rendered<=1/60+1e-5:raise RuntimeError('settled camera stale')
        return Snapshot(rgb,joints,original.captured_at,rendered)
