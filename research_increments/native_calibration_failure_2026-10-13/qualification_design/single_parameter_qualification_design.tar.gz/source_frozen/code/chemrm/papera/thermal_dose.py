"""Thermal dosing diagnostic with measured state and an event-only verifier.

This scalar surrogate exposes process sensors, which may provide timing cues. It is not a
no-clock memory benchmark, a calibrated chemistry simulator, or an arbitrary goal-graph backend.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, fields
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping

from chemrm.constraints import TRate, Violation
from chemrm.events import Event, EventBus, SimClock
from chemrm.papera.contract import ActionRecord, EpisodeVerdict, ObservationRecord, Trace, verify_bundle
from chemrm.papera.runner import ReadOnlyConstraintVerifier, WorldStep
from chemrm.process_models import ThermalModel
from chemrm.quality import QDose
from chemrm.task_program import GoalStep, TaskProgram


BACKEND = "chemrm.thermal-dose.f0"
OBSERVATION_MODE = "process-sensors-diagnostic"
MODEL_CONTRACT = "thermal-dose-surrogate-v1"


def _finite_number(value: Any) -> bool:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


@dataclass(frozen=True)
class ThermalDoseSpec:
    """Public synthetic process/instrument configuration; units are mL, s, deg C and J."""

    dt_s: float = 0.25
    horizon_s: float = 60.0
    initial_volume_ml: float = 20.0
    initial_temperature_c: float = 25.0
    target_ml: float = 5.0
    relative_tolerance: float = 0.05
    max_rate_ml_s: float = 0.3
    k: float = 0.05
    t_amb: float = 25.0
    h_mix: float = 400.0
    cp: float = 4.18
    t_smoke: float = 45.0
    vessel: str = "beaker_0"
    reagent: str = "A"

    def __post_init__(self) -> None:
        for field in fields(self):
            value = getattr(self, field.name)
            if field.name in {"vessel", "reagent"}:
                if not isinstance(value, str) or not value.strip():
                    raise ValueError(f"{field.name} must be a non-empty string")
            elif not _finite_number(value):
                raise ValueError(f"{field.name} must be a finite number")
        for key in ("dt_s", "horizon_s", "initial_volume_ml", "target_ml", "max_rate_ml_s", "k", "cp"):
            if getattr(self, key) <= 0:
                raise ValueError(f"{key} must be positive")
        if not 0 < self.relative_tolerance < 1 or self.h_mix < 0:
            raise ValueError("relative_tolerance must be in (0, 1) and h_mix non-negative")
        ticks = self.horizon_s / self.dt_s
        if not math.isfinite(ticks) or ticks < 1 or not math.isclose(ticks, round(ticks), rel_tol=0, abs_tol=1e-9):
            raise ValueError("horizon_s must be a positive integer multiple of dt_s")
        if self.t_smoke <= max(self.initial_temperature_c, self.t_amb):
            raise ValueError("t_smoke must exceed initial and ambient temperatures")


def make_thermal_dose_task(spec: ThermalDoseSpec | None = None, *, seed: int = 19) -> TaskProgram:
    spec = spec or ThermalDoseSpec()
    if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0:
        raise ValueError("seed must be a non-negative integer")
    return TaskProgram(
        task_id=f"thermal-dose-diagnostic:seed{seed}", split="closed", seed=seed,
        environment={"kind": BACKEND, "model_contract": MODEL_CONTRACT,
                     "observation_mode": OBSERVATION_MODE, "spec": asdict(spec)},
        objects=({"id": spec.vessel, "role": "beaker"},), counts={"beaker": 1},
        goals=(GoalStep("dose", "add_reagent", parameters={"reagent": spec.reagent, "vessel": spec.vessel}),
               GoalStep("stop", "add_stop", requires=("dose",), parameters={"vessel": spec.vessel})),
        public_spec_version="thermal-dose-v1",
        metadata={"evidence_scope": "process-model-diagnostic", "parameters": "synthetic-uncalibrated"},
    )


def thermal_dose_spec(task: TaskProgram) -> ThermalDoseSpec:
    """Validate the supported public program before any world or verifier interprets it."""
    env = task.environment
    if env.get("kind") != BACKEND:
        raise ValueError(f"unsupported chemistry backend {env.get('kind')!r}")
    if task.split != "closed" or task.novelty_axes:
        raise ValueError("thermal dose is a closed diagnostic, not a held-out/open release")
    if (set(env) != {"kind", "model_contract", "observation_mode", "spec"}
            or env["model_contract"] != MODEL_CONTRACT or env["observation_mode"] != OBSERVATION_MODE
            or task.public_spec_version != "thermal-dose-v1"
            or task.metadata.get("evidence_scope") != "process-model-diagnostic"
            or task.metadata.get("parameters") != "synthetic-uncalibrated"):
        raise ValueError("unsupported process model or observation contract")
    data = env["spec"]
    if not isinstance(data, Mapping) or set(data) != {field.name for field in fields(ThermalDoseSpec)}:
        raise ValueError("thermal spec must contain exactly the declared configuration fields")
    spec = ThermalDoseSpec(**data)
    starts = [goal for goal in task.goals if goal.action == "add_reagent"]
    stops = [goal for goal in task.goals if goal.action == "add_stop"]
    if len(task.goals) != 2 or len(starts) != 1 or len(stops) != 1:
        raise ValueError("thermal goals require exactly one add_reagent and one add_stop")
    start, stop = starts[0], stops[0]
    if (start.requires or stop.requires != (start.id,)
            or dict(start.parameters) != {"reagent": spec.reagent, "vessel": spec.vessel}
            or dict(stop.parameters) != {"vessel": spec.vessel}):
        raise ValueError("thermal goal parameters/dependency must be add_reagent then add_stop")
    if task.objects != ({"id": spec.vessel, "role": "beaker"},) or dict(task.counts) != {"beaker": 1}:
        raise ValueError("thermal backend supports one declared receiving beaker")
    return spec


class ThermalDoseWorld:
    """Integrate measured volume and heat each tick; no requested dose is a measured fact."""

    def __init__(self) -> None:
        self.clock = SimClock()
        self.event_bus = EventBus(self.clock)

    def reset(self, task: TaskProgram, seed: int) -> Mapping[str, Any]:
        self.spec = thermal_dose_spec(task)
        if seed != task.seed:
            raise ValueError("world seed differs from frozen task")
        self.clock.reset()
        self.event_bus = EventBus(self.clock)
        self.model = ThermalModel(self.event_bus, k=self.spec.k, t_amb=self.spec.t_amb,
                                  h_mix=self.spec.h_mix, cp=self.spec.cp,
                                  volume_ml=self.spec.initial_volume_ml, t_smoke=self.spec.t_smoke,
                                  vessel=self.spec.vessel, temperature=self.spec.initial_temperature_c)
        self.phase = "idle"
        self.done = False
        self._probe()
        return self._observation()

    def _probe(self) -> None:
        self.event_bus.emit("volume_probe", vessel=self.spec.vessel, volume_ml=self.model.volume_ml)
        self.event_bus.emit("temperature_probe", vessel=self.spec.vessel, temperature_c=self.model.temperature)
        if self.phase == "adding":
            self.event_bus.emit("rate_sample", vessel=self.spec.vessel, rate_ml_s=self.model.addition_rate)

    def _observation(self) -> Mapping[str, Any]:
        return {
            "instruction": {"reagent": self.spec.reagent, "vessel": self.spec.vessel,
                            "target_ml": self.spec.target_ml, "relative_tolerance": self.spec.relative_tolerance,
                            "max_rate_ml_s": self.spec.max_rate_ml_s, "dt_s": self.spec.dt_s},
            "sensors": {"volume_ml": self.model.volume_ml, "temperature_c": self.model.temperature,
                        "smoke": self.model.smoked},
            "phase": self.phase,
        }

    def step(self, action: Mapping[str, Any]) -> WorldStep:
        if self.done:
            raise ValueError("episode already terminated")
        kind = action.get("kind")
        if kind == "add_reagent":
            if (self.phase != "idle" or set(action) != {"kind", "reagent", "vessel", "rate_ml_s"}
                    or action["reagent"] != self.spec.reagent or action["vessel"] != self.spec.vessel):
                raise ValueError("add_reagent requires idle phase and the declared reagent/vessel")
            rate = action["rate_ml_s"]
            if not _finite_number(rate) or rate <= 0:
                raise ValueError("rate_ml_s must be a finite positive number")
            self.event_bus.emit("add_reagent", reagent=self.spec.reagent, vessel=self.spec.vessel, rate_ml_s=rate)
            self.phase = "adding"
            self.event_bus.emit("rate_sample", vessel=self.spec.vessel, rate_ml_s=rate)
        elif kind == "add_stop":
            if self.phase != "adding" or dict(action) != {"kind": "add_stop", "vessel": self.spec.vessel}:
                raise ValueError("add_stop requires a preceding addition in the declared vessel")
            self.event_bus.emit("add_stop", vessel=self.spec.vessel)
            self.phase = "stopped"
            self.done = True
            return WorldStep(self._observation(), True, "add_stop")
        elif kind != "wait" or dict(action) != {"kind": "wait"}:
            raise ValueError("unsupported thermal dose action")
        self.clock.step(self.spec.dt_s)
        self.model.step(self.spec.dt_s)
        self._probe()
        self.done = self.clock.now >= self.spec.horizon_s - 1e-9
        return WorldStep(self._observation(), self.done, "horizon" if self.done else "")


class ThermalDosePolicy:
    """Frozen sensor reference; dose_fraction also supplies declared incorrect controls."""

    policy_id = "paper-a-thermal-dose-sensor-reference-v1"

    def __init__(self, rate_ml_s: float = 0.2, dose_fraction: float = 1.0) -> None:
        if any(not _finite_number(value) or value <= 0 for value in (rate_ml_s, dose_fraction)):
            raise ValueError("policy rate and dose fraction must be finite and positive")
        self.rate_ml_s = float(rate_ml_s)
        self.dose_fraction = float(dose_fraction)
        config = json.dumps({"policy_id": self.policy_id, "rate_ml_s": self.rate_ml_s,
                             "dose_fraction": self.dose_fraction}, sort_keys=True, separators=(",", ":"))
        self.policy_hash = "sha256:" + hashlib.sha256(config.encode()).hexdigest()

    def reset(self, task: TaskProgram, _seed: int) -> None:
        thermal_dose_spec(task)
        self.initial_volume: float | None = None

    def act(self, observation: Mapping[str, Any]) -> Mapping[str, Any]:
        instruction, sensors = observation["instruction"], observation["sensors"]
        if self.initial_volume is None:
            self.initial_volume = float(sensors["volume_ml"])
            return {"kind": "add_reagent", "reagent": instruction["reagent"],
                    "vessel": instruction["vessel"], "rate_ml_s": self.rate_ml_s}
        delivered = float(sensors["volume_ml"]) - self.initial_volume
        if delivered + 1e-9 >= float(instruction["target_ml"]) * self.dose_fraction:
            return {"kind": "add_stop", "vessel": instruction["vessel"]}
        return {"kind": "wait"}


class _ThermalChecks:
    """Event-backed instrumentation guard followed by existing quantity/time checkers."""

    def __init__(self, spec: ThermalDoseSpec) -> None:
        self.spec = spec
        match = {"vessel": spec.vessel}
        self.dose = QDose("thermal.dose", spec.target_ml, spec.relative_tolerance,
                          start_kind="add_reagent", probe_match=match, anchor_match=match,
                          sample_period=spec.dt_s)
        self.rate = TRate("thermal.rate", "rate_ml_s", 0.0, spec.max_rate_ml_s, spec.dt_s,
                          max_breach_fraction=0.0, sample_match=match, active_match=match,
                          active_start_kind="add_reagent", active_end_kind="add_stop")

    def _invalid(self, detail: str, end: float) -> list[Violation]:
        return [Violation("thermal.instrumentation", "instrumentation_invalid", detail, end)]

    def _audit(self, bus: EventBus, end: float) -> list[Violation]:
        if not _finite_number(end) or any(not _finite_number(ev.t) or ev.t < 0 for ev in bus.log):
            return self._invalid("non-finite or negative audit clock", 0.0)
        starts, stops = bus.all("add_reagent"), bus.all("add_stop")
        if not starts or not stops:
            return self._invalid("mandatory addition/stop anchor missing", end) + [
                Violation("thermal.protocol", "incomplete", "addition did not terminate with add_stop", end)]
        if len(starts) != 1 or len(stops) != 1:
            return self._invalid("exactly one addition and stop anchor required", end)
        start, stop = starts[0], stops[0]
        rate = start.payload.get("rate_ml_s")
        if (start.payload.get("vessel") != self.spec.vessel or start.payload.get("reagent") != self.spec.reagent
                or stop.payload.get("vessel") != self.spec.vessel or not _finite_number(rate) or rate <= 0
                or stop.t <= start.t or not math.isclose(stop.t, end, rel_tol=0, abs_tol=1e-9)):
            return self._invalid("incorrect addition/stop identity, rate or order", end)
        ticks = end / self.spec.dt_s
        start_tick = start.t / self.spec.dt_s
        if (not math.isfinite(ticks) or not math.isfinite(start_tick)
                or not math.isclose(ticks, round(ticks), rel_tol=0, abs_tol=1e-8)
                or not math.isclose(start_tick, round(start_tick), rel_tol=0, abs_tol=1e-8)
                or end > self.spec.horizon_s + 1e-9):
            return self._invalid("episode/anchor clock outside declared tick grid or horizon", end)
        for kind, var in (("volume_probe", "volume_ml"), ("temperature_probe", "temperature_c"),
                          ("rate_sample", "rate_ml_s")):
            samples = bus.all(kind)
            offset = round(start_tick) if kind == "rate_sample" else 0
            if len(samples) != round(ticks) + 1 - offset:
                return self._invalid(f"incomplete or duplicate {kind} sampling", end)
            for index, ev in enumerate(samples, start=offset):
                value = ev.payload.get(var)
                if (ev.payload.get("vessel") != self.spec.vessel or not _finite_number(value)
                        or not math.isclose(ev.t, index * self.spec.dt_s, rel_tol=0, abs_tol=1e-8)):
                    return self._invalid(f"invalid {kind} value, vessel or cadence", end)
                if kind == "volume_probe":
                    expected = self.spec.initial_volume_ml + rate * max(0.0, ev.t - start.t)
                    if not math.isclose(value, expected, rel_tol=1e-9, abs_tol=1e-8):
                        return self._invalid("volume probe violates addition mass balance", end)
                if kind == "rate_sample" and not math.isclose(value, rate, rel_tol=1e-9, abs_tol=1e-9):
                    return self._invalid("rate probe disagrees with active addition", end)
                if kind == "temperature_probe" and index == 0 and not math.isclose(
                        value, self.spec.initial_temperature_c, rel_tol=0, abs_tol=1e-8):
                    return self._invalid("temperature probe initial condition differs from task", end)
        return []

    def check(self, bus: EventBus, episode_end: float) -> list[Violation]:
        out = self._audit(bus, episode_end)
        # Either consequence channel suffices; later samples cannot erase an earlier crossing.
        smoke = bus.first("smoke", vessel=self.spec.vessel)
        hot = next((ev for ev in bus.all("temperature_probe", vessel=self.spec.vessel)
                    if _finite_number(ev.payload.get("temperature_c"))
                    and ev.payload["temperature_c"] >= self.spec.t_smoke), None)
        consequence = smoke or hot
        if consequence is not None:
            out.append(Violation("thermal.safety", "smoke", "irreversible thermal threshold crossed", consequence.t))
        if any(row.kind == "instrumentation_invalid" for row in out):
            return out
        return out + self.dose.check(bus, episode_end) + self.rate.check(bus, episode_end)


class ThermalDoseVerifier(ReadOnlyConstraintVerifier):
    """Bound to a frozen task; never holds or mutates a world/model reference."""

    verifier_id = "paper-a-thermal-dose-verifier-v1"

    def __init__(self, task: TaskProgram) -> None:
        self.spec = thermal_dose_spec(task)
        self.task_json = task.canonical_json()
        self.checks = _ThermalChecks(self.spec)
        super().__init__((self.checks,), task.goals)

    def verify(self, task: TaskProgram, trace: Trace) -> EpisodeVerdict:
        if task.canonical_json() != self.task_json:
            raise ValueError("verifier input differs from frozen task")
        if trace.verifier_id != self.verifier_id:
            raise ValueError("trace verifier identity differs from thermal verifier")
        verdict = super().verify(task, trace)
        bus = EventBus.replay(trace.events)
        start = bus.first("add_reagent", vessel=self.spec.vessel)
        stop = bus.first("add_stop", vessel=self.spec.vessel)
        delta, delivered = None, None
        if verdict.valid:
            delta, delivered, _ = self.checks.dose.measure(bus, trace.end_time)
        temperatures = [ev.payload["temperature_c"] for ev in bus.all("temperature_probe", vessel=self.spec.vessel)
                        if _finite_number(ev.payload.get("temperature_c"))]
        metrics = {**verdict.metrics, "delivered_ml": delivered, "relative_dose_error": delta,
                   "peak_temperature_c": max(temperatures) if temperatures else None,
                   "active_duration_s": stop.t - start.t if start and stop else None,
                   "evidence_scope": "process-model-diagnostic", "observation_mode": OBSERVATION_MODE}
        return EpisodeVerdict(self.verifier_id, verdict.pass_vector, verdict.failure_vector, metrics)


def replay_thermal_dose_bundle(bundle_dir: str | Path) -> EpisodeVerdict:
    """Recompute a disk bundle's verdict without constructing a policy/world/process model.

    The terminal audit time comes from the event stream, not the stored verdict. The thermal
    backend samples at every world tick, including reset and the terminal tick.
    """
    root = Path(bundle_dir)
    check = verify_bundle(root)
    if not check.ok:
        raise ValueError("invalid evidence bundle: " + "; ".join(check.errors))
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    task = TaskProgram.from_dict(json.loads((root / "task.json").read_text(encoding="utf-8")))
    if (manifest["task_id"] != task.task_id or manifest["split"] != task.split
            or manifest["seed"] != task.seed or not isinstance(manifest["completed"], bool)):
        raise ValueError("bundle metadata differs from frozen thermal task")

    def rows(name: str) -> list[dict[str, Any]]:
        return [json.loads(line) for line in (root / name).read_text(encoding="utf-8").splitlines()]

    events = tuple(Event(row["kind"], row["t"], row["payload"]) for row in rows("events.jsonl"))
    trace = Trace(task=task, seed=manifest["seed"], policy_id=manifest["policy_id"],
                  policy_hash=manifest["policy_hash"], verifier_id=manifest["verifier_id"],
                  observations=tuple(ObservationRecord(row["step"], row["t"], row["observation"])
                                     for row in rows("observations.jsonl")),
                  actions=tuple(ActionRecord(row["step"], row["t"], row["action"])
                                for row in rows("actions.jsonl")),
                  events=events, end_time=events[-1].t if events else 0.0,
                  completed=manifest["completed"], stop_reason=manifest["stop_reason"], error=manifest["error"])
    verdict = ThermalDoseVerifier(task).verify(task, trace)
    recorded = json.loads((root / "verdict.json").read_text(encoding="utf-8"))
    if recorded != verdict.to_dict():
        raise ValueError("stored thermal verdict differs from independent event replay")
    return verdict
