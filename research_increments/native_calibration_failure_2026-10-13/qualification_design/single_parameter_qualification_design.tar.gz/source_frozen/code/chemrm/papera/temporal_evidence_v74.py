"""Interval evidence for operation timing. No policy access or simulator writes.

Bounds are conservatively closed, even when a sampled onset is (previous,current].
A timing pass requires the full error interval to fit the declared tolerance.
Host and native clocks cannot be subtracted without an explicit external calibration.
"""
from dataclasses import dataclass
import math


def number(x,nonnegative=False):
    if type(x) not in (int,float) or not math.isfinite(x) or nonnegative and x<0:
        raise ValueError('finite typed number required')
    return float(x)


@dataclass(frozen=True)
class Interval:
    lo: float
    hi: float
    clock_id: str
    kind: str
    calibrated: bool=False

    def __post_init__(self):
        lo,hi=number(self.lo,True),number(self.hi,True)
        if lo>hi or type(self.clock_id) is not str or not self.clock_id or type(self.kind) is not str or not self.kind or type(self.calibrated) is not bool:
            raise ValueError('ordered interval with explicit clock, event kind and calibration required')
        object.__setattr__(self,'lo',lo);object.__setattr__(self,'hi',hi)

    def to_dict(self):
        return dict(bounds_s=[self.lo,self.hi],clock_id=self.clock_id,kind=self.kind,
                    calibrated=self.calibrated,endpoint_semantics='CONSERVATIVE_CLOSED_BOUNDS')


def first_confirmed_rise(samples,threshold,confirm_count,max_gap_s,clock_id,kind,calibrated=False):
    threshold=number(threshold);gap=number(max_gap_s,True)
    if type(confirm_count) is not int or confirm_count<1 or gap<=0:raise ValueError('positive confirmation count and sampling-gap bound required')
    if not samples:raise ValueError('nonempty observed samples required')
    checked=[dict(t=number(r['t'],True),value=number(r['value'])) for r in samples]
    for a,b in zip(checked,checked[1:]):
        if not 0<b['t']-a['t']<=gap:raise ValueError('strictly ordered samples without unaccounted gaps required')
    candidate=None;run=0
    for index,row in enumerate(checked):
        if row['value']>=threshold:
            if run==0:candidate=index
            run+=1
            if run>=confirm_count:
                if candidate==0:return dict(status='LEFT_CENSORED',event=None,confirmation_time_s=row['t'])
                event=Interval(checked[candidate-1]['t'],checked[candidate]['t'],clock_id,kind,calibrated)
                return dict(status='DETECTED',event=event,confirmation_time_s=row['t'],
                    bracket_sample_indices=[candidate-1,candidate],confirmation_count=confirm_count,
                    continuous_dwell_established=False)
        else:run=0;candidate=None
    return dict(status='UNCONFIRMED' if run else 'NOT_OBSERVED',event=None,confirmation_time_s=None)


def same_clock(a,b):
    if not isinstance(a,Interval) or not isinstance(b,Interval) or a.clock_id!=b.clock_id:
        raise ValueError('two intervals on the same explicitly identified clock required')


def latency_interval(command,effect):
    same_clock(command,effect)
    return dict(bounds_s=[effect.lo-command.hi,effect.hi-command.lo],clock_id=effect.clock_id,
        scope='SIGNED_OBSERVED_EFFECT_MINUS_COMMAND; NOT_INFERENCE_OR_DETECTION_LATENCY')


def score_gap(a,b,requested_gap_s,tolerance_s,admission_checks=None):
    duration=number(requested_gap_s,True);tol=number(tolerance_s,True)
    if duration<=0:raise ValueError('strictly positive requested gap required')
    if a is None or b is None:return dict(verdict='UNAVAILABLE',error_interval_s=None,
        benchmark_eligible=False,reason='missing/censored effective-event evidence; no never-acted inference')
    same_clock(a,b)
    lo,hi=b.lo-a.hi-duration,b.hi-a.lo-duration
    verdict='PASS' if lo>=-tol and hi<=tol else 'EARLY' if hi<-tol else 'LATE' if lo>tol else 'INDETERMINATE'
    gates=admission_checks or {}
    admitted=a.calibrated and b.calibrated and all(gates.get(k) is True for k in ['physics','event_definitions','public_cue'])
    return dict(verdict=verdict,error_interval_s=[lo,hi],uncertainty_width_s=hi-lo,
        requested_gap_s=duration,tolerance_s=tol,clock_id=a.clock_id,
        benchmark_eligible=bool(admitted),timing_pass=verdict=='PASS',
        scientific_success=bool(admitted and verdict=='PASS'),
        scope='DIAGNOSTIC_INTERVAL_SCORE_UNLESS_ALL_ADMISSION_GATES_PASS')
