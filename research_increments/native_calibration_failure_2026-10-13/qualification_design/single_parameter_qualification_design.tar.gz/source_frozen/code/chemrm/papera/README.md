# Paper A F0 harness

The harness is the executable form of the Paper A measurement contract:

```text
TaskProgram -> ControlledWorld -> FrozenPolicy -> Trace -> ReadOnlyVerifier -> EvidenceBundle
```

`FrozenPolicy.act()` receives one public observation mapping. It has no handle to the world,
verifier, hidden state, or future events. A world owns the simulated clock and append-only
`EventBus`; the verifier replays those events through `EventBus.replay()`, which never invokes
world subscribers. Missing termination, policy exceptions, malformed actions, and missing
protocol events are recorded and fail closed.

The F0 core-family adapter in `core_f0.py` reuses the Gate 0 paired episode generator and
scripted move-and-pour skill. It is a contract test backend, not an Isaac or pixel result. A
minimal run looks like:

```python
from chemrm.papera import CoreFamilyVerifier, CoreFamilyWorld, make_core_task, run_episode

task = make_core_task("M0_relaxed", seed=19)
result = run_episode(
    task,
    CoreFamilyWorld("M0_relaxed"),
    policy,
    CoreFamilyVerifier(),
    seed=19,
    out_dir="pilot/paperA/f0/example",
)
```

Existing YAML tasks are converted with `load_benchmark_task(path)`. The adapter keeps the public
`TaskProgram` separate from the parsed temporal constraints, so a backend can sample hidden
episode parameters without copying them into the policy-visible task.

Three YAML tasks now have deterministic F0 controlled worlds in `task_worlds.py`: C5 endpoint
response, C6 timed stirring, and C13 delayed memory. Their reference policies receive only the
declared public observation (no simulated clock, step counter, event log, or verifier handle),
while the world-owned event log supplies the read-only verifier with timing ground truth. Run all
three and write one evidence bundle per task with:

```bash
python3 -m chemrm.papera.run_tasks --task all --out pilot/paperA/f0/yaml_cases_seed19 --seed 19
```

These are contract smoke cases for the measurement path. They are not learned-policy, pixel, or
Isaac results.

The C13 controlled world samples the instructed wait `D` from the YAML randomization range for
each seed, records that public instruction in the task program, and derives the verifier window
from the same declared `D`. A fixed sixty-step policy therefore fails when the seed asks for a
different wait. Freeze a public task registry before evaluation with:

```bash
python3 -m chemrm.papera.run_manifest \
  --registry pilot/paperA/f0/task_registry_seed19.json \
  --out /tmp/papera-task-manifest-demo \
  --manifest-id paper-a-f0-public-seed19
```

`manifest.json` hashes the sorted public `tasks.jsonl`, source YAMLs, split labels, and registered
novelty axes. The registry accepts no policy, verdict, or hidden-result input; `verify_task_manifest`
is read-only and does not start a world.

To create public graph fixtures with declared held-out/open novelty axes, provide a grammar:

```bash
python3 -m chemrm.papera.run_generate \
  --grammar pilot/paperA/task_grammar_v1.json \
  --split compositional-held-out \
  --novelty-axis composition --novelty-axis dependency \
  --count 4 --seed 19 \
  --out /tmp/papera-grammar-v1-demo \
  --manifest-id paper-a-compositional-seed19
```

The generated programs are public task-space fixtures. The generic goal-graph adapter in
`generated_world.py` provides contract smoke execution; its bundles validate goal ordering and
evidence integrity, and do not stand in for chemistry, vision, Isaac, or learned-policy results.
The v1 fixture labels do not certify disjoint primitive domains or chemically feasible programs;
those checks remain required before a generalization release.

Version 2 in `semantics.py` adds a finite protocol catalog with primitive preconditions/effects,
explicit split domains, registered novelty-axis families and semantic uniqueness. It audits the
entire closed catalog before judging held-out declarations, rejects unordered fact conflicts,
and refuses requests above the declared capacity. The public v2 fixture contains 24 tasks in its
complete space; the 12 seed-19 executions are in `pilot/paperA/semantic_v2/seed19/`.

Freeze and execute v2 from a new output location:

```bash
python3 -m chemrm.papera.run_generate --grammar pilot/paperA/task_grammar_v2.json \
  --split closed --count 4 --seed 19 --manifest-id papera-v2-closed-demo \
  --out /tmp/papera-v2-demo/closed/manifest
python3 -m chemrm.papera.run_generated --manifest /tmp/papera-v2-demo/closed/manifest \
  --backend graph-contract --out /tmp/papera-v2-demo/closed/execution
```

`load_task_manifest()` returns a verified byte snapshot with manifest/index hashes and its embedded
v2 grammar. Frozen execution preflights every row and backend before creating output; it never
regenerates tasks or accepts split/count/seed/axes overrides. `run.json` binds each bundle to its
canonical task hash. Task IDs never become filesystem paths. Manifests and batch output directories
must be new; existing directories cannot be overwritten. The legacy `--grammar` execution mode
supports only v1 graph smoke cases and reports no semantic gate.

The graph world applies declared facts at runtime and its event-only verifier independently
checks the bound operations, dependencies and fact transitions. These are protocol semantics;
declared environment/object differences do not yet imply physical or visual variation.
`backend_variation_validated=false` remains explicit. Ready-goal observations and the reference
policy do not establish memory or learned-policy generalization. The `thermal-dose` factory
accepts only its strict closed diagnostic; incompatible programs fail before any episode.

The first process-backed diagnostic in `thermal_dose.py` supports a strict addition-then-stop
program. It integrates the existing `ThermalModel`, samples volume, temperature and rate, and
reuses QDose/TRate behind an instrumentation and mass-balance guard. Smoke or any sampled thermal
threshold crossing permanently fails safety. Run a frozen synthetic task with:

```bash
python3 -m chemrm.papera.run_chemistry --seed 19 --rate 0.2 --out /tmp/papera-thermal/safe
python3 -m chemrm.papera.run_chemistry --task /tmp/papera-thermal/safe/task.json \
  --rate 10 --out /tmp/papera-thermal/high_rate
python3 -m chemrm.papera.replay_chemistry /tmp/papera-thermal/high_rate
```

Execution returns 1 for an unsuccessful episode while retaining its bundle; replay returns 0
when the independently recomputed verdict matches, including a correctly recorded failure.
Replay verifies hashes and reads events without constructing a world or policy. The three
seed-19 diagnostics are recorded in `pilot/paperA/chemistry/thermal_dose_seed19/`.

This backend exposes process sensors under `process-sensors-diagnostic`. These channels may
provide timing cues, so its closed diagnostic results do not establish Track A no-clock memory
claims or F1 release. It rejects arbitrary generated graphs and held-out/open labels. Its
synthetic parameters are uncalibrated and its thermal source uses the volume at each tick's
start; it provides neither pixels nor Isaac/robot geometry.

The F1 release gate combines the true-time schedule check with Gate 8 temporal aliasing and Gate 9
cue detectability:

```bash
python3 -m chemrm.papera.run_f1_release \
  --out pilot/paperA/f1/release_gate_seed19_tick_jitter.json \
  --seed 19 --episodes 24 --perturbation tick_jitter
```

Run it again with `--perturbation rate_error` for the second timing perturbation. A release report
passes only when the declared schedule, Track A no-clock probe, and cue/identity probe all pass;
the probes read frames and labels only and never alter the episode verdict.

For a deterministic F0 smoke run, use `python3 -m chemrm.papera.run_f0 --out <directory>`.
The included `DyeReferencePolicy` is a declared M0 relaxed reference; it is useful for checking
the evidence path and is not a learned-policy result.

An evidence bundle contains `task.json`, `observations.jsonl`, `actions.jsonl`, `events.jsonl`,
`verdict.json`, `artifacts.json`, and `manifest.json`. `verify_bundle(path)` checks the schema,
regular-file boundary, row JSON, byte sizes, and SHA-256 hashes without executing a policy or
world. The bundle reports the pass vector `{valid, goal, protocol, quantity, time, safety,
chem_ssr}` and a failure vector with the fail-closed reason for every rejected constraint.
