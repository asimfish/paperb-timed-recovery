"""One asynchronous, public-pixel actor decision; native clock keeps advancing."""
from pathlib import Path
from hashlib import sha256
import json
import math
import threading
import time
import shutil
from chemrm.papera.astra_boundary_v70 import public_observation
from chemrm.papera.codex_vision_v75 import invoke

TEXT=('C13-M0 development motor proxy, not calibrated chemistry. Five receiver indicators are ordered left-to-right 0 to4. '
      'A green light appears after motion A crosses30 degrees and stays visible. Observe its target and current timestamp. '
      'Schedule the repeat_transfer_motion on that receiver so the next30-degree crossing occurs30 seconds after the visible cue, tolerance0.25 seconds. '
      'The registered development motion has nominal launch-to30degree latency2.675 native seconds; this is a motor estimate, not chemical calibration. '
      'This first fixture only has a registered motion to receiver2; do not improvise another path. Return a future start_s for that skill. '
      'The skill reuses the existing donor, so there is no verified independent reagentB or dose. Use public timestamps only.')

def checked_schedule(proposal,observation,origin,now):
    expected={'observation_sha256','decision','selected_slot','observed_cue_s','start_s'}
    if type(proposal) is not dict or set(proposal)!=expected or proposal['observation_sha256']!=observation['sha256']:
        raise ValueError('exact proposal bound to current observation required')
    if proposal['decision']!='schedule_repeat':raise ValueError('actor did not schedule the first-task motion')
    if type(proposal['selected_slot']) is not int or proposal['selected_slot']!=2:raise ValueError('unregistered receiver motion rejected')
    cue,start=proposal['observed_cue_s'],proposal['start_s']
    if any(type(v) not in (int,float) or not math.isfinite(v) for v in [cue,start]):raise ValueError('finite typed actor timing required')
    if abs(cue-observation['actor']['timestamp_s'])>1e-6 or not origin+7<start<=origin+30.25 or start<=now:
        raise ValueError('public cue timestamp/future bounded execution required')
    tick=math.ceil((start-origin)*60)+1
    return dict(start_tick=tick,requested_start_s=start,observed_cue_s=cue,selected_slot=2,
        actual_dispatch_start_s=None,rounding='NEXT_OUTER_TICK_COMMAND_BOUNDARY',physical_chemical_B_verified=False)

class FirstTaskActor:
    def __init__(self,out,origin,provider=invoke,provider_directory=None):
        self.out=Path(out);self.origin=origin;self.provider=provider
        self.provider_directory=Path(provider_directory) if provider_directory else self.out.parent/'live_actor_r1'
        self.thread=None;self.result=None;self.error=None;self.observation=None
        self.schedule=None;self.requested=False;self.accepted=False;self.request_tick=None
    def start(self,row,image,joints):
        if self.requested:raise ValueError('one-request budget; no blind retry')
        self.requested=True;self.request_tick=row['tick']
        self.observation=public_observation(track='B',instruction=dict(text=TEXT,duration_s=30.,tolerance_s=.25),
            joints_q=joints,images=[dict(view='station',sha256=sha256(Path(image).read_bytes()).hexdigest())],current_clock_s=row['physics_time_s'])
        self.started_host_ns=time.monotonic_ns()
        self._persist('actor_request_binding.json',dict(observation=self.observation,
            private_binding=dict(capture_seq=row['seq'],capture_tick=row['tick'],image_sha256=sha256(Path(image).read_bytes()).hexdigest()),
            policy_fields='PUBLIC_ACTOR_PACKET_ONLY',request_limit=1,token_limit=16384,transport_mode='LIVE_CODEX'))
        def worker():
            try:self.result=self.provider(self.provider_directory,self.observation,image)
            except BaseException as e:self.error=type(e).__name__
        self.thread=threading.Thread(target=worker,name='papera_public_pixel_actor',daemon=True);self.thread.start()
    def poll(self,tick,now):
        if not self.requested or self.accepted:return
        if self.error:
            self._copy_provider()
            self._persist('actor_failure.json',dict(error_class=self.error,request_tick=self.request_tick,
                observed_completion_tick=tick,native_time_s=now,retry=False,billing_state='UNRESOLVED'))
            raise RuntimeError('ACTOR_PROVIDER_FAILED_NO_RETRY')
        if self.result is None:return
        self._copy_provider()
        self._persist('actor_response_observed.json',dict(result=self.result,received_at_native_s=now,
            received_at_tick=tick,request_tick=self.request_tick,simulation_paused_for_inference=False))
        try:self.schedule=checked_schedule(self.result['proposal'],self.observation,self.origin,now)
        except ValueError as e:
            self._persist('actor_proposal_rejected.json',dict(reason=str(e),tick=tick,native_time_s=now))
            raise RuntimeError('ACTOR_PROPOSAL_REJECTED') from None
        self.accepted=True;self._persist('actor_schedule.json',self.schedule)
    def record_dispatch(self,tick,now):
        if not self.accepted or tick!=self.schedule['start_tick']:raise ValueError('only accepted actor schedule may start repeat motion')
        self.schedule['actual_dispatch_start_s']=now
        self._persist('actor_causal_dispatch.json',dict(tick=tick,native_time_s=now,schedule=dict(self.schedule),
            observation_sha256=self.observation['sha256'],scripted_fallback=False))
    def finish(self):
        if self.thread and self.thread.is_alive():self.thread.join(timeout=95)
        self._copy_provider()
        self._persist('actor_final_receipt.json',dict(requests=int(self.requested),
            provider_responses=int(self.result is not None),accepted_schedule=self.accepted,schedule=self.schedule,
            actual_repeat_dispatch_observed=(self.out/'actor_causal_dispatch.json').exists(),
            scientific_admission=False,training_admitted=False,chemical_AB_executed=False,
            simulation_paused_for_inference=False,provider_thread_alive=bool(self.thread and self.thread.is_alive())))
    def _copy_provider(self):
        target=self.out/'actor_requests/0000'
        if self.provider_directory.exists() and not target.exists():
            if self.thread and self.thread.is_alive():return
            shutil.copytree(self.provider_directory,target)
    def _persist(self,name,data):
        with (self.out/name).open('x') as f:json.dump(data,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
