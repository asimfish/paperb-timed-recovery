"""Durable stage evidence, without claiming restartable physical simulation.

One writer owns an episode. A stage becomes visible only after its commit
marker is fsynced. Later appends may extend streams but cannot change sealed
byte ranges. A crashed writer's uncommitted tail remains available for audit;
continuing a crashed GPU world is deliberately outside this storage contract.
"""
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import time


def digest(path, offset=0, size=None):
    h = sha256()
    with Path(path).open('rb') as file:
        file.seek(offset)
        remaining = size
        while remaining is None or remaining > 0:
            data = file.read(1024 * 1024 if remaining is None else min(remaining, 1024 * 1024))
            if not data:
                if remaining:
                    raise ValueError('sealed range was truncated')
                break
            h.update(data)
            if remaining is not None:
                remaining -= len(data)
    return h.hexdigest()


def sync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_once(path, value):
    with Path(path).open('x') as file:
        json.dump(value, file, sort_keys=True, indent=2, allow_nan=False)
        file.write('\n')
        file.flush()
        os.fsync(file.fileno())
    sync_directory(Path(path).parent)


def validate_plan(plan):
    if not plan:
        raise ValueError('nonempty ordered stage plan required')
    prior_end = 0
    names = set()
    for stage in plan:
        name = stage['id']
        if not name or not name.replace('_', '').isalnum() or name in names:
            raise ValueError('unique simple stage id required')
        if type(stage['start_tick']) is not int or type(stage['end_tick']) is not int:
            raise ValueError('typed integer tick boundaries required')
        if stage['start_tick'] != prior_end or stage['end_tick'] <= prior_end:
            raise ValueError('contiguous positive-duration stage plan required')
        names.add(name)
        prior_end = stage['end_tick']


def safe_payload(root, relative):
    path = Path(relative)
    if path.is_absolute() or '..' in path.parts or not path.parts or path.parts[0] == 'stages':
        raise ValueError('episode-relative payload outside journal required')
    target = root / path
    if not target.is_file() or target.resolve() != target.absolute():
        raise ValueError('regular non-symlink owned payload required')
    return target


class StageJournal:
    def __init__(self, root, episode_id, plan, origin_s, provenance):
        validate_plan(plan)
        if type(origin_s) is not float or not math.isfinite(origin_s) or origin_s < 0:
            raise ValueError('finite actual episode clock origin required')
        self.root = Path(root).resolve()
        self.directory = self.root / 'stages'
        self.directory.mkdir(exist_ok=False)
        sync_directory(self.root)
        self.header = dict(schema='chemrm-stage-evidence-v1', episode_id=episode_id,
            plan=plan, origin_s=origin_s, provenance=provenance,
            simulation_restart_supported=False, training_admitted=False)
        write_once(self.directory / 'episode.json', self.header)
        self.plan = plan
        self.committed = []
        self.sizes = {}

    def commit(self, stage_id, actual_end_s, boundary_reader):
        index = len(self.committed)
        if index >= len(self.plan) or self.plan[index]['id'] != stage_id:
            raise ValueError('next declared stage only; duplicates and skips forbidden')
        stage = self.plan[index]
        actual_start = self.committed[-1]['actual_end_s'] if self.committed else self.header['origin_s']
        if type(actual_end_s) is not float or not math.isfinite(actual_end_s) or actual_end_s <= actual_start:
            raise ValueError('strictly advancing actual stage clock required')
        target = self.directory / stage_id
        target.mkdir(exist_ok=False)
        before = boundary_reader()
        if before['physics_time_s'] != actual_end_s:
            raise ValueError('boundary and stage clocks disagree')
        host_start = time.monotonic_ns()
        payloads = []
        sizes = dict(self.sizes)
        for path in sorted(self.root.rglob('*')):
            if not path.is_file() or path.is_relative_to(self.directory):
                continue
            relative = str(path.relative_to(self.root))
            safe_payload(self.root, relative)
            size = path.stat().st_size
            offset = self.sizes.get(relative, 0)
            if size < offset:
                raise ValueError('prior sealed file cannot shrink')
            if relative in self.sizes and size > offset and path.suffix != '.jsonl':
                raise ValueError('only declared JSONL streams may grow')
            if size > offset or relative not in self.sizes:
                with path.open('rb') as file:
                    os.fsync(file.fileno())
                payloads.append(dict(path=relative, offset=offset, size=size-offset,
                    sha256=digest(path, offset, size-offset)))
            sizes[relative] = size
        # Reads and persistence are passive at the same actual native boundary.
        after = boundary_reader()
        if before != after:
            raise ValueError('stage persistence changed physical clock or observed state')
        record = dict(schema='chemrm-stage-evidence-v1', episode_id=self.header['episode_id'],
            index=index, stage_id=stage_id, start_tick=stage['start_tick'], end_tick=stage['end_tick'],
            actual_start_s=actual_start, actual_end_s=actual_end_s,
            previous_manifest_sha256=digest(self.directory/self.plan[index-1]['id']/'manifest.json') if index else None,
            header_sha256=digest(self.directory/'episode.json'), payloads=payloads,
            boundary_before=before, boundary_after=after,
            host_persistence_seconds=(time.monotonic_ns()-host_start)/1e9,
            clock_paused_during_synchronous_persistence=True,
            storage_status='SEALED_DEVELOPMENT_EVIDENCE', training_admitted=False,
            physical_simulation_restart_supported=False)
        write_once(target / 'manifest.json', record)
        write_once(target / 'COMMITTED.json', dict(manifest_sha256=digest(target/'manifest.json')))
        sync_directory(self.directory)
        self.committed.append(record)
        self.sizes = sizes
        return record


def verify_prefix(root, require_all=False):
    """Read-only recovery inspection. Does not resume or repair a simulator."""
    root = Path(root).resolve()
    directory = root / 'stages'
    header = json.loads((directory/'episode.json').read_text())
    validate_plan(header['plan'])
    records = []
    prior_hash = None
    prior_end = header['origin_s']
    sizes = {}
    unfinished = []
    for index, stage in enumerate(header['plan']):
        target = directory / stage['id']
        if not (target/'COMMITTED.json').exists():
            if target.exists():
                unfinished.append(stage['id'])
            if any((directory/later['id']/'COMMITTED.json').exists() for later in header['plan'][index+1:]):
                raise ValueError('committed stage after uncommitted gap')
            break
        marker = json.loads((target/'COMMITTED.json').read_text())
        current_hash = digest(target/'manifest.json')
        if marker != dict(manifest_sha256=current_hash):
            raise ValueError('commit marker/hash mismatch')
        record = json.loads((target/'manifest.json').read_text())
        if (record['index'],record['stage_id'],record['episode_id'],record['start_tick'],record['end_tick']) != (
                index,stage['id'],header['episode_id'],stage['start_tick'],stage['end_tick']):
            raise ValueError('manifest belongs to another stage or episode')
        if record['previous_manifest_sha256'] != prior_hash or record['header_sha256'] != digest(directory/'episode.json'):
            raise ValueError('stage chain or episode header mismatch')
        if record['actual_start_s'] != prior_end or record['actual_end_s'] <= prior_end:
            raise ValueError('stage clock reset, gap or reversal')
        if record['boundary_before'] != record['boundary_after'] or record['boundary_after']['physics_time_s'] != record['actual_end_s']:
            raise ValueError('passive persistence boundary mismatch')
        if record['training_admitted'] or record['physical_simulation_restart_supported']:
            raise ValueError('storage evidence cannot silently grant scientific/restart admission')
        seen = set()
        for entry in record['payloads']:
            if entry['path'] in seen or entry['offset'] != sizes.get(entry['path'],0) or entry['size'] < 0:
                raise ValueError('duplicate or noncontiguous sealed byte range')
            seen.add(entry['path'])
            path = safe_payload(root,entry['path'])
            if digest(path,entry['offset'],entry['size']) != entry['sha256']:
                raise ValueError('sealed payload changed')
            sizes[entry['path']] = entry['offset']+entry['size']
        records.append(record)
        prior_hash = current_hash
        prior_end = record['actual_end_s']
    if require_all and len(records) != len(header['plan']):
        raise ValueError('full stage plan not committed')
    return dict(status='PASS_SEALED_PREFIX_INTEGRITY', committed_stages=len(records),
        planned_stages=len(header['plan']), records=records, unfinished_stage_directories=unfinished,
        actual_end_s=prior_end, whole_episode_complete=len(records)==len(header['plan']),
        physical_simulation_restart_supported=False, training_admitted=False)
