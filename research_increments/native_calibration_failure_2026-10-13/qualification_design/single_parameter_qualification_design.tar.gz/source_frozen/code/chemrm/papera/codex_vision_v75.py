"""Bounded vision-only Astra transport through the current authorized login.

No credentials are copied or serialized. No retry after an uncertain request.
The selected CLI model is recorded; raw backend model identity is not exposed.
"""
from pathlib import Path
import json
import os
import shutil
import subprocess
import time

MODEL='gpt-6-astra'
DISABLED=['shell_tool','code_mode_host','apps','plugins','multi_agent','view_image',
    'browser_use','computer_use','goals','in_app_browser','image_generation',
    'workspace_dependencies','skill_search','sleep_tool','auth_elicitation','hooks','memories']
SCHEMA=dict(type='object',properties=dict(
    observation_sha256=dict(type='string'),
    decision=dict(type='string',enum=['wait','schedule_repeat','abort']),
    selected_slot=dict(anyOf=[dict(type='integer',minimum=0,maximum=4),dict(type='null')]),
    observed_cue_s=dict(anyOf=[dict(type='number',minimum=0),dict(type='null')]),
    start_s=dict(anyOf=[dict(type='number',minimum=0),dict(type='null')])),
    required=['observation_sha256','decision','selected_slot','observed_cue_s','start_s'],additionalProperties=False)

def invoke(directory,observation,image,*,timeout_s=90):
    directory=Path(directory);directory.mkdir(exist_ok=False,parents=True)
    shutil.copy2(image,directory/'observation.png')
    (directory/'observation.json').write_text(json.dumps(observation,indent=2)+'\n')
    (directory/'schema.json').write_text(json.dumps(SCHEMA,indent=2)+'\n')
    prompt='You are a laboratory task actor. Use ONLY the attached image and this public observation. No tools, files, shell, web, retrieval, or external memory. Return only the schema JSON, bind its observation_sha256 to the supplied hash. Do not claim chemical success. If a green light is visible, identify its receiver index, remember the current public timestamp as observed_cue_s, and schedule the registered repeat motion so its 30-degree crossing occurs at the instructed delay after the visible cue. If none is visible, choose wait.\n'+json.dumps(observation)
    (directory/'prompt.txt').write_text(prompt)
    command=['codex','exec','--ignore-user-config','--ignore-rules','--ephemeral',
        '--skip-git-repo-check','--model',MODEL,'--sandbox','read-only']
    for feature in DISABLED:command+=['--disable',feature]
    command+=['-c','web_search="disabled"','-c','approval_policy="never"',
        '-c','model_reasoning_effort="low"','-c','features.skip_host_skill_discovery=true',
        '--json','--image','observation.png','--output-schema','schema.json',
        '--output-last-message','answer.json','-']
    (directory/'command.json').write_text(json.dumps(command,indent=2)+'\n')
    env=dict(os.environ)
    for key in ['LD_LIBRARY_PATH','LD_PRELOAD']:env.pop(key,None)
    before=time.monotonic_ns()
    with (directory/'events.jsonl').open('xb') as output,(directory/'stderr.log').open('xb') as errors:
        child=subprocess.Popen(command,cwd=directory,env=env,stdin=subprocess.PIPE,stdout=output,stderr=errors,start_new_session=True)
        try:child.communicate(prompt.encode(),timeout=timeout_s)
        except subprocess.TimeoutExpired:
            import signal
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=3)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
            raise TimeoutError('provider request state/billing unresolved; do not retry') from None
    elapsed=(time.monotonic_ns()-before)/1e9
    if child.returncode:raise RuntimeError('provider exited unsuccessfully; do not retry')
    events=[json.loads(line) for line in (directory/'events.jsonl').read_text().splitlines()]
    tools=[e for e in events if e.get('item',{}).get('type') not in [None,'agent_message','error','reasoning']]
    completed=[e for e in events if e.get('type')=='turn.completed']
    if tools or len(completed)!=1:raise ValueError('actor tool use or unconfirmed completion rejected')
    usage=completed[0]['usage'];tokens=usage['input_tokens']+usage['output_tokens']
    if type(tokens) is not int or not 0<=tokens<=16384:raise ValueError('actual16384-token request ceiling exceeded')
    answer=json.loads((directory/'answer.json').read_text())
    return dict(proposal=answer,usage=usage,known_billed_tokens=tokens,host_elapsed_s=elapsed,
        requested_model=MODEL,backend_model_id=None,model_identity_scope='EXPLICIT_CLI_MODEL_SELECTION_BACKEND_ID_NOT_EXPOSED',
        transport='LIVE_AUTHORIZED_CODEX_VISION',tool_calls=0,provider_response_observed=True)
