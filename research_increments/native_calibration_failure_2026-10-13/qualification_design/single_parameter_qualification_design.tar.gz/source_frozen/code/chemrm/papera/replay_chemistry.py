"""Independently recompute and compare a thermal diagnostic bundle's verdict."""

import argparse
import json

from chemrm.papera.thermal_dose import replay_thermal_dose_bundle


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bundle")
    args = parser.parse_args(argv)
    try:
        verdict = replay_thermal_dose_bundle(args.bundle)
    except (ValueError, KeyError, TypeError, OSError) as exc:
        print(json.dumps({"replay_matches": False, "error": str(exc)}, ensure_ascii=False))
        return 1
    print(json.dumps({"replay_matches": True, **verdict.to_dict()}, ensure_ascii=False, sort_keys=True, indent=2))
    # A valid negative episode is a successful replay verification.
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
