"""Exploratory renderer-history intervention after V16's clock gate failure.

Uses one previously seen development scene; no model fitting and no release claim.
The sealed provider is imported unchanged. Paused renders hold physics/event time.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import traceback

from chemrm.papera.native_leakage import dump, RidgeProbe, sensor_features
from chemrm.papera.isaac_bridge_contract import Case
from chemrm.papera.isaac_bridge_verify import sha256


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bank', type=Path, required=True)
    parser.add_argument('--models', type=Path, required=True)
    parser.add_argument('--asset', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    bank = json.loads(args.bank.read_text())
    row = next(r for r in bank['cases'] if r['split'] == 'train' and r['case']['target'] == 0)
    case = Case(**row['case'])
    args.out.mkdir(parents=True, exist_ok=False)
    model_path = args.models/'post_clock_rgb.npz'
    model = RidgeProbe.load(model_path)
    sys.argv = [sys.argv[0]]
    from isaacsim import SimulationApp
    app = SimulationApp({'headless': True, 'active_gpu': 0, 'physics_gpu': 0,
                         'multi_gpu': False, 'width': 320, 'height': 320,
                         'renderer': 'RayTracedLighting'})
    try:
        import numpy as np
        from PIL import Image
        from chemrm.papera.isaac_bridge_native import IsaacBridge
        backend = IsaacBridge(str(args.asset))
        records = []
        for condition in ['cue_rendered', 'cue_not_rendered']:
            backend.reset(case)
            folder = args.out/condition
            folder.mkdir()
            queries = [('before', case.onset_s-1.)]
            if condition == 'cue_rendered':
                queries += [('cue', case.onset_s+1.)]
            queries += [(f'age_{int(age)}', case.onset_s+age) for age in bank['ages_s']]
            queries += [('fixed_time', 110.)]
            sampled = []
            for phase, t in queries:
                backend.advance(max(0., t-backend.now))
                snap = backend.capture()
                Image.fromarray(snap.rgb).save(folder/(phase+'.png'))
                features = sensor_features(snap.rgb, snap.joints, 'rgb')
                sampled.append({'phase': phase, 'time': snap.captured_at,
                     'mean_rgb': snap.rgb.mean(axis=(0,1)).tolist(),
                     'probe_predicted_age': float(model.predict(features[None, :])[0])})
            frozen_t = backend.now
            frozen_joints = backend.robot.get_joint_positions().copy()
            frozen_events = json.dumps(backend.events, sort_keys=True)
            checkpoints = [0, 1, 2, 4, 8, 16, 32, 64]
            paused = []
            for i in range(65):
                if i:
                    backend.world.render()
                if i not in checkpoints:
                    continue
                rgb = np.asarray(backend.camera.get_rgba())[:, :, :3].copy()
                joints = backend.robot.get_joint_positions().copy()
                assert backend.now == frozen_t
                assert np.array_equal(joints, frozen_joints)
                assert json.dumps(backend.events, sort_keys=True) == frozen_events
                Image.fromarray(rgb).save(folder/f'paused_{i}.png')
                feature = sensor_features(rgb, joints, 'rgb')
                paused.append({'extra_render_calls': i, 'physical_time': backend.now,
                     'mean_rgb': rgb.mean(axis=(0,1)).tolist(),
                     'probe_predicted_age': float(model.predict(feature[None, :])[0]),
                     'joints_unchanged': True, 'events_unchanged': True})
            records.append({'condition': condition, 'sampled': sampled, 'paused': paused,
                            'native_events': backend.events})
        dump(args.out/'receipt.json', {'status': 'COMPLETE_EXPLORATORY_INTERVENTION',
             'purpose': 'identify renderer-history dependence, not a repaired release gate',
             'case': row, 'source_sha256': sha256(Path(__file__)),
             'unchanged_provider_sha256': sha256(Path(__file__).parent/'isaac_bridge_native.py'),
             'frozen_probe_sha256': sha256(model_path), 'conditions': records,
             'not_proved': 'specific renderer subsystem; all-scene repair; new prospective holdout'})
        print('CLOCK_INTERVENTION_COMPLETE', flush=True)
    except Exception:
        traceback.print_exc()
        dump(args.out/'error.json', {'traceback': traceback.format_exc()})
        sys.stdout.flush()
        sys.stderr.flush()
    finally:
        app.close()


if __name__ == '__main__':
    main()
