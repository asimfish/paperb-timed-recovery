"""Paper A F0 runner and read-only constraint verifier."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Protocol, Sequence

from chemrm.constraints import Violation, check_constraints
from chemrm.events import Event, EventBus
from chemrm.quality import assemble_pass_vector
from chemrm.papera.contract import (
    ActionRecord,
    EpisodeVerdict,
    EvidenceBundle,
    ObservationRecord,
    Trace,
)
from chemrm.task_program import GoalStep, TaskProgram


@dataclass(frozen=True)
class WorldStep:
    observation: Mapping[str, Any]
    done: bool = False
    stop_reason: str = ""


class ControlledWorld(Protocol):
    """World boundary exposed to the runner; hidden state stays behind this protocol."""

    clock: Any
    event_bus: EventBus

    def reset(self, task: TaskProgram, seed: int) -> Mapping[str, Any]: ...

    def step(self, action: Mapping[str, Any]) -> WorldStep: ...


class FrozenPolicy(Protocol):
    policy_id: str
    policy_hash: str

    def reset(self, task: TaskProgram, seed: int) -> None: ...

    def act(self, observation: Mapping[str, Any]) -> Mapping[str, Any]: ...


class ReadOnlyVerifier(Protocol):
    verifier_id: str

    def verify(self, task: TaskProgram, trace: Trace) -> EpisodeVerdict: ...


@dataclass(frozen=True)
class RunResult:
    trace: Trace
    verdict: EpisodeVerdict
    bundle_dir: str | None = None


def _events(world: ControlledWorld) -> tuple[Event, ...]:
    log = tuple(world.event_bus.log)
    if any(b.t < a.t for a, b in zip(log, log[1:])):
        raise ValueError("world event log must be chronological")
    return log


def run_episode(task: TaskProgram, world: ControlledWorld, policy: FrozenPolicy,
                verifier: ReadOnlyVerifier, seed: int, max_steps: int = 1000,
                out_dir: str | None = None) -> RunResult:
    """Run one frozen policy and produce an auditable result.

    The policy receives only the current observation.  It never receives the world, verifier,
    hidden task state, or future events.  Any boundary error is recorded and handed to the
    verifier as an invalid trace so malformed runs cannot become clean successes.
    """
    if max_steps <= 0:
        raise ValueError("max_steps must be positive")
    policy_id = str(getattr(policy, "policy_id", ""))
    policy_hash = str(getattr(policy, "policy_hash", ""))
    verifier_id = str(getattr(verifier, "verifier_id", ""))
    if not policy_id or not policy_hash or not verifier_id:
        raise ValueError("policy_id, policy_hash and verifier_id are required")

    observations: list[ObservationRecord] = []
    actions: list[ActionRecord] = []
    completed = False
    stop_reason = ""
    error: str | None = None
    try:
        policy.reset(task, seed)
        observation = world.reset(task, seed)
        for step in range(max_steps):
            now = float(world.clock.now)
            if not isinstance(observation, Mapping):
                raise TypeError("world observation must be a mapping")
            observations.append(ObservationRecord(step, now, dict(observation)))
            action = policy.act(dict(observation))
            if not isinstance(action, Mapping):
                raise TypeError("policy action must be a mapping")
            actions.append(ActionRecord(step, now, dict(action)))
            update = world.step(dict(action))
            if not isinstance(update, WorldStep):
                raise TypeError("world.step must return WorldStep")
            observation = update.observation
            if update.done:
                completed = True
                stop_reason = update.stop_reason or "world_done"
                break
        if not completed:
            stop_reason = "step_limit"
    except Exception as exc:  # recorded as evidence; the verifier remains fail-closed
        error = f"{type(exc).__name__}: {exc}"
        if len(observations) > len(actions):
            row = observations[-1]
            actions.append(ActionRecord(row.step, row.t, {"kind": "invalid", "error": error}))
        stop_reason = "runner_error"
    end_time = float(world.clock.now)
    trace = Trace(task=task, seed=int(seed), policy_id=policy_id, policy_hash=policy_hash,
                  verifier_id=verifier_id, observations=tuple(observations), actions=tuple(actions),
                  events=_events(world), end_time=end_time, completed=completed,
                  stop_reason=stop_reason, error=error)
    verdict = verifier.verify(task, trace)
    bundle_dir = None
    if out_dir is not None:
        bundle_dir = str(EvidenceBundle.write(out_dir, trace, verdict))
    return RunResult(trace, verdict, bundle_dir)


class ReadOnlyConstraintVerifier:
    """Verifier for event-backed task programs using the existing fail-closed checkers."""

    verifier_id = "paper-a-constraint-verifier-f0.1"

    def __init__(self, constraints: Sequence[Any] = (), goal_steps: Sequence[GoalStep] | None = None):
        self.constraints = tuple(constraints)
        self.goal_steps = tuple(goal_steps or ())

    @staticmethod
    def _goal_reached(bus: EventBus, goals: Sequence[GoalStep]) -> bool:
        by_id: dict[str, Event] = {}
        remaining = {goal.id: goal for goal in goals}
        # Resolve dependency order without trusting the order in a serialized task file.
        while remaining:
            progressed = False
            for goal_id, goal in tuple(remaining.items()):
                if any(dep not in by_id for dep in goal.requires):
                    continue
                after = max((by_id[dep].t for dep in goal.requires), default=-float("inf"))
                match = next((ev for ev in bus.all(goal.action, **dict(goal.parameters)) if ev.t >= after), None)
                if match is None:
                    return False
                by_id[goal_id] = match
                del remaining[goal_id]
                progressed = True
            if not progressed:
                return False
        return True

    def verify(self, task: TaskProgram, trace: Trace) -> EpisodeVerdict:
        trace.validate()
        if trace.task.canonical_json() != task.canonical_json():
            raise ValueError("trace task differs from verifier task")
        bus = EventBus.replay(list(trace.events))
        violations: list[Violation] = []
        if trace.error:
            violations.append(Violation("runner", "instrumentation_invalid", trace.error, trace.end_time))
        if not trace.completed:
            violations.append(Violation("runner", "incomplete", trace.stop_reason or "episode did not terminate",
                                         trace.end_time))
        goals = self.goal_steps or task.goals
        goal_reached = self._goal_reached(bus, goals)
        violations.extend(check_constraints(list(self.constraints), bus, trace.end_time))
        pass_vector = assemble_pass_vector(goal_reached, violations)
        failures = tuple({"constraint": v.constraint, "kind": v.kind, "detail": v.detail, "t": v.t}
                         for v in violations)
        metrics = {
            "goal_reached": bool(goal_reached),
            "n_steps": len(trace.actions),
            "end_time_s": float(trace.end_time),
            "n_events": len(trace.events),
        }
        return EpisodeVerdict(self.verifier_id, {
            "valid": pass_vector.valid,
            "goal": pass_vector.goal,
            "protocol": pass_vector.protocol,
            "quantity": pass_vector.quantity,
            "time": pass_vector.time,
            "safety": pass_vector.safety,
            "chem_ssr": pass_vector.chem_ssr,
        }, failures, metrics)
