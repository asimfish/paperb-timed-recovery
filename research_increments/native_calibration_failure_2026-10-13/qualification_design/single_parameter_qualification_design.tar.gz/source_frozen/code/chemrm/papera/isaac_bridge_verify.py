"""Policy-free, renderer-free reconstruction of native pilot verdicts."""
from __future__ import annotations
import hashlib
import json
import math
import re
from pathlib import Path
from chemrm.papera.isaac_bridge_contract import Action, Case, SCHEMA, TRACKS


def _norm(a,b):
    if not isinstance(a,list) or not isinstance(b,list) or len(a)!=3 or len(b)!=3 or not all(isinstance(x,(int,float)) and math.isfinite(x) for x in [*a,*b]):
        return math.inf
    return math.sqrt(sum((x-y)**2 for x,y in zip(a,b)))


def verify_episode(case: Case, events: list[dict], error: str | None = None) -> dict:
    result = {'schema':SCHEMA, 'valid':False, 'identity':True, 'release':True,
              'timing':False, 'execution':True, 'audit':True, 'error':error}
    times = [e.get('t',float('nan')) for e in events]
    if any(not isinstance(t,(int,float)) or not math.isfinite(t) or t<0 for t in times) or any(b<a for a,b in zip(times,times[1:])):
        result.update(audit=False, error='invalid event chronology'); return result
    commands = [e for e in events if e['kind']=='command']
    for e in commands:
        if not math.isfinite(e.get('capture_t',float('nan'))) or abs(e['t']-e['capture_t']-case.latency_s)>1/60+1e-6:
            result['audit']=False
    def first(kind):
        return next((e for e in events if e['kind']==kind),None)
    if case.family=='C13':
        a,b,release = first('add_A'),first('add_B'),first('cue_end')
        cmd = next((e for e in commands if e.get('kind_action')=='add_B'),None)
        arrival=first('tool_arrival')
        result['identity']=bool(a and b and cmd and a.get('slot')==b.get('slot')==cmd.get('slot')==case.target)
        result['release']=bool(cmd and release and cmd['capture_t']>=release['t'])
        # Binding first action: later success cannot repair an early/wrong command.
        if cmd and b:
            result['identity'] &= cmd.get('action_seq')==b.get('action_seq')
        expected=case.tool_target(cmd['slot']) if cmd and type(cmd.get('slot')) is int and 0<=cmd['slot']<5 else None
        result['execution']=bool(arrival and expected and b and
            _norm(arrival.get('target_xyz',[]),expected)<1e-4 and
            _norm(arrival.get('actual_xyz',[]),expected)<=.015 and
            arrival.get('slot')==cmd.get('slot') and abs(arrival['t']-b['t'])<1e-6 and
            arrival.get('action_seq')==cmd.get('action_seq') and b['t']>=cmd['t'])
        if a and b:
            result['gap_s']=b['t']-a['t']
            result['timing']=abs(result['gap_s']-case.wait_s)<=case.eta*case.wait_s+1e-6
    elif case.family=='C5':
        endpoint,stop=first('color_change'),first('add_stop')
        if endpoint and stop:
            result['response_s']=stop['t']-endpoint['t']
            result['timing']=0<=result['response_s']<=2.+1e-6
            result['added_ml']=stop['added_ml']
        result['execution']=bool(stop and any(e.get('kind_action')=='add_stop' for e in commands))
    else:
        start,stop=first('stir_start'),first('stir_stop')
        if start and stop:
            result['duration_s']=stop['t']-start['t']
            result['timing']=abs(result['duration_s']-120.)<=10.+1e-6
        result['execution']=bool(start and stop and any(e.get('kind_action')=='stir_start' for e in commands))
    result['valid']=not error and all(result[k] for k in ('audit','identity','release','timing','execution'))
    return result


def sha256(path: Path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()


def check_bundle(root: str | Path) -> dict:
    root=Path(root).resolve()
    if (root/'manifest.json').is_symlink(): raise ValueError('unsafe manifest path')
    manifest=json.loads((root/'manifest.json').read_text())
    required={'task.json','observations.jsonl','actions.jsonl','events.jsonl','verdict.json','artifacts.json'}
    files=manifest['files']
    if not required<=set(files): raise ValueError('missing episode evidence')
    if len(files)>1006: raise ValueError('episode file limit exceeded')
    if any(name not in required and not re.fullmatch(r'rgb/[0-9]{4}\.png',name) for name in files):
        raise ValueError('unsafe/unknown evidence path')
    if any(not isinstance(d,str) or not re.fullmatch(r'[0-9a-f]{64}',d) for d in files.values()):
        raise ValueError('invalid file digest')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='manifest.json'}
    if actual!=set(files): raise ValueError('manifest does not cover exact file set')
    for name,digest in files.items():
        path=root/name
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise ValueError('unsafe evidence path')
        if path.stat().st_size>10*1024*1024: raise ValueError('episode file too large')
        if sha256(path)!=digest: raise ValueError(f'hash mismatch: {name}')
    case=Case(**json.loads((root/'task.json').read_text()))
    events=[json.loads(line) for line in (root/'events.jsonl').read_text().splitlines()]
    stored=json.loads((root/'verdict.json').read_text())
    replay=verify_episode(case,events,manifest.get('error'))
    if replay!=stored: raise ValueError('verdict replay mismatch')
    observations=[json.loads(line) for line in (root/'observations.jsonl').read_text().splitlines()]
    actions=[json.loads(line) for line in (root/'actions.jsonl').read_text().splitlines()]
    if len(observations)!=len(actions): raise ValueError('unpaired actor trace')
    for i,(obs,action) in enumerate(zip(observations,actions)):
        if obs['step']!=i or action['step']!=i or obs['capture_t']!=action['capture_t']:
            raise ValueError('trace order mismatch')
        age=obs['capture_t']-obs['sensor_render_t']
        if not math.isfinite(age) or not -1e-5<=age<=1/60+1e-5:
            raise ValueError('stale camera evidence')
        name=obs['rgb_file']
        if name not in files or files[name]!=obs['rgb_sha256']: raise ValueError('unbound RGB frame')
        track=TRACKS[manifest['policy']]
        expected={'rgb','joints','instruction'} | ({'timestamp_s'} if track in {'B','C'} else set()) | ({'latency_budget_s'} if track=='C' else set())
        if manifest['track']!=track or set(obs['actor_fields'])!=expected or obs['public_instruction']!=dict(case.instruction()):
            raise ValueError('actor resource contract mismatch')
        if track in {'B','C'} and obs.get('actor_timestamp_s')!=obs['capture_t']:
            raise ValueError('actor clock mismatch')
        if track=='C' and obs.get('actor_latency_budget_s')!=case.latency_s:
            raise ValueError('actor latency budget mismatch')
        joints=obs['joints']
        if len(joints)!=9 or not all(isinstance(x,(int,float)) and math.isfinite(x) for x in joints):
            raise ValueError('invalid recorded proprioception')
        typed=Action.from_dict(action['action'])
        command=next((e for e in events if e['kind']=='command' and e.get('action_seq')==i),None)
        if not command or command['capture_t']!=action['capture_t'] or command['t']!=action['dispatch_t'] or command['kind_action']!=typed.kind or command['slot']!=typed.slot:
            raise ValueError('action/event linkage mismatch')
    return {'ok':True,'frames':len(observations),'verdict':replay}
