"""F1 release gate: true-time tick perturbations plus frame-level Gates 8 and 9.

The gate combines existing read-only frame probes with an explicit schedule check.  It never
changes a policy or verifier result: a release candidate is usable only when the declared true
time schedule, Track A temporal-aliasing gate, and cue-detectability gate all pass.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping

import numpy as np

from chemrm.gate0.env import DT
from chemrm.gates import GateResult, cue_detectability_gate, temporal_aliasing_gate


@dataclass(frozen=True)
class ScheduleResult:
    kind: str
    level: float
    passed: bool
    n_episodes: int
    n_ticks: int
    detail: Mapping[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class F1ReleaseResult:
    passed: bool
    schedule: ScheduleResult
    gates: tuple[GateResult, ...]
    failures: tuple[Mapping[str, Any], ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "passed": bool(self.passed),
            "schedule": self.schedule.to_dict(),
            "gates": [gate.to_dict() for gate in self.gates],
            "failures": [dict(item) for item in self.failures],
        }


def validate_tick_schedule(tick_times: np.ndarray, kind: str, level: float, *, dt: float = DT,
                           tolerance: float = 1e-9) -> ScheduleResult:
    """Check the declared F1 schedule without relying on a policy's observations."""
    ticks = np.asarray(tick_times, dtype=float)
    detail: dict[str, Any] = {}
    if ticks.ndim != 2 or ticks.shape[0] == 0 or ticks.shape[1] < 2:
        return ScheduleResult(kind, float(level), False, 0, 0, {"error": "expected (episodes, ticks>=2)"})
    deltas = np.diff(ticks, axis=1)
    positive = bool(np.all(deltas > 0))
    starts_at_zero = bool(np.all(np.abs(ticks[:, 0]) <= tolerance))
    lo, hi = dt * (1.0 - float(level)), dt * (1.0 + float(level))
    in_band = bool(np.all((deltas >= lo - tolerance) & (deltas <= hi + tolerance)))
    detail.update({"starts_at_zero": starts_at_zero, "positive_deltas": positive,
                   "delta_min_s": float(deltas.min()), "delta_max_s": float(deltas.max()),
                   "delta_mean_s": float(deltas.mean()), "allowed_min_s": lo,
                   "allowed_max_s": hi})
    if kind == "none":
        shape_ok = bool(np.all(np.abs(deltas - dt) <= tolerance))
    elif kind == "tick_jitter":
        shape_ok = in_band and bool(np.ptp(deltas) > tolerance)
    elif kind == "rate_error":
        per_episode_constant = bool(np.all(np.ptp(deltas, axis=1) <= tolerance))
        across_episode_varies = bool(np.ptp(deltas[:, 0]) > tolerance)
        shape_ok = in_band and per_episode_constant and across_episode_varies
        detail.update({"per_episode_constant": per_episode_constant,
                       "across_episode_varies": across_episode_varies})
    else:
        return ScheduleResult(kind, float(level), False, int(ticks.shape[0]), int(ticks.shape[1]),
                              {"error": f"unknown perturbation {kind!r}"})
    detail["shape_ok"] = shape_ok
    return ScheduleResult(kind, float(level), starts_at_zero and positive and shape_ok,
                          int(ticks.shape[0]), int(ticks.shape[1]), detail)


def run_f1_release_gate(*, tick_times: np.ndarray, perturbation: str, perturbation_level: float,
                        track_a_frames: np.ndarray, elapsed: np.ndarray,
                        cue_frames: np.ndarray, cue_mask: np.ndarray, cue_identity: np.ndarray,
                        aliasing_r2_max: float = 0.05, cue_acc_min: float = 0.95,
                        n_folds: int = 5, seed: int = 0) -> F1ReleaseResult:
    """Evaluate schedule, Gate 8, and Gate 9 as one fail-closed release decision."""
    schedule = validate_tick_schedule(tick_times, perturbation, perturbation_level)
    gates: list[GateResult] = []
    failures: list[Mapping[str, Any]] = []
    try:
        gates.append(temporal_aliasing_gate(track_a_frames, elapsed, r2_max=aliasing_r2_max,
                                           n_folds=n_folds, seed=seed, name="temporal_aliasing"))
    except (TypeError, ValueError, np.linalg.LinAlgError) as exc:
        failures.append({"kind": "temporal_aliasing_invalid", "detail": str(exc)})
    try:
        gates.append(cue_detectability_gate(cue_frames, cue_mask,
                                            cue_identity=cue_identity, acc_min=cue_acc_min,
                                            n_folds=n_folds, seed=seed, name="cue_detectability"))
    except (TypeError, ValueError, np.linalg.LinAlgError) as exc:
        failures.append({"kind": "cue_detectability_invalid", "detail": str(exc)})
    if not schedule.passed:
        failures.append({"kind": "schedule_invalid", "detail": dict(schedule.detail)})
    failures.extend({"kind": gate.name, "detail": gate.to_dict()} for gate in gates if not gate.passed)
    return F1ReleaseResult(schedule.passed and not failures, schedule, tuple(gates), tuple(failures))
