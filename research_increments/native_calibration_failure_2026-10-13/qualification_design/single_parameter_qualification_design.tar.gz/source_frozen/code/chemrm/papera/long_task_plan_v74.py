"""Compile a public goal DAG into private contiguous acquisition stages.

The schedule belongs to the executor/verifier. Hidden onset times, stage clocks
and retention metadata must not become policy inputs in memory-only tracks.
"""
import math
from chemrm.papera.staged_collection import validate_plan


def compile_plan(task,phases,outer_hz):
    if type(outer_hz) is not int or outer_hz<=0 or not phases:raise ValueError('positive typed observation rate and nonempty phases required')
    goals={g.id:g for g in task.goals};completed=set();active=None;tick=0;plan=[];details=[]
    for phase in phases:
        name,goal=phase['id'],phase['goal'];duration=phase['duration_s'];role=phase['role']
        if type(duration) not in (int,float) or not math.isfinite(duration) or duration<=0 or role not in ['motion','wait','observation'] or goal not in goals:
            raise ValueError('known goal, positive duration and declared phase role required')
        ticks=duration*outer_hz
        if abs(ticks-round(ticks))>1e-8:raise ValueError('phase duration must lie exactly on the native outer tick grid; no rounding')
        if goal!=active:
            if active is not None:completed.add(active)
            if goal in completed or not set(goals[goal].requires)<=completed:raise ValueError('goal stages cannot reopen or precede prerequisites')
            active=goal
        plan.append(dict(id=name,start_tick=tick,end_tick=tick+round(ticks)))
        details.append(dict(stage_id=name,goal_id=goal,role=role,duration_s=float(duration)))
        tick+=round(ticks)
    if active is not None:completed.add(active)
    if completed!=set(goals):raise ValueError('every task goal must be represented')
    validate_plan(plan)
    return dict(schema='chemrm-contiguous-goal-stage-plan-v74',task_program=task.to_dict(),stage_plan=plan,
        phase_details=details,outer_hz=outer_hz,total_ticks=tick,nominal_duration_s=tick/outer_hz,
        independent_episodes=1,physical_restart_supported=False,asynchronous_execution=False,
        policy_feature_export=False,stage_commit_role='DURABLE_EVIDENCE_NOT_SUCCESS_OR_TRAINING_ADMISSION')
