"""Development-only, all-identity render/history controls; no new holdout claim."""
from __future__ import annotations

import json
from pathlib import Path
import numpy as np
from chemrm.papera.clock_repair_v17 import build_bank as old_bank
from chemrm.papera.isaac_bridge_verify import sha256

REVISION = 'papera-causal-development-v19'
RENDER_COUNTS = [0, 8, 64]
MODES = ['visible_cue_history', 'cue_not_rendered']


def build_bank():
    old = old_bank()
    # Every geometry was already assigned to V17 train or development.
    selected = [old['scenes'][i] for i in (0, 5, 16, 21)]
    prior = {(r['scene_id'], r['case']['target']): r for r in old['cases']}
    cases = []
    for scene in selected:
        for order in ('forward', 'reverse'):
            targets = list(range(5)) if order == 'forward' else list(reversed(range(5)))
            # Counterbalance block order across scene and execution order.
            modes = MODES if (selected.index(scene) + (order == 'reverse')) % 2 == 0 else MODES[::-1]
            for mode in modes:
                for target in targets:
                    source = prior[(scene['scene_id'], target)]
                    case = dict(source['case'])
                    case['case_id'] = f"v19_{scene['scene_id']}_{order}_{mode}_t{target}"
                    cases.append(dict(scene_id=scene['scene_id'], split=scene['split'],
                                      order=order, history_mode=mode, case=case))
    return dict(revision=REVISION, scope='DEVELOPMENT_ONLY_SEEN_GEOMETRY',
                scenes=selected, cases=cases, render_counts=RENDER_COUNTS,
                post_age_s=4., renderer=old['renderer'], future_scenes=0)


def verify_freeze(bank_path: Path, freeze_path: Path):
    f = json.loads(freeze_path.read_text())
    if sha256(bank_path) != f['bank_sha256'] or json.loads(bank_path.read_text()) != build_bank():
        raise ValueError('diagnostic bank changed')
    root = Path(__file__).resolve().parents[2]
    for name, digest in f['sources'].items():
        if sha256(root / name) != digest:
            raise ValueError(f'diagnostic source changed: {name}')
    return f


def check_render_only(samples):
    if [r['extra_render_calls'] for r in samples] != RENDER_COUNTS:
        raise ValueError('incomplete render-only checkpoints')
    for r in samples:
        if not np.isfinite([r['physical_time'], *r['joints']]).all():
            raise ValueError('nonfinite native state')
    for key in ('physical_time', 'joints', 'events_sha256', 'physical_state_sha256'):
        if any(r[key] != samples[0][key] for r in samples[1:]):
            raise ValueError(f'render intervention changed {key}')
