"""Seen-scene camera development; never another V19 fresh confirmation."""
from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path

REVISION = 'papera-camera-coverage-development-v20'
SEEN_SCENES = ('v19_future_008', 'v19_future_068', 'v19_future_082', 'v19_future_000')
MULTIPLIERS = {'original': 1., 'wide': .75}
V19_BANK_SHA = '3932b009aa9bce7a1cf2980da4d7c1fac33c6d1a936d178867baa5dfaa8d6007'


def build_bank(path: Path):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != V19_BANK_SHA:
        raise ValueError('development must use the exact completed V19 bank')
    old = json.loads(raw)
    lookup = {(r['scene_id'], r['case']['target']): r for r in old['cases']}
    cases = []
    for scene_index, scene_id in enumerate(SEEN_SCENES):
        for target in range(5):
            arms = ('original', 'wide') if (scene_index + target) % 2 == 0 else ('wide', 'original')
            for arm in arms:
                source = lookup[scene_id, target]
                case = copy.deepcopy(source['case'])
                source_id = case['case_id']
                case['case_id'] = f'v20_camera_s{scene_index}_t{target}_{arm}'
                case['split'] = 'dev'
                cases.append({'scene_id': scene_id, 'target': target, 'arm': arm,
                    'source_case_id': source_id, 'focal_multiplier': MULTIPLIERS[arm], 'case': case})
    return {'revision': REVISION, 'scope': 'SEEN_DEVELOPMENT_ONLY', 'future_scenes': 0,
            'input_v19_bank_sha256': V19_BANK_SHA, 'scenes': list(SEEN_SCENES),
            'arms': MULTIPLIERS, 'phases': ['before', 'cue', 'age_4'],
            'cases': cases, 'expected_cases': 40, 'expected_images': 120,
            'scientific_limit': 'Engineering visibility diagnostic; no learned-head, admission, transfer or new holdout claim.'}


def validate_bank(bank):
    if (bank.get('revision') != REVISION or bank.get('scope') != 'SEEN_DEVELOPMENT_ONLY'
        or bank.get('future_scenes') != 0 or bank.get('scenes') != list(SEEN_SCENES)
        or bank.get('input_v19_bank_sha256') != V19_BANK_SHA
        or bank.get('expected_cases') != 40 or bank.get('expected_images') != 120
        or bank.get('phases') != ['before', 'cue', 'age_4']
        or bank.get('arms') != MULTIPLIERS or len(bank.get('cases', [])) != 40):
        raise ValueError('unsupported development bank')
    keys = {(r['scene_id'], r['target'], r['arm']) for r in bank['cases']}
    wanted = {(scene, target, arm) for scene in SEEN_SCENES for target in range(5) for arm in MULTIPLIERS}
    if keys != wanted or len({r['case']['case_id'] for r in bank['cases']}) != 40:
        raise ValueError('missing/duplicate scene-target-arm pair')
    for row in bank['cases']:
        if (row['case']['split'] != 'dev' or row['target'] != row['case']['target']
            or row['focal_multiplier'] != MULTIPLIERS[row['arm']]):
            raise ValueError('camera arm or target binding differs')
    for scene in SEEN_SCENES:
        for target in range(5):
            pair = [r for r in bank['cases'] if r['scene_id'] == scene and r['target'] == target]
            first, second = [{k: v for k, v in r['case'].items() if k != 'case_id'} for r in pair]
            if first != second or pair[0]['source_case_id'] != pair[1]['source_case_id']:
                raise ValueError('paired scene physics/events differ')
