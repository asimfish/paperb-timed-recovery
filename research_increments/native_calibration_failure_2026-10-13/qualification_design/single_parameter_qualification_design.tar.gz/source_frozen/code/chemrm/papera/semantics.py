"""Finite public protocol grammar: declared semantics, split domains and unique tasks.

Facts describe a graph execution contract, not chemistry calibration. No policy, simulator or
evaluation result is an input. Version 1 remains a separate legacy fixture format.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import itertools
import json
import random
from typing import Any, Mapping, Sequence

from chemrm.constraints import Violation
from chemrm.events import EventBus
from chemrm.task_program import GoalStep, NOVELTY_AXES, SPLITS, TaskProgram


SCHEMA_VERSION = "paper-a-semantic-grammar-2"
TASK_VERSION = "paper-a-public-grammar-2"
GRAPH_AXES = frozenset({"composition", "dependency", "topology"})


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _labels(values: Sequence[str], name: str, *, empty: bool = False) -> tuple[str, ...]:
    if isinstance(values, (str, bytes)):
        raise ValueError(f"{name} must be a sequence of labels")
    result = tuple(values)
    if (not result and not empty) or len(result) > 64:
        raise ValueError(f"{name} must contain {'0' if empty else '1'}..64 labels")
    if any(not isinstance(v, str) or not v.strip() or len(v) > 128 for v in result):
        raise ValueError(f"{name} labels must be non-empty strings of at most 128 characters")
    if len(set(result)) != len(result):
        raise ValueError(f"duplicate {name} labels")
    return result


def _bind(value: Any, receiver: str, depth: int = 0) -> Any:
    if depth > 16:
        raise ValueError("primitive parameter nesting exceeds 16")
    if isinstance(value, str) and value.startswith("$"):
        if value != "$receiver":
            raise ValueError("only the $receiver parameter binding is supported")
        return receiver
    if isinstance(value, Mapping):
        return {key: _bind(item, receiver, depth + 1) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_bind(item, receiver, depth + 1) for item in value]
    return value


@dataclass(frozen=True)
class Primitive:
    name: str
    action: str
    parameters: Mapping[str, Any]
    preconditions: tuple[str, ...] = ()
    add: tuple[str, ...] = ()
    delete: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _labels((self.name, ), "primitive name")
        _labels((self.action, ), "primitive action")
        if not isinstance(self.parameters, Mapping):
            raise ValueError("primitive parameters must be an object")
        parameters = json.loads(_json(dict(self.parameters)))
        _bind(parameters, "receiver")
        object.__setattr__(self, "parameters", parameters)
        for name in ("preconditions", "add", "delete"):
            object.__setattr__(self, name, _labels(getattr(self, name), name, empty=True))
        if set(self.add) & set(self.delete):
            raise ValueError("primitive cannot add and delete the same fact")

    @property
    def operation(self) -> str:
        return _json({"action": self.action, "parameters": self.parameters})

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "action": self.action, "parameters": dict(self.parameters),
                "preconditions": list(self.preconditions), "add": list(self.add), "delete": list(self.delete)}


@dataclass(frozen=True)
class ProgramNode:
    id: str
    primitive: str
    requires: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _labels((self.id,), "node id")
        _labels((self.primitive,), "node primitive")
        object.__setattr__(self, "requires", _labels(self.requires, "node dependencies", empty=True))

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "primitive": self.primitive, "requires": list(self.requires)}


@dataclass(frozen=True)
class SemanticProgram:
    name: str
    nodes: tuple[ProgramNode, ...]

    def __post_init__(self) -> None:
        _labels((self.name,), "program name")
        object.__setattr__(self, "nodes", tuple(self.nodes))
        if not 1 <= len(self.nodes) <= 6:
            raise ValueError("v2 programs support one to six nodes")
        if len({node.primitive for node in self.nodes}) != len(self.nodes):
            raise ValueError("each primitive may occur only once per v2 program")
        _ancestors(self)

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "nodes": [node.to_dict() for node in self.nodes]}


def _ancestors(program: SemanticProgram) -> dict[str, frozenset[str]]:
    by_id = {node.id: node for node in program.nodes}
    if len(by_id) != len(program.nodes):
        raise ValueError("program node IDs must be unique")
    out: dict[str, frozenset[str]] = {}
    visiting: set[str] = set()

    def visit(node_id: str) -> frozenset[str]:
        if node_id not in by_id or node_id in visiting:
            raise ValueError("program dependencies must be known and acyclic")
        if node_id not in out:
            visiting.add(node_id)
            node = by_id[node_id]
            parents = set(node.requires)
            for parent in node.requires:
                parents.update(visit(parent))
            visiting.remove(node_id)
            out[node_id] = frozenset(parents)
        return out[node_id]

    for node_id in by_id:
        visit(node_id)
    return out


def _check_program(program: SemanticProgram, primitives: Mapping[str, Primitive], initial: Sequence[str]) -> None:
    ancestors = _ancestors(program)
    if any(node.primitive not in primitives for node in program.nodes):
        raise ValueError("program refers to an unknown primitive")
    for a, b in itertools.combinations(program.nodes, 2):
        if a.id in ancestors[b.id] or b.id in ancestors[a.id]:
            continue
        pa, pb = primitives[a.primitive], primitives[b.primitive]
        if (set(pa.delete) & (set(pb.preconditions) | set(pb.add))
                or set(pb.delete) & (set(pa.preconditions) | set(pa.add))):
            raise ValueError(f"unordered primitive conflict in program {program.name!r}")
    ordered = sorted(program.nodes, key=lambda node: (len(ancestors[node.id]), node.id))
    for node in ordered:
        facts = set(initial)
        for parent in ordered:
            if parent.id in ancestors[node.id]:
                primitive = primitives[parent.primitive]
                facts.difference_update(primitive.delete)
                facts.update(primitive.add)
        missing = set(primitives[node.primitive].preconditions) - facts
        if missing:
            raise ValueError(f"unsatisfied precondition {sorted(missing)} at {program.name}:{node.id}")


@dataclass(frozen=True)
class TaskFamily:
    split: str
    novelty_axes: frozenset[str]
    environments: tuple[str, ...]
    object_roles: tuple[str, ...]
    object_counts: tuple[int, ...]
    programs: tuple[str, ...]

    def __post_init__(self) -> None:
        axes = frozenset(self.novelty_axes)
        if self.split not in SPLITS or axes - NOVELTY_AXES:
            raise ValueError("unknown split or novelty axes")
        if (self.split == "closed" and axes) or (self.split != "closed" and not axes):
            raise ValueError("closed has no novelty axes; held-out families require axes")
        if self.split == "compositional-held-out" and (not axes & GRAPH_AXES or axes - GRAPH_AXES):
            raise ValueError("compositional families retain base domains and declare graph axes")
        object.__setattr__(self, "novelty_axes", axes)
        for name in ("environments", "object_roles", "programs"):
            object.__setattr__(self, name, _labels(getattr(self, name), name))
        if (not self.object_counts or len(set(self.object_counts)) != len(self.object_counts)
                or any(type(n) is not int or not 1 <= n <= 3 for n in self.object_counts)):
            raise ValueError("object_counts must be unique integers in [1, 3]")
        object.__setattr__(self, "object_counts", tuple(self.object_counts))

    @property
    def key(self) -> str:
        return self.split + ":" + ",".join(sorted(self.novelty_axes))

    @property
    def capacity(self) -> int:
        return len(self.environments) * len(self.programs) * sum(len(self.object_roles) ** n for n in self.object_counts)

    def to_dict(self) -> dict[str, Any]:
        return {"split": self.split, "novelty_axes": sorted(self.novelty_axes),
                "environments": list(self.environments), "object_roles": list(self.object_roles),
                "object_counts": list(self.object_counts), "programs": list(self.programs)}


def _goals(program: SemanticProgram, primitives: Mapping[str, Primitive], receiver: str) -> tuple[GoalStep, ...]:
    return tuple(GoalStep(node.id, primitives[node.primitive].action, node.requires,
                          _bind(primitives[node.primitive].parameters, receiver)) for node in program.nodes)


def _goal_graph(goals: Sequence[GoalStep], normalize=lambda value: value) -> dict[str, Any]:
    labels = {goal.id: _json({"action": goal.action, "parameters": normalize(dict(goal.parameters))}) for goal in goals}
    if len(set(labels.values())) != len(goals):
        raise ValueError("semantic signature requires distinct operation nodes")
    if any(parent not in labels for goal in goals for parent in goal.requires):
        raise ValueError("semantic graph has an unknown dependency")
    return {"nodes": sorted(labels.values()),
            "edges": sorted((labels[parent], labels[goal.id]) for goal in goals for parent in goal.requires)}


def semantic_signature(task: TaskProgram) -> str:
    """V2 task identity excluding labels, provenance, seed, split and goal serialization order."""
    ids = {obj["id"]: f"@object{i}" for i, obj in enumerate(task.objects)}

    def normalize(value):
        if isinstance(value, str):
            return ids.get(value, value)
        if isinstance(value, Mapping):
            return {key: normalize(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [normalize(item) for item in value]
        return value

    return _json({"environment": {k: v for k, v in task.environment.items() if k != "grammar_id"},
                  "objects": [normalize({k: v for k, v in obj.items() if k != "id"}) for obj in task.objects],
                  "counts": dict(task.counts), "goals": _goal_graph(task.goals, normalize)})


def _program_graph(program: SemanticProgram, primitives: Mapping[str, Primitive]) -> dict[str, Any]:
    return _goal_graph(_goals(program, primitives, "@receiver"))


def _dependency_rows(program: SemanticProgram, primitives: Mapping[str, Primitive]) -> set[str]:
    labels = {node.id: primitives[node.primitive].operation for node in program.nodes}
    return {_json((labels[node.id], sorted(labels[parent] for parent in node.requires))) for node in program.nodes}


def _topology(program: SemanticProgram) -> str:
    ids = tuple(node.id for node in program.nodes)
    edges = {(parent, node.id) for node in program.nodes for parent in node.requires}
    return min(str(len(ids)) + ":" + "".join("1" if (a, b) in edges else "0" for a in order for b in order)
               for order in itertools.permutations(ids))


def _configurations(family: TaskFamily):
    for env in family.environments:
        for n in family.object_counts:
            for roles in itertools.product(family.object_roles, repeat=n):
                for name in family.programs:
                    yield env, roles, name


@dataclass(frozen=True)
class SemanticGrammar:
    grammar_id: str
    initial_facts: tuple[str, ...]
    primitives: tuple[Primitive, ...]
    programs: tuple[SemanticProgram, ...]
    families: tuple[TaskFamily, ...]
    max_candidates: int = 10000

    def __post_init__(self) -> None:
        _labels((self.grammar_id,), "grammar id")
        object.__setattr__(self, "initial_facts", _labels(self.initial_facts, "initial facts", empty=True))
        if type(self.max_candidates) is not int or not 1 <= self.max_candidates <= 100000:
            raise ValueError("max_candidates must be an integer in [1, 100000]")
        _audit(self)

    @property
    def primitive_map(self) -> dict[str, Primitive]:
        return {p.name: p for p in self.primitives}

    @property
    def program_map(self) -> dict[str, SemanticProgram]:
        return {p.name: p for p in self.programs}

    def to_dict(self) -> dict[str, Any]:
        return {"schema_version": SCHEMA_VERSION, "grammar_id": self.grammar_id,
                "initial_facts": list(self.initial_facts), "max_candidates": self.max_candidates,
                "primitives": [p.to_dict() for p in self.primitives],
                "programs": [p.to_dict() for p in self.programs], "families": [f.to_dict() for f in self.families]}

    @property
    def sha256(self) -> str:
        return hashlib.sha256(_json(self.to_dict()).encode()).hexdigest()

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "SemanticGrammar":
        if not isinstance(data, Mapping) or set(data) != {
                "schema_version", "grammar_id", "initial_facts", "max_candidates", "primitives", "programs", "families"}:
            raise ValueError("unsupported semantic grammar fields")
        if data["schema_version"] != SCHEMA_VERSION:
            raise ValueError("unsupported semantic grammar schema")
        try:
            _labels(data["initial_facts"], "initial facts", empty=True)
            if any(not isinstance(item, Mapping) or set(item) != {"name", "nodes"} for item in data["programs"]):
                raise ValueError("unsupported semantic program fields")
            primitives = tuple(Primitive(**item) for item in data["primitives"])
            programs = tuple(SemanticProgram(item["name"], tuple(ProgramNode(**node) for node in item["nodes"]))
                             for item in data["programs"])
            families = tuple(TaskFamily(**item) for item in data["families"])
            return cls(data["grammar_id"], tuple(data["initial_facts"]), primitives, programs, families, data["max_candidates"])
        except (KeyError, TypeError, OverflowError) as exc:
            raise ValueError("malformed semantic grammar") from exc


def _audit(grammar: SemanticGrammar) -> dict[str, Any]:
    if (not grammar.primitives or not grammar.programs or not grammar.families
            or max(len(grammar.primitives), len(grammar.programs), len(grammar.families)) > 64):
        raise ValueError("grammar catalogs must have 1..64 entries")
    primitives, programs = grammar.primitive_map, grammar.program_map
    if len(primitives) != len(grammar.primitives) or len(programs) != len(grammar.programs):
        raise ValueError("catalog names must be unique")
    if len({p.operation for p in grammar.primitives}) != len(grammar.primitives):
        raise ValueError("primitive operation alias cannot establish novelty")
    for program in grammar.programs:
        _check_program(program, primitives, grammar.initial_facts)
    if len({_json(_program_graph(p, primitives)) for p in grammar.programs}) != len(programs):
        raise ValueError("semantic program overlap under different names")
    keys = [f.key for f in grammar.families]
    if len(set(keys)) != len(keys):
        raise ValueError("family split/axis registration must be unique")
    closed_families = [f for f in grammar.families if f.split == "closed"]
    if len(closed_families) != 1:
        raise ValueError("v2 requires exactly one closed domain family")
    if sum(f.capacity for f in grammar.families) > grammar.max_candidates:
        raise ValueError("declared task capacity exceeds max_candidates")
    if any(name not in programs for f in grammar.families for name in f.programs):
        raise ValueError("family refers to an unknown program")
    closed = closed_families[0]
    closed_programs = [programs[name] for name in closed.programs]
    closed_primitives = {node.primitive for p in closed_programs for node in p.nodes}
    compositions = {_json(_program_graph(p, primitives)["nodes"]) for p in closed_programs}
    dependencies = set().union(*(_dependency_rows(p, primitives) for p in closed_programs))
    topologies = {_topology(p) for p in closed_programs}
    for family in grammar.families:
        if family.split == "closed":
            continue
        for axis, field in (("environment", "environments"), ("object", "object_roles"), ("count", "object_counts")):
            current, base = set(getattr(family, field)), set(getattr(closed, field))
            if (axis in family.novelty_axes and current & base) or (axis not in family.novelty_axes and not current <= base):
                raise ValueError(f"{axis} domain leakage or undeclared novelty in {family.key}")
        for name in family.programs:
            program = programs[name]
            used = {node.primitive for node in program.nodes}
            if ("goal" in family.novelty_axes and used <= closed_primitives
                    or "goal" not in family.novelty_axes and not used <= closed_primitives):
                raise ValueError(f"goal domain leakage or undeclared novelty in {family.key}")
            if "composition" in family.novelty_axes and _json(_program_graph(program, primitives)["nodes"]) in compositions:
                raise ValueError(f"composition already present in closed catalog: {name}")
            if "dependency" in family.novelty_axes and _dependency_rows(program, primitives) <= dependencies:
                raise ValueError(f"dependency already present in closed catalog: {name}")
            if "topology" in family.novelty_axes and _topology(program) in topologies:
                raise ValueError(f"topology already present in closed catalog: {name}")
    signatures: set[str] = set()
    for family in grammar.families:
        for env, roles, name in _configurations(family):
            signature = _configuration_signature(env, roles, programs[name], primitives)
            if signature in signatures:
                raise ValueError("declared task-space semantic overlap")
            signatures.add(signature)
    return {"schema_version": SCHEMA_VERSION, "grammar_id": grammar.grammar_id,
            "family_capacities": {f.key: f.capacity for f in grammar.families},
            "total_unique_tasks": len(signatures), "semantic_preconditions_valid": True,
            "declared_axes_valid": True, "split_spaces_disjoint": True,
            "backend_variation_validated": False,
            "evidence_scope": "goal-graph-contract"}


def _configuration_signature(env: str, roles: Sequence[str], program: SemanticProgram,
                             primitives: Mapping[str, Primitive]) -> str:
    # Audit instantiated parameters: a literal vessel and $receiver can resolve to the same
    # operation, so symbolic template identity alone must not increase catalog capacity.
    receiver = f"{roles[0]}_0"
    identifiers = {f"{role}_{i}": f"@object{i}" for i, role in enumerate(roles)}

    def normalize(value):
        if isinstance(value, str):
            return identifiers.get(value, value)
        if isinstance(value, Mapping):
            return {key: normalize(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [normalize(item) for item in value]
        return value

    return _json({"environment": env, "roles": list(roles),
                  "goals": _goal_graph(_goals(program, primitives, receiver), normalize)})


def audit_semantic_grammar(grammar: SemanticGrammar) -> dict[str, Any]:
    return _audit(grammar)


def generate_semantic_tasks(grammar: SemanticGrammar, *, split: str, count: int, seed: int,
                            novelty_axes: Sequence[str] = ()) -> tuple[TaskProgram, ...]:
    if type(count) is not int or count <= 0 or type(seed) is not int or seed < 0:
        raise ValueError("count must be a positive integer and seed a non-negative integer")
    axes = frozenset(novelty_axes)
    family = next((f for f in grammar.families if f.split == split and f.novelty_axes == axes), None)
    if family is None:
        raise ValueError("split/novelty axes must match a registered family")
    if count > family.capacity:
        raise ValueError(f"requested {count} tasks exceeds family capacity {family.capacity}")
    configs = list(_configurations(family))
    rng = random.Random(f"{SCHEMA_VERSION}:{grammar.sha256}:{family.key}:{seed}")
    selected = rng.sample(configs, count)
    tasks = []
    for index, (env, roles, name) in enumerate(selected):
        objects = tuple({"id": f"{role}_{i}", "role": role} for i, role in enumerate(roles))
        tasks.append(TaskProgram(
            task_id=f"{grammar.grammar_id}:{split}:{seed}:{index:04d}", split=split, seed=seed + index,
            environment={"kind": env}, objects=objects, counts={"object": len(objects)},
            goals=_goals(grammar.program_map[name], grammar.primitive_map, objects[0]["id"]),
            novelty_axes=axes, public_spec_version=TASK_VERSION,
            metadata={"grammar_id": grammar.grammar_id, "grammar_sha256": grammar.sha256,
                      "family": family.key, "program": name, "generation_index": index,
                      "evidence_scope": "goal-graph-contract"}))
    return tuple(tasks)


def validate_semantic_task(task: TaskProgram, grammar: SemanticGrammar) -> SemanticProgram:
    """Bind a task to the exact declared family, object assignment and program."""
    family = next((f for f in grammar.families if f.split == task.split and f.novelty_axes == task.novelty_axes), None)
    if (task.public_spec_version != TASK_VERSION or family is None
            or task.metadata.get("grammar_id") != grammar.grammar_id
            or task.metadata.get("grammar_sha256") != grammar.sha256
            or task.metadata.get("family") != family.key
            or task.metadata.get("evidence_scope") != "goal-graph-contract"):
        raise ValueError("semantic task is not bound to the registered grammar/family")
    name = task.metadata.get("program")
    if name not in family.programs or task.environment != {"kind": task.environment.get("kind")}:
        raise ValueError("semantic task program or environment contract mismatch")
    if task.environment["kind"] not in family.environments or len(task.objects) not in family.object_counts:
        raise ValueError("semantic environment/count outside registered domain")
    roles = [obj.get("role") for obj in task.objects]
    expected_objects = tuple({"id": f"{role}_{i}", "role": role} for i, role in enumerate(roles))
    if (any(role not in family.object_roles for role in roles) or task.objects != expected_objects
            or task.counts != {"object": len(roles)}):
        raise ValueError("semantic objects outside registered domain or binding")
    program = grammar.program_map[name]
    expected = _goals(program, grammar.primitive_map, task.objects[0]["id"])
    if {goal.id for goal in task.goals} != {goal.id for goal in expected} or _goal_graph(task.goals) != _goal_graph(expected):
        raise ValueError("semantic task goals differ from the registered program")
    # Bind IDs as well as isomorphic graph shape for goal_id-backed event auditing.
    by_id = {goal.id: goal for goal in expected}
    if any(goal.action != by_id[goal.id].action or goal.parameters != by_id[goal.id].parameters
           or set(goal.requires) != set(by_id[goal.id].requires) for goal in task.goals):
        raise ValueError("semantic goal ID/operation binding mismatch")
    return program


class SemanticEventCheck:
    """Replay facts and dependencies using only world-owned semantic events."""

    def __init__(self, task: TaskProgram, grammar: SemanticGrammar):
        program = validate_semantic_task(task, grammar)
        self.initial_facts = grammar.initial_facts
        self.goals = {goal.id: goal for goal in task.goals}
        self.primitives = {node.id: grammar.primitive_map[node.primitive] for node in program.nodes}

    def check(self, bus: EventBus, episode_end: float) -> list[Violation]:
        facts, completed = set(self.initial_facts), set()
        for ev in bus.log:
            goal_id = ev.payload.get("goal_id")
            goal = self.goals.get(goal_id) if isinstance(goal_id, str) else None
            if (goal is None or goal_id in completed or ev.kind != goal.action
                    or {k: v for k, v in ev.payload.items() if k != "goal_id"} != goal.parameters
                    or not set(goal.requires) <= completed
                    or not set(self.primitives[goal_id].preconditions) <= facts):
                return [Violation("semantic.events", "instrumentation_invalid", "event violates bound protocol", ev.t)]
            primitive = self.primitives[goal_id]
            facts.difference_update(primitive.delete)
            facts.update(primitive.add)
            completed.add(goal_id)
        if completed != set(self.goals):
            return [Violation("semantic.events", "incomplete", "registered program not completed", episode_end)]
        return []
