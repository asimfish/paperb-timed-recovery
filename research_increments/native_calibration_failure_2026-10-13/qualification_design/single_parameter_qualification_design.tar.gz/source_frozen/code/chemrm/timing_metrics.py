"""Timing-precision metrics for the T axis (proposal section 3.6, v0.6.1).

The pass-vector bit `time` stays binary and is the only timing quantity that enters the main
board (Timed-SR, ChemSSR).  Everything here is a diagnostic statistic computed from the same
event facts the referee already logs (target time t*, realised time t_B, instructed duration D,
tier tolerance eta), so nothing new has to be instrumented.  Each metric has a literature
precedent that fixed its definition:

    signed / normalised timing error, bias and precision  - timing psychophysics (bias and
        dispersion are different failures; early and late are different chemistry)
    Weber slope (scalar property)  - Deverett et al. 2019: recurrent agents keep an internal
        counter whose error grows with the interval (sigma_e ~ D, slope 1); reading an external
        clock gives constant absolute error (slope 0).  The slope separates the two mechanisms
        without opening the policy.
    calibration slope / central tendency  - interval reproduction regresses to the mean
        (Vierordt); a calibrated timer has slope 1.
    timing acuity eta50  - psychometric threshold: the relative tolerance at which Timed-SR
        crosses 0.5, interpolated in log eta across the tiers; censored when saturated.
    reaction latency and its decomposition  - catching in flight, table tennis, the OT-2
        titration endpoint: t_stop - t_event = detection + inference (replayed) + motor (known).
    inter-operation gap compliance and exposure time  - S-LAB mutual-boundary constraints:
        the gap between the end of one operation and the start of the next has [g_min, g_max].
    failure vector  - the fail-closed verdict vocabulary as shares, so a Timed-SR of 0.4 says
        whether the policy was early, late or never acted.

All functions take plain sequences/arrays; NaN marks episodes where B was never added.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, asdict
from typing import Dict, Iterable, List, Optional, Sequence

import numpy as np

TIERS_DEFAULT = (0.30, 0.15, 0.08)


# ---------------------------------------------------------------- per-episode errors
def signed_error(t_realised: Sequence[float], t_target: Sequence[float]) -> np.ndarray:
    """e = t_B - t*.  Negative = early (chemically the dangerous side), positive = late."""
    a = np.asarray(t_realised, dtype=float)
    b = np.asarray(t_target, dtype=float)
    if a.shape != b.shape:
        raise ValueError("unpaired arrays")
    return a - b


def normalised_error(e: Sequence[float], scale: Sequence[float]) -> np.ndarray:
    """e / D (duration constraints) or e / tau (event constraints)."""
    e = np.asarray(e, dtype=float)
    s = np.asarray(scale, dtype=float)
    return e / s


# ---------------------------------------------------------------- summaries
@dataclass
class ErrorSummary:
    n_acted: int
    n_total: int
    bias_s: float            # median signed error, seconds
    precision_s: float       # robust dispersion: 1.4826 * MAD of signed error, seconds
    bias_rel: float          # median normalised error
    precision_rel: float     # robust dispersion of normalised error
    early_share: float       # share of acted episodes with e < 0
    p95_abs_s: float         # 95th percentile of |e|


def summarise_errors(e: Sequence[float], scale: Sequence[float]) -> ErrorSummary:
    e = np.asarray(e, dtype=float)
    s = np.asarray(scale, dtype=float)
    ok = ~np.isnan(e)
    n_total = int(e.shape[0])
    if ok.sum() == 0:
        return ErrorSummary(0, n_total, float("nan"), float("nan"), float("nan"), float("nan"), float("nan"), float("nan"))
    ee, ss = e[ok], s[ok]
    rel = ee / ss
    mad = lambda v: 1.4826 * float(np.median(np.abs(v - np.median(v))))
    return ErrorSummary(int(ok.sum()), n_total, float(np.median(ee)), mad(ee), float(np.median(rel)), mad(rel),
                        float(np.mean(ee < 0)), float(np.quantile(np.abs(ee), 0.95)))


def weber_slope(e: Sequence[float], duration: Sequence[float], n_bins: int = 3) -> Dict:
    """Slope of log(sigma_e) against log(D) over duration bins.

    1.0 = scalar timing (Weber's law, internal counter); 0.0 = constant absolute error (an
    external clock or tool).  Returns NaN when fewer than two bins have a non-degenerate spread;
    a bin with zero spread is reported as `degenerate` (deterministic environment).
    """
    e = np.asarray(e, dtype=float)
    d = np.asarray(duration, dtype=float)
    ok = ~np.isnan(e)
    e, d = e[ok], d[ok]
    if e.shape[0] < 2 * n_bins:
        return {"slope": float("nan"), "bins": [], "note": "too few acted episodes"}
    edges = np.quantile(d, np.linspace(0, 1, n_bins + 1))
    bins = []
    for i in range(n_bins):
        m = (d >= edges[i]) & (d <= edges[i + 1] if i == n_bins - 1 else d < edges[i + 1])
        if m.sum() < 2:
            continue
        sig = 1.4826 * float(np.median(np.abs(e[m] - np.median(e[m]))))
        bins.append({"D_mean": float(d[m].mean()), "sigma_e": sig, "n": int(m.sum()), "cv": sig / float(d[m].mean())})
    usable = [b for b in bins if b["sigma_e"] > 1e-9]
    if len(usable) < 2:
        return {"slope": float("nan"), "bins": bins, "note": "degenerate: no spread in at least two bins"}
    x = np.log([b["D_mean"] for b in usable]); y = np.log([b["sigma_e"] for b in usable])
    slope = float(np.polyfit(x, y, 1)[0])
    return {"slope": slope, "bins": bins, "note": "1 = scalar (internal counter), 0 = constant absolute (external clock)"}


def calibration(produced: Sequence[float], instructed: Sequence[float]) -> Dict:
    """Least-squares fit produced = a + b * instructed over acted episodes.

    b = 1 is calibrated; b < 1 with a > 0 is central tendency (short intervals produced long,
    long ones short), the signature of a noisy internal estimate.
    """
    p = np.asarray(produced, dtype=float)
    q = np.asarray(instructed, dtype=float)
    ok = ~np.isnan(p)
    if ok.sum() < 3 or np.ptp(q[ok]) < 1e-9:
        return {"slope": float("nan"), "intercept": float("nan"), "n": int(ok.sum())}
    b, a = np.polyfit(q[ok], p[ok], 1)
    return {"slope": float(b), "intercept": float(a), "central_tendency": float(1.0 - b), "n": int(ok.sum())}


def acuity_eta50(tier_success: Dict[float, float], tiers: Sequence[float] = TIERS_DEFAULT) -> Dict:
    """Relative tolerance at which Timed-SR crosses 0.5, interpolated linearly in log(eta).

    Censored when success is >= 0.5 at the tightest tier ("< tightest") or < 0.5 at the loosest
    ("> loosest").  Smaller is better.  Absolute acuity at a reference duration D_ref is
    eta50 * D_ref.
    """
    ts = sorted(tiers, reverse=True)                     # loose -> tight
    sr = [tier_success[t] for t in ts]
    if all(v >= 0.5 for v in sr):
        return {"eta50": float("nan"), "censored": "<%.2f" % ts[-1], "tiers": dict(zip(ts, sr))}
    if all(v < 0.5 for v in sr):
        return {"eta50": float("nan"), "censored": ">%.2f" % ts[0], "tiers": dict(zip(ts, sr))}
    for (t_hi, s_hi), (t_lo, s_lo) in zip(zip(ts[:-1], sr[:-1]), zip(ts[1:], sr[1:])):
        if s_hi >= 0.5 > s_lo:
            f = (s_hi - 0.5) / (s_hi - s_lo)                # fraction of the way from loose to tight
            log_eta = math.log(t_hi) + f * (math.log(t_lo) - math.log(t_hi))
            return {"eta50": math.exp(log_eta), "censored": None, "tiers": dict(zip(ts, sr))}
    return {"eta50": float("nan"), "censored": "non-monotone", "tiers": dict(zip(ts, sr))}


def failure_vector(e: Sequence[float], tolerance: Sequence[float]) -> Dict[str, float]:
    """Shares of {in_window, early, late, never_acted} over all episodes of a cell."""
    e = np.asarray(e, dtype=float)
    tol = np.asarray(tolerance, dtype=float)
    n = e.shape[0]
    never = np.isnan(e)
    early = (~never) & (e < -tol)
    late = (~never) & (e > tol)
    inside = (~never) & ~early & ~late
    return {"in_window": float(inside.mean()), "early": float(early.mean()), "late": float(late.mean()),
            "never_acted": float(never.mean()), "n": int(n)}


# ---------------------------------------------------------------- event response
def reaction_latency(t_event: Sequence[float], t_stop: Sequence[float], motor_time: Sequence[float],
                     inference_latency: float = 0.0) -> Dict:
    """tau_react = t_stop - t_event, decomposed as detection + inference (replayed) + motor.

    `motor_time` is the scripted or measured skill duration; `inference_latency` the replayed
    reference latency L_ref.  The residual is the policy's detection delay.
    """
    te = np.asarray(t_event, dtype=float); ts = np.asarray(t_stop, dtype=float); tm = np.asarray(motor_time, dtype=float)
    ok = ~np.isnan(ts)
    tau = ts[ok] - te[ok]
    detect = tau - tm[ok] - inference_latency
    if ok.sum() == 0:
        return {"n": 0}
    return {"n": int(ok.sum()), "tau_median_s": float(np.median(tau)), "tau_p95_s": float(np.quantile(tau, 0.95)),
            "detection_median_s": float(np.median(detect)), "inference_s": float(inference_latency),
            "motor_median_s": float(np.median(tm[ok]))}


# ---------------------------------------------------------------- multi-step protocols
def gap_compliance(ends: Sequence[float], starts: Sequence[float], g_min: Sequence[float], g_max: Sequence[float]) -> Dict:
    """S-LAB style mutual-boundary constraints on the gaps between consecutive operations.

    gap_i = start_{i+1} - end_i must lie in [g_min_i, g_max_i].  Returns the compliant share,
    the worst normalised violation and the exposure time (total time spent past g_max, the time a
    sample sat outside its stability window).
    """
    g = np.asarray(starts, dtype=float) - np.asarray(ends, dtype=float)
    lo = np.asarray(g_min, dtype=float); hi = np.asarray(g_max, dtype=float)
    over = np.maximum(0.0, g - hi); under = np.maximum(0.0, lo - g)
    with np.errstate(divide="ignore", invalid="ignore"):
        worst = float(np.nanmax(np.maximum(np.where(hi > 0, over / hi, 0.0), np.where(lo > 0, under / lo, 0.0)))) if g.size else 0.0
    return {"n_gaps": int(g.size), "compliant_share": float(np.mean((over == 0) & (under == 0))) if g.size else float("nan"),
            "worst_normalised_violation": worst, "exposure_time_s": float(over.sum())}


def deadline_margin(t_done: Sequence[float], deadline: Sequence[float]) -> Dict:
    """u = T_done / D_deadline: below 1 met with margin, above 1 missed; never-done is NaN."""
    td = np.asarray(t_done, dtype=float); dl = np.asarray(deadline, dtype=float)
    ok = ~np.isnan(td)
    if ok.sum() == 0:
        return {"n": 0}
    u = td[ok] / dl[ok]
    return {"n": int(ok.sum()), "met_share": float(np.mean(u <= 1.0)), "u_median": float(np.median(u)),
            "u_p95": float(np.quantile(u, 0.95)), "never_done_share": float(np.mean(~ok))}


def track_contrast(sr_a: float, sr_b: float, sr_c: Optional[float] = None) -> Dict:
    """Clock benefit (B - A) and tool benefit (C - B) on the same stratum and tier."""
    out = {"clock_benefit": sr_b - sr_a}
    if sr_c is not None:
        out["tool_benefit"] = sr_c - sr_b
    return out
