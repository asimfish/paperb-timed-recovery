"""Probe-based release gates for the core paired family (proposal 3.5, gates 8 and 9).

Both gates fit a cheap probe on single observation frames and read its out-of-fold score.
They are the frame-level counterparts of the aliasing gate: that gate asks whether a fact is
recoverable *without* memory by an oracle rule; these ask whether a fact leaks into, or is
missing from, the frames a real policy would see.

Gate 8 - temporal aliasing (no visual clock).  On Track A the elapsed time since the pour
must not be predictable from any single post-cue frame.  A dye that keeps spreading, an
assistant arm that returns to rest, a bottle whose level drops, a shadow that moves: every
visibly evolving process is a clock, and a policy that reads it is not internalising time.
The gate passes when the cross-validated R^2 of a ridge probe (linear + squared features)
is at most `r2_max`.  Track B and the timing oracle are *declared* clocks; run on them the
same statistic is the positive control and must be large.

Gate 9 - cue detectability.  The M factor is meant to manipulate whether the identity fact
can be recovered from the *current* frame, not how hard the cue is to see while it is
there.  During the cue window a stateless probe must therefore detect that a pour is
happening (balanced accuracy >= `acc_min`) and which flask receives it (accuracy >=
`acc_min`).  When this gate fails, an M1 failure of a policy is a perception failure and
must not be read as a memory failure.

Everything is numpy: closed-form ridge, Newton-step logistic regression, K-fold splits by
frame with a fixed seed.  Frames from the same episode may fall into different folds; this
is intended - the question is whether the *frame* carries the fact, not whether the episode
can be memorised - but callers should pass frames from many episodes so that the probe
cannot key on episode-specific constants.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Dict, Optional

import numpy as np


@dataclass(frozen=True)
class GateResult:
    name: str
    passed: bool
    statistic: float
    threshold: float
    n: int
    detail: Dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["passed"] = bool(self.passed)
        return d


# ------------------------------------------------------------------ probes
def _expand(X: np.ndarray, kind: str) -> np.ndarray:
    X = np.asarray(X, dtype=np.float64)
    if X.ndim != 2:
        raise ValueError("frames must be a 2-D array (n_frames, n_features)")
    if kind == "linear":
        return X
    if kind == "quadratic":
        return np.concatenate([X, X * X], axis=1)
    raise ValueError(kind)


def _folds(n: int, n_folds: int, seed: int):
    if n < 2 * n_folds:
        raise ValueError(f"need at least {2 * n_folds} frames for {n_folds}-fold CV, got {n}")
    perm = np.random.default_rng(seed).permutation(n)
    return np.array_split(perm, n_folds)


def _standardise(train: np.ndarray, test: np.ndarray):
    mu = train.mean(axis=0)
    sd = train.std(axis=0)
    sd = np.where(sd > 1e-12, sd, 1.0)                      # constant columns stay at zero
    return (train - mu) / sd, (test - mu) / sd


def ridge_r2_cv(X: np.ndarray, y: np.ndarray, n_folds: int = 5, alpha: float = 1e-2,
                seed: int = 0, expand: str = "quadratic") -> float:
    """Pooled out-of-fold R^2 of a ridge probe; <= 0 means 'no better than the mean'."""
    Xe = _expand(X, expand)
    y = np.asarray(y, dtype=np.float64).ravel()
    if y.shape[0] != Xe.shape[0]:
        raise ValueError("X and y must have the same number of frames")
    pred = np.empty_like(y)
    for test_idx in _folds(y.shape[0], n_folds, seed):
        train_mask = np.ones(y.shape[0], dtype=bool)
        train_mask[test_idx] = False
        Xtr, Xte = _standardise(Xe[train_mask], Xe[test_idx])
        ytr = y[train_mask]
        y_mu = ytr.mean()
        d = Xtr.shape[1]
        beta = np.linalg.solve(Xtr.T @ Xtr + alpha * Xtr.shape[0] * np.eye(d), Xtr.T @ (ytr - y_mu))
        pred[test_idx] = Xte @ beta + y_mu
    sst = float(np.sum((y - y.mean()) ** 2))
    if sst <= 0:
        return 0.0                                          # constant target: nothing to predict
    return 1.0 - float(np.sum((y - pred) ** 2)) / sst


def _fit_logistic(X: np.ndarray, y: np.ndarray, alpha: float, n_iter: int) -> np.ndarray:
    """L2-penalised logistic regression by damped Newton steps; X already has an intercept."""
    n, d = X.shape
    w = np.zeros(d)
    reg = alpha * n * np.eye(d)
    reg[0, 0] = 0.0                                         # intercept unpenalised
    for _ in range(n_iter):
        z = X @ w
        p = 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))
        grad = X.T @ (p - y) + reg @ w
        s = np.clip(p * (1.0 - p), 1e-6, None)
        hess = X.T @ (X * s[:, None]) + reg
        step = np.linalg.solve(hess, grad)
        w = w - step
        if np.max(np.abs(step)) < 1e-6:
            break
    return w


def _with_intercept(X: np.ndarray) -> np.ndarray:
    return np.concatenate([np.ones((X.shape[0], 1)), X], axis=1)


def logistic_balanced_accuracy_cv(X: np.ndarray, y: np.ndarray, n_folds: int = 5,
                                  alpha: float = 1e-3, seed: int = 0, n_iter: int = 25) -> float:
    """Out-of-fold balanced accuracy (mean of true-positive and true-negative rate)."""
    X = _expand(X, "linear")
    y = np.asarray(y).astype(bool).ravel()
    if y.shape[0] != X.shape[0]:
        raise ValueError("X and y must have the same number of frames")
    if y.all() or (~y).all():
        raise ValueError("cue detectability needs both cue and non-cue frames")
    pred = np.zeros_like(y)
    for test_idx in _folds(y.shape[0], n_folds, seed):
        train_mask = np.ones(y.shape[0], dtype=bool)
        train_mask[test_idx] = False
        Xtr, Xte = _standardise(X[train_mask], X[test_idx])
        w = _fit_logistic(_with_intercept(Xtr), y[train_mask].astype(np.float64), alpha, n_iter)
        pred[test_idx] = (_with_intercept(Xte) @ w) > 0
    tpr = float(np.mean(pred[y])) if y.any() else 0.0
    tnr = float(np.mean(~pred[~y])) if (~y).any() else 0.0
    return 0.5 * (tpr + tnr)


def multiclass_accuracy_cv(X: np.ndarray, labels: np.ndarray, n_folds: int = 5,
                           alpha: float = 1e-3, seed: int = 0, n_iter: int = 25) -> float:
    """Out-of-fold accuracy of a one-vs-rest logistic probe on integer labels."""
    X = _expand(X, "linear")
    labels = np.asarray(labels).astype(int).ravel()
    classes = np.unique(labels)
    if classes.size < 2:
        raise ValueError("need at least two classes")
    pred = np.empty_like(labels)
    for test_idx in _folds(labels.shape[0], n_folds, seed):
        train_mask = np.ones(labels.shape[0], dtype=bool)
        train_mask[test_idx] = False
        Xtr, Xte = _standardise(X[train_mask], X[test_idx])
        Xtr_i, Xte_i = _with_intercept(Xtr), _with_intercept(Xte)
        scores = np.empty((test_idx.shape[0], classes.size))
        for k, c in enumerate(classes):
            ytr = (labels[train_mask] == c).astype(np.float64)
            if ytr.all() or not ytr.any():
                scores[:, k] = 30.0 if ytr.all() else -30.0
                continue
            scores[:, k] = Xte_i @ _fit_logistic(Xtr_i, ytr, alpha, n_iter)
        pred[test_idx] = classes[np.argmax(scores, axis=1)]
    return float(np.mean(pred == labels))


# ------------------------------------------------------------------ gates
def temporal_aliasing_gate(frames: np.ndarray, elapsed: np.ndarray, r2_max: float = 0.05,
                           n_folds: int = 5, seed: int = 0, expand: str = "quadratic",
                           name: str = "temporal_aliasing") -> GateResult:
    """Gate 8.  `frames` are single post-cue Track A observations, `elapsed` the true time
    since the pour for each frame.  Passes when the probe's out-of-fold R^2 <= r2_max."""
    r2 = ridge_r2_cv(frames, elapsed, n_folds=n_folds, seed=seed, expand=expand)
    e = np.asarray(elapsed, dtype=np.float64)
    return GateResult(name=name, passed=bool(r2 <= r2_max), statistic=float(r2), threshold=r2_max,
                      n=int(e.shape[0]),
                      detail={"elapsed_min_s": float(e.min()), "elapsed_max_s": float(e.max()),
                              "elapsed_sd_s": float(e.std()), "probe": 1.0 if expand == "quadratic" else 0.0})


def cue_detectability_gate(frames: np.ndarray, is_cue: np.ndarray, cue_identity: Optional[np.ndarray] = None,
                           acc_min: float = 0.95, n_folds: int = 5, seed: int = 0,
                           name: str = "cue_detectability") -> GateResult:
    """Gate 9.  `frames` are single observations spanning cue and non-cue ticks, `is_cue`
    marks frames inside the cue window, `cue_identity` (optional) gives the flask index for
    cue frames.  Passes when presence balanced accuracy and (if given) identity accuracy are
    both >= acc_min."""
    is_cue = np.asarray(is_cue).astype(bool).ravel()
    presence = logistic_balanced_accuracy_cv(frames, is_cue, n_folds=n_folds, seed=seed)
    detail = {"presence_balanced_acc": presence, "n_cue_frames": float(is_cue.sum())}
    stat = presence
    if cue_identity is not None:
        ident = multiclass_accuracy_cv(np.asarray(frames)[is_cue], np.asarray(cue_identity)[is_cue],
                                       n_folds=n_folds, seed=seed)
        detail["identity_acc"] = ident
        stat = min(presence, ident)
    return GateResult(name=name, passed=bool(stat >= acc_min), statistic=float(stat), threshold=acc_min,
                      n=int(is_cue.shape[0]), detail=detail)
