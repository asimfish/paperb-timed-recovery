"""The T axis: four temporal constraint types and their violation checkers.

All checkers consume only the EventBus log (plus declared parameters), never
fluid state, per the PBD-drift countermeasure in the proposal.

Verdict vocabulary (ChemSSR V-time family plus two fail-closed kinds added
after review round 1):
- overtime, premature, late, duration_short, duration_long, response_lag,
  rate_breach: genuine temporal violations.
- incomplete: the constraint's anchoring event (trigger / start / stop) never
  occurred by episode end, so the constraint cannot be satisfied. Reported
  instead of a silent "clean" verdict (fail-closed).
- instrumentation_invalid: the referee lacks the instrumentation the task
  declares (no rate samples, sampling clock off-contract). A run with an
  invalid referee is never scored clean.

TRate integrates out-of-band time, not out-of-band sample counts, so the
verdict is invariant to sampling frequency (review round 1, weakness 4).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Optional, Union

from chemrm.events import Event, EventBus

Kind = Literal[
    "overtime", "premature", "late",
    "duration_short", "duration_long",
    "response_lag", "rate_breach",
    "incomplete", "instrumentation_invalid",
]

# Kinds that count as genuine temporal violations (V-time). The two fail-closed
# kinds are reported separately: `incomplete` folds into goal/protocol failure,
# `instrumentation_invalid` voids the episode for scoring.
VTIME_KINDS = frozenset({
    "overtime", "premature", "late", "duration_short", "duration_long",
    "response_lag", "rate_breach",
})


@dataclass(frozen=True)
class Violation:
    constraint: str
    kind: Kind
    detail: str
    t: float

    @property
    def is_vtime(self) -> bool:
        return self.kind in VTIME_KINDS


def _first_after(events: list[Event], t0: float) -> Optional[Event]:
    return next((ev for ev in events if ev.t >= t0), None)


@dataclass
class TEvent:
    """After the trigger event fires, the response event must occur within tau."""

    name: str
    trigger_kind: str                  # e.g. "color_change"
    response_kind: str                 # e.g. "add_stop"
    tau: float                         # allowed response latency, seconds
    trigger_match: dict = field(default_factory=dict)
    response_match: dict = field(default_factory=dict)
    trigger_required: bool = True      # False only for constraints that are
                                       # conditional on an optional event
    persist: float = 0.0               # the trigger counts only once its condition has held for
                                       # `persist` seconds without a `trigger_off_kind` event in
                                       # between (the permanganate endpoint: a pink that persists
                                       # ~30 s; a flicker is not an endpoint)
    trigger_off_kind: str | None = None

    def _trigger_time(self, bus: EventBus, episode_end: float):
        """First trigger whose condition persists for `persist` s; None if none qualifies yet."""
        ons = bus.all(self.trigger_kind, **self.trigger_match)
        if not ons:
            return None, False
        if self.persist <= 0:
            return ons[0].t + 0.0, True
        offs = bus.all(self.trigger_off_kind) if self.trigger_off_kind else []
        for on in ons:
            next_off = _first_after(offs, on.t)
            end = next_off.t if next_off is not None else episode_end
            if end - on.t >= self.persist:
                return on.t + self.persist, True                # the event is dated when persistence is met
        return None, True

    def check(self, bus: EventBus, episode_end: float) -> list[Violation]:
        trig_t, seen = self._trigger_time(bus, episode_end)
        if trig_t is None:
            if not seen:
                if self.trigger_required:
                    return [Violation(self.name, "incomplete",
                                      f"trigger {self.trigger_kind} never occurred", episode_end)]
                return []
            return [Violation(self.name, "incomplete",
                              f"{self.trigger_kind} seen but never persisted {self.persist}s", episode_end)]

        class _T:  # minimal stand-in carrying the qualified trigger time
            t = trig_t
        trig = _T()
        resp = _first_after(bus.all(self.response_kind, **self.response_match), trig.t)
        if resp is None:
            lag = episode_end - trig.t
            if lag > self.tau:
                return [Violation(self.name, "response_lag",
                                  f"no {self.response_kind} within {self.tau}s of "
                                  f"{self.trigger_kind} (waited {lag:.2f}s)", episode_end)]
            return [Violation(self.name, "incomplete",
                              f"episode ended {lag:.2f}s after trigger, before response "
                              f"(tau {self.tau}s not yet exceeded)", episode_end)]
        lag = resp.t - trig.t
        if lag > self.tau:
            return [Violation(self.name, "response_lag",
                              f"responded {lag:.2f}s after trigger (limit {self.tau}s)", resp.t)]
        return []


@dataclass
class TDeadline:
    """The goal event must occur within D seconds of a start event (or t=0)."""

    name: str
    goal_kind: str
    deadline: float
    start_kind: Optional[str] = None   # None = episode start (t = 0)
    goal_match: dict = field(default_factory=dict)
    start_match: dict = field(default_factory=dict)

    def check(self, bus: EventBus, episode_end: float) -> list[Violation]:
        t0 = 0.0
        if self.start_kind is not None:
            start = bus.first(self.start_kind, **self.start_match)
            if start is None:
                return [Violation(self.name, "incomplete",
                                  f"start {self.start_kind} never occurred", episode_end)]
            t0 = start.t
        goal = _first_after(bus.all(self.goal_kind, **self.goal_match), t0)
        if goal is None:
            if episode_end - t0 > self.deadline:
                return [Violation(self.name, "overtime",
                                  f"{self.goal_kind} not achieved within {self.deadline}s",
                                  episode_end)]
            return [Violation(self.name, "incomplete",
                              f"episode ended before {self.goal_kind} (deadline not yet exceeded)",
                              episode_end)]
        if goal.t - t0 > self.deadline:
            return [Violation(self.name, "overtime",
                              f"achieved at +{goal.t - t0:.2f}s (deadline {self.deadline}s)",
                              goal.t)]
        return []


@dataclass
class TDuration:
    """Interval between a start and a stop event must last D +/- eps seconds.

    style="hold": stir for D (short -> duration_short, long -> duration_long).
    style="gap":  wait D between two acts, the C13 pattern (early -> premature,
                  late -> late).

    Missing stop is classified against the window at episode end: past the
    upper bound it is a genuine late/long violation; otherwise the interval is
    simply `incomplete` (the act never happened) - never a silent pass and
    never a false "short".
    """

    name: str
    start_kind: str
    stop_kind: str
    duration: float
    eps: float
    start_match: dict = field(default_factory=dict)
    stop_match: dict = field(default_factory=dict)
    style: Literal["hold", "gap"] = "hold"
    eps_lo: float | None = None        # asymmetric window [D - eps_lo, D + eps_hi]; None = eps
    eps_hi: float | None = None        # (over-exposure and under-exposure rarely cost the same:
                                       #  a Gram-stain decolorisation left too long is irreversible)

    @property
    def lower(self) -> float:
        return self.duration - (self.eps if self.eps_lo is None else self.eps_lo)

    @property
    def upper(self) -> float:
        return self.duration + (self.eps if self.eps_hi is None else self.eps_hi)

    def _short_kind(self) -> Kind:
        return "duration_short" if self.style == "hold" else "premature"

    def _long_kind(self) -> Kind:
        return "duration_long" if self.style == "hold" else "late"

    def check(self, bus: EventBus, episode_end: float) -> list[Violation]:
        start = bus.first(self.start_kind, **self.start_match)
        if start is None:
            return [Violation(self.name, "incomplete",
                              f"start {self.start_kind} never occurred", episode_end)]
        stop = _first_after(bus.all(self.stop_kind, **self.stop_match), start.t)
        if stop is None:
            elapsed = episode_end - start.t
            if elapsed > self.upper:
                return [Violation(self.name, self._long_kind(),
                                  f"no {self.stop_kind} within {self.upper:.2f}s "
                                  f"of {self.start_kind} (elapsed {elapsed:.2f}s)", episode_end)]
            return [Violation(self.name, "incomplete",
                              f"episode ended {elapsed:.2f}s after {self.start_kind}, "
                              f"no {self.stop_kind} yet (window upper bound not exceeded)",
                              episode_end)]
        held = stop.t - start.t
        if held < self.lower:
            return [Violation(self.name, self._short_kind(),
                              f"interval {held:.2f}s < {self.lower:.2f}s", stop.t)]
        if held > self.upper:
            return [Violation(self.name, self._long_kind(),
                              f"interval {held:.2f}s > {self.upper:.2f}s", stop.t)]
        return []


@dataclass
class TRate:
    """A sampled process variable must stay inside [lo, hi] (time-weighted).

    Instrumentation contract: the environment samples the variable into
    `rate_sample` events on a fixed clock of `sample_period` seconds. Each
    sample's value is held until the next sample (zero-order hold); the last
    sample is held for one period. The violation statistic is the fraction of
    TIME spent out of band, so doubling the sampling rate cannot change it.

    Fail-closed: no samples, inter-sample gaps drifting more than
    `max_gap_ratio` x the declared period, the median gap off the declared
    period by more than that ratio, or the samples not COVERING the active
    interval (from `active_start_kind` to `active_end_kind`, default: first
    sample to episode end) within one tolerated gap at each end - all yield
    `instrumentation_invalid` (review round 2: a 99 s tail without samples
    must not score clean).
    """

    name: str
    variable: str                      # payload key, e.g. "rate_ml_s"
    lo: float
    hi: float
    sample_period: float               # declared sampling clock, seconds
    max_breach_fraction: float = 0.05  # tolerated out-of-band TIME fraction
    max_gap_ratio: float = 2.0
    sample_kind: str = "rate_sample"
    sample_match: dict = field(default_factory=dict)
    active_start_kind: Optional[str] = None   # e.g. "add_reagent"
    active_end_kind: Optional[str] = None     # e.g. "add_stop"
    active_match: dict = field(default_factory=dict)

    def check(self, bus: EventBus, episode_end: float) -> list[Violation]:
        samples = [ev for ev in bus.all(self.sample_kind, **self.sample_match)
                   if self.variable in ev.payload]
        if not samples:
            return [Violation(self.name, "instrumentation_invalid",
                              f"no {self.sample_kind} events carrying {self.variable!r}",
                              episode_end)]
        tol = self.max_gap_ratio * self.sample_period
        gaps = [b.t - a.t for a, b in zip(samples, samples[1:])]
        if any(g > tol for g in gaps):
            return [Violation(self.name, "instrumentation_invalid",
                              f"sampling gap {max(gaps):.3f}s exceeds {tol:.3f}s "
                              f"({self.max_gap_ratio} x declared period)", episode_end)]
        if gaps:
            med = sorted(gaps)[len(gaps) // 2]
            if not (self.sample_period / self.max_gap_ratio <= med <= tol):
                return [Violation(self.name, "instrumentation_invalid",
                                  f"median sampling gap {med:.3f}s off the declared "
                                  f"period {self.sample_period}s", episode_end)]
        # active interval: declared anchors are mandatory once declared (fail-closed)
        if self.active_start_kind:
            a_start = bus.first(self.active_start_kind, **self.active_match)
            if a_start is None:
                return [Violation(self.name, "instrumentation_invalid",
                                  f"declared active-start anchor {self.active_start_kind} never emitted",
                                  episode_end)]
            t_start = a_start.t
        else:
            t_start = samples[0].t
        if self.active_end_kind:
            a_end = bus.first(self.active_end_kind, **self.active_match)
            if a_end is None:
                return [Violation(self.name, "instrumentation_invalid",
                                  f"declared active-end anchor {self.active_end_kind} never emitted",
                                  episode_end)]
            t_end = a_end.t
        else:
            t_end = samples[-1].t + self.sample_period   # sample-and-hold: one period after the last sample
        if samples[0].t - t_start > tol or t_end - samples[-1].t > tol:
            return [Violation(self.name, "instrumentation_invalid",
                              f"samples cover [{samples[0].t:.2f}, {samples[-1].t:.2f}] but the "
                              f"active interval is [{t_start:.2f}, {t_end:.2f}]", episode_end)]
        # zero-order hold, clipped to the active interval
        holds = []
        for ev, nxt in zip(samples, samples[1:] + [None]):
            h_start = max(ev.t, t_start)
            h_end = min(nxt.t if nxt else ev.t + self.sample_period, t_end)
            holds.append(max(h_end - h_start, 0.0))
        total = sum(holds)
        out_time = 0.0
        worst: Optional[Event] = None
        worst_dev = -1.0
        mid = (self.lo + self.hi) / 2
        for ev, hold in zip(samples, holds):
            v = float(ev.payload[self.variable])
            if not (self.lo <= v <= self.hi):
                out_time += hold
                dev = abs(v - mid)
                if dev > worst_dev:
                    worst_dev, worst = dev, ev
        frac = out_time / total if total > 0 else 0.0
        if frac > self.max_breach_fraction:
            assert worst is not None
            return [Violation(self.name, "rate_breach",
                              f"{frac:.0%} of time outside [{self.lo}, {self.hi}] "
                              f"(worst {worst.payload[self.variable]})", worst.t)]
        return []


TemporalConstraint = Union[TEvent, TDeadline, TDuration, TRate]


def check_constraints(constraints: list[TemporalConstraint], bus: EventBus,
                      episode_end: float) -> list[Violation]:
    """Run every checker. Split the result with `split_verdicts` for scoring."""
    out: list[Violation] = []
    for c in constraints:
        out.extend(c.check(bus, episode_end))
    return out


def split_verdicts(violations: list[Violation]) -> dict[str, list[Violation]]:
    """Partition into the three scoring buckets used by the pass vector."""
    return {
        "vtime": [v for v in violations if v.is_vtime],
        "incomplete": [v for v in violations if v.kind == "incomplete"],
        "invalid": [v for v in violations if v.kind == "instrumentation_invalid"],
    }
