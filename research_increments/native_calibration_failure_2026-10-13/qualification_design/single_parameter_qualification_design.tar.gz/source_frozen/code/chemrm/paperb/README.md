# Paper B Q0a development control

This module implements a causal observation-record teacher and the four student
cells WA/WB/RA/RB. It reuses the frozen Gate 0 environment and networks without
changing their condition registry, labels, training code, or results.

From the repository root:

```bash
python3 -m pytest tests/test_paperb_q0a.py -q
python3 -m chemrm.paperb.run_q0a --out pilot/paperB/q0a/my_dev_run --n-train 256 --n-eval 32 --epochs 12 --batch 32 --threads 2
```

The output directory must not exist; a previous run is never overwritten. CPU
PyTorch and NumPy are sufficient. No API credentials or GPU are needed. Evaluation
uses paired episodes across cells and three cadence conditions. `--train-cadence`
selects training cadence; fixed training followed by perturbed evaluation is a
distribution-shift experiment, not a reproduction of the matched-distribution F1
add-on.

## What is implemented

- WA/WB use the same single-frame MLP; RA/RB use the same GRU. B cells get a bare
  timestamp. All cells receive numerical D and have all oracle values/flags zeroed.
- `RecordTeacher.step` sees one current observation and public task tolerance. It
  detects the pouring cue, stores identity and the bracketed start-time estimate,
  and accounts for skill execution duration. It does not receive episode truth.
- The teacher is an **active scheduler**. It emits a short target-centered action
  band for full-prefix supervised training. Unknown event starts and expired
  windows produce wait plus a diagnostic status. Veto-only scheduling is not yet
  implemented; this is not a safety certificate for arbitrary robot states.
- The runner trains all four cells with identical optimization/query budgets and
  saves four checkpoints, losses, source hashes, configuration, paired episode
  records, stratified scores, and a concise result table.
- Reset, prefix causality, input-channel isolation, parameter matching, teacher
  behavior against the independent referee, and the complete runner are tested.

## Diagnostic controls (not competition scores)

The runner accepts four diagnostic flags. Any non-default value marks the manifest
and `RESULTS.md` as `diagnostic`; such runs live under `pilot/paperB/q0a_diag/` and
never enter Track A/B comparisons.

| Flag | Default | Purpose |
|---|---|---|
| `--oracle both` | `none` | Students also read the identity and timing oracle channels (12–20). Positive control: supplies both latent facts directly, so a student that still fails has a label/optimisation problem, not a memory or clock limit. |
| `--act-weight W` | `10` | Loss weight of act ticks in tight episodes (Gate 0 used 10). |
| `--band-s B` / `full` | `0.75` | Teacher label band above the estimated target. `full` labels the whole late half of the referee window minus the onset-estimate uncertainty, so every labelled tick is admissible under the true event time. The band only changes label density; the referee is untouched. |
| `--cells RA,RB` | all four | Subset of cells. |

Every student row in `episodes.jsonl` also records `p_target_in_window` (largest
softmax probability of the correct act at any tick whose landing time the referee
would accept) and `p_act_peak` (largest 1 − P(wait) over the episode). A never-acting
student with `p_target_in_window` near 0.5 is under-confident at the right time; one
near 0 has no timing signal. `summary.json` carries the per-cell medians.

`python3 -m chemrm.paperb.summarize <run_dirs>` prints one Markdown table over any
set of runs; `python3 -m chemrm.paperb.readout <run_dir>` re-evaluates saved
checkpoints under fixed cadence and writes `readout.json` (for runs recorded before
the read-outs existed). Results of the first diagnostic round are in
[pilot/paperB/Q0A_DIAGNOSTICS_2026-09-12.md](../../pilot/paperB/Q0A_DIAGNOSTICS_2026-09-12.md).

## Interpretation boundaries

This is **full-prefix observation-teacher distillation**, not OPD, offline RL,
online RL, or a comparison of those algorithms. The scene is exogenous until the
first terminal action; records after a hypothetical first action are training
prefixes, not executed recovery trajectories. Teacher query counts refer to this
shared full-prefix labeling pass. No unseen-state recovery claim follows.

The first observed cue brackets the start time; its midpoint is an estimate, not
the hidden `t_a`. A mid-cue reset cannot establish its start and returns
`unknown_start` on a tight task. All task cells remain in evaluation even if a
teacher fails. A missing or zero teacher denominator yields undefined retention.
Single-seed development runs do not test the proposal's retention hypotheses.

Remaining work: separately budgeted offline/occupancy-matched controls, synchronous
student-rollout collection, matched-cadence training, timing-cue calibration
controls, and the multi-step Q0b environment. See
[Q0 design](../../pilot/paperB/Q0_DESIGN_DRAFT.md).
