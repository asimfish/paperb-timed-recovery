"""Four students and a causal observation-driven teacher for the Q0a control.

The teacher receives only current observations and public task tolerance. Episode
truth is available exclusively to the runner's environment and referee.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from chemrm.gate0.env import (OBS_CLOCK, OBS_D, OBS_DIM, OBS_POURED, OBS_TIGHT,
                             SKILL_TIME, TIME_SCALE)
from chemrm.gate0.policies import ReactivePolicy, RecurrentPolicy

CELLS = {"WA": (False, False), "WB": (False, True),
         "RA": (True, False), "RB": (True, True)}


def make_student(cell):
    recurrent, _ = CELLS[cell]
    return RecurrentPolicy() if recurrent else ReactivePolicy()


ORACLE_CHANNELS = slice(12, 21)   # identity + timing oracle flags/values (zeroed in competition cells)


def student_observations(observations, cell, oracle=False, clock_encoding='raw'):
    """Copy and enforce the declared channel budget, including masked-oracle flags.

    `oracle=True` keeps the identity and timing oracle channels. That is a diagnostic
    positive control only: it supplies the two latent facts directly, so a student that
    still fails to act indicates a label/optimisation problem rather than a memory or
    clock limit. Never use it for Track A/B competition scores.
    """
    _, clock = CELLS[cell]
    if clock_encoding not in ('raw', 'bounded'):
        raise ValueError("clock_encoding must be raw or bounded")
    out = np.array(observations, dtype=np.float32, copy=True)
    if out.shape[-1] != OBS_DIM:
        raise ValueError("Expected 22 observation channels")
    if not oracle:
        out[..., ORACLE_CHANNELS] = 0
    if not clock:
        out[..., OBS_CLOCK] = 0
    elif clock_encoding == 'bounded':
        # Keep one scalar channel and the same network parameter count.  The
        # Gate 0 horizon is 160 s, so this maps its declared clock to [0, 1].
        # This is a representation diagnostic, not an extra information channel.
        out[..., OBS_CLOCK] = np.clip(out[..., OBS_CLOCK] / 16.0, 0.0, 1.0)
    return out


@dataclass(frozen=True)
class Decision:
    action: int
    status: str
    target_time: float | None
    source: str = "observation_record"
    intervention_kind: str = "active_scheduler"


DEFAULT_BAND_S = 0.75   # s; one-sided label band above the estimated target (landing >= target)


class RecordTeacher:
    """One-episode active scheduler; timing estimate is the detection-interval midpoint.

    The first observed cue is bracketed by the preceding empty observation and
    current time. If reset occurs during a cue, its start is not identifiable:
    tight timing is withheld. The persistent dye is deliberately not used to
    invent an unobserved start time. Expired decisions remain failure diagnostics.

    `band_s` is the width of the label band: ticks whose landing falls in
    [target, target + min(band_s, eta * D)] are labelled act. The default 0.75 s
    gives one or two act ticks per tight episode at DT = 0.5 s; `math.inf` labels
    the whole late half of the referee window. The band only changes label
    density; the referee window is untouched.
    """

    def __init__(self, band_s=DEFAULT_BAND_S):
        if not band_s > 0:
            raise ValueError("Label band must be positive")
        self.band_s = float(band_s)
        self.reset()

    def reset(self):
        self.flask = None
        self.start_interval = None
        self.previous_time = None
        self.cue_ended = False

    def step(self, observation, eta):
        obs = np.asarray(observation)
        if obs.shape != (OBS_DIM,):
            raise ValueError("Teacher expects a single current observation")
        # Ignore oracle and dye channels, even if a caller supplies them.
        allowed = obs[np.r_[5:12, OBS_CLOCK]]
        if not np.isfinite(allowed).all():
            raise ValueError("Nonfinite permitted observation")
        t = float(obs[OBS_CLOCK]) * TIME_SCALE
        if t < 0 or (self.previous_time is not None and t <= self.previous_time):
            raise ValueError("Clock must strictly increase within an episode; reset between episodes")
        if not np.isfinite(eta) or eta < 0:
            raise ValueError("Invalid task tolerance")
        cue = obs[OBS_POURED]
        if not np.all((cue == 0) | (cue == 1)) or cue.sum() > 1:
            raise ValueError("Q0a requires zero or one visible pouring cue")
        pouring = bool(cue.sum())
        if self.flask is None and pouring:
            self.flask = int(cue.argmax())
            if self.previous_time is not None:
                self.start_interval = (self.previous_time, t)
        elif self.flask is not None and not pouring:
            self.cue_ended = True
        self.previous_time = t
        if self.flask is None:
            return Decision(0, "unobserved", None)
        if not bool(obs[OBS_TIGHT]):
            return Decision(1 + self.flask if self.cue_ended else 0,
                            "ready" if self.cue_ended else "waiting", None)
        if self.start_interval is None:
            return Decision(0, "unknown_start", None)
        d = float(obs[OBS_D]) * TIME_SCALE
        if d <= 0:
            raise ValueError("Tight task requires positive D")
        target = sum(self.start_interval) / 2 + d
        landing = t + float(SKILL_TIME[self.flask])
        if landing > target + eta * d:
            return Decision(0, "expired", target)
        # A narrow target band gives a full-prefix supervised control, not an
        # instruction to act at every time in the broad referee window. The late edge
        # keeps a margin equal to the onset-estimate uncertainty (half the detection
        # interval), so every labelled tick is admissible under the true event time.
        half_interval = (self.start_interval[1] - self.start_interval[0]) / 2
        late_edge = target + max(0., min(self.band_s, eta * d - half_interval))
        ready = self.cue_ended and target <= landing <= late_edge
        return Decision(1 + self.flask if ready else 0,
                        "ready" if ready else "waiting", target)


def teacher_sequences(observations, eta, band_s=DEFAULT_BAND_S):
    """Causal replay, resetting record for every row. No truth or future input."""
    n, steps, _ = observations.shape
    if np.shape(eta) != (n,):
        raise ValueError("One public tolerance required per episode")
    actions = np.zeros((n, steps), dtype=np.int64)
    teacher = RecordTeacher(band_s)
    for i in range(n):
        teacher.reset()
        for k in range(steps):
            actions[i, k] = teacher.step(observations[i, k], eta[i]).action
    return actions
