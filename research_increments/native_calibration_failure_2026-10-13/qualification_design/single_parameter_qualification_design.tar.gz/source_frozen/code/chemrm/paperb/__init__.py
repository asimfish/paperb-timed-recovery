"""Paper B development experiments; independent of the frozen Gate 0 pilot."""
