"""Lightweight process models driving the T axis with physical consequences.

Route chosen in proposal section 5.2: calibrated parameters + first-order ODEs,
no real chemistry solver. Both models are stepped from the same SimClock dt so
"overtime" manifests physically (color crosses a threshold, smoke fires) rather
than only in the final score.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from chemrm.events import EventBus


@dataclass
class ColorKinetics:
    """First-order color response to a driving concentration signal.

    x(t) follows dx/dt = (u - x) / tau, with u the input drive in [0, 1]
    (e.g. indicator concentration past the equivalence point) and x the
    displayed color intensity in [0, 1]. Crossing `threshold` upward emits a
    single `color_change` event: the T(event) trigger for tasks like C5.

    Closed form under constant u from x0: x(t) = u + (x0 - u) * exp(-t / tau).
    Time to reach threshold from 0 under u=1: t* = -tau * ln(1 - threshold).

    Material coupling (v0.3): instead of an externally set drive, call
    `add_titrant(volume_ml)` and the drive follows a logistic step around the
    equivalence volume `v_eq_ml` with transition width `w_ml`:
        u = 1 / (1 + exp(-(V - V_eq) / w))
    so the endpoint is reached by adding the right AMOUNT, not by a script.
    This is a calibrated low-order surrogate, not a pH model; MATTERIX's
    kinetics engine is the reference for anything richer.
    """

    bus: EventBus
    tau: float = 2.0                # seconds; response time constant
    threshold: float = 0.5          # intensity that counts as "visibly changed"
    vessel: str = "beaker_0"
    intensity: float = 0.0
    drive: float = 0.0
    v_eq_ml: float = 10.0           # equivalence volume of titrant
    w_ml: float = 0.3               # logistic transition width around V_eq
    added_ml: float = 0.0
    _fired: bool = field(default=False, repr=False)

    def set_drive(self, u: float) -> None:
        self.drive = min(max(u, 0.0), 1.0)

    def add_titrant(self, volume_ml: float) -> float:
        """Material-driven drive: cumulative titrant volume vs equivalence."""
        self.added_ml += max(volume_ml, 0.0)
        z = (self.added_ml - self.v_eq_ml) / self.w_ml
        self.drive = 1.0 / (1.0 + math.exp(-z))
        return self.drive

    def step(self, dt: float) -> float:
        # exact exponential update: stable for any dt
        a = math.exp(-dt / self.tau)
        self.intensity = self.drive + (self.intensity - self.drive) * a
        if not self._fired and self.intensity >= self.threshold:
            self._fired = True
            self.bus.emit("color_change", vessel=self.vessel, intensity=self.intensity)
        return self.intensity

    def time_to_threshold(self, from_intensity: float = 0.0) -> float:
        """Analytic crossing time under the current drive (inf if unreachable)."""
        u, th = self.drive, self.threshold
        if u <= th or from_intensity >= th:
            return 0.0 if from_intensity >= th else math.inf
        return -self.tau * math.log((u - th) / (u - from_intensity))


@dataclass
class ThermalModel:
    """Newtonian cooling plus an exotherm source coupled to addition rate.

    dT/dt = -k * (T - T_amb) + q(t) * h_mix / (cp * V(t))

    q(t) is the reagent addition rate (mL/s), fed via `set_addition_rate` or
    by subscribing to `add_reagent` / `add_stop` events on this vessel. The
    exotherm term is a mixing enthalpy per mL of reagent (`h_mix`, J/mL)
    spread over the current liquid volume V(t) (mL, grows with additions) and
    heat capacity cp (J/(mL K)) - so the same rate heats a small volume more
    than a large one. If the temperature exceeds `t_smoke`, a single
    irreversible `smoke` event fires (task C11 consequence).

    Calibrated low-order surrogate (energy balance with lumped parameters);
    MATTERIX's heat-transfer semantics is the reference for conduction /
    convection detail.
    """

    bus: EventBus
    k: float = 0.05                 # 1/s cooling constant
    t_amb: float = 25.0             # deg C ambient
    h_mix: float = 400.0            # J per mL of added reagent (mixing enthalpy)
    cp: float = 4.18                # J/(mL K), water-like
    volume_ml: float = 100.0        # current liquid volume, grows with additions
    t_smoke: float = 80.0           # deg C irreversible threshold
    vessel: str = "beaker_0"
    temperature: float = 25.0
    addition_rate: float = 0.0      # mL/s
    _smoked: bool = field(default=False, repr=False)

    def __post_init__(self) -> None:
        self.bus.subscribe(self._on_event)

    def _on_event(self, ev) -> None:
        if ev.kind == "add_reagent" and ev.payload.get("vessel") == self.vessel:
            self.addition_rate = float(ev.payload.get("rate_ml_s", 0.0))
        if ev.kind == "add_stop" and ev.payload.get("vessel") == self.vessel:
            self.addition_rate = 0.0

    def set_addition_rate(self, q: float) -> None:
        self.addition_rate = max(q, 0.0)

    @property
    def smoked(self) -> bool:
        return self._smoked

    @property
    def c_exo(self) -> float:
        """Effective heating gain (K per mL) at the current volume."""
        return self.h_mix / (self.cp * self.volume_ml)

    def step(self, dt: float) -> float:
        # exact update of the linear ODE with the source held over dt; the
        # volume added during dt is accounted for after the step
        drive = self.t_amb + (self.c_exo / self.k) * self.addition_rate
        a = math.exp(-self.k * dt)
        self.temperature = drive + (self.temperature - drive) * a
        self.volume_ml += self.addition_rate * dt
        if not self._smoked and self.temperature >= self.t_smoke:
            self._smoked = True
            self.bus.emit("smoke", vessel=self.vessel, temperature=self.temperature)
        return self.temperature

    def steady_state_rate_limit(self) -> float:
        """Max sustained addition rate (mL/s) that never reaches t_smoke at the
        CURRENT volume (conservative: the limit relaxes as volume grows)."""
        return self.k * (self.t_smoke - self.t_amb) / self.c_exo
