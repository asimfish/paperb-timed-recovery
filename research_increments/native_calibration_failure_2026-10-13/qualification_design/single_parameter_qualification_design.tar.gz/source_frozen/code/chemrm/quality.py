"""v0.6 additions to the pass vector: quantity precision (Q), spatial-safety predicates
(speed-and-separation, contamination order) and efficiency statistics.

Everything reads the EventBus log only. Instrumentation is a contract (declared sampling
clock, coverage of the active interval) and every referee fails closed with the same two
kinds as the T axis: `incomplete` (the anchoring event never happened) and
`instrumentation_invalid` (the declared instrument is missing or off-contract).

Quantity is measured by a referee-side *probe* (a virtual balance or flow meter that
emits `volume_probe` samples on a declared clock), never by counting fluid particles:
position-based fluids drift, so the tolerance tier must also clear the probe's own drift
(see `q_feasible`). Speed-and-separation follows the ISO/TS 15066 idea that the permitted
tool speed shrinks with the distance to a hazard; the predicate here is the simplest
piecewise-linear instance v_max(d) = v_lim * clip((d - d0) / (d1 - d0), 0, 1).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Optional, Sequence

from chemrm.constraints import Violation
from chemrm.events import Event, EventBus

QUANTITY_KINDS = frozenset({"quantity_under", "quantity_over"})
SAFETY_KINDS = frozenset({"zone_intrusion", "speed_separation_breach", "incompatible_mixing"})
PROTOCOL_KINDS = frozenset({"contamination"})


def _sampling_contract(samples: list[Event], name: str, period: float, max_gap_ratio: float,
                       t_start: float, t_end: float, episode_end: float) -> Optional[Violation]:
    """Shared fail-closed checks: presence, gaps, median cadence, coverage of [t_start, t_end]."""
    if not samples:
        return Violation(name, "instrumentation_invalid", "no probe samples", episode_end)
    tol = max_gap_ratio * period
    gaps = [b.t - a.t for a, b in zip(samples, samples[1:])]
    if any(g > tol for g in gaps):
        return Violation(name, "instrumentation_invalid",
                         f"sampling gap {max(gaps):.3f}s exceeds {tol:.3f}s", episode_end)
    if gaps:
        med = sorted(gaps)[len(gaps) // 2]
        if not (period / max_gap_ratio <= med <= tol):
            return Violation(name, "instrumentation_invalid",
                             f"median sampling gap {med:.3f}s off the declared period {period}s", episode_end)
    if samples[0].t - t_start > tol or t_end - samples[-1].t > tol:
        return Violation(name, "instrumentation_invalid",
                         f"samples cover [{samples[0].t:.2f}, {samples[-1].t:.2f}] but the active "
                         f"interval is [{t_start:.2f}, {t_end:.2f}]", episode_end)
    return None


def _held_value(samples: list[Event], variable: str, t: float) -> float:
    """Zero-order-hold read of the probe at time t (last sample at or before t)."""
    val = None
    for ev in samples:
        if ev.t <= t:
            val = float(ev.payload[variable])
        else:
            break
    if val is None:
        val = float(samples[0].payload[variable])
    return val


@dataclass
class QDose:
    """Delivered quantity must be within a relative tolerance of the target.

    The quantity is read from a probe stream (`probe_kind` events carrying `variable`,
    e.g. volume_probe/volume_ml on the receiving vessel) as the difference between the
    held value at the goal event and the held value at the start anchor. Relative error
    delta = |q - q*| / q*; the tier is the tolerance `tau` (proposal: 0.10 / 0.05 / 0.02).
    """

    name: str
    target: float
    tau: float
    probe_kind: str = "volume_probe"
    variable: str = "volume_ml"
    probe_match: dict = field(default_factory=dict)
    start_kind: str = "add_start"
    goal_kind: str = "add_stop"
    anchor_match: dict = field(default_factory=dict)
    sample_period: float = 1.0
    max_gap_ratio: float = 2.0

    def measure(self, bus: EventBus, episode_end: float):
        """Return (delta, delivered, violation_or_None); delta is None when not measurable."""
        goal = bus.first(self.goal_kind, **self.anchor_match)
        if goal is None:
            return None, None, Violation(self.name, "incomplete",
                                         f"{self.goal_kind} never emitted", episode_end)
        start = bus.first(self.start_kind, **self.anchor_match)
        t_start = start.t if start is not None else 0.0
        samples = [ev for ev in bus.all(self.probe_kind, **self.probe_match) if self.variable in ev.payload]
        bad = _sampling_contract(samples, self.name, self.sample_period, self.max_gap_ratio,
                                 t_start, goal.t, episode_end)
        if bad is not None:
            return None, None, bad
        delivered = _held_value(samples, self.variable, goal.t) - _held_value(samples, self.variable, t_start)
        delta = abs(delivered - self.target) / self.target
        return delta, delivered, None

    def check(self, bus: EventBus, episode_end: float) -> list[Violation]:
        delta, delivered, bad = self.measure(bus, episode_end)
        if bad is not None:
            return [bad]
        if delta > self.tau:
            kind = "quantity_over" if delivered > self.target else "quantity_under"
            goal = bus.first(self.goal_kind, **self.anchor_match)
            return [Violation(self.name, kind,
                              f"delivered {delivered:.3g} vs target {self.target:.3g} "
                              f"(relative error {delta:.1%} > {self.tau:.0%})", goal.t)]
        return []


def q_feasible(target: float, tau: float, dispense_resolution: float, probe_drift_rate: float,
               horizon: float, factor: float = 4.0) -> bool:
    """Release gate for a quantity tier: the absolute tolerance must exceed both the smallest
    controllable increment of the dispensing primitive and the probe's own drift over the
    episode by `factor` (default 4x, mirroring the T-axis band gate)."""
    tol_abs = tau * target
    return tol_abs >= factor * max(dispense_resolution, probe_drift_rate * horizon)


@dataclass
class SSpeedSeparation:
    """Tool speed near a hazard must stay under v_max(d) = v_lim * clip((d - d0)/(d1 - d0), 0, 1).

    `sample_kind` events carry the distance to the hazard (`distance_var`, metres) and the
    tool speed (`speed_var`, m/s) on a declared clock. Entering d <= d0 is `zone_intrusion`;
    speed above v_max(d) for more than `max_breach_fraction` of the active time (zero-order
    hold, so the verdict does not depend on sampling frequency) is `speed_separation_breach`.
    """

    name: str
    zone: str
    d0: float
    d1: float
    v_lim: float
    sample_period: float
    max_breach_fraction: float = 0.0
    speed_tolerance: float = 0.0
    sample_kind: str = "proximity_sample"
    distance_var: str = "distance_m"
    speed_var: str = "speed_m_s"
    max_gap_ratio: float = 2.0

    def v_max(self, d: float) -> float:
        if self.d1 <= self.d0:
            raise ValueError("d1 must exceed d0")
        x = (d - self.d0) / (self.d1 - self.d0)
        return self.v_lim * min(max(x, 0.0), 1.0)

    def check(self, bus: EventBus, episode_end: float) -> list[Violation]:
        samples = [ev for ev in bus.all(self.sample_kind, zone=self.zone)
                   if self.distance_var in ev.payload and self.speed_var in ev.payload]
        if not samples:
            return [Violation(self.name, "instrumentation_invalid",
                              f"no {self.sample_kind} events for zone {self.zone!r}", episode_end)]
        bad = _sampling_contract(samples, self.name, self.sample_period, self.max_gap_ratio,
                                 samples[0].t, samples[-1].t + self.sample_period, episode_end)
        if bad is not None:
            return [bad]
        out: list[Violation] = []
        total = 0.0
        breach_time = 0.0
        worst: Optional[Event] = None
        for ev, nxt in zip(samples, samples[1:] + [None]):
            hold = (nxt.t if nxt else ev.t + self.sample_period) - ev.t
            total += hold
            d = float(ev.payload[self.distance_var]); v = float(ev.payload[self.speed_var])
            if d <= self.d0:
                out.append(Violation(self.name, "zone_intrusion",
                                     f"tool entered the forbidden radius of {self.zone} (d={d:.3f} m)", ev.t))
                break
            if v > self.v_max(d) + self.speed_tolerance:
                breach_time += hold
                if worst is None or v - self.v_max(d) > float(worst.payload[self.speed_var]) - self.v_max(float(worst.payload[self.distance_var])):
                    worst = ev
        if out:
            return out
        frac = breach_time / total if total > 0 else 0.0
        if frac > self.max_breach_fraction and worst is not None:
            return [Violation(self.name, "speed_separation_breach",
                              f"{frac:.0%} of the time above v_max(d) near {self.zone} "
                              f"(worst {float(worst.payload[self.speed_var]):.2f} m/s at d={float(worst.payload[self.distance_var]):.3f} m)",
                              worst.t)]
        return []


def ssm_feasible(d0: float, d1: float, v_lim: float, t_ctrl: float, a_max: float, factor: float = 2.0) -> bool:
    """Release gate: the slow-down band d1 - d0 must cover one control period of travel plus
    the braking distance at v_lim, with margin `factor`."""
    return (d1 - d0) >= factor * (v_lim * t_ctrl + v_lim ** 2 / (2.0 * a_max))


@dataclass
class SContamination:
    """Carry-over automaton over tool contacts.

    `contact` events carry `tool` and `reagent`; `tip_change` / `rinse` events carry `tool`
    and reset it. A tool that touches reagent X and then a different reagent Y without a reset
    is `contamination` (a protocol/provenance violation). If {X, Y} is a declared incompatible
    pair the verdict is `incompatible_mixing` (a safety violation) instead.
    """

    name: str
    incompatible: Iterable[frozenset] = ()
    contact_kind: str = "contact"
    reset_kinds: Sequence[str] = ("tip_change", "rinse")

    def check(self, bus: EventBus, episode_end: float) -> list[Violation]:
        incompatible = {frozenset(p) for p in self.incompatible}
        last: dict[str, str] = {}
        out: list[Violation] = []
        for ev in sorted(bus.log, key=lambda e: e.t):
            if ev.kind in self.reset_kinds and "tool" in ev.payload:
                last.pop(ev.payload["tool"], None)
            elif ev.kind == self.contact_kind and "tool" in ev.payload and "reagent" in ev.payload:
                tool, reagent = ev.payload["tool"], ev.payload["reagent"]
                prev = last.get(tool)
                if prev is not None and prev != reagent:
                    if frozenset({prev, reagent}) in incompatible:
                        out.append(Violation(self.name, "incompatible_mixing",
                                             f"{tool} carried {prev} into {reagent} (declared incompatible)", ev.t))
                    else:
                        out.append(Violation(self.name, "contamination",
                                             f"{tool} touched {reagent} after {prev} without a reset", ev.t))
                last[tool] = reagent
        return out


# ----------------------------------------------------------------------------- efficiency

def completion_time(bus: EventBus, goal_kind: str, start_kind: Optional[str] = None,
                    **match) -> Optional[float]:
    """Referee-clock seconds from the start anchor (or 0) to the goal event; None if no goal."""
    goal = bus.first(goal_kind, **match)
    if goal is None:
        return None
    start = bus.first(start_kind, **match) if start_kind else None
    return goal.t - (start.t if start is not None else 0.0)


def normalized_speed(t_done: Optional[float], t_min: float) -> Optional[float]:
    """s = t_min / t_done in (0, 1]; t_min is the minimum-time reference trajectory."""
    if t_done is None or t_done <= 0:
        return None
    return min(t_min / t_done, 1.0)


def pareto_front(points: Sequence[tuple[float, float]]) -> list[tuple[float, float]]:
    """Non-dominated (speed, safe_rate) pairs, both to be maximised; sorted by speed."""
    pts = sorted(set(points), key=lambda p: (-p[0], -p[1]))
    front: list[tuple[float, float]] = []
    best_y = float("-inf")
    for x, y in pts:
        if y > best_y:
            front.append((x, y)); best_y = y
    return sorted(front)


@dataclass
class PassVector:
    """(valid, goal, protocol, quantity, time, safety); ChemSSR is the conjunction."""

    valid: bool
    goal: bool
    protocol: bool
    quantity: bool
    time: bool
    safety: bool

    @property
    def chem_ssr(self) -> bool:
        return self.valid and self.goal and self.protocol and self.quantity and self.time and self.safety


def assemble_pass_vector(goal_reached: bool, violations: Sequence[Violation]) -> PassVector:
    """Fold referee verdicts into the six-entry pass vector (multi-label violations allowed)."""
    kinds = {v.kind for v in violations}
    valid = "instrumentation_invalid" not in kinds
    incomplete = "incomplete" in kinds
    from chemrm.constraints import VTIME_KINDS
    return PassVector(
        valid=valid,
        goal=goal_reached and not incomplete,
        protocol=not (kinds & PROTOCOL_KINDS) and not incomplete,
        quantity=not (kinds & QUANTITY_KINDS),
        time=not (kinds & VTIME_KINDS),
        safety=not (kinds & SAFETY_KINDS) and "smoke" not in kinds,
    )
