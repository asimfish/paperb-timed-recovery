"""Gate 0 design-validation pilot: a low-fidelity (2-D kinematic) implementation of the
core paired family, three budget-matched learned conditions, and the preregistered
decision rule.

Modules
- env:       eight strata, four oracle masks, observation builder, privileged expert
             labels, fail-closed referee producing the six-entry pass vector
- policies:  reactive k=1 (MLP), memory adapter (GRU, Track A), clock token (GRU + bare
             timestamp channel, Track B); parameter budgets within 5%
- train:     behaviour cloning on exogenous trajectories with oracle-mask randomisation
- evaluate:  one frozen checkpoint, four masks, identical episodes (ideal-paused)
- run_pilot: trains 3 conditions x 3 seeds, evaluates, applies analysis.estimands.decide

Nothing here imports a simulator. The scene is exogenous until the policy's first
discrete decision; a scripted skill (execution substitution ON) then performs the motion
with a deterministic kinematic duration.
"""
