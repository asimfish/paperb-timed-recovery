"""Evaluate one frozen checkpoint on all eight strata under all four oracle masks.

Ideal-paused mode with an exogenous scene: the policy's per-tick logits over the whole
observation sequence are computed in one pass and the episode's decision is the first tick
whose argmax is not `wait`.  This is tick-for-tick identical to stepping the environment
and querying the policy at every tick, because nothing the policy does before its first
act changes what it observes.  Decisions are deterministic (argmax), so the common
policy-randomness key of proposal 5.1 has nothing to randomise.

Each training seed gets its own paired evaluation draw (EVAL_SEED + seed): pairing across
strata, masks and conditions holds within a seed, which is all the estimands need, and the
pooled 300 units cover three times as many episodes as one shared draw would.

Output: one record per (episode, stratum, mask) with the pass vector, t_B and s.  The
`unit` field is "<training seed>:<episode id>", the contract of analysis/estimands.py.
"""
from __future__ import annotations

import argparse
import json
from typing import Dict, List, Optional

import numpy as np
import torch

from chemrm.gate0.env import (HARDEST, MASKS, N_STEPS, STRATA, build_observations, cell_arrays,
                              draw_episode_batch, first_action, judge, make_tick_times)
from chemrm.gate0.policies import CONDITIONS, make_policy

EVAL_SEED = 20260905            # base of the evaluation seed stream; draw for seed s is EVAL_SEED + s
TICK_SEED_OFFSET = 777_000      # tick-time draws for the evaluation episodes (paired across cells)


def eval_seed_for(train_seed: int, base: int = EVAL_SEED) -> int:
    return base + int(train_seed)


def load_policy(ckpt_path: str):
    ck = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    cond = ck["meta"]["condition"]
    model = make_policy(cond)
    model.load_state_dict(ck["state_dict"])
    model.eval()
    return model, ck["meta"]


@torch.no_grad()
def decide_batch(model, obs: np.ndarray):
    logits = model(torch.from_numpy(obs))
    actions = logits.argmax(dim=-1).numpy()                       # (N, T)
    return first_action(actions)


def evaluate_checkpoint(ckpt_path: str, n_eval: int = 100, eval_seed: Optional[int] = None,
                        strata=STRATA, masks=MASKS) -> List[Dict]:
    """`eval_seed=None` uses the preregistered per-training-seed draw EVAL_SEED + seed."""
    model, meta = load_policy(ckpt_path)
    cond = meta["condition"]
    clock = CONDITIONS[cond]["clock"]
    if eval_seed is None:
        eval_seed = eval_seed_for(meta["seed"])
    perturb = meta.get("perturb") or {"kind": "none", "level": 0.0, "n_steps": N_STEPS}
    eps = draw_episode_batch(n_eval, eval_seed)
    ticks = make_tick_times(n_eval, perturb["n_steps"], perturb["kind"], perturb["level"], seed=eval_seed + TICK_SEED_OFFSET)
    records: List[Dict] = []
    for stratum in strata:
        for mask in masks:
            transient, tight, eta, id_on, tm_on = cell_arrays(n_eval, stratum, mask)
            obs = build_observations(eps, transient, tight, id_on, tm_on, clock, tick_times=ticks)
            step, flask = decide_batch(model, obs)
            verdict = judge(eps, tight, eta, step, flask, tick_times=ticks)
            for i in range(n_eval):
                records.append({
                    "condition": cond, "track": CONDITIONS[cond]["track"], "seed": meta["seed"],
                    "perturb": f"{perturb['kind']}:{perturb['level']}",
                    "unit": f"{meta['seed']}:{i}", "episode": i, "eval_seed": eval_seed,
                    "stratum": stratum, "mask": mask,
                    "valid": 1, "goal": int(verdict["goal"][i]), "protocol": int(verdict["protocol"][i]),
                    "time": int(verdict["time"][i]), "safety": int(verdict["safety"][i]),
                    "quantity": 1, "added": int(verdict["added"][i]),
                    "t_b": None if not verdict["added"][i] else round(float(verdict["t_b"][i]), 2),
                    "s_norm": None if not verdict["added"][i] else round(float(verdict["s_norm"][i]), 4),
                    "act_flask": int(flask[i]), "true_flask": int(eps.flask[i]),
                    "t_a": round(float(eps.t_a[i]), 2), "d": round(float(eps.d[i]), 2),
                })
    return records


def estimand_records(records: List[Dict]) -> List[Dict]:
    """Project the wide records onto the estimands' cell vocabulary (one condition).

    RD cells come from the mask-none evaluation of the named strata; the oracle cells come
    from the four masks on the hardest stratum.
    """
    out = []
    for r in records:
        if r["mask"] == "none" and r["stratum"] in ("M0_relaxed", "M1_relaxed", "M0_tight_0.15"):
            out.append({**r, "cell": r["stratum"]})
        if r["stratum"] == HARDEST:
            out.append({**r, "cell": f"oracle:{r['mask']}"})
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("ckpt")
    ap.add_argument("--out", required=True, help="JSONL of wide records")
    ap.add_argument("--n-eval", type=int, default=100)
    a = ap.parse_args()
    recs = evaluate_checkpoint(a.ckpt, n_eval=a.n_eval)
    with open(a.out, "w", encoding="utf-8") as fh:
        for r in recs:
            fh.write(json.dumps(r) + "\n")
    print(f"wrote {len(recs)} records to {a.out}")


if __name__ == "__main__":
    main()
