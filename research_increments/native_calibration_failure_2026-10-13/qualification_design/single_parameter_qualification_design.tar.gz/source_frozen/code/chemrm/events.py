"""Simulated clock and event bus: the single source of time and history.

The event log doubles as (a) ground truth for temporal-violation verdicts and
(b) the supervision-signal interface of the benchmark (proposal section 1.3).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass(frozen=True)
class Event:
    """One timestamped occurrence in the simulated world."""

    kind: str            # e.g. "add_reagent", "uncap", "stir_start", "color_change", "smoke"
    t: float             # simulated seconds since episode start
    payload: dict[str, Any] = field(default_factory=dict)


class SimClock:
    """Deterministic simulated time. Advanced only by explicit step(dt)."""

    def __init__(self) -> None:
        self._t = 0.0

    @property
    def now(self) -> float:
        return self._t

    def step(self, dt: float) -> float:
        if dt < 0:
            raise ValueError(f"dt must be non-negative, got {dt}")
        self._t += dt
        return self._t

    def reset(self) -> None:
        self._t = 0.0


class EventBus:
    """Append-only event log bound to a SimClock, with subscriptions.

    Subscribers receive events synchronously at emit time; process models use
    this to couple (e.g. an add_reagent event feeds the thermal model).
    """

    def __init__(self, clock: SimClock) -> None:
        self.clock = clock
        self._log: list[Event] = []
        self._subs: list[Callable[[Event], None]] = []

    @classmethod
    def replay(cls, events: list[Event] | tuple[Event, ...]) -> "EventBus":
        """Build a read-only replay input for verifiers.

        Replay deliberately does not call subscribers: process models and worlds must not be
        mutated while a Paper A verifier inspects a trace.  The returned bus is still useful to
        the existing constraint checkers because it exposes the same append-only query API as a
        live bus.
        """
        ordered = tuple(events)
        if any(ev.t < 0 for ev in ordered):
            raise ValueError("event timestamps must be non-negative")
        if any(b.t < a.t for a, b in zip(ordered, ordered[1:])):
            raise ValueError("events must be in non-decreasing timestamp order")
        clock = SimClock()
        clock._t = ordered[-1].t if ordered else 0.0
        bus = cls(clock)
        bus._log.extend(ordered)
        return bus

    @property
    def log(self) -> tuple[Event, ...]:
        return tuple(self._log)

    def subscribe(self, fn: Callable[[Event], None]) -> None:
        self._subs.append(fn)

    def emit(self, kind: str, **payload: Any) -> Event:
        ev = Event(kind=kind, t=self.clock.now, payload=dict(payload))
        self._log.append(ev)
        for fn in self._subs:
            fn(ev)
        return ev

    # -- query helpers used by constraint checkers ---------------------------

    def first(self, kind: str, **match: Any) -> Event | None:
        for ev in self._log:
            if ev.kind == kind and all(ev.payload.get(k) == v for k, v in match.items()):
                return ev
        return None

    def all(self, kind: str, **match: Any) -> list[Event]:
        return [
            ev for ev in self._log
            if ev.kind == kind and all(ev.payload.get(k) == v for k, v in match.items())
        ]

    def count(self, kind: str, **match: Any) -> int:
        return len(self.all(kind, **match))
