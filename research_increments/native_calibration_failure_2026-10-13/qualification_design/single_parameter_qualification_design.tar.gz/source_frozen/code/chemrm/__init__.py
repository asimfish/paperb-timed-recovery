"""ChemRMBench P1 groundwork: simulator-agnostic temporal machinery.

Modules:
- events: SimClock and EventBus, the single source of simulated time.
- process_models: color kinetics, thermal model with exotherm coupling.
- constraints: the T-axis temporal constraint types and violation checkers.
- task_schema: YAML task-spec extension carrying the (M, T, S) triple.

Design principles (proposal section 2.2 / section 5.2):
- Everything advances via explicit step(dt) from SimClock; never wall clock.
- Temporal violations are judged from the event log and process states, so
  verdicts stay valid even if fluid particle state drifts (PBD caveat).
- No Isaac Lab imports here; the package plugs into psilab as a plain layer.
"""

from chemrm.events import EventBus, SimClock
from chemrm.process_models import ColorKinetics, ThermalModel
from chemrm.constraints import (
    TDeadline,
    TDuration,
    TEvent,
    TRate,
    Violation,
    check_constraints,
)

__version__ = "0.1.0"
__all__ = [
    "SimClock",
    "EventBus",
    "ColorKinetics",
    "ThermalModel",
    "TEvent",
    "TDeadline",
    "TDuration",
    "TRate",
    "Violation",
    "check_constraints",
]
