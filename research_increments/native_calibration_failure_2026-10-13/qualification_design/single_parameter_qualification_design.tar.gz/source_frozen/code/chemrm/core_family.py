"""Abstract model of the v0.4 core paired family: one decision rule, paired
episode draws, observation interventions only.

Base protocol P0: n flasks; an assistant adds reagent A to ONE random flask at a
random time t_A; the policy must add B to THAT flask after the instructed wait
D (tight) or any time after A (relaxed).

Two latent facts, orthogonal by construction:
  F1 identity  - which flask received A (time-independent)
  F2 timing    - elapsed time since A was added

Environment factors (what the world shows):
  M  cue: persistent (dye stays on the flask -> F1 observable every tick)
          transient  (cue visible only on the tick A is poured)
  T  tolerance: relaxed (any time after A, before the horizon)
                tight   (|t_B - (t_A + D)| <= eps, eps = eta * D)

Oracle interventions (what is injected into the observation):
  identity oracle -> F1 (flask index) every tick, nothing about time
  timing oracle   -> F2 (elapsed since A) every tick, nothing about identity;
                     None before A (this reveals that A has not happened yet,
                     which is a timing fact, not an identity fact)

ONE stateless decision rule is used in every cell. Only the observation
sigma-algebra changes. All cells of a table share the same episode draws
(same seed -> same flask, t_A, D), so differences are paired.

The abstract table is a release SANITY CHECK for the design; it does not
predict learned-policy effects (review round 2, weakness 2).
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Episode:
    flask: int
    t_a: float
    d: float


@dataclass(frozen=True)
class Obs:
    d: float                          # instructed wait (always visible)
    busy: bool                        # assistant is pouring A right now (observable)
    visible_flask: Optional[int]      # F1 from the WORLD (dye, or the cue while pouring)
    identity_known: bool              # identity oracle switched on
    identity: Optional[int]           # F1 from the identity oracle (None before A)
    timing_known: bool                # timing oracle switched on
    elapsed_since_a: Optional[float]  # F2 from the timing oracle (None before A)
    tight: bool                       # instruction says "exactly D" vs "after A"


T_POUR = 3.0   # seconds the assistant occupies the flask while pouring A


def draw_episodes(n: int, seed: int, n_flasks: int = 5,
                  t_a_range=(5.0, 40.0), d_range=(30.0, 90.0)) -> list[Episode]:
    rng = random.Random(seed)
    return [Episode(rng.randrange(n_flasks), rng.uniform(*t_a_range), rng.uniform(*d_range))
            for _ in range(n)]


def decide(obs: Obs, rng: random.Random, dt: float, n_flasks: int) -> Optional[int]:
    """The single stateless rule. Returns the flask to add B to, or None (wait).

    Graceful degradation: use the best information available this tick.
    """
    if obs.busy:                                  # never reach into the assistant's pour
        return None
    flask = obs.identity if obs.identity_known else obs.visible_flask
    if obs.tight:
        if obs.timing_known:
            if obs.elapsed_since_a is None or obs.elapsed_since_a < obs.d:
                return None
            return flask if flask is not None else rng.randrange(n_flasks)
        # no timing information: constant hazard 1/D per unit time
        if rng.random() < dt / obs.d:
            return flask if flask is not None else rng.randrange(n_flasks)
        return None
    # relaxed: act as soon as there is evidence that A has happened
    if flask is not None:
        return flask
    if obs.timing_known and obs.elapsed_since_a is not None:   # A happened, flask unknown
        return rng.randrange(n_flasks)
    return None


def run_cell_outcomes(episodes: list[Episode], *, transient: bool, tight: bool,
                      identity_oracle: bool = False, timing_oracle: bool = False,
                      dt: float = 1.0, eta: float = 0.15, horizon: float = 240.0,
                      n_flasks: int = 5, seed: int = 0) -> list[bool]:
    """Per-episode success flags for one cell, in episode order (paired across cells)."""
    rng = random.Random(seed)                    # same stream in every cell
    outcomes: list[bool] = []
    n_ticks = int(horizon / dt)
    for ep in episodes:
        eps = eta * ep.d
        acted = None
        for tick in range(1, n_ticks + 1):
            t = tick * dt
            a_happened = t >= ep.t_a
            busy = ep.t_a <= t < ep.t_a + T_POUR
            if not a_happened:
                visible = None
            elif transient:
                visible = ep.flask if busy else None        # cue only while pouring
            else:
                visible = ep.flask                          # dye persists
            obs = Obs(
                d=ep.d,
                busy=busy,
                visible_flask=visible,
                identity_known=identity_oracle,
                identity=ep.flask if (identity_oracle and a_happened) else None,
                timing_known=timing_oracle,
                elapsed_since_a=(t - ep.t_a) if (timing_oracle and a_happened) else None,
                tight=tight,
            )
            choice = decide(obs, rng, dt, n_flasks)
            if choice is not None:
                acted = (t, choice)
                break
        if acted is None:
            outcomes.append(False)
            continue
        t_b, choice = acted
        if choice != ep.flask or t_b < ep.t_a + T_POUR:     # wrong flask or collision
            outcomes.append(False)
            continue
        if tight and abs(t_b - (ep.t_a + ep.d)) > eps:
            outcomes.append(False)
            continue
        outcomes.append(True)
    return outcomes


def run_cell(episodes: list[Episode], **kw) -> float:
    """Success rate of one cell (mean of run_cell_outcomes)."""
    outcomes = run_cell_outcomes(episodes, **kw)
    return sum(outcomes) / len(outcomes)


def env_factorial(episodes: int = 2000, seed: int = 0, **kw) -> dict[str, float]:
    """2x2 environment factorial (M x T) with NO oracles; paired draws."""
    eps = draw_episodes(episodes, seed)
    return {
        "M0_relaxed": run_cell(eps, transient=False, tight=False, seed=seed, **kw),
        "M1_relaxed": run_cell(eps, transient=True, tight=False, seed=seed, **kw),
        "M0_tight": run_cell(eps, transient=False, tight=True, seed=seed, **kw),
        "M1_tight": run_cell(eps, transient=True, tight=True, seed=seed, **kw),
    }


def oracle_factorial(episodes: int = 2000, seed: int = 0, **kw) -> dict[str, float]:
    """2x2 oracle factorial on the hardest cell (M1, tight): identity x timing."""
    eps = draw_episodes(episodes, seed)
    cells = {}
    for ident in (False, True):
        for timing in (False, True):
            key = f"identity={int(ident)},timing={int(timing)}"
            cells[key] = run_cell(eps, transient=True, tight=True, identity_oracle=ident,
                                  timing_oracle=timing, seed=seed, **kw)
    return cells


def risk_difference_interaction(tab: dict[str, float]) -> float:
    """I = (S11 - S10) - (S01 - S00) on the env factorial (risk-difference scale).

    Negative I means the joint (transient, tight) drop exceeds the sum of the
    individual drops - the preregistered direction of H3.
    """
    s00, s10 = tab["M0_relaxed"], tab["M1_relaxed"]
    s01, s11 = tab["M0_tight"], tab["M1_tight"]
    return (s11 - s10) - (s01 - s00)


def oracle_recovery_interaction(tab: dict[str, float]) -> float:
    """Preregistered H3 estimand on the oracle factorial of the hardest cell:

        I_rec = (S_both - S_identity_only) - (S_timing_only - S_none)

    Positive I_rec = superadditive recovery: each oracle alone recovers little,
    both together recover most - the signature of a genuine memory x timing
    coupling. Unlike the environment risk-difference interaction, this
    estimand is not floor-dominated (S_both is away from 0).
    """
    s00 = tab["identity=0,timing=0"]
    s10 = tab["identity=1,timing=0"]
    s01 = tab["identity=0,timing=1"]
    s11 = tab["identity=1,timing=1"]
    return (s11 - s10) - (s01 - s00)
