"""Task-spec schema: SafeLab's T = (S, G, C) extended with the T axis.

A task YAML gains two fields:
- `mts`: the (M, T, S) triple declared for grading and report slicing.
- `temporal_constraints`: a list of dicts, each built into a chemrm.constraints
  object by `build_constraints`.

This module is deliberately schema-only (no Isaac imports) so the same specs
drive both the local unit tests and, later, the psilab environment layer.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from chemrm.constraints import TDeadline, TDuration, TEvent, TRate, TemporalConstraint

_BUILDERS = {
    "event": TEvent,
    "deadline": TDeadline,
    "duration": TDuration,
    "rate": TRate,
}

_M_LEVELS = {"M0", "M1", "Mn"}
_T_LEVELS = {"T0", "T-event", "T-dl", "T-dur", "T-rate"}
_MEM_TYPES = {"temporal", "spatial", "object", "procedural", "none"}


@dataclass
class TaskSpec:
    task_id: str
    title: str
    m_level: str
    memory_budget_k: int              # exact latent-fact count (0 for M0, 1 for M1, >=2 for Mn)
    t_levels: list[str]
    s_level: str
    memory_types: list[str]
    goal: list[dict[str, Any]]
    temporal_constraints: list[TemporalConstraint] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)


def build_constraints(items: list[dict[str, Any]]) -> list[TemporalConstraint]:
    out: list[TemporalConstraint] = []
    for item in items:
        spec = dict(item)
        kind = spec.pop("type")
        try:
            builder = _BUILDERS[kind]
        except KeyError:
            raise ValueError(f"unknown temporal constraint type: {kind!r}") from None
        out.append(builder(**spec))
    return out


def load_task_spec(path: str | Path) -> TaskSpec:
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    mts = raw.get("mts", {})
    m = mts.get("M", "M0")
    ts = mts.get("T", ["T0"])
    ts = [ts] if isinstance(ts, str) else list(ts)
    if m not in _M_LEVELS:
        raise ValueError(f"invalid M level {m!r}, expected one of {sorted(_M_LEVELS)}")
    bad_t = set(ts) - _T_LEVELS
    if bad_t:
        raise ValueError(f"invalid T levels {sorted(bad_t)}, expected subset of {sorted(_T_LEVELS)}")
    slots = raw.get("memory_slots", [])
    for s in slots:
        dom = s.get("domain")
        if not isinstance(dom, list) or not dom or len(dom) > 64:
            raise ValueError(f"memory slot {s.get('name')!r} needs a finite domain list (<= 64 values)")
    k = int(raw.get("memory_budget_k", len(slots) if slots else {"M0": 0, "M1": 1}.get(m, -1)))
    if slots and k != len(slots):
        raise ValueError(f"memory_budget_k={k} but {len(slots)} memory_slots declared")
    if m == "M0" and k != 0 or m == "M1" and k != 1 or m == "Mn" and k < 2:
        raise ValueError(f"memory_budget_k={k} inconsistent with M level {m!r}")
    mem = raw.get("memory_types", ["none"])
    bad_mem = set(mem) - _MEM_TYPES
    if bad_mem:
        raise ValueError(f"invalid memory types {sorted(bad_mem)}")
    return TaskSpec(
        task_id=raw["task_id"],
        title=raw.get("title", raw["task_id"]),
        m_level=m,
        memory_budget_k=k,
        t_levels=ts,
        s_level=mts.get("S", "S0"),
        memory_types=list(mem),
        goal=raw.get("goal", []),
        temporal_constraints=build_constraints(raw.get("temporal_constraints", [])),
        raw=raw,
    )
