"""Filter only a robot's fixed rigid components and directly jointed neighbors."""
def configure(stage, robots):
    from pxr import Usd, UsdPhysics
    report = []
    for robot in robots:
        prefix=robot['prim_path'];parents={};edges=[]
        def find(a):
            parents.setdefault(a,a)
            if parents[a]!=a:parents[a]=find(parents[a])
            return parents[a]
        prims=list(Usd.PrimRange(stage.GetPrimAtPath(prefix)))
        bodies=[str(p.GetPath()) for p in prims if p.HasAPI(UsdPhysics.RigidBodyAPI)]
        def body_owner(path):
            # A joint may target a flange Xform below the actual rigid body.
            prim=stage.GetPrimAtPath(path)
            while prim and not prim.HasAPI(UsdPhysics.RigidBodyAPI):prim=prim.GetParent()
            return str(prim.GetPath()) if prim else None
        for p in prims:
            if not p.IsA(UsdPhysics.Joint):continue
            j=UsdPhysics.Joint(p)
            if j.GetJointEnabledAttr().Get()==False:continue
            a=j.GetBody0Rel().GetTargets();b=j.GetBody1Rel().GetTargets()
            if len(a)!=1 or len(b)!=1:continue
            a,b=body_owner(a[0]),body_owner(b[0])
            if a is None or b is None:continue
            if not a.startswith(prefix) or not b.startswith(prefix):continue
            edges.append((a,b))
            if p.IsA(UsdPhysics.FixedJoint):parents[find(a)]=find(b)
        neighboring={tuple(sorted((find(a),find(b)))) for a,b in edges}
        pairs=[]
        for i,a in enumerate(bodies):
            for b in bodies[i+1:]:
                same=find(a)==find(b)
                adjacent=tuple(sorted((find(a),find(b)))) in neighboring
                if not (same or adjacent):continue
                api=UsdPhysics.FilteredPairsAPI.Apply(stage.GetPrimAtPath(a))
                relation=api.CreateFilteredPairsRel()
                current=relation.GetTargets()
                if b not in [str(v) for v in current]:relation.AddTarget(b)
                pairs.append({'body0':a,'body1':b,'reason':'same_fixed_component' if same else 'direct_joint_neighbors'})
        report.append({'robot':prefix,'filtered_pairs':pairs,'nonadjacent_movable_bodies_filtered':False})
    return report
