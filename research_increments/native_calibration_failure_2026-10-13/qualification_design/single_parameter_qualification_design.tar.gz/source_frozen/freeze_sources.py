"""Freeze the single prospective controller qualification; does not launch it."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
gate=json.loads((ROOT/'CPU_PREFLIGHT.json').read_text())
if gate['status']!='PASS_GPU_FREE_QUALIFICATION_GATE':raise ValueError('CPU gate failed')
origin=json.loads((ROOT/'SOURCE_ORIGIN.json').read_text())
fixed=[n for n in origin['copied_source_hashes'] if n.startswith(('code/','inputs/')) or n in ('plan.json','source_pins.json')]
for n in fixed:
    if sha(ROOT/n)!=origin['copied_source_hashes'][n]:raise ValueError('original non-controller source/input changed: '+n)
owned=['native_probe.py','expansion_protocol.py','gain_installation.py','protocol.json','run_worker.py','gpu_mapping.py',
    'launch_worker.sh','test_qualification.py','freeze_sources.py','SOURCE_ORIGIN.json','CPU_PREFLIGHT.json','INSTALLED_API_READ_ONLY.json']
files={n:sha(ROOT/n) for n in fixed+owned}
receipt=dict(schema='paperb-single-factor-controller-qualification-release-v1',files=files,
    cases_total=1,qualification_cases=1,calibration_cases=0,test_cases=0,
    only_actor_parameter='HAND_POSITION_DRIVE_STIFFNESS_800_TO_1600',
    candidate_installed_after_original_baseline_acceptance=True,
    altered_targets_or_object_physics=False,original_mechanical_thresholds_unchanged=True,
    original_failed_calibration_cohort_preserved=True,root_cause_not_proven=True,
    maximum_owned_workers_per_gpu=1,minimum_free_gpu_mib=24576,max_worker_seconds=700)
with (ROOT/'EXECUTION_RELEASE.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(dict(status='QUALIFICATION_SOURCE_FROZEN_NO_GPU_JOB',files=len(files),release_sha256=sha(ROOT/'EXECUTION_RELEASE.json'))))
