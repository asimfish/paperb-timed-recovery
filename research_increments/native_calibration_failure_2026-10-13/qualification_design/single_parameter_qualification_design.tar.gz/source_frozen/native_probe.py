"""New native physics from pinned drive commands on the preserved A-r7 scene."""
import argparse
import copy
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import time
import traceback

started=time.monotonic()
parser=argparse.ArgumentParser(allow_abbrev=False)
parser.add_argument('--case',required=True)
parser.add_argument('--root',required=True)
from isaaclab.app import AppLauncher
AppLauncher.add_app_launcher_args(parser)
args=parser.parse_args();root=Path(args.root).resolve();out=root/'cases'/args.case
out.mkdir(exist_ok=False);os.environ['ALAB_PLAN_PATH']=str(root/'plan.json')
protocol=json.loads((root/'protocol.json').read_text());app=None;telemetry=None
cases=[c for c in protocol['cases'] if c['id']==args.case]
if len(cases)!=1:raise ValueError('one frozen case required')
case=cases[0]
from expansion_protocol import dispatch_schedule,score_gap,FixedDelayFIFO,sampled_operation_events
from gain_installation import install as install_declared_gain,verify_end as verify_active_gain_end
calibration=None;calibration_receipt_sha256=None
if case['method'] in ('calibrated_interval','joint_interval_scheduler'):
    release=json.loads((root/'CALIBRATION_RELEASE.json').read_text())
    calibration_receipt_sha256=hashlib.sha256((root/'CALIBRATION.json').read_bytes()).hexdigest()
    if calibration_receipt_sha256!=release['calibration_sha256']:raise ValueError('calibration seal mismatch')
    calibration=json.loads((root/'CALIBRATION.json').read_text())
    for rel,h in calibration['sources'].items():
        if hashlib.sha256((root/rel).read_bytes()).hexdigest()!=h:raise ValueError('calibration raw source changed: '+rel)
schedule=dispatch_schedule(case,protocol,calibration)



def record(name,value):
    p=out/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())


def milestone(name,**fields):
    row=dict(event=name,wall_s=time.monotonic()-started,**fields)
    with (out/'milestones.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    print('BOTTLE_MILESTONE',json.dumps(row),flush=True)


try:
    milestone('APP_STARTING')
    app=AppLauncher(dict(vars(args))).app
    milestone('APP_STARTED')
    import numpy as np
    import torch
    import carb
    import omni.usd
    import omni.kit.app
    from pxr import UsdPhysics,PhysxSchema
    from PIL import Image
    from types import SimpleNamespace
    import isaaclab.sim as sim_utils
    from isaaclab.scene import InteractiveScene
    from isaaclab.utils.math import quat_apply
    from isaacsim.core.version import get_version
    from scene_cfg_twin import GOAI_SCENE_CFG,PLAN,PLAN_PATH
    from contact_telemetry import ContactTelemetry
    from robot_collision_filters import configure
    from gripper_geometry import pad_frames
    from trajectory_audit import rescore
    from chemrm.papera.physical_bottle_baseline import load_commands,measured_events
    # Scheduling and scoring imported before native app construction.
    from chemrm.papera.legacy_reconstruction.checkpoint_runtime import capture
    from chemrm.papera.reconstruction import seal_boundary,continue_from_boundary,LegacyTwinAdapter,compare_state,RestoreLimits
    from chemrm.papera.staged_collection import digest,write_once,StageJournal,verify_prefix

    version=get_version();manager=omni.kit.app.get_app().get_extension_manager()
    physx_id=manager.get_enabled_extension_id('omni.physx')
    if version[0]!='5.1.0' or not physx_id:raise RuntimeError('native runtime identity unavailable')
    record('runtime_versions.json',dict(isaac_version=version,physx_extension=physx_id,
        isaaclab_distribution=importlib.metadata.version('isaaclab'),selected_experience=args.experience))
    dt=protocol['dt_s'];T=lambda x:torch.tensor(x,dtype=torch.float32,device='cpu')
    sim=sim_utils.SimulationContext(sim_utils.SimulationCfg(dt=dt,device='cpu',use_fabric=True,
        physx=sim_utils.PhysxCfg(solver_type=1,max_position_iteration_count=32,
            max_velocity_iteration_count=4,enable_ccd=True)))
    cfg=GOAI_SCENE_CFG(num_envs=1,env_spacing=2.)
    for name in list(vars(cfg)):
        if name.endswith('_camera') and name!='station_a_camera':setattr(cfg,name,None)
    cfg.station_a_camera.width,cfg.station_a_camera.height=protocol['camera_resolution']
    scene=InteractiveScene(cfg);stage=omni.usd.get_context().get_stage()
    record('collision_filters.json',configure(stage,PLAN['robots']))
    particle_prims=[str(p.GetPath()) for p in stage.Traverse()
        if p.IsA(PhysxSchema.PhysxParticleSystem) or p.HasAPI(PhysxSchema.PhysxParticleSetAPI)]
    if particle_prims:raise RuntimeError('this rigid checkpoint experiment cannot restore particles')
    telemetry=ContactTelemetry(stage,out/'contacts_all.jsonl.gz')
    sim.reset();scene.reset()
    for asset in scene.articulations.values():
        asset.write_joint_state_to_sim(asset.data.default_joint_pos,asset.data.default_joint_vel)
        asset.set_joint_position_target(asset.data.default_joint_pos)
    expected_rigid={p['name'] for p in PLAN['prims'] if not p['articulated']}
    expected_art={p['name'] for p in PLAN['prims'] if p['articulated']}|{r['prim_path'].split('/')[-1] for r in PLAN['robots']}
    if expected_rigid!=set(scene.rigid_objects) or expected_art!=set(scene.articulations):
        raise RuntimeError('preserved scene registry incomplete')
    kin={name for name,asset in scene.rigid_objects.items() if bool(
        UsdPhysics.RigidBodyAPI(stage.GetPrimAtPath(asset.root_physx_view.prim_paths[0])).GetKinematicEnabledAttr().Get())}
    record('registry.json',dict(rigid_objects=sorted(scene.rigid_objects),articulations=sorted(scene.articulations),
        measured_kinematic_roots=sorted(kin),particle_prims=particle_prims))
    milestone('NATIVE_REGISTRY',rigid=56,articulations=9)
    robot=scene.articulations['fr3_A'];bottle=scene.rigid_objects[protocol['object']]
    policy=load_commands(root/'inputs/commands.npz',protocol['command_policy_sha256'],dt,robot.joint_names)
    # Material installation is completed before warmup or task. PhysX values
    # are independently read back; USD authored defaults are separately logged.
    mass_before=bottle.root_physx_view.get_masses().clone()
    inertia_before=bottle.root_physx_view.get_inertias().clone()
    requested_mass=mass_before*case['mass_factor'];requested_inertia=inertia_before*case['mass_factor']
    env_ids=torch.tensor([0],dtype=torch.int,device='cpu')
    bottle.root_physx_view.set_masses(requested_mass,env_ids)
    bottle.root_physx_view.set_inertias(requested_inertia,env_ids)
    mass_after=bottle.root_physx_view.get_masses().clone()
    inertia_after=bottle.root_physx_view.get_inertias().clone()
    if not torch.isfinite(mass_after).all() or not (mass_after>0).all() or not torch.allclose(mass_after,requested_mass,rtol=1e-6,atol=1e-8):
        raise RuntimeError('actual native mass readback differs from requested installed mass')
    if not torch.isfinite(inertia_after).all() or not torch.allclose(inertia_after,requested_inertia,rtol=1e-6,atol=1e-10):
        raise RuntimeError('actual native inertia readback differs from requested installed inertia')
    authored=[]
    for path in bottle.root_physx_view.prim_paths:
        api=UsdPhysics.MassAPI(stage.GetPrimAtPath(path))
        authored.append(dict(prim_path=path,usd_authored_mass_kg=api.GetMassAttr().Get() if api else None))
    record('mass_parameter_readback.json',dict(schema='paperb-installed-physx-properties-v1',object_name=protocol['object'],
        requested_factor=case['mass_factor'],mass_before_kg=mass_before.tolist(),mass_requested_kg=requested_mass.tolist(),
        mass_after_kg=mass_after.tolist(),inertia_before=inertia_before.tolist(),inertia_requested=requested_inertia.tolist(),
        inertia_after=inertia_after.tolist(),usd_authored_defaults=authored,physics_tensor_is_actual_mass=True,
        installed_before_warmup=True,installed_before_task=True,mass_readback_pass=True,inertia_readback_pass=True,
        setter_api='root_physx_view.set_masses/set_inertias CPU indices; Isaac Lab installed events.py',
        public_installation_metadata=True,actor_scheduler_reads_mass=False))
    record('case.json',dict(schema='paperb-native-case-v2',case=case,protocol_sha256=digest(root/'protocol.json'),
        execution_release_sha256=digest(root/'EXECUTION_RELEASE.json'),command_policy_sha256=policy.source_sha256,
        schedule_sha256=hashlib.sha256(json.dumps(schedule,sort_keys=True).encode()).hexdigest(),
        calibration_receipt_sha256=calibration_receipt_sha256,
        actor_inputs=['public contact/duration contract','public fixed transport delay','pinned joint drive skill',
                     'old nominal mechanical prior','frozen calibration for calibrated_interval only'],
        current_private_events_used_for_scheduling=False,current_mass_used_for_scheduling=False))
    pads=pad_frames(robot,robot.cfg.prim_path)
    hand=robot.find_bodies('fr3_hand')[0][0]
    camera=scene.sensors['station_a_camera']
    record('jaw_geometry.json',dict(pads=pads,scope='ACTUAL_COMPOSED_COLLISION_PADS_AND_NATIVE_BODY_FRAMES'))
    callback=dict(count=0,last_dt=None)
    def on_physics(value):callback['count']+=1;callback['last_dt']=float(value)
    sim.add_physics_callback('chemrm_v79_native_count',on_physics)
    args.seed=0
    rec=SimpleNamespace(kin={},kinematic_support=set(),pinned={},contact_frames=[[] for _ in range(6)],
        tick=0,metrics={},contract=dict(task_id='A_r7_precursor1',policy_kind=protocol['policy_kind'],
            command_policy_sha256=protocol['command_policy_sha256'],agent_context_restored=False),arm=None,
        task_graph_position=dict(stage='ready',next_command_index=0))
    ns=dict(scene=scene,PLAN=PLAN,PLAN_PATH=PLAN_PATH,__file__=str(Path(__file__).resolve()),args=args,DT=dt,
        dev='cpu',ISAAC_VERSION=version[0],PHYSX_VERSION=physx_id,
        SOLVER_PROFILE='global32/4_object16/2_FR3_authored_with_contact_reports',
        INPUT_MANIFEST_SHA256=digest(root/'source_pins.json'),RNG_DRAW_COUNT=0,KINEMATIC_RIGID_NAMES=kin)
    epochs='paperb_native_expansion_v2:'+args.case+':'+digest(root/'protocol.json')[:16]
    native_steps=0;last_contact=None

    def advance(tick):
        global native_steps,last_contact
        before=float(sim.current_time);count=callback['count']
        telemetry.begin(tick,('/World/StationA',robot.cfg.prim_path))
        scene.write_data_to_sim();sim.step(render=False);scene.update(dt)
        last_contact=telemetry.end();native_steps+=1;rec.tick+=1
        rec.contact_frames=(rec.contact_frames+[last_contact['contacts']])[-6:]
        after=float(sim.current_time)
        if callback['count']-count!=1 or abs(callback['last_dt']-dt)>1e-9 or abs(after-before-dt)>1e-7:
            raise RuntimeError('unaccounted physical integration callback/time')
        if last_contact['errors']:raise RuntimeError('native contact parse failure')
        return before,after

    def gravity():
        effort=torch.zeros((1,robot.num_joints));effort[:,:7]=robot.root_physx_view.get_gravity_compensation_forces()[:,:7]
        if not torch.isfinite(effort).all():raise RuntimeError('nonfinite live gravity compensation')
        robot.set_joint_effort_target(effort)

    setup=out/'setup';setup.mkdir()
    journal=StageJournal(setup,'v79_setup',[dict(id='released',start_tick=0,end_tick=protocol['warmup_ticks'])],
        float(sim.current_time),dict(scope='RELEASED_RIGID_BOTTLE_TASK_START'))
    reference=None
    for i in range(protocol['warmup_ticks']):
        gravity();before,after=advance(-protocol['warmup_ticks']+i)
        with (setup/'native_clock.jsonl').open('a') as f:
            f.write(json.dumps(dict(tick=i+1,native_before_s=before,native_after_s=after))+'\n')
        if i==protocol['warmup_ticks']-241:reference=capture(ns,rec,chain_id='v79_setup')
    cp=capture(ns,rec,chain_id='v79_setup');ns['CHECKPOINT_IDENTITY']=cp['identity']
    stability=compare_state(reference,cp,RestoreLimits());write_once(setup/'stability.json',stability)
    if stability['status']!='PASS':raise RuntimeError('start boundary is not stable at the original gate')
    write_once(setup/'boundary_state.json',cp)
    def boundary():return dict(physics_time_s=float(sim.current_time),semantic_tick=rec.tick,state=capture(ns,rec,chain_id='v79_setup'))
    journal.commit('released',float(sim.current_time),boundary)
    if True:
        seal_boundary(setup,cp,'released',parent_manifest_sha256=digest(setup/'stages/released/manifest.json'),
            parent_manifest_path=setup/'stages/released/manifest.json',scene_has_particles=False,expected_identity=cp['identity'])
        milestone('PARENT_STAGE_SAVED')

    def render_snapshot(task_dir,index):
        before=capture(ns,rec);native_before=float(sim.current_time);count=callback['count']
        for _ in range(3):sim.render()
        camera.update(dt,force_recompute=True)
        rgb=camera.data.output['rgb'][0,:,:,:3].cpu().numpy()
        depth=camera.data.output['distance_to_image_plane'][0].cpu().numpy()
        after=capture(ns,rec)
        if before!=after or float(sim.current_time)!=native_before or callback['count']!=count:
            raise RuntimeError('snapshot rendering changed native physics/state')
        if rgb.shape!=(400,640,3) or rgb.dtype!=np.uint8 or rgb.std()<2.:
            raise RuntimeError('missing or invalid scene image')
        image=task_dir/'images'/f'{index:05d}.jpg';Image.fromarray(rgb).save(image,quality=92)
        sensor=task_dir/'depth'/f'{index:05d}.npz';np.savez_compressed(sensor,depth_m=depth)
        return dict(command_index=index,native_time_s=native_before,native_epoch=epochs,native_rgb_sha256=hashlib.sha256(rgb.tobytes()).hexdigest(),
            image=str(image.relative_to(task_dir)),image_sha256=digest(image),depth=str(sensor.relative_to(task_dir)),
            physics_callbacks_during_render=0,physical_state_changed=False,
            sensor_clock_is_native_clock=False,camera_frame=int(camera.frame[0]))

    def run_task():
        source_indices=schedule['source_indices']
        local_plan=schedule['stage_plan']
        public_cue=None
        record('schedule_decision.json',schedule)
        task=out/'task';task.mkdir();(task/'images').mkdir();(task/'depth').mkdir()
        limits=robot.data.joint_pos_limits[0].cpu().numpy();tolerance=np.array([.15]*7+[.0005]*2)
        speed=np.array([30.]*7+[2.]*2)
        contract=json.loads((root/'inputs/original_contract.json').read_text())
        contract['diagnostic']=True;contract['seed']=0
        contract['origin_tick']=0;contract['phases'][0]['initial_root_xyz']=bottle.data.root_pos_w[0].tolist()
        contract['phases'][0]['goal_root_xyz']=bottle.data.root_pos_w[0].tolist()
        contract['robot_state_bounds']['position_limits']=limits.tolist()
        contract['policy_kind']=protocol['policy_kind'];contract['independent_native_epoch']=epochs
        (task/'contract.json').write_text(json.dumps(contract,indent=2)+'\n')
        taskjournal=StageJournal(task,'v79_bottle_'+args.case,local_plan,float(sim.current_time),
            dict(scope=protocol['task_description'],policy_kind=protocol['policy_kind'],
                command_policy_sha256=policy.source_sha256,native_epoch=epochs,chemical_event_verified=False))
        rows=[];contacts=[];images=[]
        # Enforce drive-only actions throughout the live task. Construction and
        # the preceding declared checkpoint restoration have already finished.
        write_audit=[]
        def prohibited(*a,**kw):write_audit.append('forbidden_state_write');raise RuntimeError('state-writing action forbidden')
        for asset in [*scene.rigid_objects.values(),*scene.articulations.values()]:
            for name in ['write_root_pose_to_sim','write_root_velocity_to_sim']:
                setattr(asset,name,prohibited)
            if hasattr(asset,'write_joint_state_to_sim'):asset.write_joint_state_to_sim=prohibited
        images.append(render_snapshot(task,0))
        endings={s['end_tick']:s['id'] for s in local_plan}
        captures={s['end_tick'] for s in local_plan}
        video_frames=[]
        task_origin=float(sim.current_time)
        fifo=FixedDelayFIFO(case['public_transport_delay_ticks'])
        native_clock_by_tick={}
        applied_source_index=-1;applied_command_id=-1
        applied_target=np.r_[policy.arm_targets[0],policy.finger_targets[0]].astype(float)
        with (task/'states.jsonl').open('x') as states,(task/'contact_rows.jsonl').open('x') as contact_file, \
                (task/'dispatch.jsonl').open('x') as dispatch_file,(task/'command_events.jsonl').open('x') as command_file:
            for i in range(len(source_indices)+case['public_transport_delay_ticks']):
                source_index=source_indices[i] if i<len(source_indices) else None
                if source_index==protocol['cue_source_index']:
                    public_cue=dict(clock_id=epochs,bounds_s=[float(sim.current_time)]*2,
                        kind='PUBLIC_TASK_CUE',requested_gap_s=case['requested_contact_gap_s'],
                        contact_to_release_s=case['requested_contact_to_release_s'],
                        tolerance_s=case['contact_tolerance_s'],duration_tolerance_s=case['duration_tolerance_s'],
                        submission_tick=i,instruction='Form bilateral contact after the requested gap and reach verified stable release after the requested contact-to-release interval.',
                        observation_track='PUBLIC_EVENT_MESSAGE; SCRIPTED_SKILL_ONLY_NO_VLA')
                    record('task/public_cue.json',public_cue)
                submitted_target=np.r_[policy.arm_targets[source_index],policy.finger_targets[source_index]] if source_index is not None else None
                native_before=float(sim.current_time)
                native_clock_by_tick[i]=native_before
                submitted,applied=fifo.step(i,source_index,submitted_target)
                def packet_record(packet,applied_now=False):
                    if packet is None:return None
                    row=dict(command_id=packet.command_id,source_index=packet.source_index,enqueue_tick=packet.enqueue_tick,
                        ready_tick=packet.ready_tick,sampled_delay_ticks=case['public_transport_delay_ticks'],
                        native_epoch=epochs,enqueue_time_s=native_clock_by_tick[packet.enqueue_tick],
                        ready_time_nominal_prediction_s=task_origin+packet.ready_tick*dt,arm_target=list(packet.target[:7]),grip_target=list(packet.target[7:]))
                    if applied_now:row.update(apply_tick=i,apply_time_s=native_before,ready_observed_time_s=native_clock_by_tick[packet.ready_tick])
                    return row
                if applied is not None:
                    applied_target=np.array(applied.target,dtype=float)
                    applied_source_index=applied.source_index;applied_command_id=applied.command_id
                target=applied_target
                if np.any(target<limits[:,0]) or np.any(target>limits[:,1]):raise RuntimeError('applied drive target outside actual native limits')
                dispatch=dict(tick=i,native_before_s=native_before,native_epoch=epochs,submitted=packet_record(submitted),
                    applied=packet_record(applied,True),pending_command_ids=[p.command_id for p in fifo.pending],
                    held_previous_target=applied is None,applied_source_command_index=applied_source_index,applied_command_id=applied_command_id)
                dispatch_file.write(json.dumps(dispatch,allow_nan=False)+'\n')
                if submitted is not None:command_file.write(json.dumps(dict(event='SUBMITTED',**packet_record(submitted)),allow_nan=False)+'\n')
                if applied is not None:command_file.write(json.dumps(dict(event='APPLIED',**packet_record(applied,True)),allow_nan=False)+'\n')
                robot.set_joint_position_target(T(target)[None]);gravity()
                before,after=advance(i)
                q=robot.data.joint_pos[0].cpu().numpy();qd=robot.data.joint_vel[0].cpu().numpy()
                if not (np.isfinite(q).all() and np.isfinite(qd).all()) or np.any(q<limits[:,0]-tolerance) or np.any(q>limits[:,1]+tolerance) or np.any(abs(qd)>speed):
                    raise RuntimeError('actual native robot violated the original state guard')
                d=robot.data;centres=[];vertices=[]
                for pad in pads:
                    bp,bq=d.body_link_pos_w[0,pad['body_id']],d.body_link_quat_w[0,pad['body_id']]
                    centres.append(bp+quat_apply(bq[None],T(pad['local_centre'])[None])[0])
                    v=T(pad['corners']);vertices.append(bp+quat_apply(bq.expand(len(v),4),v))
                tcp=(centres[0]+centres[1])/2.;axis=centres[1]-centres[0];axis/=axis.norm().clamp(min=1e-8)
                width=max(0.,float((vertices[1]@axis).min()-(vertices[0]@axis).max()))
                pose=torch.cat((bottle.data.root_pos_w[0],bottle.data.root_quat_w[0])).tolist()
                row=dict(command_index=i,source_command_index=applied_source_index,
                    applied_source_command_index=applied_source_index,submitted_source_command_index=source_index,
                    applied_command_id=applied_command_id,pending_command_ids=dispatch['pending_command_ids'],
                    native_before_s=before,native_after_s=after,native_epoch=epochs,
                    semantic_tick=rec.tick,command_clock_s=native_before,q_all=q.tolist(),qd_all=qd.tolist(),
                    arm_target=target[:7].tolist(),grip_target=target[7:].tolist(),
                    tcp=torch.cat((tcp,d.body_link_quat_w[0,hand])).tolist(),jaw_width_m=width,object_pose=pose)
                rows.append(row);contacts.append(copy.deepcopy(last_contact))
                states.write(json.dumps(row,allow_nan=False)+'\n');contact_file.write(json.dumps(last_contact,allow_nan=False)+'\n')
                video_tick=case['id'] in protocol['video_case_ids'] and (i+1)%40==0 and protocol['video_start_task_s']<=after-task_origin<protocol['video_end_task_s']
                if i+1 in captures or video_tick:
                    images.append(render_snapshot(task,i+1))
                    with (task/'captures.jsonl').open('a') as f:f.write(json.dumps(images[-1])+'\n')
                    if video_tick:video_frames.append(images[-1])
                if i+1 in endings:
                    states.flush();contact_file.flush()
                    taskjournal.commit(endings[i+1],float(sim.current_time),
                        lambda:dict(physics_time_s=float(sim.current_time),command_index=i+1,
                            q=robot.data.joint_pos[0].tolist(),object_pose=torch.cat((bottle.data.root_pos_w[0],bottle.data.root_quat_w[0])).tolist()))
                    milestone('TASK_STAGE_SAVED',stage=endings[i+1],commands=i+1)
        if fifo.pending or fifo.submitted!=fifo.applied or fifo.submitted!=len(source_indices):
            raise RuntimeError('FIFO tail commands not completely applied')
        record('task/queue_completion.json',dict(submitted=fifo.submitted,applied=fifo.applied,tail_flush_ticks=case['public_transport_delay_ticks'],
            pending_command_ids=[],queue_complete=True,at_most_one_application_per_tick=True,fifo_reset_count=0,
            no_dropped_commands=True,no_reordered_commands=True))
        mass_final=bottle.root_physx_view.get_masses().clone();inertia_final=bottle.root_physx_view.get_inertias().clone()
        if not torch.equal(mass_final,mass_after) or not torch.equal(inertia_final,inertia_after):
            raise RuntimeError('installed physical properties changed inside task')
        record('task/installed_properties_end.json',dict(mass_kg=mass_final.tolist(),inertia=inertia_final.tolist(),unchanged_during_task=True))
        record('task/ACTIVE_DRIVE_END.json',verify_active_gain_end(robot,gain_expected))
        arrays=dict(t=np.array([r['native_after_s']-rows[0]['native_before_s'] for r in rows]),
            q=np.array([r['q_all'][:7] for r in rows]),qd=np.array([r['qd_all'][:7] for r in rows]),
            q_all=np.array([r['q_all'] for r in rows]),qd_all=np.array([r['qd_all'] for r in rows]),
            tcp=np.array([r['tcp'] for r in rows]),jaw_width_m=np.array([r['jaw_width_m'] for r in rows]),
            obj_precursor_1=np.array([r['object_pose'] for r in rows]))
        np.savez_compressed(task/'measured_arrays.npz',**arrays)
        expected=[];missing=[]
        for prefix in [robot.cfg.prim_path,bottle.cfg.prim_path]:
            for prim in stage.Traverse():
                if str(prim.GetPath()).startswith(prefix) and prim.HasAPI(UsdPhysics.RigidBodyAPI):
                    name=str(prim.GetPath());expected.append(name)
                    if name not in telemetry.body_paths:missing.append(name)
        coverage=bool(expected and not missing and sum(c['callbacks'] for c in contacts)>0 and not any(c['errors'] for c in contacts))
        score=rescore(arrays,contract,contacts,coverage)
        score['task_mechanism_pass']=all(v for k,v in score['conditions'].items() if k!='not_diagnostic')
        score.update(scientific_admission=False,training_admission=False,policy_kind=protocol['policy_kind'])
        record('task/independent_score.json',score)
        events=measured_events(rows,contacts,bottle.cfg.prim_path,robot.cfg.prim_path,dt,epochs)
        record('task/operation_events.json',events)
        expanded=sampled_operation_events(rows,contacts,protocol,epochs)
        record('task/expanded_events.json',expanded)
        effect=expanded['events']['bilateral_grasp']['event']
        release_effect=expanded['events']['supported_release']['event']
        contact_timing=score_gap(public_cue,effect,case['requested_contact_gap_s'],case['contact_tolerance_s'])
        release_timing=score_gap(public_cue,release_effect,
            case['requested_contact_gap_s']+case['requested_contact_to_release_s'],protocol['primary_score_definition']['release_tolerance_s'])
        duration_timing=score_gap(effect,release_effect,case['requested_contact_to_release_s'],case['duration_tolerance_s'])
        qualification_pass=score['task_mechanism_pass'] and effect is not None and release_effect is not None
        record('task/qualification_score.json',dict(schema='paperb-single-factor-skill-qualification-score-v1',
            qualification_pass=qualification_pass,original_mechanism_pass=score['task_mechanism_pass'],
            independent_grasp_available=effect is not None,independent_supported_release_available=release_effect is not None,
            active_gain_installed_after_baseline_pass=True,active_gain_unchanged_during_task=True,
            full_source_command_sequence_unchanged=True,source_duration_and_H_constraints_not_relaxed=True,
            calibration_fit_or_main_test=False,causal_root_cause_proven=False))
        joint=not schedule['schedule_refused'] and all(x['timing_pass'] for x in (contact_timing,release_timing,duration_timing)) and score['task_mechanism_pass']
        timing=dict(contact=contact_timing,release=release_timing,duration_gap=duration_timing,joint_time_and_mechanism=joint,
            joint_with_sampled_hold=joint and expanded['sampled_contact_hold']['sampled_contact_hold'],
            sampled_contact_hold=expanded['sampled_contact_hold'],scientific_admission=False,chemical_event_verified=False,
            cue=public_cue,contact_effect=effect,release_effect=release_effect,method=case['method'],role=case['role'],
            current_test_events_used_to_fit_schedule=False,schedule_refused=schedule['schedule_refused'],qualification_not_test=True)
        record('task/timing_score.json',timing)
        record('task/video_frames.json',dict(fps=6,frames=video_frames,task_origin_native_s=task_origin,
            inference_waits_included=False,scope='NEW_NATIVE_RGB_AT_FIXED_PHYSICS_TICKS; NO_LLM_INFERENCE_IN_THIS_PILOT'))
        record('task/action_write_audit.json',dict(object_pose_writes=0,robot_pose_writes=0,robot_joint_state_writes=0,
            prohibited_calls=write_audit,scope='AFTER_DECLARED_RESTORE_AND_BEFORE_TASK_COMPLETION'))
        record('task/contact_coverage.json',dict(expected_bodies=expected,missing_bodies=missing,
            callbacks=sum(c['callbacks'] for c in contacts),coverage_pass=coverage))
        record('task/capture_index.json',images)
        record('task/stage_verification.json',verify_prefix(task,require_all=True))
        return dict(status='BASELINE_COMMANDS_COMPLETED',commands=len(rows),qualification_pass=qualification_pass,schedule_refused=schedule['schedule_refused'],timing_verdict=contact_timing['verdict'],release_verdict=release_timing['verdict'],duration_verdict=duration_timing['verdict'],joint_time_and_mechanism=joint,joint_with_sampled_hold=timing['joint_with_sampled_hold'],task_mechanism_pass=score['task_mechanism_pass'],
            task_stage=score['stage'],native_rgbd_snapshots=len(images),state_writes_during_task=0,
            native_epoch=epochs,policy_kind=protocol['policy_kind'],scientific_admission=False)

    gain_expected=None
    if True:
        # Matched control: retain the same 30 real steps without rewriting state.
        transient=[]
        for i in range(protocol['restore_ticks']):advance(-30+i);transient.append(capture(ns,rec))
        verdict=compare_state(cp,transient[-1],RestoreLimits())
        record('uninterrupted_transient_verdict.json',verdict)
        if verdict['status']!='PASS':raise RuntimeError('matched uninterrupted start gate failed')
        # The original baseline has been accepted. This separately declared
        # candidate controller installation follows it; it is not restoration.
        installation,gain_expected=install_declared_gain(robot,scene,sim,callback,verdict,
            baseline=protocol['qualification_actor_change']['baseline'],candidate=protocol['qualification_actor_change']['candidate'])
        record('CONTROLLER_INSTALLATION.json',installation)
        materials=dict(robot=robot.root_physx_view.get_material_properties().clone().tolist(),
            bottle=bottle.root_physx_view.get_material_properties().clone().tolist(),
            scope='ACTIVE_PHYSX_SHAPE_MATERIAL_PROPERTY_ARRAYS; SHAPE_TO_COLLIDER_MAPPING_NOT_ESTABLISHED',
            schema='paperb-active-material-readback-v1',material_changes=0)
        record('MATERIAL_ACTIVE_READBACK.json',materials)
        milestone('DECLARED_ACTIVE_HAND_GAIN_INSTALLED',baseline=800.,candidate=1600.,physics_steps_during_install=0)
        result=run_task()
    else:
        adapter=LegacyTwinAdapter(ns,rec,transient_step=lambda:advance(-30),next_stage=run_task)
        raise RuntimeError('reconstruction is disabled for this fresh uninterrupted cohort')
    result.update(phase=args.case,native_steps=native_steps,full_benchmark_pass=False,
        chemical_event_verified=False,event_memory_evaluated=False,agent_context_restored=False,
        native_clock_continuous_across_rebuild=False,wall_s=time.monotonic()-started)
    record('RESULT.json',result);milestone('RESULT',status=result['status'])
except BaseException as e:
    record('ERROR.json',dict(type=type(e).__name__,message=str(e),scientific_admission=False))
    traceback.print_exc()
finally:
    if telemetry is not None:telemetry.close()
    if app is not None:
        record('PROCESS_EXIT.json',dict(mode='CONTROLLED_EXIT_WITHOUT_SDK_CLEANUP',graceful_sdk_cleanup=False,
            scientific_admission=False))
        for path in out.rglob('*.jsonl'):
            with path.open('rb') as f:os.fsync(f.fileno())
        os._exit(0 if (out/'RESULT.json').exists() and not (out/'ERROR.json').exists() else 1)
