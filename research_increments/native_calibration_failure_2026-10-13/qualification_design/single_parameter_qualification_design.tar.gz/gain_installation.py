"""Declared single controller-parameter installation after baseline acceptance.

All measurements come from active PhysX views. No pose, velocity, joint state,
material, mass, damping or force-limit setter is used here.
"""
import hashlib
import json
import math

def safe_list(tensor):
    def clean(value):
        if isinstance(value,list):return [clean(x) for x in value]
        if isinstance(value,float) and math.isinf(value):return 'POSITIVE_INFINITY' if value>0 else 'NEGATIVE_INFINITY'
        if isinstance(value,float) and math.isnan(value):raise ValueError('NaN active parameter')
        return value
    return clean(tensor.tolist())

def active_drives(robot):
    return dict(stiffness=robot.root_physx_view.get_dof_stiffnesses().clone(),
                damping=robot.root_physx_view.get_dof_dampings().clone(),
                effort_limits=robot.root_physx_view.get_dof_max_forces().clone())

def state_token(scene):
    # Cached Isaac Lab scene-data tensors, deliberately excluding the
    # controller parameter. This is an additional cached-state check.
    bodies={k:dict(pos=a.data.root_pos_w.tolist(),quat=a.data.root_quat_w.tolist(),
                   lin_vel=a.data.root_lin_vel_w.tolist(),ang_vel=a.data.root_ang_vel_w.tolist())
            for k,a in scene.rigid_objects.items()}
    arms={k:dict(q=a.data.joint_pos.tolist(),qd=a.data.joint_vel.tolist(),
                 pos=a.data.root_pos_w.tolist(),quat=a.data.root_quat_w.tolist()) for k,a in scene.articulations.items()}
    return hashlib.sha256(json.dumps(dict(bodies=bodies,arms=arms),sort_keys=True,allow_nan=False).encode()).hexdigest()

def fresh_state_token(scene):
    # Getter names were checked in the installed rigid_object_data.py and
    # articulation_data.py before freezing this qualification source.
    bodies={k:dict(transforms=a.root_physx_view.get_transforms().clone().tolist(),
                   velocities=a.root_physx_view.get_velocities().clone().tolist())
            for k,a in scene.rigid_objects.items()}
    arms={k:dict(root_transforms=a.root_physx_view.get_root_transforms().clone().tolist(),
                 root_velocities=a.root_physx_view.get_root_velocities().clone().tolist(),
                 dof_positions=a.root_physx_view.get_dof_positions().clone().tolist(),
                 dof_velocities=a.root_physx_view.get_dof_velocities().clone().tolist())
          for k,a in scene.articulations.items()}
    return hashlib.sha256(json.dumps(dict(bodies=bodies,arms=arms),sort_keys=True,allow_nan=False).encode()).hexdigest()

def install(robot,scene,sim,callbacks,baseline_verdict,baseline=800.,candidate=1600.):
    import torch
    if baseline_verdict['status']!='PASS':raise ValueError('original baseline transient must pass before candidate installation')
    ids=[robot.joint_names.index(n) for n in ('fr3_finger_joint1','fr3_finger_joint2')]
    before=active_drives(robot);others=[i for i in range(robot.num_joints) if i not in ids]
    if not torch.equal(before['stiffness'][:,ids],torch.full_like(before['stiffness'][:,ids],baseline)):
        raise ValueError('active hand stiffness is not the predeclared baseline 800')
    if not torch.equal(before['damping'][:,ids],torch.full_like(before['damping'][:,ids],40.)):
        raise ValueError('active hand damping is not the predeclared 40')
    epoch_time=float(sim.current_time);count=callbacks['count'];physical_before=state_token(scene)
    fresh_before=fresh_state_token(scene)
    robot.write_joint_stiffness_to_sim(candidate,joint_ids=ids)
    # The installed SDK writer updates physical views/data buffers but not the
    # actuator-model cache (#128). Mirror the same declared gain in its cache
    # so effort diagnostics use the actual installed controller parameter.
    cached_before=robot.actuators['hand'].stiffness.clone()
    robot.actuators['hand'].stiffness.fill_(candidate)
    after=active_drives(robot)
    if not torch.equal(after['stiffness'][:,ids],torch.full_like(after['stiffness'][:,ids],candidate)):
        raise ValueError('active candidate hand gain installation failed')
    if not torch.equal(before['stiffness'][:,others],after['stiffness'][:,others]):raise ValueError('arm stiffness changed')
    if not torch.equal(before['damping'],after['damping']):raise ValueError('damping changed')
    if not torch.equal(before['effort_limits'],after['effort_limits']):raise ValueError('effort limits changed')
    physical_after=state_token(scene)
    fresh_after=fresh_state_token(scene)
    if epoch_time!=float(sim.current_time) or count!=callbacks['count'] or physical_before!=physical_after or fresh_before!=fresh_after:
        raise ValueError('controller installation changed native physical state/time')
    receipt=dict(schema='paperb-declared-active-controller-installation-v1',status='PASS_ACTIVE_GAIN_READBACK',
        original_baseline_transient_verdict=baseline_verdict,baseline_active_stiffness=safe_list(before['stiffness']),
        candidate_active_stiffness=safe_list(after['stiffness']),active_damping=safe_list(after['damping']),
        active_effort_limits=safe_list(after['effort_limits']),finger_joint_names=[robot.joint_names[i] for i in ids],
        finger_joint_indices=ids,actuator_cache_before=safe_list(cached_before),actuator_cache_after=safe_list(robot.actuators['hand'].stiffness),
        baseline_stiffness_N_per_m=baseline,candidate_stiffness_N_per_m=candidate,only_stiffness_changed=True,
        native_time_before_s=epoch_time,native_time_after_s=float(sim.current_time),physics_callbacks_before=count,physics_callbacks_after=callbacks['count'],
        cached_scene_state_sha256_before=physical_before,cached_scene_state_sha256_after=physical_after,
        fresh_physics_view_state_sha256_before=fresh_before,fresh_physics_view_state_sha256_after=fresh_after,
        cached_state_fingerprint_scope='ISAACLAB_SCENE_DATA_CACHED_TENSORS',fresh_state_fingerprint_scope='FRESH_RIGID_AND_ARTICULATION_PHYSX_VIEW_GETTERS',
        object_state_writes=0,robot_state_writes=0,parameter_installation_location='AFTER_ORIGINAL_BASELINE_ACCEPTANCE_BEFORE_TASK',
        runtime_view_is_authoritative=True,original_failed_cohort_active_readback_available=False)
    return receipt,after

def verify_end(robot,expected):
    import torch
    actual=active_drives(robot)
    if not all(torch.equal(actual[k],expected[k]) for k in expected):raise ValueError('active drive parameter changed during qualification task')
    return dict(schema='paperb-active-controller-end-readback-v1',status='PASS_UNCHANGED_DURING_ENTIRE_TASK',
                actual={k:safe_list(v) for k,v in actual.items()},unchanged_during_task=True)
