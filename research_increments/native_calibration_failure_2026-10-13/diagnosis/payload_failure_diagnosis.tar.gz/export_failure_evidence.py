"""Additive publication export: untouched raw, closed source archives, no GPU."""
import gzip
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

HERE = Path(__file__).parent
NATIVE = Path('/data/liyufeng/paperb_scene_methods_expansion_20261013_v1')
QUAL = Path('/data/liyufeng/paperb_grip_stiffness_qualification_20261013_v1')
PUBLIC = Path('/mnt/nas/data/lyf/chem_mem/awesome_memory_chem/papers/paperB/research_increments/native_calibration_failure_2026-10-13')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, payload):
    with path.open('x') as stream:
        json.dump(payload, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')


def assert_frozen(root, expected_sha):
    release = root / 'EXECUTION_RELEASE.json'
    if sha(release) != expected_sha:
        raise ValueError('release changed: ' + str(root))
    entries = json.loads(release.read_text())['files']
    for name, digest in entries.items():
        if sha(root / name) != digest:
            raise ValueError('frozen source changed: ' + name)
    return entries


def copy_exact(source, target):
    if target.exists():
        raise ValueError('do not overwrite export artifact: ' + str(target))
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    if sha(source) != sha(target):
        raise ValueError('copy mismatch: ' + str(source))


def archive_and_validate(folder, archive_name, extra_context):
    # Explicit current file roster; exclude the archive/receipt themselves.
    members = sorted(p for p in folder.rglob('*') if p.is_file())
    roster = {str(p.relative_to(folder)): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in members}
    write_json(folder / 'EXPORT_MANIFEST.json', dict(schema='paperb-additive-evidence-export-manifest-v1', files=roster, **extra_context))
    members.append(folder / 'EXPORT_MANIFEST.json')
    roster['EXPORT_MANIFEST.json'] = {'sha256': sha(members[-1]), 'bytes': members[-1].stat().st_size}
    archive = folder / archive_name
    with archive.open('xb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as bundle:
                for path in sorted(members):
                    name = str(path.relative_to(folder))
                    if path.is_symlink():
                        raise ValueError('symlink is not archive member: ' + name)
                    info = bundle.gettarinfo(str(path), arcname=name)
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    with path.open('rb') as stream:
                        bundle.addfile(info, stream)
    seen = set()
    with tarfile.open(archive, 'r:gz') as bundle:
        for member in bundle.getmembers():
            name = member.name
            if not member.isfile() or name.startswith('/') or '..' in Path(name).parts or name in seen:
                raise ValueError('invalid archive member: ' + name)
            seen.add(name)
            contents = bundle.extractfile(member).read()
            if hashlib.sha256(contents).hexdigest() != roster[name]['sha256'] or len(contents) != roster[name]['bytes']:
                raise ValueError('archive reopen mismatch: ' + name)
    if seen != set(roster):
        raise ValueError('archive roster incomplete')
    validation = dict(schema='paperb-evidence-archive-reopen-validation-v1', status='PASS_ALL_MEMBERS_REOPEN_SHA256',
        archive=archive.name, archive_sha256=sha(archive), archive_bytes=archive.stat().st_size,
        members_total=len(roster), each_member_sha256_exact=True, safe_regular_members_only=True,
        source_and_raw_modified=False, new_physics_integrations=0, **extra_context)
    write_json(folder / 'ARCHIVE_VALIDATION.json', validation)
    return validation


def main():
    native_release_sha = 'cf5cc59c9b9e0b215f2f5db408052ccb9cac8912c7c89ea8adc74e9d4c8b2efa'
    qual_release_sha = 'a41e73f426c232899f7b74ecd16db3caaf715cfa5ca11ce1023a06c15330000c'
    native_source = assert_frozen(NATIVE, native_release_sha)
    qual_source = assert_frozen(QUAL, qual_release_sha)
    diagnosis = json.loads((HERE / 'DIAGNOSIS.json').read_text())
    frames = json.loads((HERE / 'FRAME_PROVENANCE.json').read_text())
    for case in diagnosis['cases']:
        for name, digest in case['raw_bindings'].items():
            if sha(NATIVE / name) != digest:
                raise ValueError('raw diagnosis input changed: ' + name)
    for frame in frames['frames']:
        if sha(frame['original_frame']) != frame['original_jpeg_sha256']:
            raise ValueError('native RGB changed')
    diagnostics_dir = PUBLIC / 'diagnosis'
    design_dir = PUBLIC / 'qualification_design'
    diagnostics_dir.mkdir()
    design_dir.mkdir()
    for name in ['diagnose_payload.py', 'plot_diagnosis.py', 'export_failure_evidence.py', 'DIAGNOSIS.json',
                 'USD_AUTHORED_READ_ONLY.json', 'MATERIAL_BINDINGS_READ_ONLY.json', 'FRAME_PROVENANCE.json', 'README_cn.md',
                 'payload_failure_curves.png', 'payload_failure_curves.svg', 'payload_failure_curves.pdf', 'native_RGB_phase_comparison.png']:
        copy_exact(HERE / name, diagnostics_dir / name)
    for case in diagnosis['cases']:
        copy_exact(HERE / (case['case_id'] + '.csv'), diagnostics_dir / (case['case_id'] + '.csv'))
    for frame in frames['frames']:
        source = Path(frame['original_frame'])
        copy_exact(source, diagnostics_dir / 'original_RGB' / frame['case_id'] / source.name)
    copy_exact(NATIVE / 'EXECUTION_RELEASE.json', diagnostics_dir / 'native_EXECUTION_RELEASE.json')
    copy_exact(NATIVE / 'code/scene_cfg_twin.py', diagnostics_dir / 'configuration_only/scene_cfg_twin.py')
    summary = dict(schema='paperb-public-native-payload-diagnosis-summary-v1', status=diagnosis['status'],
        original_calibration_cases=4, original_mechanism_pass=2, original_mechanism_fail=2,
        all_original_calibration_cases_retained=True, original_task_samples=sum(c['native_samples'] for c in diagnosis['cases']),
        new_robot_episodes=0, new_native_samples=0, source_or_raw_changes=False,
        original_cohort_fit_admission=False, causal_root_cause_proven=False,
        case_results=[{k: c[k] for k in ['case_id', 'native_samples', 'mass_factor', 'actual_mass_kg', 'public_delay_ticks', 'mechanism_pass', 'first_bad_transitions']} for c in diagnosis['cases']],
        paired_arm_following=diagnosis['paired_arm_following'],
        diagnosis_metrics_are_not_replacement_scores=True,
        source_release_sha256=native_release_sha, CSV_rows_include_after_failure_and_FIFO_flush=True,
        figures_use_only_existing_raw=True,
        limitations=['Four fixed-scene calibration conditions, not four random-seed generalization trials',
                     'Contact loss occurs before 30mm/14.32deg diagnostics; smaller progressive slip already occurs earlier',
                     'Old cohort has configured hand K800 but no active gain, force-limit or effective material-pair readback',
                     'Reported contact impulse/dt is not calibrated tactile or total tangential friction force',
                     'Readonly localization is not counterfactual proof or qualification acceptance'])
    write_json(diagnostics_dir / 'summary.json', summary)
    for name, digest in qual_source.items():
        copy_exact(QUAL / name, design_dir / 'source_frozen' / name)
        if sha(design_dir / 'source_frozen' / name) != digest:
            raise ValueError('qualified source copy mismatch')
    copy_exact(QUAL / 'EXECUTION_RELEASE.json', design_dir / 'EXECUTION_RELEASE.json')
    for name in ['protocol.json', 'CPU_PREFLIGHT.json', 'INSTALLED_API_READ_ONLY.json', 'gain_installation.py']:
        copy_exact(QUAL / name, design_dir / name)
    actor = json.loads((QUAL / 'protocol.json').read_text())
    design = dict(schema='paperb-public-predeclared-single-parameter-qualification-v1', status='FROZEN_DESIGN_NOT_ACCEPTANCE_RESULT',
        frozen_source_files=len(qual_source), source_release_sha256=qual_release_sha,
        planned_case_id=actor['cases'][0]['id'], role='qualification', denominator=1,
        qualification_actor_change=actor['qualification_actor_change'], primary_gates=actor['qualification_primary_gates'],
        split_contract=actor['split_contract'], commands=actor['total_commands'], physics_dt_s=actor['dt_s'],
        calibrated_cases_in_design=0, test_cases_in_design=0, runtime_cases_archived_here=0,
        full_source_targets_identical=True, command_policy_sha256=actor['command_policy_sha256'],
        candidate_parameters_installed_after_original_baseline_acceptance=True,
        active_readback_receipt_plan=['CONTROLLER_INSTALLATION.json', 'MATERIAL_ACTIVE_READBACK.json', 'task/ACTIVE_DRIVE_END.json'],
        source_external_asset_dependencies_are_pinned_but_not_bundled=True,
        no_performance_or_causal_acceptance_claim=True, no_learning_claim=True,
        GPU_gate_unchanged_min_free_MiB=24576, foreign_processes_never_signaled=True,
        later_execution_and_independent_audit_are_separate=True,
        CPU_preflight=json.loads((QUAL / 'CPU_PREFLIGHT.json').read_text()))
    write_json(design_dir / 'summary.json', design)
    readback_design = dict(schema='paperb-qualification-active-readback-design-v1',
        source_release_sha256=qual_release_sha, active_parameters='root_physx_view: dof stiffness, damping, max force',
        install_before=['original warmup1200', 'original matched30-tick baseline acceptance PASS'],
        install_after='before first task command; exactly one physical parameter family changed',
        installation_operations=['IsaacLab write_joint_stiffness_to_sim on two finger IDs', 'mirror the same K into implicit hand actuator cache'],
        expected_baseline_finger_K=[800,800], expected_candidate_finger_K=[1600,1600], expected_finger_D=[40,40],
        exact_unchanged_parameters=['all seven arm stiffnesses', 'all damping entries', 'all maxForce entries', 'all full command targets', 'object mass/inertia/friction'],
        no_step_evidence=['native time before==after', 'physics callback count before==after'],
        separate_state_fingerprints=['cached IsaacLab scene-data tensors', 'fresh rigid-body PhysX transforms/velocities and articulation root transforms/velocities/DOF positions/velocities'],
        all_episode_gain_guard='task/ACTIVE_DRIVE_END.json exact matches installation receipt',
        material_readback_limit='active tensor rows do not alone identify effective collider-pair friction; no friction change or causal claim',
        post_install_root_cause_claim=False,
        future_calibration_rule='Only after qualification independent acceptance may a separate prospective protocol run all four calibration conditions; original four failures retained; qualification not fit data',
        scheduler_fairness='The same unconditional actor installation for all four future methods; no private current test truth or mass-conditioned scheduling')
    write_json(design_dir / 'READBACK_DESIGN.json', readback_design)
    with (design_dir / 'README_cn.md').open('x') as stream:
        stream.write('''# 单参数夹持资格设计：冻结 source，与运行结论分离

本目录保存 mass1.2 / FIFO0 的一条完整瓶体技能资格设计。原四条校准中的两条重载运输失败全部保留；本设计不回写失败轨迹，不改变机械计分门槛，不删重载，不拟合校准包络，也不作为16条主测试的一部分。

假设是增大夹持力储备可能改善运输稳定性。唯一 actor 参数变化为双指 hand stiffness800→1600，damping40、关节目标、arm、瓶体质量/惯量、摩擦、FIFO及原13427条完整技能指令不变。保持原技能时长，不能通过放慢 transport 挤占未来H18/18.5、最短技能17秒合同空间。它是一个前瞻资格假设，单次通过仍不是统计因果证明或方法胜出。

候选先按原800配置完成warmup1200和matched30-tick原baseline PASS，再在task之前公开安装1600。不能只改USD authored或在restore之前改cfg。active PhysX读回双指K800→1600，其他7arm K、全部D/maxForce须exact相同；同时只把同一个K镜像到implicit hand actuator缓存。native time/callback不推进，fresh PhysX状态张量与cached scene-data张量分别比较before/after指纹，禁止task内物体或关节状态setter。任务结束再次读回K/D/maxForce，独立RAW审计须验证全指令、FIFO、epoch、质量/惯量、原机械条件及独立稳定release。

`summary.json`、`protocol.json`与`READBACK_DESIGN.json`给出前瞻角色、准入和读回契约。分母为1条qualification；未来主矩阵16条另列。contact/release/duration的EARLY或PASS不是本资格的主指标。源中保留原计分器与所有门槛，资格必须满足完整执行、原机械任务、接触与独立稳定释放以及安装/全程参数验收。

`source_frozen/`为原117个冻结文件的精确副本，`EXECUTION_RELEASE.json`为source closure。压缩归档可下载，`ARCHIVE_VALIDATION.json`逐member重开验sha。外部IsaacLab/IsaacSim与USD资产依赖以原pin记录，资产及完整环境没有在本归档中重分发；本包不能当作无需这些依赖的独立仿真器。

8项CPU假接口/静态lineage预检通过，native episode=0，不能替代运行时读回或机械审计。GPU24GiB空闲门槛及UUID/minor/DRM、单GPU一owned worker/锁保持不变；资源拒绝不是物理episode，真实启动后的失败保留。实际执行、原始日志与独立审计由另一个结果组件发布，本目录不承诺资格已通过。

若此资格被独立验收，仍需另立冻结协议运行全部四条新校准，再独立审核、冻结校准包络，然后运行16条新测试。不能把本资格或旧失败挑选成校准样本，也不能追改旧源或事后调门槛。
''')
    # Verify both old immutable closures and all readonly input bindings again.
    assert_frozen(NATIVE, native_release_sha)
    assert_frozen(QUAL, qual_release_sha)
    for case in diagnosis['cases']:
        for name, digest in case['raw_bindings'].items():
            if sha(NATIVE / name) != digest:
                raise ValueError('raw changed during export')
    dv = archive_and_validate(diagnostics_dir, 'payload_failure_diagnosis.tar.gz', dict(
        source_release_sha256=native_release_sha, original_calibration_cases=4, original_task_samples=53732,
        causal_root_cause_proven=False, independent_acceptance_replaced=False))
    qv = archive_and_validate(design_dir, 'single_parameter_qualification_design.tar.gz', dict(
        source_release_sha256=qual_release_sha, frozen_source_files=len(qual_source), actual_runtime_results_archived=0,
        prospective_qualification_denominator=1, independent_acceptance_result=False))
    assert_frozen(NATIVE, native_release_sha)
    assert_frozen(QUAL, qual_release_sha)
    print(json.dumps(dict(diagnosis=dv, qualification_design=qv), ensure_ascii=False))


if __name__ == '__main__':
    main()
