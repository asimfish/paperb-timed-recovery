"""Scientific plots of existing native samples and unchanged original RGB frames."""
import hashlib,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image

ROOT=Path(__file__).parent
SOURCE=Path('/data/liyufeng/paperb_scene_methods_expansion_20261013_v1')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                     'pdf.fonttype':42,'svg.fonttype':'none'})
colors={80:'#356AA0',120:'#C4513E'}
fig,axes=plt.subplots(4,2,figsize=(11.5,9.5),sharex=True,layout='constrained')
for col,delay in enumerate((0,12)):
    for mass in (80,120):
        name=f'cal_m{mass:03}_d{delay:02}'
        a=np.genfromtxt(ROOT/(name+'.csv'),delimiter=',',names=True)
        x=a['source_index']/240.;mask=(x>=14)&(x<=31)
        ys=[a['left_reported_N']+a['right_reported_N'],a['jaw_width_mm'],a['relative_displacement_mm'],a['tilt_deg']]
        for row,y in enumerate(ys):axes[row,col].plot(x[mask],y[mask],color=colors[mass],lw=1.4,label=f'{.15*(mass/100):.2f} kg')
    axes[0,col].set_title(f'FIFO delay: {delay/240*1000:.0f} ms',loc='left',fontweight='bold')
    for row in range(4):
        ax=axes[row,col]
        ax.axvspan(16,19,color='#8FA4B4',alpha=.08,zorder=-2);ax.axvspan(19,27,color='#8FA4B4',alpha=.16,zorder=-2)
        ax.set_xlim(14,31);ax.grid(alpha=.2,linewidth=.5);ax.tick_params(length=3)
    axes[2,col].axhline(30,color='#666',ls='--',lw=.8)
    axes[3,col].axhline(np.degrees(.25),color='#666',ls='--',lw=.8)
    axes[3,col].set_xlabel('Source skill time (s), aligned by applied command')
axes[0,0].set_ylabel('Reported finger impulse / dt\nsum of both fingers (N)')
axes[1,0].set_ylabel('Jaw width (mm)')
axes[2,0].set_ylabel('Bottle–TCP relative drift (mm)')
axes[3,0].set_ylabel('Bottle tilt (degrees)')
axes[0,0].legend(frameon=False,loc='upper right',ncol=2)
fig.suptitle('Heavier bottles lose the grasp during transport',fontsize=14,fontweight='bold')
for ext in ('svg','pdf','png'):fig.savefig(ROOT/f'payload_failure_curves.{ext}',dpi=180)
plt.close(fig)

fig,axes=plt.subplots(2,4,figsize=(13,4.8),layout='constrained')
provenance=[]
for row,index in enumerate((4560,6480)):
    for col,(mass,delay) in enumerate(((80,0),(120,0),(80,12),(120,12))):
        name=f'cal_m{mass:03}_d{delay:02}';capture=index+delay
        path=SOURCE/'cases'/name/'task/images'/f'{capture:05}.jpg'
        if not path.exists():raise ValueError('missing original phase frame: '+str(path))
        rgb=np.asarray(Image.open(path).convert('RGB'));axes[row,col].imshow(rgb);axes[row,col].axis('off')
        axes[row,col].set_title(f'{.15*(mass/100):.2f} kg, FIFO {delay/240*1000:.0f} ms\n'+('After lift commands' if row==0 else 'After transport commands'),fontsize=10)
        captures=json.loads((SOURCE/'cases'/name/'task/capture_index.json').read_text())
        meta=next(x for x in captures if x['command_index']==capture)
        provenance.append(dict(case_id=name,source_stage_tick=index,task_capture_tick=capture,
            original_frame=str(path),original_jpeg_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            native_time_s=meta['native_time_s'],native_epoch=meta['native_epoch'],native_rgb_sha256=meta['native_rgb_sha256'],
            original_frame_pixels_not_edited=True,scope='UNMODIFIED_ORIGINAL_NATIVE_JPEG_IN_A_SCIENTIFIC_COMPARISON_FIGURE'))
fig.suptitle('Original native RGB: both lift, heavier bottles leave the hand during transport',fontsize=12,fontweight='bold')
fig.savefig(ROOT/'native_RGB_phase_comparison.png',dpi=160);plt.close(fig)
provenance_payload=dict(frames=provenance,new_physics_or_native_episodes=0)
provenance_path=ROOT/'FRAME_PROVENANCE.json'
if provenance_path.exists():
    if json.loads(provenance_path.read_text()) != provenance_payload:
        raise ValueError('existing original-RGB provenance differs; do not overwrite')
else:
    with provenance_path.open('x') as f:json.dump(provenance_payload,f,indent=2);f.write('\n')
print('rendered curves and original RGB comparison; no image generation or physics reintegration')
