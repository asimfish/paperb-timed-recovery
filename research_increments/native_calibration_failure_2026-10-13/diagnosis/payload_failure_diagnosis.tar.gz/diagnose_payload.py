"""Read-only native failure localization. No solver, GPU, policy or world mutation."""
import csv
import hashlib
import json
import math
from pathlib import Path
import numpy as np

ROOT=Path(__file__).parent
SOURCE=Path('/data/liyufeng/paperb_scene_methods_expansion_20261013_v1')
CASES=('cal_m080_d00','cal_m080_d12','cal_m120_d00','cal_m120_d12')

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def relative_position(tcp,pose):
    q=tcp[:,3:]/np.linalg.norm(tcp[:,3:],axis=1,keepdims=True)
    v=pose[:,:3]-tcp[:,:3];u=-q[:,1:];c=2*np.cross(u,v)
    return v+q[:,:1]*c+np.cross(u,c)

def tilt(pose):
    q=pose[:,3:]/np.linalg.norm(pose[:,3:],axis=1,keepdims=True)
    return np.degrees(np.arccos(np.clip(1-2*(q[:,1]**2+q[:,2]**2),-1,1)))

def first_run(mask,count,start=0):
    current=0
    for i in range(start,len(mask)):
        current=current+1 if mask[i] else 0
        if current>=count:return i-count+1
    return None

def summary_values(v):
    v=np.asarray(v)
    return dict(min=float(v.min()),median=float(np.median(v)),p05=float(np.percentile(v,5)),p95=float(np.percentile(v,95)),max=float(v.max()))

def analyze_case(name):
    path=SOURCE/'cases'/name;task=path/'task'
    rows=[json.loads(s) for s in (task/'states.jsonl').open()]
    contacts=[json.loads(s) for s in (task/'contact_rows.jsonl').open()]
    meta=json.loads((path/'case.json').read_text());events=json.loads((task/'expanded_events.json').read_text())
    score=json.loads((task/'independent_score.json').read_text());mass=json.loads((path/'mass_parameter_readback.json').read_text())
    n=len(rows);dt=np.array([r['native_after_s']-r['native_before_s'] for r in rows]);src=np.array([r['applied_source_command_index'] for r in rows])
    times=np.array([r['native_after_s']-rows[0]['native_before_s'] for r in rows]);pose=np.array([r['object_pose'] for r in rows]);tcp=np.array([r['tcp'] for r in rows])
    q=np.array([r['q_all'] for r in rows]);qd=np.array([r['qd_all'] for r in rows]);target=np.array([r['arm_target']+r['grip_target'] for r in rows])
    error=q-target;finger=np.zeros((n,2));finger_vec=np.zeros((n,2,3));normal=np.zeros((n,2));active=np.zeros((n,2),dtype=bool)
    anchors_requested=[]
    for i,c in enumerate(contacts):
        anchors_requested.append(c['friction_anchors_requested'])
        for point in c['contacts']:
            paths=[point[k] for k in ('actor0','actor1','collider0','collider1')]
            if not any(p=='/World/StationA/precursor_1' or p.startswith('/World/StationA/precursor_1/') for p in paths):continue
            impulse=np.array(point['impulse']);length=np.linalg.norm(impulse)
            if length<=1e-8:continue
            for j,side in enumerate(('left','right')):
                if any(p.startswith('/World/Robots/fr3_A/') and side in p and 'finger' in p for p in paths):
                    active[i,j]=True;finger[i,j]+=length/dt[i];finger_vec[i,j]+=impulse/dt[i]
                    normal[i,j]+=abs(np.dot(impulse,np.array(point['normal'])))/dt[i]
    bilateral=active.all(axis=1);relative=relative_position(tcp,pose)
    grasp=events['events']['bilateral_grasp']['confirmation_index'];onset=events['events']['bilateral_grasp']['onset_index']
    ref=np.median(relative[grasp:grasp+10],axis=0);rel_error=np.linalg.norm(relative-ref,axis=1)
    angles=tilt(pose);jaw=np.array([r['jaw_width_m'] for r in rows]);carry=(src>=3840)&(src<7440)
    lost_mask=~bilateral;lost_mask[src>=7440]=False;lost_mask[:grasp]=False
    transitions=dict(first_missing_bilateral=first_run(lost_mask,1,grasp),first_3_missing_bilateral=first_run(lost_mask,3,grasp),
        first_12_missing_bilateral=first_run(lost_mask,12,grasp),first_tilt_above_14_32_deg=first_run((angles>math.degrees(.25))&carry,1,grasp),
        first_relative_displacement_above_30mm=first_run((rel_error>.03)&carry,1,grasp))
    transition_details={}
    for key,i in transitions.items():
        if i is None:transition_details[key]=None;continue
        transition_details[key]=dict(row_index=int(i),applied_source_index=int(src[i]),native_time_s=rows[i]['native_after_s'],
            task_elapsed_s=float(times[i]),tilt_deg=float(angles[i]),relative_displacement_m=float(rel_error[i]),
            jaw_width_m=float(jaw[i]),finger_positions_m=q[i,7:].tolist(),finger_target_m=target[i,7:].tolist(),
            arm_tracking_error_rad=error[i,:7].tolist(),reported_finger_impulse_norm_per_dt_N=finger[i].tolist(),
            object_pose=pose[i].tolist(),tcp=tcp[i].tolist())
    stages={}
    for stage,a,b in [('closed_pre_lift',3404,3840),('lift',3840,4560),('transport',4560,6480),('placed_before_open',6480,7440),('release',7440,7920)]:
        mask=(src>=a)&(src<b)
        stages[stage]=dict(samples=int(mask.sum()),bilateral_fraction=float(bilateral[mask].mean()),
            arm_error_max_deg=float(np.degrees(abs(error[mask,:7]).max())),arm_error_rms_deg=float(np.degrees(np.sqrt(np.mean(error[mask,:7]**2)))),
            finger_error_mm=[summary_values(error[mask,7+j]*1000) for j in range(2)],jaw_width_mm=summary_values(jaw[mask]*1000),
            tilt_deg=summary_values(angles[mask]),relative_displacement_mm=summary_values(rel_error[mask]*1000),
            reported_impulse_norm_per_dt_N=[summary_values(finger[mask,j]) for j in range(2)],
            reported_normal_component_per_dt_N=[summary_values(normal[mask,j]) for j in range(2)])
    # Implicit position-drive proxy only: commanded velocity is zero, finger
    # effort feedforward is zero, but actual solver effort limits are unlogged.
    pd_proxy=-800*error[:,7:]-40*qd[:,7:]
    arrays=dict(t=times,source_index=src,bilateral=bilateral.astype(int),left_reported_N=finger[:,0],right_reported_N=finger[:,1],
        tilt_deg=angles,relative_displacement_mm=rel_error*1000,jaw_width_mm=jaw*1000,
        arm_error_rms_deg=np.degrees(np.sqrt(np.mean(error[:,:7]**2,axis=1))),
        left_error_mm=error[:,7]*1000,right_error_mm=error[:,8]*1000,left_PD_proxy_N=pd_proxy[:,0],right_PD_proxy_N=pd_proxy[:,1],
        object_x=pose[:,0],object_y=pose[:,1],object_z=pose[:,2])
    with (ROOT/(name+'.csv')).open('x',newline='') as f:
        w=csv.writer(f);w.writerow(list(arrays));w.writerows(zip(*arrays.values()))
    index_by_source={int(v):i for i,v in enumerate(src) if v>=0}
    result=dict(case_id=name,mass_factor=meta['case']['mass_factor'],public_delay_ticks=meta['case']['public_transport_delay_ticks'],
        actual_mass_kg=mass['mass_after_kg'][0][0],native_samples=n,mechanism_pass=score['task_mechanism_pass'],
        mechanical_conditions=score['conditions'],original_phase_score=score['phases'],confirmed_grasp_index=grasp,onset_grasp_index=onset,
        first_bad_transitions=transition_details,stage_metrics=stages,
        friction_anchors_requested=any(anchors_requested),friction_coefficient_or_force_limit_inferred=False,
        contact_force_scope='SUM_OF_REPORTED_CONTACT_IMPULSE_NORMS_DIVIDED_BY_MEASURED_DT; NOT_CALIBRATED_TACTILE_OR_FRICTION_FORCE',
        PD_proxy_scope='UNSATURATED_800N_PER_M_POSITION_MINUS_40NS_PER_M_VELOCITY_PROXY; NOT_MEASURED_ACTUATOR_EFFORT',
        raw_bindings={str(p.relative_to(SOURCE)):sha(p) for p in [task/'states.jsonl',task/'contact_rows.jsonl',task/'expanded_events.json',task/'independent_score.json',path/'mass_parameter_readback.json',path/'case.json']})
    return result,dict(rows=rows,source=src,q=q,tcp=tcp,pose=pose,error=error,index=index_by_source)

def main():
    freeze=json.loads((SOURCE/'EXECUTION_RELEASE.json').read_text())
    for n,h in freeze['files'].items():
        if sha(SOURCE/n)!=h:raise ValueError('frozen source changed: '+n)
    results=[];data={}
    for name in CASES:
        r,d=analyze_case(name);results.append(r);data[name]=d
    pairs=[]
    for delay in (0,12):
        light=data[f'cal_m080_d{delay:02}'];heavy=data[f'cal_m120_d{delay:02}']
        common=sorted(set(light['index'])&set(heavy['index']));li=[light['index'][i] for i in common];hi=[heavy['index'][i] for i in common]
        carry=np.array([(i>=3840 and i<7440) for i in common]);dq=heavy['q'][hi,:7]-light['q'][li,:7]
        dtcp=heavy['tcp'][hi,:3]-light['tcp'][li,:3]
        pairs.append(dict(public_delay_ticks=delay,matched_source_commands=len(common),carry_samples=int(carry.sum()),
            max_arm_joint_difference_deg=float(np.degrees(abs(dq[carry]).max())),
            rms_arm_joint_difference_deg=float(np.degrees(np.sqrt(np.mean(dq[carry]**2)))),
            max_TCP_position_difference_mm=float(np.linalg.norm(dtcp[carry],axis=1).max()*1000),
            median_TCP_position_difference_mm=float(np.median(np.linalg.norm(dtcp[carry],axis=1))*1000)))
    report=dict(schema='paperb-readonly-payload-failure-localization-v1',status='OBSERVATION_DIAGNOSIS_NO_CAUSAL_REPAIR_PROOF',
        frozen_native_execution_release_sha256=sha(SOURCE/'EXECUTION_RELEASE.json'),cases=results,paired_arm_following=pairs,
        actual_native_episodes_reused=4,new_native_episodes=0,physics_reintegration=0,source_and_raw_modified=False,
        cause_not_yet_identified_by_counterfactual=True,actuator_readback_or_material_friction_missing=True,
        output_csv_sha256={n+'.csv':sha(ROOT/(n+'.csv')) for n in CASES})
    with (ROOT/'DIAGNOSIS.json').open('x') as f:json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps(dict(status=report['status'],paired_arm_following=pairs)))

if __name__=='__main__':main()
