"""Write results/V02_CAPACITY_RESULT.json: v0.1 counterexample sequence under v0.2, bounds, thresholds."""
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tests'))
sys.path.insert(0, str(ROOT / 'code'))
import async_bridge as ab
import test_capacity as tc


def main():
    with tempfile.TemporaryDirectory(dir='/dev/shm') as tmp:
        root = Path(tmp)
        sequence = tc.v01_sequence_result(root, stride=7)
        rows, _ = tc.thresholds(root)
        labels = [label for i, (label, cap) in enumerate(rows) if i == 0 or cap > rows[i - 1][1]]
        exact = {label: tc.exact_threshold(root, label) for label in labels}
        boundary = {label: dict(cap=cap, at_cap_minus_1=tc.execute(root, 'b', cap - 1)[0], at_cap=tc.execute(root, 'a', cap)[0]) for label, cap in exact.items()}
    h = ab.fixture_header()
    result = dict(schema='PaperBAsyncBridgeV02CapacityResult/1', source='code/async_bridge.py',
                  v01_retained_red='retained_v01_red/byte_closure_rerun/RESULT.json (v0.1 d044729: start admitted at 5,260 B under 5,360 B cap, CASE_END refused)',
                  v02_on_v01_sequence=sequence,
                  fixture_line_bounds_bytes=ab.line_bounds(h), fixture_max_token_chars=h['caps']['max_token_chars'],
                  one_open_ticket_reserve_bytes=(lambda b: b['INFERENCE_RETURN'] + 8 * (b['SLOT_DISPOSITION'] + b['CHANNEL_RESULT']) + b['CASE_END_PER_TICKET'])(ab.line_bounds(h)),
                  scenario_binding_thresholds=boundary,
                  meaning='v0.2 either refuses at admission (CASE_BEGIN or the ordinary step) or, once admitted, writes every reserved event and CASE_END within the cap; '
                          'at 5,360 B the fixture case is refused at CASE_BEGIN because 8 refusal receipts and a worst-case CASE_END are reserved up front.',
                  limits=['Bounds are derived from canonical JSON of worst-case token/int/float values; caps smaller than the reservation refuse early by design.',
                          'Persistence faults (fsync uncertainty) still make the live owner BROKEN; the guarantee is about byte/count admission, not disk failure.',
                          'Single trusted owner; no concurrent writers.'])
    out = ROOT / 'results' / 'V02_CAPACITY_RESULT.json'
    with out.open('x') as f:
        json.dump(result, f, indent=2)
        f.write('\n')
    print(json.dumps(dict(start_threshold=sequence['start_threshold_bytes'], cap_5360=sequence['cap_5360'], sweep=sequence['sweep_outcomes'],
                          bindings={k: (v['cap'], v['at_cap_minus_1'], v['at_cap']) for k, v in boundary.items()}), indent=1))


if __name__ == '__main__':
    main()
