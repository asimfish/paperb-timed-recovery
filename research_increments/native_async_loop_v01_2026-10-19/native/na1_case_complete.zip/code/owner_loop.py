"""Single-owner asynchronous control loop: physics keeps stepping while a CPU worker infers.

Clock domains (never mixed):
  native tick k   - physics steps since the task origin (dt fixed by the adapter);
  native time     - simulator time since the task origin, integer ns; bridge tick/time/deadline;
  owner wall      - time.monotonic_ns() in this process; worker wall is the same host clock.

Per tick k, in this order: observe state k -> drain worker messages (RETURN is accepted
at the current state and all 8 original slots are dispositioned) -> apply the FIFO head if
its original desired tick is k -> maybe render + publish + start one ticket -> maybe render
a video frame -> one physics step to k+1. Only this loop calls the bridge and the adapter.
"""
from __future__ import annotations
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import selectors
import struct
import subprocess
import time

import numpy as np

from async_bridge import AsyncBridge, canonical, digest

HORIZON = 8


def frame(obj):
    data = canonical(obj)
    return struct.pack('>I', len(data)) + data


class WorkerClient:
    """Framed JSON over the worker's stdin/stdout; every inbound message is retained raw first."""

    def __init__(self, argv, env, raw_path, stderr_path, max_message=4 * 1024 * 1024):
        self.raw = open(raw_path, 'xb', buffering=0)
        self.stderr = open(stderr_path, 'xb', buffering=0)
        self.proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.stderr, env=env, start_new_session=False)
        os.set_blocking(self.proc.stdout.fileno(), False)
        self.selector = selectors.DefaultSelector()
        self.selector.register(self.proc.stdout, selectors.EVENT_READ)
        self.buffer = b''
        self.max_message = max_message

    def retain(self, direction, body):
        row = canonical({'direction': direction, 'owner_wall_ns': time.monotonic_ns(), 'body': body}) + b'\n'
        if self.raw.write(row) != len(row):
            raise OSError('RAW_WORKER_SHORT_WRITE')
        os.fsync(self.raw.fileno())

    def send(self, obj, retained=None):
        self.retain('OWNER_TO_WORKER', obj if retained is None else retained)
        self.proc.stdin.write(frame(obj))
        self.proc.stdin.flush()

    def poll(self, timeout=0.0):
        messages = []
        if self.selector.select(timeout):
            while True:
                try:
                    chunk = os.read(self.proc.stdout.fileno(), 1 << 20)
                except BlockingIOError:
                    break
                if not chunk:
                    break
                self.buffer += chunk
        while len(self.buffer) >= 4:
            size = struct.unpack('>I', self.buffer[:4])[0]
            if size > self.max_message:
                raise ValueError('WORKER_MESSAGE_TOO_LARGE')
            if len(self.buffer) < 4 + size:
                break
            raw, self.buffer = self.buffer[4:4 + size], self.buffer[4 + size:]
            self.retain('WORKER_TO_OWNER_RAW', {'bytes_b64': base64.b64encode(raw).decode('ascii')})
            messages.append(json.loads(raw))
        return messages

    def wait_message(self, timeout_s):
        end = time.monotonic() + timeout_s
        while time.monotonic() < end:
            got = self.poll(0.05)
            if got:
                return got
            if self.proc.poll() is not None:
                raise RuntimeError('WORKER_EXITED:%s' % self.proc.returncode)
        raise TimeoutError('WORKER_MESSAGE_TIMEOUT')

    def stop(self, timeout_s=10.0):
        """STOP, wait for exit, retain every trailing message (e.g. STOPPED with parameter digests)."""
        try:
            self.send({'kind': 'STOP'})
            self.proc.stdin.close()
        except (BrokenPipeError, OSError):
            pass
        try:
            code = self.proc.wait(timeout_s)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            code = self.proc.wait(5)
        tail = []
        try:
            tail = self.poll(0.2)
        except (OSError, ValueError):
            pass
        self.raw.close()
        self.stderr.close()
        return code, tail


def public_packet(rgb, q, qd, dt_s):
    """P0 public input: 64x40 bilinear RGB (CHW uint8), q9+qd9, nominal offsets (1..8)*dt in seconds (P0 training units), full mask."""
    from PIL import Image
    small = np.asarray(Image.fromarray(rgb).resize((64, 40), Image.BILINEAR), dtype=np.uint8)
    buffer = io.BytesIO()
    np.savez(buffer, image=np.ascontiguousarray(small.transpose(2, 0, 1)), proprio=np.r_[q, qd].astype(np.float64),
             nominal_offsets=np.arange(1, HORIZON + 1, dtype=np.float64) * dt_s, mask=np.ones(HORIZON, dtype=np.bool_))
    return buffer.getvalue(), small


def float_hex(values):
    return [float(v).hex() for v in values]


def run_owner_loop(adapter, bridge: AsyncBridge, worker: WorkerClient, out: Path, *, task_ticks, request_period,
                   video_every, return_wait_s, actor_id, dt_s):
    """Returns a summary dict. Raises only for owner faults; a guard stop ends the case normally."""
    from PIL import Image
    frames = out / 'frames'
    frames.mkdir()
    requests = out / 'request_frames'
    requests.mkdir()
    ticks = (out / 'TICKS.jsonl').open('x')
    header = bridge.snapshot()['header']
    tickets = {}
    inflight = None
    next_request = 0
    applied_target = list(adapter.initial_target())
    stop_reason = None
    guard_stop_tick = None
    last_observed = None
    counts = dict(applied=0, rejected=0, video_frames=0, requests=0, returns=0, worker_errors=0, dropped_at_end=0)

    def bstate(k, s):
        return {'attempt_id': header['attempt_id'], 'native_epoch': header['native_epoch'], 'state_id': 'n%d' % k,
                'physical_state_sha256': digest({'q': float_hex(s['q']), 'qd': float_hex(s['qd']), 'native_time_ns': s['time_ns']}),
                'tick': k, 'time_ns': s['time_ns'], 'deadline_clock_id': header['deadline_clock_id'], 'deadline_time_ns': s['time_ns'],
                'collector_source_sha256': header['collector_source_sha256'], 'lawful_state': s['lawful']}

    def handle(messages, k):
        nonlocal inflight
        for m in messages:
            kind = m.get('kind')
            if kind == 'RECEIVED':
                if inflight is None or m.get('ticket_id') != inflight:
                    raise RuntimeError('UNEXPECTED_WORKER_RECEIPT')
                tickets[inflight]['worker_received_ns'] = m['wall_ns']
                continue
            if kind not in ('RETURN', 'ERROR'):
                raise RuntimeError('UNEXPECTED_WORKER_MESSAGE:%s' % kind)
            if inflight is None:
                raise RuntimeError('WORKER_MESSAGE_WITHOUT_TICKET')
            t = tickets[inflight]
            wall = time.monotonic_ns()
            if kind == 'RETURN':
                if m['ticket_id'] != inflight or m['snapshot_sha256'] != t['snapshot_sha256'] or m['input_sha256'] != t['input_sha256']:
                    raise RuntimeError('WORKER_RETURN_BINDING_MISMATCH')
                bridge.accept_return(inflight, snapshot_sha256=t['snapshot_sha256'], output_8x9=m['output_8x9'], current_state_id='n%d' % k, wall_ns=wall)
                counts['returns'] += 1
            else:
                bridge.accept_return(inflight, snapshot_sha256=t['snapshot_sha256'], output_8x9=None, current_state_id='n%d' % k, wall_ns=wall, status='ERROR')
                counts['worker_errors'] += 1
            t.update(return_tick=k, return_owner_ns=wall, worker={x: m.get(x) for x in ('compute_start_ns', 'compute_end_ns', 'wall_return_send_ns', 'error_type', 'message')})
            dispositions = []
            for slot in range(HORIZON):
                q = bridge.queue_snapshot()['sha256']
                p = bridge.prepare_slot(inflight, slot, current_state_id='n%d' % k, queue_sha256=q, purpose='ORIGINAL_GOAL')
                bridge.commit_slot(p, current_state_id='n%d' % k, queue_sha256=q, wall_ns=time.monotonic_ns())
                dispositions.append(p['disposition'])
            t['dispositions'] = dispositions
            inflight = None

    for k in range(task_ticks):
        s = adapter.state()
        if s['tick'] != k:
            raise RuntimeError('ADAPTER_TICK_MISMATCH')
        wall_observe = time.monotonic_ns()
        bridge.observe_state(bstate(k, s), wall_ns=wall_observe)
        last_observed = k
        handle(worker.poll(0.0), k)
        if not s['lawful']:
            # Guard first: nothing more is applied or started; pending commands are dropped at the end.
            stop_reason, guard_stop_tick = 'STATE_GUARD_STOP', k
            break
        applied_now = None
        head = bridge.queue_snapshot()['commands'][:1]
        if head and head[0]['desired_tick'] == k:
            cmd = head[0]
            status = 'APPLIED' if adapter.target_admissible(cmd['target_9d']) else 'REJECTED'
            if status == 'APPLIED':
                applied_target = list(cmd['target_9d'])
                counts['applied'] += 1
            else:
                counts['rejected'] += 1
            bridge.record_channel_result(cmd['command_id'], status=status, current_state_id='n%d' % k, actual_target_9d=cmd['target_9d'], claimed_owner=cmd['owner'], wall_ns=time.monotonic_ns())
            applied_now = [cmd['command_id'], status]
        rgb = None
        if inflight is None and k >= next_request and k + HORIZON < task_ticks:
            rgb = adapter.render()
            packet, _ = public_packet(rgb, s['q'], s['qd'], dt_s)
            Image.fromarray(rgb).save(requests / ('%05d.jpg' % k), quality=92)
            tid = 'k%05d' % k
            bridge.publish_packet('p%05d' % k, packet, wall_ns=time.monotonic_ns())
            start = bridge.start_inference(tid, actor_id=actor_id, actual_input_bytes=packet, desired_ticks=[k + o for o in range(1, HORIZON + 1)], declared_end_tick=task_ticks, purpose='ORIGINAL_GOAL', wall_ns=time.monotonic_ns())
            body = start['body']
            tickets[tid] = dict(ticket_id=tid, start_tick=k, start_owner_ns=start['wall_ns'], snapshot_sha256=body['snapshot_sha256'], input_sha256=body['snapshot']['input_sha256'])
            request = {'kind': 'INFER', 'ticket_id': tid, 'snapshot_sha256': body['snapshot_sha256'], 'input_sha256': body['snapshot']['input_sha256'], 'input_base64': body['snapshot']['input_bytes_b64']}
            worker.send(request, retained={x: v for x, v in request.items() if x != 'input_base64'})
            inflight = tid
            next_request = k + request_period
            counts['requests'] += 1
        if k % video_every == 0:
            Image.fromarray(adapter.render() if rgb is None else rgb).save(frames / ('%05d.jpg' % k), quality=92)
            counts['video_frames'] += 1
        before = time.monotonic_ns()
        adapter.step(applied_target)
        after = time.monotonic_ns()
        ticks.write(json.dumps(dict(tick=k, native_time_ns=s['time_ns'], owner_observe_ns=wall_observe, step_wall_start_ns=before, step_wall_end_ns=after,
                                    inflight=inflight, applied=applied_now, lawful=s['lawful'], q=s['q'], qd=s['qd'], target=applied_target), allow_nan=False) + '\n')
    final = adapter.state()
    if final['tick'] != last_observed:
        bridge.observe_state(bstate(final['tick'], final), wall_ns=time.monotonic_ns())
    # A started ticket is not abandoned silently: wait (no physics) for its return, else it is censored.
    deadline = time.monotonic() + return_wait_s
    while inflight is not None and time.monotonic() < deadline:
        try:
            handle(worker.wait_message(max(0.05, deadline - time.monotonic())), final['tick'])
        except TimeoutError:
            break
    # Commands whose original tick can no longer occur are recorded explicitly, never re-timed.
    while bridge.queue_snapshot()['commands']:
        cmd = bridge.queue_snapshot()['commands'][0]
        bridge.record_channel_result(cmd['command_id'], status='DROPPED', current_state_id='n%d' % final['tick'], actual_target_9d=cmd['target_9d'], claimed_owner=cmd['owner'], wall_ns=time.monotonic_ns())
        counts['dropped_at_end'] += 1
    end = bridge.close(reason=stop_reason or 'TASK_TICKS_COMPLETED', wall_ns=time.monotonic_ns())
    ticks.close()
    (out / 'TICKETS.json').write_text(json.dumps(tickets, indent=1, allow_nan=False) + '\n')
    return dict(stop_reason=stop_reason or 'TASK_TICKS_COMPLETED', guard_stop_tick=guard_stop_tick, final_tick=final['tick'], counts=counts,
                censored=end['body']['censored'], tickets=len(tickets))
