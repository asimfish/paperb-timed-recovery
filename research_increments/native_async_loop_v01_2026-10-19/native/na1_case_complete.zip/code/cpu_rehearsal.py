"""CPU rehearsal of the NA1 owner loop with the real P0 worker and a stand-in physics adapter.

The adapter is a first-order joint tracker with an artificial per-step wall cost, so that
inference overlaps physics ticks. It exercises wiring only; it is not native physics.
"""
import argparse
import json
import os
from pathlib import Path
import sys
import time

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from async_bridge import AsyncBridge, fixture_header, canonical
from owner_loop import WorkerClient, run_owner_loop


class StandInAdapter:
    def __init__(self, q0, limits, dt_ns, step_sleep_s, images, unlawful_at=None):
        self.k, self.q, self.qd = 0, np.asarray(q0, float), np.zeros(9)
        self.limits, self.dt_ns, self.sleep, self.unlawful_at = np.asarray(limits, float), dt_ns, step_sleep_s, unlawful_at
        self.q0 = list(q0)
        self.images = images  # recorded M1 frames (3x40x64), nearest-upsampled to 640x400 as stand-in renders

    def initial_target(self):
        return self.q0

    def state(self):
        lawful = self.unlawful_at is None or self.k < self.unlawful_at
        return dict(tick=self.k, time_ns=self.k * self.dt_ns, q=self.q.tolist(), qd=self.qd.tolist(), lawful=lawful)

    def target_admissible(self, target):
        t = np.asarray(target, float)
        return bool(t.shape == (9,) and np.isfinite(t).all() and np.all(t >= self.limits[:, 0]) and np.all(t <= self.limits[:, 1]))

    def render(self):
        small = self.images[min(self.k // 80, len(self.images) - 1)].transpose(1, 2, 0)
        return np.ascontiguousarray(small.repeat(10, axis=0).repeat(10, axis=1))

    def step(self, target):
        new = self.q + 0.08 * (np.asarray(target, float) - self.q)
        self.qd = (new - self.q) / (self.dt_ns * 1e-9)
        self.q = new
        self.k += 1
        time.sleep(self.sleep)


def main():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--root', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--task-ticks', type=int, default=240)
    p.add_argument('--step-sleep-s', type=float, default=0.02)
    p.add_argument('--unlawful-at', type=int, default=None)
    a = p.parse_args()
    root, out = Path(a.root).resolve(), Path(a.out)
    out.mkdir(parents=True, exist_ok=False)
    protocol = json.loads((root / 'protocol.json').read_text())
    data = np.load(root / 'inputs/p0_dataset.npz')
    q0 = data['proprio'][0][:9].tolist()
    # Native FR3 limits read back in M1 (task/contract.json robot_state_bounds.position_limits).
    limits = [[-2.743699789047241, 2.743699789047241], [-1.7836999893188477, 1.7836999893188477], [-2.9006998538970947, 2.9006998538970947],
              [-3.042099952697754, -0.1517999917268753], [-2.80649995803833, 2.80649995803833], [0.544499933719635, 4.516899585723877],
              [-3.015899658203125, 3.015899658203125], [0.0, 0.03999999910593033], [0.0, 0.03999999910593033]]
    adapter = StandInAdapter(q0, limits, int(round(protocol['dt_s'] * 1e9)), a.step_sleep_s, data['images'], a.unlawful_at)
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='')
    worker = WorkerClient([sys.executable, '-B', str(root / 'code/p0_service_worker.py'), '--root', str(root)], env, out / 'RAW_WORKER_CHANNEL.jsonl', out / 'worker_stderr.log')
    ready = worker.wait_message(120)
    assert len(ready) == 1 and ready[0]['kind'] == 'READY' and not ready[0]['cuda_initialized'], ready
    header = fixture_header()
    header.update(mode='CPU_FIXTURE', attempt_id='na1-cpu-rehearsal', failure_root_id='cpu-rehearsal-no-task', native_epoch='cpu-stand-in-adapter',
                  original_deadline_ns=int(round(a.task_ticks * protocol['dt_s'] * 1e9)), deadline_clock_id='stand-in-time-since-origin', graph_id='na1-cpu-rehearsal')
    header['actors'] = [dict(actor_id='p0_student', role='STUDENT', actor_source_sha256='a' * 64, weights_sha256='b' * 64, input_adapter_sha256='c' * 64)]
    header['initial_actor_id'] = 'p0_student'
    header['channel']['latency_ticks'] = protocol['channel_latency_ticks']
    (out / 'EXPECTED_HEADER.json').write_bytes(canonical(header) + b'\n')
    bridge = AsyncBridge(out / 'ASYNC_JOURNAL.jsonl', header, expected_header=json.loads(canonical(header)))
    t0 = time.monotonic()
    summary = run_owner_loop(adapter, bridge, worker, out, task_ticks=a.task_ticks, request_period=protocol['request_period_ticks'],
                             video_every=protocol['video_every_ticks'], return_wait_s=protocol['return_wait_s'], actor_id='p0_student', dt_s=protocol['dt_s'])
    code, tail = worker.stop()
    result = dict(status='CPU_REHEARSAL_FINISHED', **summary, worker_exit_code=code, worker_tail=tail, wall_s=time.monotonic() - t0,
                  native_physics=False, task_ticks=a.task_ticks)
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('censored', 'worker_tail')}))


if __name__ == '__main__':
    main()
