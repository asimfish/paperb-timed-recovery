"""CPU-only P0 engineering-model service: repeated INFER requests over framed stdin/stdout.

Same frozen-input checks, preprocessing, fixed-noise 16-step DDIM reverse and
denormalisation as the 2026-10-16 one-shot worker. Only the owner's public packet bytes
cross the pipe; no SDK, robot, state, outcome or future target is visible here.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import struct
import sys
import time

os.environ['CUDA_VISIBLE_DEVICES'] = ''


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def send(obj):
    data = canonical(obj)
    sys.stdout.buffer.write(struct.pack('>I', len(data)) + data)
    sys.stdout.buffer.flush()


def receive(limit=4 * 1024 * 1024):
    head = sys.stdin.buffer.read(4)
    if len(head) < 4:
        return None
    size = struct.unpack('>I', head)[0]
    if size > limit:
        raise ValueError('REQUEST_TOO_LARGE')
    data = sys.stdin.buffer.read(size)
    if len(data) != size:
        raise ValueError('TRUNCATED_REQUEST')
    return json.loads(data)


def parameter_digest(model):
    h = hashlib.sha256()
    for name, value in sorted(model.state_dict().items()):
        h.update(name.encode())
        h.update(str(value.dtype).encode())
        h.update(str(tuple(value.shape)).encode())
        h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--root', required=True)
    root = Path(parser.parse_args().root)
    try:
        import numpy as np
        import torch
        pins = json.loads((root / 'INPUT_PINS.json').read_text())['inputs']
        for name in ('p0_model.py', 'p0_checkpoint.pt', 'P0_PROTOCOL.json'):
            data = (root / 'inputs' / name).read_bytes()
            if len(data) != pins[name]['bytes'] or hashlib.sha256(data).hexdigest() != pins[name]['sha256']:
                raise ValueError('WORKER_FROZEN_SOURCE_CHANGED:' + name)
        checkpoint = torch.load(root / 'inputs/p0_checkpoint.pt', map_location='cpu', weights_only=True)
        if checkpoint['schema'] != 'PaperBOfflineEngineeringCPUCheckpoint/1' or checkpoint['updates'] != 200:
            raise ValueError('EXPECTED_PRIOR_ENGINEERING_CHECKPOINT')
        cfg = checkpoint['config']
        if torch.__version__ != cfg['torch_version']:
            raise ValueError('FROZEN_TORCH_VERSION_REQUIRED')
        torch.set_num_threads(2)
        torch.set_num_interop_threads(1)
        torch.use_deterministic_algorithms(True)
        spec = importlib.util.spec_from_file_location('frozen_p0_model', root / 'inputs/p0_model.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        model = module.ImageConditionedDenoiser(8, 9).to('cpu')
        model.load_state_dict(checkpoint['state_dict'], strict=True)
        model.eval()
        before = parameter_digest(model)
        if before != checkpoint['final_parameter_digest']:
            raise ValueError('CHECKPOINT_PARAMETER_DIGEST_MISMATCH')
        normalizer = checkpoint['normalizer']
        beta = torch.linspace(cfg['beta_start'], cfg['beta_end'], cfg['diffusion_steps'])
        alpha_bar = torch.cumprod(1 - beta, dim=0)
        send({'kind': 'READY', 'pid': os.getpid(), 'checkpoint_sha256': pins['p0_checkpoint.pt']['sha256'], 'parameter_digest': before,
              'torch_version': torch.__version__, 'cuda_initialized': torch.cuda.is_initialized(), 'wall_ns': time.monotonic_ns()})

        def norm(name, arr):
            n = normalizer[name]
            return ((arr - np.asarray(n['mean'])) / np.asarray(n['scale'])).astype(np.float32)

        served = 0
        while True:
            request = receive()
            if request is None or request.get('kind') == 'STOP':
                break
            if set(request) != {'kind', 'ticket_id', 'snapshot_sha256', 'input_sha256', 'input_base64'} or request['kind'] != 'INFER':
                raise ValueError('EXACT_PUBLIC_REQUEST_SCHEMA')
            public_bytes = base64.b64decode(request['input_base64'], validate=True)
            if hashlib.sha256(public_bytes).hexdigest() != request['input_sha256']:
                raise ValueError('WORKER_INPUT_BYTES_SHA_MISMATCH')
            received_ns = time.monotonic_ns()
            send({'kind': 'RECEIVED', 'ticket_id': request['ticket_id'], 'actual_input_sha256': request['input_sha256'], 'wall_ns': received_ns})
            with np.load(io.BytesIO(public_bytes), allow_pickle=False) as bundle:
                if set(bundle.files) != {'image', 'proprio', 'nominal_offsets', 'mask'}:
                    raise ValueError('PUBLIC_INPUT_HAS_UNDECLARED_FIELDS')
                arrays = {key: bundle[key].copy() for key in bundle.files}
            if arrays['image'].shape != (3, 40, 64) or arrays['image'].dtype != np.uint8:
                raise ValueError('IMAGE_INPUT_SHAPE_DTYPE')
            if arrays['proprio'].shape != (18,) or arrays['nominal_offsets'].shape != (8,) or arrays['mask'].shape != (8,):
                raise ValueError('PROPRIO_OFFSET_MASK_SHAPE')
            if arrays['mask'].dtype != np.bool_ or not arrays['mask'].all():
                raise ValueError('DECLARED_EIGHT_VALID_SLOTS_REQUIRED')
            if not all(np.isfinite(arrays[key]).all() for key in ('proprio', 'nominal_offsets')):
                raise ValueError('NONFINITE_PUBLIC_TENSOR')
            image = torch.from_numpy(arrays['image'].astype(np.float32) / 255.0)[None]
            proprio = torch.from_numpy(norm('proprio', arrays['proprio']))[None]
            offsets = torch.from_numpy(norm('nominal_offset', arrays['nominal_offsets']))[None]
            mask = torch.from_numpy(arrays['mask'])[None]
            generator = torch.Generator(device='cpu').manual_seed(20261016)
            noise = torch.randn((1, 8, 9), generator=generator)
            compute_start = time.monotonic_ns()
            sampled = module.deterministic_reverse(model, noise, image, proprio, offsets, mask, alpha_bar, 16)
            compute_end = time.monotonic_ns()
            n = normalizer['action']
            physical = sampled[0].cpu().numpy() * np.asarray(n['scale']) + np.asarray(n['mean'])
            if physical.shape != (8, 9) or not np.isfinite(physical).all():
                raise ValueError('NONFINITE_OR_WRONG_OUTPUT')
            served += 1
            output = physical.tolist()
            send({'kind': 'RETURN', 'ticket_id': request['ticket_id'], 'snapshot_sha256': request['snapshot_sha256'], 'input_sha256': request['input_sha256'],
                  'output_8x9': output, 'wall_received_ns': received_ns, 'compute_start_ns': compute_start, 'compute_end_ns': compute_end,
                  'wall_return_send_ns': time.monotonic_ns(), 'served': served, 'cuda_initialized': torch.cuda.is_initialized()})
        after = parameter_digest(model)
        if after != before:
            raise ValueError('PARAMETER_CHANGE')
        send({'kind': 'STOPPED', 'served': served, 'initial_parameter_digest': before, 'final_parameter_digest': after,
              'new_training_updates': 0, 'cuda_initialized': torch.cuda.is_initialized(), 'wall_ns': time.monotonic_ns()})
    except BaseException as exc:
        try:
            send({'kind': 'ERROR', 'error_type': type(exc).__name__, 'message': str(exc), 'wall_ns': time.monotonic_ns()})
        except (BrokenPipeError, OSError):
            pass
        raise


if __name__ == '__main__':
    main()
