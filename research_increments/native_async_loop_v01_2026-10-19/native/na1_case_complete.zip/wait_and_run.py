"""Poll GPU free memory read-only until the frozen gate passes, then run one gated attempt.

Never signals other processes or changes driver settings. Bounded wait; every poll is logged.
"""
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
POLL_S = 120
MAX_WAIT_S = 10 * 3600


def free_mib():
    rows = subprocess.check_output(['nvidia-smi', '--query-gpu=uuid,memory.free', '--format=csv,noheader,nounits'], text=True).strip().splitlines()
    return {r.split(',')[0].strip(): int(r.split(',')[1]) for r in rows}


def main():
    gate = json.loads((ROOT / 'protocol.json').read_text())['budget']['gpu_min_free_mib']
    log = (ROOT / 'logs').mkdir(exist_ok=True) or (ROOT / 'logs' / 'gpu_wait.jsonl')
    start = time.monotonic()
    while True:
        free = free_mib()
        passed = max(free.values()) >= gate
        with log.open('a') as f:
            f.write(json.dumps(dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), free_mib=free, gate_mib=gate, passed=passed)) + '\n')
        if passed:
            break
        if time.monotonic() - start > MAX_WAIT_S:
            with log.open('a') as f:
                f.write(json.dumps(dict(status='WAIT_BUDGET_EXHAUSTED_NOT_LAUNCHED')) + '\n')
            return
        time.sleep(POLL_S)
    result = subprocess.run(['python3', str(ROOT / 'run_case.py'), '--execute'], capture_output=True, text=True)
    with log.open('a') as f:
        f.write(json.dumps(dict(status='RUN_CASE_RETURNED', code=result.returncode, stdout=result.stdout[-4000:], stderr=result.stderr[-4000:])) + '\n')


if __name__ == '__main__':
    main()
