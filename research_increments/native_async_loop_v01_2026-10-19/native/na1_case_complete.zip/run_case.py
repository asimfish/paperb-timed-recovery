"""Gate and launch one NA1 attempt; retain every attempt, never rerun after the native clock started.

Checks: source freeze pins, attempt budget, prior native clock, live GPU free memory (read-only
nvidia-smi), unique PCI/DRM mapping. Launches launch.sh in its own session with a wall cap and
kills only that session on timeout. No foreign process is signalled; no driver setting changes.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write_once(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


def verify_freeze():
    freeze = json.loads((ROOT / 'SOURCE_FREEZE.json').read_text())
    for name, pin in freeze['files'].items():
        if sha(ROOT / name) != pin:
            raise SystemExit('SOURCE_PIN_MISMATCH:' + name)
    for name, pin in freeze['external_read_only'].items():
        if sha(name) != pin:
            raise SystemExit('EXTERNAL_PIN_MISMATCH:' + name)
    for link, target in freeze['driver_capsule'].items():
        if os.readlink(ROOT / 'driver_capsule_570.124.06' / link) != target:
            raise SystemExit('CAPSULE_CHANGED:' + link)
    return freeze


def gpus():
    rows = subprocess.check_output(['nvidia-smi', '--query-gpu=uuid,pci.bus_id,memory.free,memory.used,utilization.gpu', '--format=csv,noheader,nounits'], text=True)
    out = []
    for line in rows.strip().splitlines():
        uuid, pci, free, used, util = [x.strip() for x in line.split(',')]
        out.append(dict(uuid=uuid, pci=pci, free_mib=int(free), used_mib=int(used), util=int(util)))
    return out


def mapping(uuid):
    matches = [(p, p.read_text()) for p in Path('/proc/driver/nvidia/gpus').glob('*/information') if uuid in p.read_text()]
    if len(matches) != 1:
        raise SystemExit('GPU_UUID_NOT_UNIQUE')
    p, info = matches[0]
    pci = p.parent.name
    minor = int(re.search(r'Device Minor:\s*(\d+)', info).group(1))
    drm = [d.name for d in Path('/sys/class/drm').iterdir() if re.fullmatch(r'card\d+|renderD\d+', d.name) and (d / 'device').resolve().name == pci]
    cards, renders = sorted(x for x in drm if x.startswith('card')), sorted(x for x in drm if x.startswith('renderD'))
    if len(cards) != 1 or len(renders) != 1:
        raise SystemExit('GPU_DRM_PAIR_NOT_UNIQUE')
    return dict(pci=pci, minor=minor, card=cards[0], render=renders[0])


def main():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--execute', action='store_true')
    a = p.parse_args()
    freeze = verify_freeze()
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    budget = protocol['budget']
    attempts_dir = ROOT / 'launch_attempts'
    attempts_dir.mkdir(exist_ok=True)
    previous = sorted(attempts_dir.glob('attempt_*.json'))
    for prior in (ROOT / 'cases').glob('*') if (ROOT / 'cases').exists() else []:
        if (prior / 'NATIVE_CLOCK_STARTED.json').exists():
            raise SystemExit('FORMAL_NATIVE_CASE_ALREADY_STARTED:' + prior.name)
    n = len(previous) + 1
    if n > budget['max_launch_attempts']:
        raise SystemExit('LAUNCH_ATTEMPT_BUDGET_EXHAUSTED')
    live = gpus()
    best = max(live, key=lambda g: g['free_mib'])
    receipt = dict(schema='PaperBNA1LaunchAttempt/1', attempt=n, case_id='%s_a%d' % (protocol['case_id'], n), source_freeze_sha256=sha(ROOT / 'SOURCE_FREEZE.json'),
                   gpus_observed=live, selected_gpu=best['uuid'], min_free_mib=budget['gpu_min_free_mib'], foreign_processes_signaled=False, global_driver_changes=False,
                   started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    if best['free_mib'] < budget['gpu_min_free_mib']:
        receipt['status'] = 'REFUSED_GPU_FREE_MEMORY_BELOW_GATE'
        refusal = ROOT / 'resource_gate_refusals' / ('%s.json' % time.strftime('%Y%m%dT%H%M%S'))
        write_once(refusal, receipt)
        raise SystemExit(receipt['status'])
    m = mapping(best['uuid'])
    receipt.update(mapping=m)
    if not a.execute:
        print(json.dumps(dict(receipt, status='VERIFY_ONLY_NOT_LAUNCHED'), indent=1))
        return
    receipt['status'] = 'LAUNCHED'
    attempt_file = attempts_dir / ('attempt_%d.json' % n)
    write_once(attempt_file, receipt)
    logs = ROOT / 'logs'
    logs.mkdir(exist_ok=True)
    with (logs / ('%s.stdout.log' % receipt['case_id'])).open('xb') as so, (logs / ('%s.stderr.log' % receipt['case_id'])).open('xb') as se:
        start = time.monotonic()
        proc = subprocess.Popen(['bash', str(ROOT / 'launch.sh'), receipt['case_id'], str(m['minor']), m['card'], m['render']], stdout=so, stderr=se, start_new_session=True)
        timed_out = False
        try:
            code = proc.wait(budget['child_wall_cap_s'])
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(proc.pid, signal.SIGKILL)
            code = proc.wait(30)
        wall = time.monotonic() - start
    case = ROOT / 'cases' / receipt['case_id']
    write_once(attempts_dir / ('attempt_%d_exit.json' % n), dict(attempt=n, case_id=receipt['case_id'], exit_code=code, timed_out=timed_out, wall_s=wall,
                                                                native_clock_started=(case / 'NATIVE_CLOCK_STARTED.json').exists(),
                                                                result_exists=(case / 'RESULT.json').exists(), error_exists=(case / 'ERROR.json').exists(),
                                                                source_freeze_unchanged_after=all(sha(ROOT / k) == v for k, v in freeze['files'].items())))
    print(json.dumps(dict(attempt=n, exit_code=code, timed_out=timed_out, wall_s=round(wall, 1)), indent=1))


if __name__ == '__main__':
    main()
