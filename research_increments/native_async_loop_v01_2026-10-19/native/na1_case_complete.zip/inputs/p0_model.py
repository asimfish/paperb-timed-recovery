import math
import torch
from torch import nn


class ImageConditionedDenoiser(nn.Module):
    def __init__(self, horizon=8, action_dims=9):
        super().__init__()
        self.horizon, self.action_dims = horizon, action_dims
        self.encoder = nn.Sequential(nn.Conv2d(3, 8, 3, stride=2, padding=1), nn.SiLU(),
                                     nn.Conv2d(8, 16, 3, stride=2, padding=1), nn.SiLU(),
                                     nn.Conv2d(16, 16, 3, stride=2, padding=1), nn.SiLU(),
                                     nn.AdaptiveAvgPool2d((2, 2)), nn.Flatten(), nn.Linear(64, 32), nn.SiLU())
        inputs = horizon * action_dims + 32 + 18 + horizon * 2 + 16
        self.net = nn.Sequential(nn.Linear(inputs, 128), nn.SiLU(), nn.Linear(128, 128),
                                 nn.SiLU(), nn.Linear(128, horizon * action_dims))

    def forward(self, noisy_action, step, image, proprio, nominal_offsets, slot_mask):
        freq = torch.exp(torch.arange(8, dtype=noisy_action.dtype, device=noisy_action.device)
                         * (-math.log(10000.0) / 7.0))
        angles = step[:, None].to(noisy_action.dtype) * freq[None]
        step_embedding = torch.cat([torch.sin(angles), torch.cos(angles)], dim=1)
        features = torch.cat([noisy_action.flatten(1), self.encoder(image), proprio,
                              nominal_offsets, slot_mask.to(noisy_action.dtype), step_embedding], dim=1)
        return self.net(features).reshape(-1, self.horizon, self.action_dims)


def masked_mse(prediction, reference, slot_mask):
    weights = slot_mask[:, :, None].to(prediction.dtype).expand_as(prediction)
    if weights.sum().item() == 0:
        raise ValueError('NO_OBSERVED_TARGETS')
    return ((prediction - reference).square() * weights).sum() / weights.sum()


@torch.no_grad()
def deterministic_reverse(model, initial_noise, image, proprio, offsets, mask, alpha_bar, reverse_steps):
    # 100-step DDPM forward/noise training; deterministic 16-index DDIM reverse.
    indices = torch.linspace(len(alpha_bar) - 1, 0, reverse_steps).round().long().tolist()
    x = initial_noise.clone()
    for i, step in enumerate(indices):
        t = torch.full((len(x),), step, dtype=torch.long)
        eps = model(x, t, image, proprio, offsets, mask)
        a = alpha_bar[step]
        clean = (x - torch.sqrt(1 - a) * eps) / torch.sqrt(a)
        if i + 1 == len(indices):
            x = clean
        else:
            previous = alpha_bar[indices[i + 1]]
            x = torch.sqrt(previous) * clean + torch.sqrt(1 - previous) * eps
    return x
