"""Driver user-space capsule: soname and unversioned symlinks to the loaded kernel module's 570.124.06 libraries.

Read-only on the host: only creates symlinks inside this work directory. Refuses if the
loaded kernel module is not 570.124.06.
"""
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
VERSION = '570.124.06'
LIB = Path('/usr/lib/x86_64-linux-gnu')


def main():
    loaded = Path('/proc/driver/nvidia/version').read_text()
    if VERSION not in loaded.splitlines()[0]:
        raise SystemExit('KERNEL_MODULE_VERSION_NOT_%s' % VERSION)
    capsule = ROOT / ('driver_capsule_' + VERSION)
    capsule.mkdir(exist_ok=False)
    links = {}
    for lib in sorted(LIB.glob('*.so.' + VERSION)):
        soname = subprocess.check_output(['objdump', '-p', str(lib)], text=True)
        name = next(line.split()[1] for line in soname.splitlines() if line.strip().startswith('SONAME'))
        base = lib.name[:-len('.' + VERSION)]
        for alias in sorted({name, base, lib.name}):
            if alias not in links:
                (capsule / alias).symlink_to(lib)
                links[alias] = str(lib)
    record = dict(schema='PaperBDriverCapsule/1', kernel_module=loaded.splitlines()[0], version=VERSION, links=links,
                  reason='host default sonames libcuda/libnvidia-ml/ptxjit/nvvm/opencl/cudadebugger point to 580.178.04 while the loaded module and GLX/EGL/Vulkan user space are 570.124.06')
    (ROOT / 'DRIVER_CAPSULE.json').write_text(json.dumps(record, indent=2) + '\n')
    print(len(links), 'links')


if __name__ == '__main__':
    main()
