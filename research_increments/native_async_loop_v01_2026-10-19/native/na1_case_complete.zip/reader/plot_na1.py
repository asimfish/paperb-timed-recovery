"""NA1 timeline figure from recorded files only (journal, TICKETS.json, TICKS.jsonl).

A: per-ticket worker interval on the native tick axis, and the channel outcome of every
   submitted slot at its original tick.  B: measured joint position vs. the stepped target.
"""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

INK, INK2, GRID = '#0b0b0b', '#52514e', '#e4e3df'
BLUE, ORANGE, AQUA = '#2a78d6', '#eb6834', '#1baf7a'


def main():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--case', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--dt', type=float, required=True)
    a = p.parse_args()
    case, out = Path(a.case), Path(a.out)
    out.mkdir(parents=True, exist_ok=False)
    events = [json.loads(x) for x in (case / 'ASYNC_JOURNAL.jsonl').read_bytes().splitlines()]
    tickets = json.loads((case / 'TICKETS.json').read_text())
    rows = [json.loads(x) for x in (case / 'TICKS.jsonl').read_text().splitlines()]
    names = json.loads((case / 'registry.json').read_text())['robot_joint_names'] if (case / 'registry.json').exists() else ['joint%d' % i for i in range(1, 10)]
    applied = [e['clock'][0] for e in events if e['kind'] == 'CHANNEL_RESULT' and e['body']['status'] == 'APPLIED']
    rejected = [e['clock'][0] for e in events if e['kind'] == 'CHANNEL_RESULT' and e['body']['status'] == 'REJECTED']
    stale = [e['body']['prepared']['desired_tick'] for e in events if e['kind'] == 'SLOT_DISPOSITION' and e['body']['prepared']['disposition'] == 'STALE']
    plt.rcParams.update({'font.size': 9, 'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2,
                         'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'DejaVu Sans'})
    fig, (ax, bx) = plt.subplots(2, 1, figsize=(10, 6.2), sharex=True, gridspec_kw={'height_ratios': [1, 1.6]})
    fig.subplots_adjust(left=0.15, right=0.98, top=0.88, bottom=0.1, hspace=0.32)
    for t in tickets.values():
        if 'return_tick' in t:
            ax.plot([t['start_tick'], max(t['return_tick'], t['start_tick'] + 0.35)], [3, 3], color=BLUE, lw=5, solid_capstyle='round')
    ax.scatter(applied, [2] * len(applied), s=14, color=AQUA, label='APPLIED at original tick', zorder=3)
    ax.scatter(rejected, [1] * len(rejected), s=14, marker='x', color=ORANGE, label='REJECTED (outside joint limits)', zorder=3)
    ax.scatter(stale, [0] * len(stale), s=10, marker='|', color=INK2, label='STALE (tick passed before return)', zorder=3)
    ax.set_yticks([0, 1, 2, 3], ['STALE slot', 'REJECTED', 'APPLIED', 'start→return'])
    ax.set_ylim(-0.7, 3.7)
    ax.grid(axis='x', color=GRID, lw=0.8)
    ax.set_title('A  Worker intervals and slot outcomes on the native physics tick axis', loc='left', fontsize=10, fontweight='bold', color=INK)
    ticks = [r['tick'] for r in rows]
    for j, color in ((0, BLUE), (3, AQUA)):
        bx.plot(ticks, [r['q'][j] for r in rows], color=color, lw=1.6, label='%s measured' % names[j])
        bx.step(ticks, [r['target'][j] for r in rows], where='post', color=color, lw=1.0, ls='--', label='%s stepped target' % names[j])
    bx.grid(color=GRID, lw=0.8)
    bx.set_ylabel('joint position (rad)')
    bx.set_xlabel('native physics tick since task origin (dt = %.4f s)' % a.dt)
    bx.set_title('B  Measured joint position and the target held between applied commands', loc='left', fontsize=10, fontweight='bold', color=INK)
    handles = ax.get_legend_handles_labels()
    fig.legend(*handles, loc='upper left', bbox_to_anchor=(0.145, 0.965), ncol=3, frameon=False, fontsize=8)
    bx.legend(loc='center right', bbox_to_anchor=(1.0, 0.42), ncol=2, frameon=False, fontsize=8)
    fig.suptitle('NA1: one native asynchronous P0 loop (wiring check, not task success)', x=0.15, ha='left', y=0.995, fontsize=11.5, fontweight='bold', color=INK)
    for ext in ('svg', 'pdf', 'png'):
        fig.savefig(out / ('na1_timeline.' + ext), dpi=160)
    (out / 'FIGURE_INPUTS.json').write_text(json.dumps(dict(case=str(case), tickets=len(tickets), applied=len(applied), rejected=len(rejected), stale=len(stale),
                                                            ticks=len(rows), joints_plotted=[names[0], names[3]], data_windowed=False), indent=2) + '\n')


if __name__ == '__main__':
    main()
