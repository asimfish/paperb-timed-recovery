"""Offline NA1 reader: replays the journal and cross-checks it with raw worker messages, tick log and frames.

Uses only the case directory and the frozen bridge module (for its read-only replay). Every
check is derived from recorded bytes; nothing is re-executed. Writes READER_REPORT.json.
"""
import argparse
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics

import numpy as np


def load_bridge(path):
    spec = importlib.util.spec_from_file_location('frozen_bridge', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def stats(values):
    if not values:
        return None
    return dict(n=len(values), min=min(values), median=statistics.median(values), max=max(values), mean=statistics.fmean(values))


def main():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--case', required=True)
    p.add_argument('--bridge', required=True)
    p.add_argument('--task-ticks', type=int, required=True)
    p.add_argument('--video-every', type=int, required=True)
    p.add_argument('--output', default='READER_REPORT.json')
    a = p.parse_args()
    case = Path(a.case)
    bridge = load_bridge(a.bridge)
    checks = {}
    header = json.loads((case / 'EXPECTED_HEADER.json').read_text())
    replay = bridge.AsyncBridge.replay(case / 'ASYNC_JOURNAL.jsonl', expected_header=header).snapshot()
    checks['journal_replay_closed'] = bool(replay['closed'])
    events = [json.loads(line) for line in (case / 'ASYNC_JOURNAL.jsonl').read_bytes().splitlines()]
    kinds = {}
    for e in events:
        kinds[e['kind']] = kinds.get(e['kind'], 0) + 1
    end = events[-1]
    checks['last_event_case_end'] = end['kind'] == 'CASE_END'

    # Per ticket: physics ticks that elapsed while the worker held the ticket.
    starts, returns, observed_between = {}, {}, {}
    current_tick = None
    open_tickets = set()
    for e in events:
        if e['kind'] == 'OBSERVED_STATE':
            current_tick = e['body']['state']['tick']
            for t in open_tickets:
                observed_between[t] = observed_between.get(t, 0) + 1
        elif e['kind'] == 'INFERENCE_START':
            starts[e['body']['ticket_id']] = dict(tick=e['clock'][0], wall=e['wall_ns'])
            open_tickets.add(e['body']['ticket_id'])
            observed_between[e['body']['ticket_id']] = 0
        elif e['kind'] == 'INFERENCE_RETURN':
            returns[e['body']['ticket_id']] = dict(tick=e['clock'][0], wall=e['wall_ns'], status=e['body']['status'], output_sha=e['body']['output_sha256'])
            open_tickets.discard(e['body']['ticket_id'])
    ticks_during = [returns[t]['tick'] - starts[t]['tick'] for t in returns]
    checks['every_started_ticket_returned_or_censored'] = set(starts) == set(returns) | set(end['body']['censored']['unreturned_tickets'])
    checks['observed_states_match_tick_gaps'] = all(observed_between[t] == returns[t]['tick'] - starts[t]['tick'] for t in returns)

    # Slot dispositions and channel results.
    disp = {}
    submitted = {}
    for e in events:
        if e['kind'] == 'SLOT_DISPOSITION':
            pr = e['body']['prepared']
            disp[pr['disposition']] = disp.get(pr['disposition'], 0) + 1
            if pr['disposition'] == 'SUBMIT':
                submitted[pr['command_id']] = pr
    applied_ok = True
    channel = {}
    applied_ticks = []
    for e in events:
        if e['kind'] == 'CHANNEL_RESULT':
            b = e['body']
            channel[b['status']] = channel.get(b['status'], 0) + 1
            if b['status'] == 'APPLIED':
                pr = submitted[b['command_id']]
                applied_ticks.append(e['clock'][0])
                applied_ok &= e['clock'][0] == pr['desired_tick'] and b['actual_target_9d'] == pr['target_9d'] and pr['desired_tick'] >= pr['earliest_apply_tick']
    checks['applied_exactly_at_original_slot_tick'] = applied_ok
    checks['at_most_one_applied_per_tick'] = len(applied_ticks) == len(set(applied_ticks))

    # Tick log: the stepped target equals the latest applied command target, else is held.
    rows = [json.loads(line) for line in (case / 'TICKS.jsonl').read_text().splitlines()]
    tick_ok = [r['tick'] for r in rows] == list(range(len(rows)))
    target_ok = True
    last = rows[0]['target'] if rows else None
    applied_by_tick = {}
    for e in events:
        if e['kind'] == 'CHANNEL_RESULT' and e['body']['status'] == 'APPLIED':
            applied_by_tick[e['clock'][0]] = e['body']['actual_target_9d']
    for r in rows:
        if r['tick'] in applied_by_tick:
            target_ok &= r['target'] == applied_by_tick[r['tick']]
        elif last is not None:
            target_ok &= r['target'] == last
        last = r['target']
    checks['tick_log_contiguous'] = tick_ok
    checks['stepped_target_equals_applied_or_held'] = target_ok
    step_wall = [(r['step_wall_end_ns'] - r['step_wall_start_ns']) / 1e6 for r in rows]

    # Raw worker channel: returned outputs equal journal returns; parameters unchanged.
    raw = [json.loads(line) for line in (case / 'RAW_WORKER_CHANNEL.jsonl').read_text().splitlines()]
    inbound = [json.loads(base64.b64decode(r['body']['bytes_b64'])) for r in raw if r['direction'] == 'WORKER_TO_OWNER_RAW']
    worker_returns = {m['ticket_id']: m for m in inbound if m.get('kind') == 'RETURN'}
    digest = lambda v: hashlib.sha256(bridge.canonical(v)).hexdigest()
    checks['raw_worker_outputs_equal_journal'] = all(t in worker_returns and digest(worker_returns[t]['output_8x9']) == r['output_sha']
                                                     for t, r in returns.items() if r['status'] == 'OK')
    stopped = [m for m in inbound if m.get('kind') == 'STOPPED']
    checks['worker_parameters_unchanged'] = len(stopped) == 1 and stopped[0]['initial_parameter_digest'] == stopped[0]['final_parameter_digest'] and stopped[0]['served'] == len(worker_returns)
    checks['worker_never_initialized_cuda'] = all(not m.get('cuda_initialized') for m in inbound if 'cuda_initialized' in m)
    compute_ms = [(m['compute_end_ns'] - m['compute_start_ns']) / 1e6 for m in worker_returns.values()]
    owner_roundtrip_ms = [(returns[t]['wall'] - starts[t]['wall']) / 1e6 for t in returns]

    # Frames.
    frames = sorted((case / 'frames').glob('*.jpg'))
    from PIL import Image
    sizes = {Image.open(f).size for f in frames}
    expected_frames = len([k for k in range(len(rows)) if k % a.video_every == 0])
    checks['video_frames_complete_and_decodable'] = len(frames) == expected_frames and len(sizes) == 1
    request_frames = sorted((case / 'request_frames').glob('*.jpg'))
    checks['request_frame_per_ticket'] = len(request_frames) == len(starts)

    report = dict(schema='PaperBNA1ReaderReport/1', case=str(case), status='PASS' if all(checks.values()) else 'FAIL', checks=checks,
                  event_kinds=kinds, tickets=len(starts), returns=len(returns), dispositions=disp, channel_results=channel,
                  physics_ticks_during_inference=stats(ticks_during),
                  tickets_with_physics_progress_during_inference=sum(1 for v in ticks_during if v > 0),
                  worker_compute_ms=stats(compute_ms), owner_start_to_return_ms=stats(owner_roundtrip_ms), step_wall_ms=stats(step_wall),
                  task_ticks_logged=len(rows), video_frames=len(frames), frame_size=sorted(sizes), censored=end['body']['censored'],
                  close_reason=end['body']['reason'], journal_bytes=replay['journal_bytes'])
    (case / a.output).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('status', 'checks', 'tickets', 'dispositions', 'channel_results', 'physics_ticks_during_inference', 'worker_compute_ms')}, indent=1))


if __name__ == '__main__':
    main()
