"""Descriptive: did each worker compute interval overlap an actual native physics step?

Worker compute_start/end and owner step_wall_start/end are both CLOCK_MONOTONIC on one host.
No re-execution; reads RAW_WORKER_CHANNEL.jsonl, TICKETS.json and TICKS.jsonl.
"""
import argparse
import base64
import json
from pathlib import Path
import statistics


def main():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--case', required=True)
    p.add_argument('--output', required=True)
    a = p.parse_args()
    case = Path(a.case)
    raw = [json.loads(x) for x in (case / 'RAW_WORKER_CHANNEL.jsonl').read_text().splitlines()]
    inbound = [json.loads(base64.b64decode(r['body']['bytes_b64'])) for r in raw if r['direction'] == 'WORKER_TO_OWNER_RAW']
    returns = {m['ticket_id']: m for m in inbound if m.get('kind') == 'RETURN'}
    tickets = json.loads((case / 'TICKETS.json').read_text())
    steps = [json.loads(x) for x in (case / 'TICKS.jsonl').read_text().splitlines()]
    rows = []
    for tid, t in sorted(tickets.items()):
        m = returns[tid]
        cs, ce = m['compute_start_ns'], m['compute_end_ns']
        window = [s for s in steps if t['start_tick'] <= s['tick'] < t['return_tick']]
        overlap = sum(max(0, min(ce, s['step_wall_end_ns']) - max(cs, s['step_wall_start_ns'])) for s in window)
        rows.append(dict(ticket=tid, start_tick=t['start_tick'], return_tick=t['return_tick'], compute_ms=(ce - cs) / 1e6,
                         physics_steps_between=len(window), compute_overlapping_physics_step_ms=overlap / 1e6,
                         owner_start_to_worker_received_ms=(m['wall_received_ns'] - t['start_owner_ns']) / 1e6,
                         worker_return_to_owner_accept_ms=(t['return_owner_ns'] - m['wall_return_send_ns']) / 1e6))
    over = [r['compute_overlapping_physics_step_ms'] for r in rows]
    summary = dict(schema='PaperBNA1ComputePhysicsOverlap/1', tickets=len(rows),
                   tickets_with_compute_overlapping_a_physics_step=sum(1 for v in over if v > 0),
                   overlap_ms=dict(min=min(over), median=statistics.median(over), max=max(over), total=sum(over)),
                   compute_ms_median=statistics.median(r['compute_ms'] for r in rows),
                   owner_start_to_worker_received_ms_median=statistics.median(r['owner_start_to_worker_received_ms'] for r in rows),
                   worker_return_to_owner_accept_ms_median=statistics.median(r['worker_return_to_owner_accept_ms'] for r in rows),
                   clock='host CLOCK_MONOTONIC (time.monotonic_ns) in both processes', per_ticket=rows)
    Path(a.output).write_text(json.dumps(summary, indent=1) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k != 'per_ticket'}, indent=1))


if __name__ == '__main__':
    main()
