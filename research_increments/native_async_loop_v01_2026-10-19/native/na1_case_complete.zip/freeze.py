"""Write SOURCE_FREEZE.json once: local sources/inputs, read-only M1 scene files, capsule links."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
M1 = Path('/data/liyufeng/paperb_handoff_force_diagnostics_20261014_v2')
LOCAL = ['code/async_bridge.py', 'code/owner_loop.py', 'code/p0_service_worker.py', 'code/native_async_loop.py', 'code/cpu_rehearsal.py',
         'reader/check_na1.py', 'protocol.json', 'launch.sh', 'run_case.py', 'build_capsule.py', 'freeze.py', 'INPUT_PINS.json', 'DRIVER_CAPSULE.json',
         'inputs/p0_model.py', 'inputs/p0_checkpoint.pt', 'inputs/P0_PROTOCOL.json', 'inputs/P0_NORMALIZER.json', 'inputs/p0_dataset.npz']
EXTERNAL = [M1 / 'plan.json', M1 / 'code/scene_cfg_twin.py', M1 / 'code/robot_collision_filters.py', M1 / 'code/contact_calibration.json',
            M1 / 'code/xrd_window_cfg.py', M1 / 'code/xrd_window_passive_cfg.py']
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    out = ROOT / 'SOURCE_FREEZE.json'
    capsule = ROOT / 'driver_capsule_570.124.06'
    value = dict(schema='PaperBNA1SourceFreeze/1', files={n: sha(ROOT / n) for n in LOCAL}, external_read_only={str(p): sha(p) for p in EXTERNAL},
                 driver_capsule={l.name: os.readlink(l) for l in sorted(capsule.iterdir())},
                 bridge_parent='/data/liyufeng/paperb_async_bridge_v02_20261019_v1/code/async_bridge.py',
                 bridge_parent_sha256=sha('/data/liyufeng/paperb_async_bridge_v02_20261019_v1/code/async_bridge.py'))
    if value['files']['code/async_bridge.py'] != value['bridge_parent_sha256']:
        raise SystemExit('BRIDGE_COPY_DIFFERS_FROM_V02')
    with out.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
    print(out, len(value['files']), len(value['external_read_only']), len(value['driver_capsule']))


if __name__ == '__main__':
    main()
