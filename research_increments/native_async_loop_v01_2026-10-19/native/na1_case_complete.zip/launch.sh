#!/usr/bin/env bash
# One sandboxed native NA1 case on one explicitly admitted GPU. Same binds and Kit flags as M1.
set -euo pipefail
root=/data/liyufeng/paperb_native_async_loop_20261019_v1
m1=/data/liyufeng/paperb_handoff_force_diagnostics_20261014_v2
chem_root=/mnt/nas/data/safelab/retreat/lyf-back/chembench
capsule="$root/driver_capsule_570.124.06"
local_sdk=/home/liyufeng/miniforge3/envs/safeduo
case_id=${1:?case}
gpu_minor=${2:?minor}
gpu_card=${3:?card}
gpu_render=${4:?render}
runtime_local=/tmp/paperb-na1-runtime-$case_id
mkdir -p "$runtime_local/"{tmp,cache,config,data,kit,omni,torch,cuda}
mkdir -p "$root/runtime"
exec bwrap --die-with-parent --ro-bind / / --tmpfs /home --ro-bind /home/liyufeng /home/liyufeng \
 --ro-bind /data/liyufeng/goai_assets/scenes/psibot_root /home/psibot \
 --tmpfs /data/lyf --ro-bind "$chem_root/psilab/assets/usd/Chemistrylab/Textures" '/data/lyf/Chemistry lab/textures' \
 --bind "$root" "$root" --bind "$runtime_local" "$root/runtime" \
 --bind "$runtime_local/tmp" /tmp --bind "$runtime_local/tmp" /var/tmp \
 --dev /dev --dev-bind "/dev/nvidia$gpu_minor" "/dev/nvidia$gpu_minor" --dev-bind /dev/nvidiactl /dev/nvidiactl \
 --dev-bind /dev/nvidia-uvm /dev/nvidia-uvm --dev-bind /dev/nvidia-uvm-tools /dev/nvidia-uvm-tools \
 --dev-bind /dev/nvidia-modeset /dev/nvidia-modeset --dir /dev/dri \
 --dev-bind "/dev/dri/$gpu_card" "/dev/dri/$gpu_card" --dev-bind "/dev/dri/$gpu_render" "/dev/dri/$gpu_render" --proc /proc \
 --bind "$runtime_local/omni" /home/liyufeng/.nvidia-omniverse --chdir "$root" -- \
 env -u CUDA_VISIBLE_DEVICES -u http_proxy -u https_proxy -u HTTP_PROXY -u HTTPS_PROXY -u ALL_PROXY -u all_proxy \
 LD_LIBRARY_PATH="$capsule" LD_PRELOAD="$local_sdk/lib/libstdc++.so.6" \
 CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_MPS_PIPE_DIRECTORY=/tmp/paperb-na1-no-mps PYTHONDONTWRITEBYTECODE=1 \
 PYTHONPATH="$root/code:$m1/code:/home/liyufeng/safeduo_isaaclab/source/isaaclab" \
 ISAAC_PATH="$local_sdk/lib/python3.11/site-packages/isaacsim" TERM=xterm OMNI_KIT_ACCEPT_EULA=YES PRIVACY_CONSENT=Y \
 XDG_CACHE_HOME="$root/runtime/cache" XDG_CONFIG_HOME="$root/runtime/config" XDG_DATA_HOME="$root/runtime/data" \
 TMPDIR="$root/runtime/tmp" TORCH_EXTENSIONS_DIR="$root/runtime/torch" CUDA_CACHE_PATH="$root/runtime/cuda" \
 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 \
 "$local_sdk/bin/python" -u "$root/code/native_async_loop.py" --headless --device cpu --enable_cameras \
 --experience /home/liyufeng/safeduo_isaaclab/apps/isaaclab.python.headless.rendering.kit \
 --kit_args "--portable --portable-root $root/runtime/kit --/renderer/multiGpu/enabled=false --/renderer/multiGpu/autoEnable=false --/renderer/activeGpu=0 --/plugins/carb.tasking.plugin/threadCount=8" \
 --case "$case_id" --root "$root"
