"""Synthetic, CPU-only contract regressions; zero simulator imports/epochs."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

from physical_capture import capture_snapshot, digest, WriteOnceJSONL, observed
from physical_validate import validate_snapshot


class FakeBody:
    # No mutating API is implemented: any accidental setter would fail a test.
    def get_transforms(self): return [[0., 0., 1., 0., 0., 0., 1.]]
    def get_velocities(self): return [[.1, .2, .3, .4, .5, .6]]
    def get_accelerations(self): return [[0.] * 6]
    def get_masses(self): return [[.135]]
    def get_inv_masses(self): return [[1. / .135]]
    def get_coms(self): return [[0., 0., .05, 0., 0., 0., 1.]]
    def get_inertias(self): return [[1., 0., 0., 0., 2., 0., 0., 0., 3.]]
    def get_disable_gravities(self): return [[0]]
    def get_disable_simulations(self): return [[0]]


class FakeSim:
    def get_gravity(self): return [0., 0., -9.81]


class FakeComposer:
    active = True
    composed_force_as_torch = [[[0., 0., .8]]]
    composed_torque_as_torch = [[[0., 0., 0.]]]


class FakeAsset:
    def __init__(self):
        self.instantaneous_wrench_composer = FakeComposer()
        self.permanent_wrench_composer = FakeComposer()


def row(**kwargs):
    defaults = dict(body_view=FakeBody(), simulation_view=FakeSim(), rigid_object=FakeAsset(),
                    clock_read=lambda: {"native_epoch": "SYNTHETIC_NOT_NATIVE", "time_s": 1., "callback_count": 240},
                    tick=0, phase="PRE_WRITE", body_path="/World/StationA/precursor_1",
                    usd_inventory={"composed_kinematic_enabled": False, "backend_inventory_status": "UNKNOWN"})
    defaults.update(kwargs)
    return capture_snapshot(**defaults)


def reseal(value):
    value["record_sha256"] = digest({k: v for k, v in value.items() if k != "record_sha256"})
    return value


class CaptureTests(unittest.TestCase):
    def test_complete_readonly_fake_getters(self):
        result = validate_snapshot(row())
        self.assertTrue(result["structure_pass"])
        self.assertTrue(result["all_body_getters_observed"])
        self.assertEqual(result["load_bearing_verdict"], "UNKNOWN")

    def test_no_sdk_import(self):
        self.assertFalse(any(x in sys.modules for x in ("isaacsim", "omni.physics.tensors", "torch", "mujoco")))

    def test_velocity_and_quaternion_order_unchanged(self):
        r = row()
        self.assertEqual(r["rigid_body"]["velocity_world_com_linear_angular"]["value"], [[.1, .2, .3, .4, .5, .6]])
        self.assertEqual(r["rigid_body"]["transform_xyz_xyzw"]["value"][0][-4:], [0., 0., 0., 1.])

    def test_getter_none_not_zero(self):
        class Missing(FakeSim):
            def get_gravity(self): return None
        r = row(simulation_view=Missing())
        self.assertIsNone(r["scene_gravity_world_m_s2"]["value"])
        self.assertTrue(validate_snapshot(r)["structure_pass"])
        self.assertFalse(validate_snapshot(r)["all_body_getters_observed"])

    def test_getter_exception_retained(self):
        class Missing(FakeBody):
            def get_disable_gravities(self): raise RuntimeError("synthetic unavailable")
        r = row(body_view=Missing())
        self.assertEqual(r["rigid_body"]["gravity_disabled_flag"]["exception_type"], "RuntimeError")
        self.assertTrue(validate_snapshot(r)["structure_pass"])

    def test_missing_method_is_unknown(self):
        r = row(simulation_view=object())
        self.assertEqual(r["scene_gravity_world_m_s2"]["exception_type"], "AttributeError")

    def test_nonfinite_getter_is_unknown(self):
        class Bad(FakeBody):
            def get_masses(self): return [[float("nan")]]
        r = row(body_view=Bad())
        self.assertIsNone(r["rigid_body"]["mass_kg"]["value"])
        self.assertTrue(validate_snapshot(r)["structure_pass"])

    def test_clock_advance_is_detected(self):
        values = iter([{"native_epoch": "x", "time_s": 1., "callback_count": 240},
                       {"native_epoch": "x", "time_s": 1.1, "callback_count": 241}])
        r = row(clock_read=lambda: next(values))
        self.assertFalse(r["no_native_step_during_getters"])
        self.assertIn("GETTER_CLOCK_ADVANCED", validate_snapshot(r)["errors"])

    def test_clock_epoch_change_is_detected(self):
        values = iter([{"native_epoch": "x", "time_s": 1., "callback_count": 240},
                       {"native_epoch": "y", "time_s": 1., "callback_count": 240}])
        self.assertFalse(validate_snapshot(row(clock_read=lambda: next(values)))["structure_pass"])

    def test_clock_bool_time_rejected(self):
        with self.assertRaises(ValueError):
            row(clock_read=lambda: {"native_epoch": "x", "time_s": True, "callback_count": 0})

    def test_mass_shape_failure(self):
        r = row(); r["rigid_body"]["mass_kg"]["value"] = [.135]
        self.assertIn("SHAPE_mass_kg", validate_snapshot(reseal(r))["errors"])

    def test_flag_value_failure(self):
        r = row(); r["rigid_body"]["gravity_disabled_flag"]["value"] = [[2]]
        self.assertFalse(validate_snapshot(reseal(r))["structure_pass"])

    def test_gravity_disabled_is_observed_but_never_success(self):
        r = row(); r["rigid_body"]["gravity_disabled_flag"]["value"] = [[1]]
        result = validate_snapshot(reseal(r))
        self.assertTrue(result["structure_pass"])
        self.assertEqual(result["load_bearing_verdict"], "UNKNOWN")

    def test_inactive_simulation_not_loadbearing(self):
        r = row(); r["rigid_body"]["simulation_disabled_flag"]["value"] = [[1]]
        self.assertEqual(validate_snapshot(reseal(r))["load_bearing_verdict"], "UNKNOWN")

    def test_authored_kinematic_not_backend_flag(self):
        r = row(usd_inventory={"composed_kinematic_enabled": True})
        self.assertEqual(r["active_kinematic_flag_status"], "UNKNOWN_NO_INSTALLED_TENSOR_GETTER")
        self.assertEqual(validate_snapshot(r)["load_bearing_verdict"], "UNKNOWN")

    def test_constraints_missing_not_empty(self):
        r = row(usd_inventory=None)
        self.assertEqual(r["backend_constraint_inventory_status"], "UNKNOWN_NO_COMPLETE_INSTALLED_GETTER")

    def test_wrench_pre_clear_value_copied(self):
        asset = FakeAsset(); asset.instantaneous_wrench_composer = copy.deepcopy(asset.instantaneous_wrench_composer)
        asset.instantaneous_wrench_composer.composed_force_as_torch = [[[0., 0., .8]]]
        before = row(rigid_object=asset)
        asset.instantaneous_wrench_composer.active = False
        asset.instantaneous_wrench_composer.composed_force_as_torch[0][0][2] = 0.
        after = row(rigid_object=asset, phase="POST_STEP")
        self.assertEqual(before["external_wrench_buffers"]["instantaneous"]["value"]["force_body_frame_N"][0][0][2], .8)
        self.assertEqual(after["external_wrench_buffers"]["instantaneous"]["value"]["force_body_frame_N"][0][0][2], 0.)

    def test_wrench_shape_failure(self):
        r = row(); r["external_wrench_buffers"]["instantaneous"]["value"]["force_body_frame_N"] = [[0., 0., 0.]]
        self.assertFalse(validate_snapshot(reseal(r))["structure_pass"])

    def test_hash_tamper_failure(self):
        r = row(); r["tick"] = 1
        self.assertIn("RECORD_HASH", validate_snapshot(r)["errors"])

    def test_forbidden_loadbearing_pass(self):
        r = row(); r["load_bearing_verdict"] = "PASS"
        self.assertFalse(validate_snapshot(reseal(r))["structure_pass"])

    def test_writeonce_and_cross_epoch(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "raw.jsonl"
            writer = WriteOnceJSONL(path); writer.write(row())
            r = row(); r["native_clock_before"]["native_epoch"] = r["native_clock_after"]["native_epoch"] = "different"
            with self.assertRaises(ValueError): writer.write(reseal(r))
            writer.close()
            with self.assertRaises(FileExistsError): WriteOnceJSONL(path)
            self.assertEqual(len(path.read_text().splitlines()), 1)

    def test_tick_regression(self):
        with tempfile.TemporaryDirectory() as tmp:
            writer = WriteOnceJSONL(Path(tmp) / "raw.jsonl"); writer.write(row(tick=2))
            with self.assertRaises(ValueError): writer.write(row(tick=1))
            writer.close()


if __name__ == "__main__":
    unittest.main()
