"""Terminal gate for the minimal collector; no native imports or invocations."""
import ast
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
CODE = ROOT / "code"


def main():
    forbidden = []
    allowed_imports = {"__future__", "hashlib", "json", "math", "pathlib", "physical_validate", "physical_capture"}
    for name in ("physical_capture.py", "physical_validate.py"):
        tree = ast.parse((CODE / name).read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                forbidden.extend(f"{name}:import:{x.name}" for x in node.names if x.name not in allowed_imports)
            if isinstance(node, ast.ImportFrom) and node.module not in allowed_imports:
                forbidden.append(f"{name}:from:{node.module}")
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                attr = node.func.attr
                if attr.startswith("set_") or attr.startswith("write_root_") or attr in {"step", "reset", "play", "stop", "CreateJoint", "Apply"}:
                    forbidden.append(f"{name}:{node.lineno}:mutator:{attr}")
    process = subprocess.run([sys.executable, "-B", "-m", "unittest", "-v", "test_physical_capture"],
                             cwd=CODE, text=True, capture_output=True)
    from test_physical_capture import row
    from physical_validate import validate_snapshot
    fixture = row()
    output = ROOT / "cpu_checks"
    with (output / "SYNTHETIC_SNAPSHOT.json").open("x") as f:
        json.dump(fixture, f, sort_keys=True, indent=2, allow_nan=False)
    text = process.stdout + process.stderr
    with (output / "UNIT_TESTS.txt").open("x") as f:
        f.write(text)
    receipt = {
        "schema": "paperb-physical-collector-cpu-preflight-v1",
        "status": "PASS_CPU_ONLY" if process.returncode == 0 and not forbidden else "FAIL",
        "unit_tests": 22, "test_exit_code": process.returncode,
        "ast_forbidden_imports_or_physics_mutators": forbidden,
        "synthetic_snapshot_structure": validate_snapshot(fixture),
        "python_version": platform.python_version(),
        "unit_test_log_sha256": hashlib.sha256(text.encode()).hexdigest(),
        "source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(CODE.glob("*.py"))},
        "sdk_imported": False, "native_epochs": 0, "gpu_jobs": 0,
        "simulation_steps": 0, "load_bearing_labels_created": 0,
        "claim": "STRUCTURAL_AND_READONLY_ADAPTER_TESTS_ONLY;NOT_ACTIVE_SDK_GETTER_ACCEPTANCE",
    }
    with (output / "CPU_PREFLIGHT.json").open("x") as f:
        json.dump(receipt, f, sort_keys=True, indent=2, allow_nan=False)
    print(json.dumps(receipt, sort_keys=True))
    return 0 if receipt["status"] == "PASS_CPU_ONLY" else 1


if __name__ == "__main__":
    sys.path.insert(0, str(CODE))
    raise SystemExit(main())
