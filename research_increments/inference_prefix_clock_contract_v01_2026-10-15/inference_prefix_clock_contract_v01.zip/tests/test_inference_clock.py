import copy
import hashlib
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"code"))
from inference_clock import InferenceClockContract, digest, PARENT, sha, verify_parent

h = lambda text: hashlib.sha256(text.encode()).hexdigest()


def header():
    return {"schema":"PaperBMixedActorRegistryHeader/0.2", "dataset_kind":"CPU_FIXTURE", "original_attempt_id":"SYNTHETIC-A", "attempt_id":"SYNTHETIC-A", "native_epoch":"SYNTHETIC-E", "failure_root_id":"SYNTHETIC-failure",
        "original_deadline_clock_id":"SYNTHETIC-D", "original_deadline_ns":10000, "action_dim":9, "history_cap":16,
        "actors":{"STUDENT":{"actor_id":"student", "source_sha256":h("CPU-student")}, "TEACHER":{"actor_id":"teacher", "source_sha256":h("CPU-teacher")}},
        "channel_order":"FIFO_ONE_APPLICATION_PER_TICK",
        "split":{"group_id":"CPU-group","pool":"FUTURE_TRAIN","original_role":"development","seen_before_protocol":False,"original_role_training_use":None},
        "pins":{"collector_source_sha256":h("CPU-collector"), "safety_authorizer_source_sha256":h("CPU-authorizer"),
            "channel_source_sha256":h("CPU-channel"),"registry_source_sha256":sha(PARENT/"code/mixed_actor_registry.py"),
            "split_plan_sha256":h("CPU-split"),"v04_manifest_sha256":"be4882960804a9d23fb1b0d633054e3ee85d2d3c0fdec70748f7bba7fddaebdb",
            "audit_sources_sha256":[h("CPU-audit")]}}


def execution(tick=0, time=100, lawful=True, role="STUDENT", full=False, known=False):
    hd = header()
    return {"state":{"state_id":f"CPU-state-{tick}", "attempt_id":hd["attempt_id"], "native_epoch":hd["native_epoch"],
        "tick":tick, "time_ns":time, "deadline_clock_id":hd["original_deadline_clock_id"], "deadline_time_ns":time,
        "lawful_state":lawful, "physical_state_sha256":h("CPU-not-physical"), "collector_source_sha256":hd["pins"]["collector_source_sha256"]},
        "active_role":role, "active_actor_id":hd["actors"][role]["actor_id"], "original_full_failure":full, "known_original_failure":known}


def setup(role="STUDENT", assets=(), private=None):
    hd = header(); contract = InferenceClockContract(hd, expected_header_sha256=digest(hd))
    features = {"public_packet":{"CPU_fixture_no_image":True}, "proprioception":{"q":[0.0]*9}, "history":{"ledger":[{"observed_tick":0}]}}
    p = {"packet_id":"CPU-p0", "attempt_id":hd["attempt_id"], "native_epoch":hd["native_epoch"], "capture_time_ns":100,
        "delivery_time_ns":100, "features":features, "assets":[a["descriptor"] for a in assets], "collector_source_sha256":hd["pins"]["collector_source_sha256"]}
    p["state_sha256"] = digest({"features":features,"assets":p["assets"]})
    prefix = {"attempt_id":hd["attempt_id"], "native_epoch":hd["native_epoch"], "start":0, "end":1, "length":1,
        "digest":digest([p]), "packet_ids":[p["packet_id"]], "as_of_time_ns":100}
    inputs = {"observation":features["public_packet"], "proprioception":features["proprioception"], "ledger":features["history"]}
    bindings = {key:{"packet_id":p["packet_id"],"feature_key":feature} for key,feature in (("observation","public_packet"),("proprioception","proprioception"),("ledger","history"))}
    request = dict(actor_role=role, execution=execution(), prefix=prefix, packets=[p], policy_inputs=inputs, input_bindings=bindings,
        desired_ticks=list(range(1,9)), declared_end_tick=8, wall_monotonic_ns=100,
        asset_bytes=[{"packet_id":p["packet_id"], "asset_index":i, "data":a["data"]} for i,a in enumerate(assets)], teacher_private_inputs=private)
    receipt = contract.start("t0", **request)
    return contract, request, receipt


def complete(contract, receipt, current=None):
    return contract.complete("t0", original_snapshot_sha256=receipt["data"]["snapshot_sha256"],
        original_prefix=receipt["data"]["prefix"], current_execution=current or execution(4,140),
        wall_monotonic_ns=500, chunk=[[i/100]*9 for i in range(8)])


class InferenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Check the real 27-member source boundary once, then isolate only that
        # expensive, immutable filesystem gate in data/clock unit cases.
        cls.actual_parent_receipt = verify_parent()
        cls.parent_gate_patch = patch("inference_clock.verify_parent", return_value=cls.actual_parent_receipt)
        cls.parent_gate_patch.start()
        cls.addClassCleanup(cls.parent_gate_patch.stop)
    def test_inputs_frozen_at_start_not_rebuilt_at_return(self):
        c, request, receipt = setup()
        original = c.model_inputs("t0")
        request["policy_inputs"]["proprioception"]["q"][0] = 7
        request["packets"][0]["features"]["history"]["ledger"].append({"observed_tick":999})
        returned = complete(c, receipt)
        self.assertEqual(c.model_inputs("t0"), original)
        self.assertEqual(returned["data"]["original_prefix"]["as_of_time_ns"],100)
        self.assertEqual(returned["data"]["native_ticks_elapsed"],4)

    def test_actual_supplied_bytes_copied_without_image_generation(self):
        data = bytearray(b"EXPLICIT_CPU_SYNTHETIC_NOT_RGB")
        asset = {"descriptor":{"kind":"CPU_SYNTHETIC_NON_RGB", "sha256":hashlib.sha256(data).hexdigest()}, "data":data}
        c, request, receipt = setup(assets=[asset]); data[0] = 0
        self.assertEqual(c.model_inputs("t0")["captured_asset_bytes"][0][2],b"EXPLICIT_CPU_SYNTHETIC_NOT_RGB")

    def test_return_late_and_unsafe_preserved_not_success(self):
        c, request, receipt = setup(); returned = complete(c, receipt, execution(12,12000,lawful=False))
        self.assertTrue(returned["data"]["original_deadline_exceeded_at_return"])
        self.assertFalse(returned["data"]["lawful_state_at_return"])
        guarded = c.guard_submit("t0",current_execution=execution(13,12010,lawful=False),earliest_apply_tick=14)
        self.assertTrue(all(not s["eligible_by_current_guard"] for s in guarded["data"]["slots"]))
        self.assertEqual(guarded["data"]["S_F_R_admitted"],0)

    def test_submit_current_state_not_safe_return_snapshot(self):
        c, request, receipt = setup(); complete(c,receipt,execution(1,110))
        guarded = c.guard_submit("t0",current_execution=execution(2,12000,lawful=False),earliest_apply_tick=3)
        self.assertIn("UNSAFE_CURRENT_EXECUTION_STATE",guarded["data"]["slots"][3]["reasons"])
        self.assertIn("ORIGINAL_DEADLINE_EXCEEDED_NOW",guarded["data"]["slots"][3]["reasons"])

    def test_8_by_9_stale_and_tail_metadata_without_rebase_or_flatten(self):
        c, request, receipt = setup(); complete(c,receipt)
        guarded = c.guard_submit("t0",current_execution=execution(5,150),earliest_apply_tick=6)
        slots=guarded["data"]["slots"]
        self.assertEqual([s["original_desired_tick"] for s in slots],list(range(1,9)))
        self.assertEqual([s["slot"] for s in slots if s["eligible_by_current_guard"]],[5,6])
        self.assertIn("DECLARED_EPISODE_TAIL_CENSORED",slots[7]["reasons"])
        self.assertTrue(all(len(s["target"])==9 and not s["actual_APPLIED"] for s in slots))

    def test_student_owner_not_reassigned_on_teacher_takeover(self):
        c, request, receipt = setup(); complete(c,receipt,execution(1,110,role="TEACHER"))
        guarded=c.guard_submit("t0",current_execution=execution(2,120,role="TEACHER"),earliest_apply_tick=3)
        self.assertTrue(all(s["owner"]["actor_id"]=="student" for s in guarded["data"]["slots"]))
        self.assertTrue(all("INFERENCE_OWNER_NOT_CURRENT_ACTOR" in s["reasons"] for s in guarded["data"]["slots"]))

    def test_teacher_privilege_separate_from_student_prefix(self):
        c, request, receipt = setup(role="TEACHER",private={"private_state":{"object_pose":[1,2,3]}})
        self.assertNotIn("private_state",str(c.model_inputs("t0")))
        self.assertIn("private_state",c.teacher_private_inputs("t0"))
        with self.assertRaisesRegex(ValueError,"STUDENT_INPUT_CANNOT"):
            setup(private={"private_state":{}})

    def test_prefix_hash_or_clock_tampering_rejected(self):
        c, request, receipt=setup(); prefix=copy.deepcopy(receipt["data"]["prefix"]);prefix["as_of_time_ns"]=140
        with self.assertRaisesRegex(ValueError,"ORIGINAL_INPUT"):
            c.complete("t0",original_snapshot_sha256=receipt["data"]["snapshot_sha256"],original_prefix=prefix,
                       current_execution=execution(4,140),wall_monotonic_ns=500,chunk=[[0]*9 for _ in range(8)])

    def test_future_observation_and_nonactual_reference_rejected(self):
        for changed in ("future","reference"):
            c, request, receipt=setup(); request=copy.deepcopy(request)
            if changed=="future":
                p=request["packets"][0];p["capture_time_ns"]=101;p["delivery_time_ns"]=101;request["prefix"]["digest"]=digest(request["packets"])
            else:request["policy_inputs"]["observation"]={"different":True}
            with self.assertRaises(ValueError):c.start("t1",**request)

    def test_flat72_bool_nonfinite_or_duplicate_return_rejected(self):
        c, request, receipt=setup()
        for chunk in ([0]*72,[[True]*9 for _ in range(8)],[[float('nan')]*9 for _ in range(8)]):
            with self.assertRaisesRegex(ValueError,"8_BY_9"):
                c.complete("t0",original_snapshot_sha256=receipt["data"]["snapshot_sha256"],original_prefix=receipt["data"]["prefix"],
                           current_execution=execution(4,140),wall_monotonic_ns=500,chunk=chunk)
        complete(c,receipt)
        with self.assertRaisesRegex(ValueError,"ALREADY_RECORDED"):complete(c,receipt)

    def test_foreign_epoch_and_header_pin_rejected(self):
        hd=header()
        with self.assertRaisesRegex(ValueError,"FULL_HEADER_PIN"):
            InferenceClockContract(hd,expected_header_sha256="0"*64)
        c, request, receipt=setup(); current=execution(4,140);current["state"]["native_epoch"]="foreign"
        with self.assertRaisesRegex(ValueError,"EPISODE_CLOCK_SOURCE"):complete(c,receipt,current)

    def test_safety_abort_fresh_authorization_not_old_return_state(self):
        c, request, receipt=setup();complete(c,receipt,execution(1,110,lawful=False))
        current=execution(2,120,lawful=False);target=[.03]*9
        authorizations={3:{"source_sha256":header()["pins"]["safety_authorizer_source_sha256"],
          "artifact_sha256":h("CPU-synthetic-authorizer-not-physical"),"observed_state_id":"CPU-state-1",
          "operation_purpose":"SAFETY_ABORT","target_sha256":digest(target),"verdict":"LAWFUL_TARGET_AUTHORIZED"}}
        denied=c.guard_submit("t0",current_execution=current,earliest_apply_tick=3,operation_purpose="SAFETY_ABORT",safety_authorizations=authorizations)
        self.assertFalse(denied["data"]["slots"][3]["eligible_by_current_guard"])
        authorizations[3]["observed_state_id"]="CPU-state-2"
        allowed=c.guard_submit("t0",current_execution=current,earliest_apply_tick=3,operation_purpose="SAFETY_ABORT",safety_authorizations=authorizations)
        self.assertTrue(allowed["data"]["slots"][3]["eligible_by_current_guard"])
        self.assertFalse(allowed["data"]["current_execution"]["original_full_failure"])
        self.assertEqual(allowed["data"]["S_F_R_admitted"],0)

    def test_absorbing_original_failure_not_reset_after_return(self):
        c, request, receipt=setup();complete(c,receipt,execution(1,110,full=True,known=True))
        with self.assertRaisesRegex(ValueError,"FULL_FAILURE_CANNOT_BE_CLEARED"):
            c.guard_submit("t0",current_execution=execution(2,120),earliest_apply_tick=3)


if __name__=="__main__":unittest.main()
