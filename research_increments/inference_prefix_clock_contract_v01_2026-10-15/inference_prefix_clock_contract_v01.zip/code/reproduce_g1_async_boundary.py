"""Pinned G1 public API counterexample; CPU synthetic, never native."""
import json
import os
from pathlib import Path
import subprocess
import sys

from inference_clock import PARENT, verify_parent

SCRIPT = r'''
import json
from test_registry import reg,state,packet,visit,target
r=reg();state(r,0,time=100);packet(r);visit(r);start_prefix=r.public_prefix(0,1,100)
state(r,4,time=140)
try:
 r.append('PROPOSAL',{'proposal_id':'async-from-start','actor_id':'student','observed_state_id':r.latest['state_id'],
   'public_prefix':start_prefix,'target':[.1,.2],'operation_purpose':'ORIGINAL_GOAL','safety_authorization':None})
except ValueError as exc:
 error=str(exc)
else:
 error='UNEXPECTED_ASYNC_PROPOSAL_ACCEPTED'
target(r)
print(json.dumps({'schema':'PinnedG1InferenceStartReturnCPUCounterexample/1','dataset_kind':'CPU_FIXTURE',
 'async_proposal_status':'RED_NOT_INTEGRATED','async_proposal_rejection':error,'start_prefix':start_prefix,
 'teacher_supervision_public_prefix':r.targets['teacher-target-0']['public_prefix'],
 'teacher_target_return_time_ns':r.targets['teacher-target-0']['target_record_time_ns'],
 'teacher_supervision_status':'GREEN_PUBLIC_API_ORIGINAL_STUDENT_VISIT_PREFIX_PRESERVED',
 'actual_execution':False,'native_model_GPU_calls':0,'S_F_R_admitted':0},sort_keys=True))
raise SystemExit(2 if error=='PUBLIC_PREFIX_BINDING_MISMATCH' else 1)
'''

if __name__ == "__main__":
    verify_parent()
    env = dict(os.environ); env["PYTHONDONTWRITEBYTECODE"]="1"
    env["PYTHONPATH"] = str(PARENT/"code")+os.pathsep+str(PARENT/"tests")
    completed = subprocess.run([sys.executable,"-B","-c",SCRIPT],env=env,capture_output=True,text=True,timeout=90)
    sys.stdout.write(completed.stdout);sys.stderr.write(completed.stderr)
    raise SystemExit(completed.returncode)
