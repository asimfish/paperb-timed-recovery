"""Private native model and physical ACK effects, never imported by actor."""
from pathlib import Path
import mujoco
import xml.etree.ElementTree as ET
HERE=Path(__file__).resolve().parent

def create(private,initial):
    x=ET.fromstring((HERE/'three_rotors.xml').read_text())
    for name in ['A','B','C']:
        b=x.find('./worldbody/body[@name="'+name+'"]');I=private['inertia']
        b.find('inertial').set('diaginertia',f'{I/2} {I/2} {I}');b.find('joint').set('damping',str(private['damping']))
    m=mujoco.MjModel.from_xml_string(ET.tostring(x,encoding='unicode'));d=mujoco.MjData(m)
    d.qpos[:]=initial['qpos'];d.qvel[:]=initial['qvel'];d.ctrl[:]=initial['torque'];mujoco.mj_forward(m,d)
    return m,d

class Effects:
    def __init__(self,private,B_after):self.private=private;self.B_after=B_after;self.A_count=0
    def apply(self,d,r):
        before=d.ctrl.copy().tolist()
        if r.target=='B':d.ctrl[1]=self.B_after
        elif r.target=='A':
            self.A_count+=1
            if not (self.A_count==1 and self.private['fault']=='first_A_stop_drop'):d.ctrl[0]=0.
        elif r.target=='C':d.ctrl[2]=0.
        else:raise ValueError('unsupported native action')
        return {'seq':r.seq,'target':r.target,'actual_ACK_ns':round(d.time*1e9),'torque_before':before,'torque_after':d.ctrl.copy().tolist()}
