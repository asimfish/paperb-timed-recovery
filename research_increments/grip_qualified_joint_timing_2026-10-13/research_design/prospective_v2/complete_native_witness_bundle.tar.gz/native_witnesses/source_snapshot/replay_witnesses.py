"""All8 command-driven native diagnostic replays; no actor/oracle event input."""
from pathlib import Path
import json,csv
import mujoco,numpy as np
from plant import create
from referee import evaluate
ROOT=Path(__file__).resolve().parent.parent

def replay(out):
    p=json.loads((out/'contract.json').read_text());commands=json.loads((out/'commands.json').read_text())
    with (out/'independent_samples.csv').open() as f:raw=list(csv.DictReader(f))
    m,d=create(p['private_plant'],p['initial_state']);Aseen=0;applied=set();maximum=clockerr=0.;new=[]
    for tick in range(p['horizon_ns']//p['dt_ns']+1):
        now=tick*p['dt_ns']
        for r in commands:
            if r['ack_ns']==now and r['seq'] not in applied:
                applied.add(r['seq'])
                if r['target']=='B':d.ctrl[1]=p['resource']['B_reservation']['torque_after_ACK']
                elif r['target']=='A':
                    Aseen+=1
                    if not (Aseen==1 and p['private_plant']['fault']=='first_A_stop_drop'):d.ctrl[0]=0
                elif r['target']=='C':d.ctrl[2]=0
        row={'sim_ns':now,'native_time_s':d.time,'epoch':0}
        for a,i in [('A',0),('B',1),('C',2)]:
            for key,v in [('q',d.qpos[i]),('v',d.qvel[i]),('ctrl_next',d.ctrl[i])]:row[a+'_'+key]=float(v);maximum=max(maximum,abs(float(raw[tick][a+'_'+key])-float(v)))
        clockerr=max(clockerr,abs(float(raw[tick]['native_time_s'])-d.time));new.append({k:str(v) for k,v in row.items()})
        if tick<p['horizon_ns']//p['dt_ns']:mujoco.mj_step(m,d);mujoco.mj_forward(m,d)
    verdict=evaluate(new,commands,p);match=verdict==json.loads((out/'raw_verdict.json').read_text())
    return {'case_id':out.name,'state_error':maximum,'native_time_error':clockerr,'verdict_matches':match,'samples':len(new),'integration_type':'REINTEGRATION_DIAGNOSTIC_NOT_MAIN'}
def main():
    root=ROOT/'native_witnesses';rows=[replay(root/c['id']) for c in json.loads((ROOT/'code/PROTOCOL_V2.json').read_text())['cases']]
    result={'schema':'paperb-v2-native-command-reintegration-v1','status':'PASS' if all(r['state_error']==0 and r['native_time_error']==0 and r['verdict_matches'] for r in rows) else 'FAIL_RETAINED','diagnostic_reintegrations':len(rows),'samples':sum(r['samples'] for r in rows),'actor_decisions_or_private_effect_successflag_used':False,'raw_ctrl_as_integration_input_used':False,'formal_tests':0,'fits':0,'cases':rows,'mujoco':mujoco.__version__,'numpy':np.__version__}
    with (root/'REINTEGRATION.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
