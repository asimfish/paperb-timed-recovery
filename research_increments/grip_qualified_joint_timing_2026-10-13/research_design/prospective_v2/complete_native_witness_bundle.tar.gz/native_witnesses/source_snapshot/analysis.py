"""Pre-execution public model certificates; no native integration or fit."""
from pathlib import Path
import json,math,copy
from dataclasses import asdict
from interfaces import Packet,ObservedEvent,ReservedChannel
from planning import plan
HERE=Path(__file__).resolve().parent

def model_packet(t,public,dt):
    m=public['public_nominal_model'];r=m['inertia']/(m['inertia']+dt/1e9*m['damping']);q=v=0.;steady=public['initial_torque']/m['damping']
    for _ in range(t//dt):v=steady+(v-steady)*r;q+=v*dt/1e9
    return Packet(t,t+100_000_000,(q,q,q),(v,v,v),(.06,.06,.06))
def configure(p,case,start):
    x=copy.deepcopy(p);x['case_id']=case['id'];x['public'].update({k:case[k] for k in ['D_C_ns','A_window_ns','graph_edges']})
    b=x['resource']['B_reservation'];b['service_start_ns']=start;b['service_end_ns']=start+case['B_service_ns'];return x

def matrix(p):
    out=[]
    for start in [750_000_000,650_000_000]:
        for case in p['cases']:
            x=configure(p,case,start);q=model_packet(450_000_000,x['public'],x['dt_ns']);channel=ReservedChannel(x['resource'])
            refs={'public_coarse_no_model_refinement':ObservedEvent(400_000_000,450_000_000,550_000_000),
             'same_event_public_model_conditional':ObservedEvent(440_000_000,450_000_000,550_000_000,'CONDITIONAL_MODEL'),
             'private_truth_known_drop_model_diagnostic':ObservedEvent(440_000_000,450_000_000,550_000_000,'PRIVATE_MODEL_ONLY')}
            results={k:plan(q,r,x['public'],x['resource'],channel.public_snapshot(),560_000_000,x['dt_ns'],x['charged_decision_ns'],known_drop_oracle=k.startswith('private')) for k,r in refs.items()}
            bound=None
            if start==750_000_000 and case['graph_id']=='C_then_A' and case['B_service_ns']==450_000_000 and case['D_C_ns']==2_800_000_000:
                bound={'kind':'STRICT_MODEL_RESOURCE_LOWER_BOUND','C_earliest_postslot_ACK_ns':1_650_000_000,'C_earliest_postslot_stop_interval_ns':[3_200_000_000,3_210_000_000],
                  'A_latest_stop_end_ns':3_240_000_000,'C_latest_stop_end_from_edge_plus_A_bracket_ns':3_190_000_000,
                  'early_C_preslot_latest_stop_end_ns':2_240_000_000,'C_earliest_end_from_original_window_ns':3_110_000_000,
                  'reason':'Neither pre-slot nor post-slot C stop can meet original window plus C→A gap and A deadline, even known-drop private oracle.'}
            out.append({'candidate_B_slot_start_ns':start,'case':case,'plans':results,'strict_private_infeasible_bound':bound,
             'coarse_box_refusal_is_not_public_information_lower_bound':True,'public_known_model_refinement_available_to_every_arm':True})
    return {'schema':'paperb-v2-preexecution-model-reachability-matrix-v1','entries':out,'native_integrations':0,'fits':0,'formal_tests':0,
     'symbolic_box_condition':'w+c+g+a <= U_A-D+eps; a may include60ms fault branch envelope before feedback, or10ms once legal torque feedback resolves it.',
     'conditioning':'Scalar public nominal model and exact noiseless public sensor; no model support guarantee. No parameter inferred from native heldout outcomes.'}
def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();p=json.loads((HERE/'PROTOCOL_V2.json').read_text());r=matrix(p)
    with a.out.open('x') as f:json.dump(r,f,indent=2);f.write('\n')
    print(json.dumps({'entries':len(r['entries']),'native_integrations':0,'status_counts':{str(start):{k:sum(e['candidate_B_slot_start_ns']==start and e['plans'][k]['status'].startswith('FEASIBLE') for e in r['entries']) for k in ['public_coarse_no_model_refinement','same_event_public_model_conditional','private_truth_known_drop_model_diagnostic']} for start in [750_000_000,650_000_000]}}))
if __name__=='__main__':main()
