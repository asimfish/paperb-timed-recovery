"""Eight frozen public conditional native diagnostic witnesses; formal tests0."""
from pathlib import Path
from dataclasses import asdict
import csv,json,hashlib,time,shutil,copy
import mujoco,numpy as np
from interfaces import Packet,Ack,ReservedChannel
from public_estimator import SharedPublicEstimator
from plant import create,Effects
from witness_actor import PublicWitnessActor
from referee import evaluate
from analysis import configure
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def run(out,p):
    out.mkdir(exist_ok=False);m,d=create(p['private_plant'],p['initial_state']);effects=Effects(p['private_plant'],p['resource']['B_reservation']['torque_after_ACK'])
    channel=ReservedChannel(p['resource']);obs=SharedPublicEstimator(p['public'],p['dt_ns']);actor=PublicWitnessActor(p['public'],p['resource'],p['dt_ns'],p['charged_decision_ns'])
    pending=[];applied=set();acks=[];intents=[];captures=[];deliveries=[];private=[];inputs=[];raw=[];submissions=[];start=time.monotonic_ns()
    for tick in range(p['horizon_ns']//p['dt_ns']+1):
        now=tick*p['dt_ns']
        if round(d.time*1e9)!=now:raise RuntimeError('native clock mismatch')
        if tick%p['sensor_period_ticks']==0:
            packet=Packet(now,now+p['sensor_lag_ns'],tuple(d.qpos.copy().tolist()),tuple(d.qvel.copy().tolist()),tuple(d.ctrl.copy().tolist()));pending.append(packet);captures.append(asdict(packet))
        while pending and pending[0].arrival_ns<=now:
            packet=pending.pop(0);obs.deliver(packet,now);deliveries.append(asdict(packet))
        for r in channel.reservations:
            if r.ack_ns==now and r.seq not in applied:
                applied.add(r.seq);private.append(effects.apply(d,r));acks.append(Ack(r.seq,r.target,r.tag,now))
        inputs.append({'now_ns':now,'latest_packet_capture_ns':None if obs.latest is None else obs.latest.capture_ns,'latest_packet_arrival_ns':None if obs.latest is None else obs.latest.arrival_ns,
          'original_coarse_B':None if obs.original_B is None else asdict(obs.original_B),'conditional_same_event_B_estimate':None if obs.model_estimate is None else asdict(obs.model_estimate),'ACKs':[asdict(a) for a in acks]})
        if tick%p['decision_period_ticks']==0:
            before=time.monotonic_ns();new=actor.decide(now,obs,tuple(acks),channel.public_snapshot());spent=time.monotonic_ns()-before
            for a in new:
                if a['submit_ns']<now+p['charged_decision_ns']:raise RuntimeError('uncharged native action')
                intents.append(a)
            if actor.decisions and actor.decisions[-1]['now_ns']==now:actor.decisions[-1]['host_compute_ns']=spent
        for a in list(intents):
            if a['submit_ns']==now:
                r=channel.submit(now,a['target'],a['tag'])
                if r.service_start_ns!=a['service_start_ns'] or r.ack_ns!=a['ACK_ns']:raise RuntimeError('actual service differs from public planned reservation')
                submissions.append(asdict(r));intents.remove(a)
            elif a['submit_ns']<now:raise RuntimeError('missed native submission')
        raw.append({'sim_ns':now,'native_time_s':float(d.time),'epoch':0,**{name+'_'+k:float(v) for name,i in [('A',0),('B',1),('C',2)] for k,v in [('q',d.qpos[i]),('v',d.qvel[i]),('ctrl_next',d.ctrl[i])]}})
        if tick<p['horizon_ns']//p['dt_ns']:mujoco.mj_step(m,d);mujoco.mj_forward(m,d)
    with (out/'independent_samples.csv').open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(raw[0]));w.writeheader();w.writerows(raw)
    commands=[asdict(r) for r in channel.reservations]
    for name,v in [('commands.json',commands),('public_captures.json',captures),('public_deliveries.json',deliveries),('public_actor_inputs.json',inputs),('public_decisions.json',actor.decisions),('public_model_refinement_evidence.json',obs.evidence),('private_effects.json',private),('contract.json',p)]:write(out/name,v)
    verdict=evaluate([{k:str(v) for k,v in r.items()} for r in raw],commands,p);write(out/'raw_verdict.json',verdict)
    result={'case_id':p['case_id'],'role':'NATIVE_PROSPECTIVE_DEVELOPMENT_WITNESS_NOT_FORMAL','native_steps':1200,'samples':len(raw),'epoch_count':1,'commands':len(commands),'C_A_selective_requests':len(submissions),'original_public_coarse':None if obs.original_B is None else asdict(obs.original_B),
      'conditional_shared_public_model_estimate':None if obs.model_estimate is None else asdict(obs.model_estimate),'private_referee_anchor':verdict['original_B_raw_interval_ns'],'joint':verdict['joint'],'values':verdict['values'],
      'referee_same_as_public_estimate_in_this_diagnostic':'Equality checked only after execution; never input to actor','public_unknown_none_or_drop_plan':True,'history_query_count':0,'weights':0,'fit':0,'calibration':0,'formal_main':0,'GPU':0,'LLM':0,'host_elapsed_ns':time.monotonic_ns()-start,'host_computation_advances_plant':False,'charged_decision_ns':p['charged_decision_ns'],'state_writes_during_native_epoch':0,
      'pending_native_reservations':[r.seq for r in channel.reservations if r.seq not in applied],'pending_intents':intents,'mujoco':mujoco.__version__,'numpy':np.__version__,'no_chemical_original_robot_or_learning_credit':True}
    write(out/'SUMMARY.json',result);return result

def main():
    release=json.loads((HERE/'WITNESS_RELEASE.json').read_text());assert all(sha(HERE/n)==h for n,h in release['files'].items())
    p=json.loads((HERE/'PROTOCOL_V2.json').read_text());out=ROOT/'native_witnesses';out.mkdir(exist_ok=False);snap=out/'source_snapshot';snap.mkdir()
    for n in release['files']:
        dst=snap/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(HERE/n,dst)
    write(out/'witness_release_snapshot.json',release);results=[]
    for case in p['cases']:
        spec=configure(p,case,650_000_000);results.append(run(out/case['id'],spec));print(json.dumps(results[-1]),flush=True)
    summary={'schema':'paperb-v2-native-public-witness-results-v1','controlled_native_diagnostics':8,'controlled_samples':sum(r['samples'] for r in results),'diagnostic_joint_T':sum(r['joint']=='TRUE' for r in results),'diagnostic_joint_F':sum(r['joint']=='FALSE' for r in results),'diagnostic_joint_U':sum(r['joint']=='UNKNOWN' for r in results),
      'no_query_eight_cell_witness_not_primary_performance':True,'formal_trials':0,'fits':0,'calibration':0,'GPU':0,'LLM':0,'weights':0,'cases':results,'source_release_sha256':sha(HERE/'WITNESS_RELEASE.json')}
    write(out/'MAIN_SUMMARY.json',summary);assert all(sha(HERE/n)==h for n,h in release['files'].items())
if __name__=='__main__':main()
