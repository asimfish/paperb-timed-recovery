"""Independent RAW state/event referee; controller decisions not an oracle."""
import csv,math

def rows(path):
    with open(path) as f:return list(csv.DictReader(f))
def conjunction(xs):
    if 'FALSE' in xs:return 'FALSE'
    return 'TRUE' if all(x=='TRUE' for x in xs) else 'UNKNOWN'
def trigger(raw,axis,angle):
    for a,b in zip(raw,raw[1:]):
        if float(a[axis+'_q'])<angle<=float(b[axis+'_q']) and abs(float(a[axis+'_v']))>.1:
            return [int(a['sim_ns']),int(b['sim_ns'])]
    return None
def stop(raw,axis,hold):
    moving=False;pending=None
    for i,r in enumerate(raw):
        low=abs(float(r[axis+'_v']))<=.1
        if not low:moving=True;pending=None
        elif moving:
            if pending is None:pending=i
            if int(r['sim_ns'])-int(raw[pending]['sim_ns'])>=hold:
                return {'interval_ns':[int(raw[pending-1]['sim_ns']),int(raw[pending]['sim_ns'])],
                 'confirmation_ns':int(r['sim_ns']),'confirmation_positive_samples':i-pending+1,'had_prior_moving_sample':True}
    return None
def timing(anchor,event,window):
    if anchor is None or event is None:return {'verdict':'UNKNOWN','duration_interval_ns':None}
    lo=event['interval_ns'][0]-anchor[1];hi=event['interval_ns'][1]-anchor[0]
    v='TRUE' if window[0]<=lo and hi<=window[1] else 'FALSE' if hi<window[0] or lo>window[1] else 'UNKNOWN'
    return {'verdict':v,'duration_interval_ns':[lo,hi]}
def evaluate(raw,commands,p):
    dt=p['dt_ns'];end=p['horizon_ns'];s=p['public']
    valid=len(raw)==end//dt+1 and all(int(r['sim_ns'])==i*dt and int(r['epoch'])==0 for i,r in enumerate(raw))
    finite=all(math.isfinite(float(r[k])) for r in raw for k in [a+'_'+x for a in ['A','B','C'] for x in ['q','v','ctrl_next']])
    anchor=trigger(raw,'B',s['original_B_angle']);events={a:stop(raw,a,s['stop_hold_ns']) for a in ['A','C']}
    times={'A':timing(anchor,events['A'],s['A_window_ns']),'C':timing(anchor,events['C'],[s['D_C_ns']-s['eps_C_ns'],s['D_C_ns']+s['eps_C_ns']])}
    maintenance='UNKNOWN' if anchor is None else 'TRUE';viol=[]
    if anchor:
        boundary=[anchor[0]+s['B_maintenance_ns'],anchor[1]+s['B_maintenance_ns']]
        for r in raw:
            t=int(r['sim_ns'])
            if anchor[1]<t<=boundary[1] and (float(r['B_ctrl_next']) not in [.06,.045] or abs(float(r['B_v']))<=.1):
                viol.append(t);maintenance='FALSE' if t<=boundary[0] else 'UNKNOWN'
                if maintenance=='FALSE':break
    Bmonotone=all(float(b['B_q'])>=float(a['B_q']) and float(a['B_ctrl_next'])>=0 for a,b in zip(raw,raw[1:]))
    capacity=True
    services=sorted(commands,key=lambda x:(x['service_start_ns'],x['seq']))
    for a,b in zip(services,services[1:]):
        if a['ack_ns']>b['service_start_ns']:capacity=False
    A=[r for r in commands if r['target']=='A'];drop=False;recovery=False;anchor_before=False
    if A:
        first=raw[A[0]['ack_ns']//dt]
        drop=float(first['A_ctrl_next'])>0 and abs(float(first['A_v']))>.1
        anchor_before=anchor is not None and anchor[1]<A[0]['ack_ns']
        for a in A[1:]:
            if float(raw[a['ack_ns']//dt]['A_ctrl_next'])==0:recovery=True
    graph=[]
    for before,after in s['graph_edges']:
        b,a=events.get(before),events.get(after)
        if b is None or a is None:graph.append('UNKNOWN')
        else:
            lo=a['interval_ns'][0]-b['interval_ns'][1];hi=a['interval_ns'][1]-b['interval_ns'][0]
            graph.append('TRUE' if lo>=s['minimum_edge_gap_ns'] else 'FALSE' if hi<s['minimum_edge_gap_ns'] else 'UNKNOWN')
    values={'raw_one_epoch':'TRUE' if valid and finite else 'FALSE','actual_B_original_anchor':'TRUE' if anchor is not None else 'UNKNOWN',
      'irreversible_B_angle':'TRUE' if Bmonotone else 'FALSE','A_original_time':times['A']['verdict'],'C_original_time':times['C']['verdict'],
      'B_sampled_maintenance':maintenance,'service_capacity':'TRUE' if capacity else 'FALSE','original_anchor_before_failure':'TRUE' if anchor_before else 'FALSE',
      'actual_drop_and_effective_recovery':'TRUE' if drop and recovery else 'FALSE','graph':conjunction(graph)}
    return {'values':values,'joint':conjunction(list(values.values())),'original_B_raw_interval_ns':anchor,'stop_events':events,'time_scores':times,
      'maintenance_failure_ticks_ns':viol,'physical_continuity_between_ticks_proven':False,'controller_internal_flags_used':False,'chemical_or_original_robot_credit':0}
