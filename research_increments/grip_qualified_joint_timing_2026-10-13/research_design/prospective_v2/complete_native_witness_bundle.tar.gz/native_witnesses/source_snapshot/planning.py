"""Pure model/interval/resource feasibility construction.
Public calls use the entire none/one-drop A result box. Known-drop mode is only
an explicit private-oracle MODEL diagnostic, never passed to live public actor.
"""
import math
from dataclasses import asdict
from interfaces import ReservedChannel

def ceilgrid(t,dt):return ((t+dt-1)//dt)*dt

def stop_box(packet,axis,ack,model,dt):
    decay=model['inertia']/(model['inertia']+dt/1e9*model['damping'])
    v=packet.velocities[axis];steady=packet.torques[axis]/model['damping']
    n=max(0,(ack-packet.capture_ns)//dt);v=steady+(v-steady)*decay**n
    if v<=.1:return [ack,ack]
    n=max(1,math.ceil(math.log(.1/v)/math.log(decay)))
    while v*decay**n>.1:n+=1
    while n>1 and v*decay**(n-1)<=.1:n-=1
    return [ack+(n-1)*dt,ack+n*dt]

def within(ref,e,window):return e[0]-ref.upper_ns>=window[0] and e[1]-ref.lower_ns<=window[1]
def envelope(xs):return [min(x[0] for x in xs),max(x[1] for x in xs)]
def request_for_ACK(ack,target,now,resource,reservations):
    duration=resource['services_ns'][target+'_stop'];req=ack-duration
    if req<now:return None
    start,end=ReservedChannel.earliest_service(req,duration,reservations)
    if end!=ack:return None
    return {'submit_ns':req,'target':target,'tag':target+'_stop','service_start_ns':start,'ACK_ns':end}
def as_reserved(actions):
    from interfaces import Reservation
    return [Reservation(100+i,x['target'],x['tag'],x['submit_ns'],x['service_start_ns'],x['ACK_ns']) for i,x in enumerate(actions)]
def earliest_action(now,target,resource,reservations):
    start,end=ReservedChannel.earliest_service(now,resource['services_ns'][target+'_stop'],reservations)
    return {'submit_ns':now,'target':target,'tag':target+'_stop','service_start_ns':start,'ACK_ns':end}

def plan(packet,ref,public,resource,reservations,now,dt,charge,known_drop_oracle=False):
    minimum=ceilgrid(now+charge,dt);model=public['public_nominal_model'];D=public['D_C_ns'];eps=public['eps_C_ns'];gap=public['minimum_edge_gap_ns'];order=public['graph_edges'][0]
    earliest_C=ceilgrid(ref.upper_ns+D-eps,dt);latest_C=ref.lower_ns+D+eps
    candidates=0;best=None
    initial=[];base=list(reservations)
    if known_drop_oracle:
        dropped=earliest_action(minimum,'A',resource,base);initial=[dropped];base+=as_reserved(initial)
    if order==['A','C']:
        if known_drop_oracle:
            for ack in range(minimum,ref.lower_ns+public['A_window_ns'][1]+dt,dt):
                if candidates>=public['maximum_candidates_per_decision']:return {'status':'REFUSED_BUDGET','actions':[],'candidate_evaluations':candidates}
                candidates+=1
                a=request_for_ACK(ack,'A',minimum,resource,base)
                if a is not None and within(ref,stop_box(packet,0,ack,model,dt),public['A_window_ns']):initial.append(a);break
            if len(initial)!=2:return {'status':'REFUSED_CONDITIONAL_PLAN','reason':'A_effective_box_or_resource','actions':[],'candidate_evaluations':candidates}
        else:
            for ack in range(minimum,ref.lower_ns+public['A_window_ns'][1]+dt,dt):
                if candidates>=public['maximum_candidates_per_decision']:return {'status':'REFUSED_BUDGET','actions':[],'candidate_evaluations':candidates}
                candidates+=1
                a1=request_for_ACK(ack,'A',minimum,resource,base)
                if a1 is None:continue
                a2=earliest_action(ack,'A',resource,base+as_reserved([a1]))
                a_box=envelope([stop_box(packet,0,a1['ACK_ns'],model,dt),stop_box(packet,0,a2['ACK_ns'],model,dt)])
                if within(ref,a_box,public['A_window_ns']):initial=[a1,a2];break
            if len(initial)!=2:return {'status':'REFUSED_CONDITIONAL_PLAN','reason':'A_none_drop_union_box_or_resource','actions':[],'candidate_evaluations':candidates}
        used_base=list(reservations)+as_reserved(initial)
        for ack in range(minimum,latest_C+dt,dt):
            if candidates>=public['maximum_candidates_per_decision']:break
            candidates+=1
            c=request_for_ACK(ack,'C',minimum,resource,used_base)
            if c is None or c['service_start_ns']<max(x['ACK_ns'] for x in initial):continue
            C=stop_box(packet,2,ack,model,dt)
            A=stop_box(packet,0,initial[1]['ACK_ns'],model,dt) if known_drop_oracle else envelope([stop_box(packet,0,x['ACK_ns'],model,dt) for x in initial])
            if within(ref,C,[D-eps,D+eps]) and C[0]-A[1]>=gap:
                cost=((C[0]+C[1])-(ref.lower_ns+ref.upper_ns+2*D))**2
                value=(cost,ack,initial+[c],A,C)
                if best is None or value[:2]<best[:2]:best=value
    else:
        for ack in range(minimum,latest_C+dt,dt):
            if candidates>=public['maximum_candidates_per_decision']:break
            candidates+=1
            c=request_for_ACK(ack,'C',minimum,resource,base)
            if c is None:continue
            after=list(base)+as_reserved([c]);a1=earliest_action(ack,'A',resource,after)
            if known_drop_oracle:actions=initial+[c,a1];A=stop_box(packet,0,a1['ACK_ns'],model,dt)
            else:
                a2=earliest_action(a1['ACK_ns'],'A',resource,after+as_reserved([a1]));actions=[c,a1,a2]
                A=envelope([stop_box(packet,0,a1['ACK_ns'],model,dt),stop_box(packet,0,a2['ACK_ns'],model,dt)])
            C=stop_box(packet,2,ack,model,dt)
            if within(ref,C,[D-eps,D+eps]) and within(ref,A,public['A_window_ns']) and A[0]-C[1]>=gap:
                cost=((C[0]+C[1])-(ref.lower_ns+ref.upper_ns+2*D))**2;value=(cost,ack,actions,A,C)
                if best is None or value[:2]<best[:2]:best=value
    if best is None:return {'status':'REFUSED_CONDITIONAL_PLAN','reason':'joint_box_resource_or_graph','actions':[],'candidate_evaluations':candidates,'not_information_theoretic_impossibility':True}
    _,_,actions,A,C=best
    return {'status':'FEASIBLE_CONDITIONAL_MODEL_PLAN','actions':actions,'A_possible_event_box_ns':A,'C_event_box_ns':C,'reference_used':asdict(ref),'candidate_evaluations':candidates,
      'none_drop_guarded':not known_drop_oracle,'known_drop_private_oracle':known_drop_oracle,'scope':'CONDITIONAL_PUBLIC_NOMINAL_MODEL; NOT_SUPPORT_CONFIDENCE_GUARANTEE'}
