"""Live public-only no-query diagnostic witness, not any formal learned arm."""
from dataclasses import asdict
from planning import plan
class PublicWitnessActor:
    def __init__(self,public,resource,dt,charge):
        self.p,self.resource,self.dt,self.charge=public,resource,dt,charge;self.planned=False;self.decisions=[]
    def decide(self,now,observer,acks,reservations):
        if self.planned or observer.original_B is None or observer.latest is None:return []
        self.planned=True;reference=observer.reference()
        result=plan(observer.latest,reference,self.p,self.resource,reservations,now,self.dt,self.charge,known_drop_oracle=False)
        self.decisions.append({'now_ns':now,'packet':asdict(observer.latest),'original_B_coarse':asdict(observer.original_B),
          'same_event_reference_estimate':asdict(reference),'public_ACKs':[asdict(x) for x in acks],'public_reservations':[asdict(x) for x in reservations],
          'plan':result,'current_private_fault_read':False,'private_native_state_read':False,'query_requests':0})
        return result['actions']
