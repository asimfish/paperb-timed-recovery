"""Shared public-only same-event refinement, no private state or referee.
A conditional known public B model can reconstruct the crossing inside an
already observed coarse bracket. Coarse uncertainty is not information-theoretic.
"""
from dataclasses import asdict
from interfaces import PublicObserver,ObservedEvent

class SharedPublicEstimator(PublicObserver):
    def __init__(self,public,dt):
        super().__init__(public['original_B_angle'],public['moving_threshold'])
        self.spec,self.dt=public,dt;self.model_estimate=None;self.evidence=[]
    def deliver(self,p,now):
        old=self.latest;before=self.original_B
        super().deliver(p,now)
        if before is None and self.original_B is not None:
            m=self.spec['public_nominal_model'];decay=m['inertia']/(m['inertia']+self.dt/1e9*m['damping'])
            q,v=old.positions[1],old.velocities[1];steady=old.torques[1]/m['damping'];cross=None
            for t in range(old.capture_ns+self.dt,p.capture_ns+self.dt,self.dt):
                prev=q;v=steady+(v-steady)*decay;q+=v*self.dt/1e9
                if cross is None and prev<self.threshold<=q:cross=[t-self.dt,t]
            residual=[abs(q-p.positions[1]),abs(v-p.velocities[1])]
            compatible=old.torques[1]==p.torques[1] and max(residual)<=1e-9
            if cross is not None and compatible:
                self.model_estimate=ObservedEvent(cross[0],cross[1],p.arrival_ns,'B_SAME_EVENT_CONDITIONAL_PUBLIC_MODEL')
            self.evidence.append({'old_public_packet':asdict(old),'crossing_public_packet':asdict(p),'coarse_original_event':asdict(self.original_B),
             'public_model':m,'conditional_model_same_event_estimate':None if self.model_estimate is None else asdict(self.model_estimate),
             'public_prediction_residual':residual,'compatibility_tolerance':1e-9,'no_model_parameter_fitted':True,'private_native_or_referee_read':False,
             'does_not_establish_model_support_guarantee':True})
    def reference(self):return self.model_estimate if self.model_estimate is not None else self.original_B
