"""Public three-rotor packets, immutable observed-event ledger, actual service queue.
No private plant, model, fault or truth flag enters these public types.
"""
from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class Packet:
    capture_ns:int
    arrival_ns:int
    positions:tuple
    velocities:tuple
    torques:tuple
    def __post_init__(self):
        if self.capture_ns>self.arrival_ns or any(len(x)!=3 for x in [self.positions,self.velocities,self.torques]):raise ValueError('public packet shape/time')
@dataclass(frozen=True)
class ObservedEvent:
    lower_ns:int
    upper_ns:int
    first_arrival_ns:int
    kind:str='B_PUBLIC_OBSERVED_FIRST_Q2'
@dataclass(frozen=True)
class Reservation:
    seq:int
    target:str
    tag:str
    request_ns:int
    service_start_ns:int
    ack_ns:int
    external:bool=False
@dataclass(frozen=True)
class Ack:
    seq:int
    target:str
    tag:str
    ack_ns:int
    # Receipt says the command transaction was serviced, not plant success.

class PublicObserver:
    def __init__(self,threshold,moving):
        self.threshold,self.moving=threshold,moving
        self.previous=self.latest=self.original_B=None
    def deliver(self,p,now):
        if p.arrival_ns>now:raise ValueError('future observation')
        if self.latest is not None and p.capture_ns<=self.latest.capture_ns:raise ValueError('capture order')
        previous=self.latest
        if self.original_B is None and previous is not None:
            if previous.positions[1]<self.threshold<=p.positions[1] and abs(previous.velocities[1])>self.moving:
                self.original_B=ObservedEvent(previous.capture_ns,p.capture_ns,p.arrival_ns)
        self.previous,self.latest=previous,p

class ReservedChannel:
    def __init__(self,spec):
        self.services=dict(spec['services_ns']);b=spec['B_reservation']
        self.reservations=[Reservation(0,'B',b['tag'],b['request_ns'],b['service_start_ns'],b['service_end_ns'],True)]
    @staticmethod
    def earliest_service(now,duration,reservations):
        start=now
        for r in sorted(reservations,key=lambda r:(r.service_start_ns,r.seq)):
            if start+duration<=r.service_start_ns:break
            if start<r.ack_ns and start+duration>r.service_start_ns:start=r.ack_ns
        return start,start+duration
    def submit(self,now,target,tag):
        if target not in ('A','C') or tag!=target+'_stop':raise ValueError('legal selective action only')
        duration=self.services[tag]
        start,end=self.earliest_service(now,duration,self.reservations)
        r=Reservation(len(self.reservations),target,tag,now,start,end)
        self.reservations.append(r);return r
    def public_snapshot(self):return tuple(self.reservations)
