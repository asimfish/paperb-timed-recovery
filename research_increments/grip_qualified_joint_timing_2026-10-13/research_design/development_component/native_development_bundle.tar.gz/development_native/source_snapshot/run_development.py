"""One frozen development epoch, never a calibration/main test/fitted learner."""
from pathlib import Path
from dataclasses import asdict
import csv,json,hashlib,time,shutil
import mujoco,numpy as np
from interfaces import Packet,Ack,PublicObserver,ReservedChannel
from plant import create,Effects
from controller import DevelopmentActor
from referee import evaluate
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def main():
    release=json.loads((HERE/'DEVELOPMENT_RELEASE.json').read_text())
    assert all(sha(HERE/n)==h for n,h in release['files'].items())
    p=json.loads((HERE/'PROTOCOL_DEV.json').read_text());out=ROOT/'development_native';out.mkdir(exist_ok=False)
    snap=out/'source_snapshot';snap.mkdir()
    for n in release['files']:
        dst=snap/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(HERE/n,dst)
    write(out/'development_release_snapshot.json',release)
    m,d=create(p['private_plant'],p['initial_state']);effects=Effects(p['private_plant'],p['resource']['B_reservation']['torque_after_ACK'])
    channel=ReservedChannel(p['resource']);obs=PublicObserver(p['public']['original_B_angle'],p['public']['moving_threshold'])
    actor=DevelopmentActor(p['public'],p['resource'],p['dt_ns'],p['charged_decision_ns'])
    pending=[];applied=set();acks=[];intents=[];captures=[];deliveries=[];private=[];inputs=[];raw=[];submissions=[]
    start=time.monotonic_ns()
    for tick in range(p['horizon_ns']//p['dt_ns']+1):
        now=tick*p['dt_ns']
        if round(d.time*1e9)!=now:raise RuntimeError('native clock grid violation')
        # Capture before this tick ACKs: every logged public torque is pre-ACK.
        if tick%p['sensor_period_ticks']==0:
            packet=Packet(now,now+p['sensor_lag_ns'],tuple(d.qpos.copy().tolist()),tuple(d.qvel.copy().tolist()),tuple(d.ctrl.copy().tolist()))
            pending.append(packet);captures.append(asdict(packet))
        while pending and pending[0].arrival_ns<=now:
            packet=pending.pop(0);obs.deliver(packet,now);deliveries.append(asdict(packet))
        for r in channel.reservations:
            if r.ack_ns==now and r.seq not in applied:
                applied.add(r.seq);private.append(effects.apply(d,r));acks.append(Ack(r.seq,r.target,r.tag,now))
        inputs.append({'now_ns':now,'latest_packet_capture_ns':None if obs.latest is None else obs.latest.capture_ns,'latest_packet_arrival_ns':None if obs.latest is None else obs.latest.arrival_ns,
          'public_B_observed':None if obs.original_B is None else asdict(obs.original_B),'ACK_seq':[a.seq for a in acks]})
        if tick%p['decision_period_ticks']==0:
            before=time.monotonic_ns();new=actor.decide(now,obs,tuple(acks),channel.public_snapshot());spent=time.monotonic_ns()-before
            for a in new:
                if a['submit_ns']<now+p['charged_decision_ns']:raise RuntimeError('uncharged decision')
                intents.append(a)
            if actor.decisions and actor.decisions[-1]['now_ns']==now:actor.decisions[-1]['measured_host_compute_ns']=spent
        for a in list(intents):
            if a['submit_ns']==now:
                r=channel.submit(now,a['target'],a['tag']);submissions.append(asdict(r));intents.remove(a)
            elif a['submit_ns']<now:raise RuntimeError('missed scheduled native submission')
        raw.append({'sim_ns':now,'native_time_s':float(d.time),'epoch':0,**{name+'_'+k:float(v) for name,i in [('A',0),('B',1),('C',2)] for k,v in [('q',d.qpos[i]),('v',d.qvel[i]),('ctrl_next',d.ctrl[i])]}})
        if tick<p['horizon_ns']//p['dt_ns']:
            before=d.time;mujoco.mj_step(m,d);mujoco.mj_forward(m,d)
            if abs(d.time-before-p['dt_ns']/1e9)>1e-12:raise RuntimeError('native integration discontinuity')
    with (out/'independent_samples.csv').open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(raw[0]));w.writeheader();w.writerows(raw)
    commands=[asdict(r) for r in channel.reservations]
    write(out/'commands.json',commands);write(out/'public_captures.json',captures);write(out/'public_deliveries.json',deliveries)
    write(out/'public_actor_inputs.json',inputs);write(out/'public_decisions.json',actor.decisions);write(out/'private_effects.json',private)
    write(out/'contract.json',p);verdict=evaluate([{k:str(v) for k,v in r.items()} for r in raw],commands,p);write(out/'independent_verdict.json',verdict)
    summary={'status':'COMPLETE_DEVELOPMENT_COMPONENT_NOT_MAIN','samples':len(raw),'native_steps':p['horizon_ns']//p['dt_ns'],'duration_ns':p['horizon_ns'],'epoch_count':1,'public_packets_captured':len(captures),'public_packets_delivered':len(deliveries),
      'command_transactions':len(commands),'selective_A_C_transactions':len(submissions),'original_B_public_event':None if obs.original_B is None else asdict(obs.original_B),
      'joint_development_only':verdict['joint'],'component_values':verdict['values'],'formal_test_count':0,'calibration_count':0,'fit_count':0,'weights':0,'GPU':0,'LLM':0,
      'host_elapsed_ns':time.monotonic_ns()-start,'host_computation_advances_plant':False,'charged_decision_ns':p['charged_decision_ns'],'pending_actor_intents':intents,'pending_channel_transactions':[r.seq for r in channel.reservations if r.seq not in applied],
      'mujoco':mujoco.__version__,'numpy':np.__version__,'source_release_sha256':sha(HERE/'DEVELOPMENT_RELEASE.json'),'state_writes_during_epoch':0,'role':'NONMAIN_DEVELOPMENT','chemical_or_original_robot_credit':0}
    write(out/'SUMMARY.json',summary)
    assert all(sha(HERE/n)==h for n,h in release['files'].items())
    print(json.dumps(summary))
if __name__=='__main__':main()
