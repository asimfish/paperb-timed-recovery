"""One DEVELOPMENT controller; not one of the four formal arms.
Public packet/model/contracts/queue only. No plant/referee/imported private data.
"""
from dataclasses import asdict
import math
from interfaces import ReservedChannel

def stop_prediction(packet,axis,zero_ns,model,dt,drive):
    mass,damping=model['inertia'],model['damping'];decay=mass/(mass+dt/1e9*damping)
    v=packet.velocities[axis];steady=packet.torques[axis]/damping
    n=max(0,(zero_ns-packet.capture_ns)//dt);v=steady+(v-steady)*decay**n
    if v<=.1:return [zero_ns,zero_ns]
    k=max(1,math.ceil(math.log(.1/v)/math.log(decay)))
    while v*decay**k>.1:k+=1
    while k>1 and v*decay**(k-1)<=.1:k-=1
    return [zero_ns+(k-1)*dt,zero_ns+k*dt]

class DevelopmentActor:
    def __init__(self,public,resource,dt,charge):
        self.p,self.resource,self.dt,self.charge=public,resource,dt,charge
        self.first_planned=self.C_planned=self.retry_planned=False
        self.decisions=[];self.candidates=0
    def decide(self,now,observer,acks,reservations):
        packet,anchor=observer.latest,observer.original_B
        if packet is None or anchor is None:return []
        actions=[];earliest=now+self.charge
        if not self.first_planned:
            self.first_planned=True
            actions.append({'submit_ns':max(earliest,anchor.upper_ns+350_000_000),'target':'A','tag':'A_stop'})
        A_acks=[x for x in acks if x.target=='A']
        if A_acks and not self.retry_planned and packet.capture_ns>=A_acks[0].ack_ns+self.dt and packet.torques[0]>0:
            self.retry_planned=True
            actions.append({'submit_ns':earliest,'target':'A','tag':'A_stop'})
        candidates=0;selected=None
        if not self.C_planned:
            duration=self.resource['services_ns']['C_stop']
            target=(anchor.lower_ns+anchor.upper_ns)//2+self.p['D_C_ns']
            limit=min(7_000_000_000,earliest+999*self.dt)
            for t in range(earliest,limit+self.dt,self.dt):
                if candidates>=self.p['maximum_candidates_per_decision'] or self.candidates+candidates>=self.p['maximum_candidates_epoch']:break
                _,end=ReservedChannel.earliest_service(t,duration,reservations)
                predicted=stop_prediction(packet,2,end,self.p['public_nominal_model'],self.dt,self.p['initial_torque']);candidates+=1
                lo=predicted[0]-anchor.upper_ns-self.p['D_C_ns'];hi=predicted[1]-anchor.lower_ns-self.p['D_C_ns']
                if lo>=-self.p['eps_C_ns'] and hi<=self.p['eps_C_ns']:
                    value=((predicted[0]+predicted[1])//2-target)**2
                    choice=(value,t,end,predicted)
                    if selected is None or choice<selected:selected=choice
            self.candidates+=candidates
            if selected is not None:
                self.C_planned=True;actions.append({'submit_ns':selected[1],'target':'C','tag':'C_stop'})
        self.decisions.append({'now_ns':now,'packet':asdict(packet),'original_B_public':asdict(anchor),'public_ACKs':[asdict(x) for x in acks],
          'public_reservations':[asdict(x) for x in reservations],'actions':actions,'candidate_evaluations':candidates,'candidate_evaluations_cumulative':self.candidates,
          'C_selected_prediction':selected,'private_truth_or_fault_read':False,'development_only':True})
        return actions
