"""Separate command-driven native integration, no actor decisions/effect labels."""
from pathlib import Path
import json,csv,hashlib,math
import mujoco,numpy as np
from plant import create
from referee import evaluate
ROOT=Path(__file__).resolve().parent.parent

def main():
    out=ROOT/'development_native';p=json.loads((out/'contract.json').read_text());commands=json.loads((out/'commands.json').read_text())
    with (out/'independent_samples.csv').open() as f:raw=list(csv.DictReader(f))
    m,d=create(p['private_plant'],p['initial_state']);applied=set();Aseen=0;maxerr=0.;timeerr=0.;new=[]
    for tick in range(p['horizon_ns']//p['dt_ns']+1):
        now=tick*p['dt_ns']
        for cmd in commands:
            if cmd['ack_ns']==now and cmd['seq'] not in applied:
                applied.add(cmd['seq'])
                if cmd['target']=='B':d.ctrl[1]=p['resource']['B_reservation']['torque_after_ACK']
                elif cmd['target']=='A':
                    Aseen+=1
                    if not(Aseen==1 and p['private_plant']['fault']=='first_A_stop_drop'):d.ctrl[0]=0
                elif cmd['target']=='C':d.ctrl[2]=0
                else:raise RuntimeError('unknown action')
        row={'sim_ns':now,'native_time_s':d.time,'epoch':0}
        for name,i in [('A',0),('B',1),('C',2)]:
            for k,v in [('q',d.qpos[i]),('v',d.qvel[i]),('ctrl_next',d.ctrl[i])]:
                key=name+'_'+k;row[key]=float(v);maxerr=max(maxerr,abs(float(raw[tick][key])-float(v)))
        timeerr=max(timeerr,abs(float(raw[tick]['native_time_s'])-d.time));new.append({k:str(v) for k,v in row.items()})
        if tick<p['horizon_ns']//p['dt_ns']:mujoco.mj_step(m,d);mujoco.mj_forward(m,d)
    verdict=evaluate(new,commands,p);original=json.loads((out/'independent_verdict.json').read_text())
    matches=verdict==original
    result={'schema':'paperb-development-command-reintegration-v1','status':'PASS_REINTEGRATION_DEVELOPMENT_ONLY' if maxerr==0 and timeerr==0 and matches else 'FAIL_RETAINED',
      'native_reintegration_epochs':1,'reintegration_diagnostic_not_main_episode':True,'samples':len(new),'maximum_state_ctrl_error':maxerr,'maximum_native_clock_error_s':timeerr,'verdict_matches':matches,
      'inputs_used':['Frozen development source/MJCF','Private contract initial parameters','Public command reservation actual ACKs'],
      'inputs_not_used':['Actor decisions','Private effect success flags','RAW ctrl targets as integration input','RAW oracle event as actor input'],
      'mujoco':mujoco.__version__,'numpy':np.__version__,'formal_tests':0,'fits':0,'GPU':0}
    with (out/'REINTEGRATION.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
