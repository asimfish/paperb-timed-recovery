# 下载包验证与CPU复算

本包只包含131个冻结源、协议、CPU证据和16个synthetic调度示例，不包含当前native输出或测试成绩。外部IsaacLab、IsaacSim与USD资产仅保留原pin，没有重分发。启动robot/GPU不是这里的复现步骤；原20条件仍必须先独立4cal准入再fit，资格不替代calibration。

先下载本目录`qualified_joint_timing_execution_design.tar.gz`与`ARCHIVE_VALIDATION.json`，使用标准Python即可逐成员验证，无解包、无物理App、无GPU分配：

```bash
python3 -s verify_and_reproduce.py --design-archive qualified_joint_timing_execution_design.tar.gz --receipt ARCHIVE_VALIDATION.json
```

可另下载上一轮`scene_methods_expansion_2026-10-13/methods_component/cpu_contract_validation_7172.tar.gz`，以完全相同公开输入/独立oracle复算exact candidate7172数学条件：

```bash
python3 -s verify_and_reproduce.py --design-archive qualified_joint_timing_execution_design.tar.gz --receipt ARCHIVE_VALIDATION.json --math-archive cpu_contract_validation_7172.tar.gz
```

工具先核对归档SHA、所有source SHA和member manifest，只运行已知SHA的纯Fraction solver。应得到7172条件、2606可行、4566拒绝以及全部selected tick/objective和原独立oracle相同。复算分母保留全部infeasible条件；它不是新增native样本、训练过程或机器人成功率。

如需检查代码，可在个人空目录解包。`source_frozen/`是原131文件的逐字副本；任何再次native执行需相应外部资产与隔离SDK，并另立输出/源版本，不能覆盖本文已运行的case或修改已冻结版本。旧118/117源、旧失败、旧solver误拒与qualification logging限制全部保留。
