"""Export only the reviewed131 frozen files, not any current native outcomes."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

ROOT=Path('/data/liyufeng/paperb_grip_qualified_joint_timing_20261013_v1')
PUBLIC=Path(__file__).parent
RELEASE='0c3cff79148f20f6b5f212eb484ac205122b02e63fac98d657ad8e14db3041dd'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path,payload):
    with path.open('x') as f:
        json.dump(payload,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')


def frozen_check():
    if sha(ROOT/'EXECUTION_RELEASE.json')!=RELEASE:
        raise ValueError('reviewed release changed')
    release=json.loads((ROOT/'EXECUTION_RELEASE.json').read_text())
    if len(release['files'])!=131:
        raise ValueError('complete131 source files required')
    for name,h in release['files'].items():
        if sha(ROOT/name)!=h:
            raise ValueError('frozen source changed: '+name)
    return release


def copy_exact(source,target):
    if target.exists():raise ValueError('do not overwrite exported artifact')
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    if sha(source)!=sha(target):raise ValueError('export copy differs')


def main():
    release=frozen_check()
    for name,h in release['files'].items():
        copy_exact(ROOT/name,PUBLIC/'source_frozen'/name)
    copy_exact(ROOT/'EXECUTION_RELEASE.json',PUBLIC/'EXECUTION_RELEASE.json')
    for name in ['protocol.json','RAW_SCHEMA.json','CPU_PREFLIGHT.json','RUN_BUDGET.json','README_cn.md',
                 'SOURCE_REVIEW.json','REGRESSION_EVIDENCE.json','DEMO_DECISIONS.json','test_contract.json']:
        copy_exact(ROOT/name,PUBLIC/name)
    protocol=json.loads((ROOT/'protocol.json').read_text())
    summary=dict(schema='paperb-public-qualified-joint-timing-execution-design-v1',
        status='FROZEN_DESIGN_AND_CPU_PREFLIGHT_NOT_NATIVE_ACCEPTANCE_RESULTS',
        source_files=131,source_release_sha256=RELEASE,
        planned_new_calibration=4,planned_new_test=16,qualification_is_separate=True,
        old_failed_calibration_cases_preserved=4,common_actor_K1600_unconditional=True,
        primary_tolerances_s={'contact':.025,'release':.025,'duration_gap':.025},
        method_names=['nominal_prior','public_delay_prior','calibrated_interval','joint_exact_grid'],
        exact_candidate_source_sha256=protocol['exact_grid_scheduler']['candidate_solver_sha256'],
        prior_legacy_midpoint_bug_repaired_in_separate_exact_method=True,
        historical_math_conditions_rechecked=7172,CPU_focused_tests=19,
        teacher_demo_scope='16_SYNTHETIC_PUBLIC_INFORMATION_DISPATCH_TARGETS; NO_ROBOT_ROLLOUTS_OR_LEARNING',
        current_native_raw_or_outcome_files_packaged=0,new_native_episodes_added_by_export=0,
        all_test_methods_require_independent_new4cal_fit=True,
        single_qualification_cannot_replace_calibration=True,
        complete_before_after_end_arrays_and_state_preimages_required=True,
        parameter_readback_is_endpoint_not_continuous_telemetry=True,
        empirical_latency_box_is_not_true_support_or_statistical_confidence_guarantee=True,
        measured_native_event_clock_not_replaced_by_nominal_grid=True,
        simulation_dependencies_pinned_not_bundled=True,
        learned_policy_claim=False,causal_mechanical_root_cause_claim=False,
        role_counts_are_plans_not_acceptance_counts=True)
    write_json(PUBLIC/'summary.json',summary)
    with (PUBLIC/'REPRODUCE_cn.md').open('x') as f:
        f.write('''# 下载包验证与CPU复算

本包只包含131个冻结源、协议、CPU证据和16个synthetic调度示例，不包含当前native输出或测试成绩。外部IsaacLab、IsaacSim与USD资产仅保留原pin，没有重分发。启动robot/GPU不是这里的复现步骤；原20条件仍必须先独立4cal准入再fit，资格不替代calibration。

先下载本目录`qualified_joint_timing_execution_design.tar.gz`与`ARCHIVE_VALIDATION.json`，使用标准Python即可逐成员验证，无解包、无物理App、无GPU分配：

```bash
python3 -s verify_and_reproduce.py --design-archive qualified_joint_timing_execution_design.tar.gz --receipt ARCHIVE_VALIDATION.json
```

可另下载上一轮`scene_methods_expansion_2026-10-13/methods_component/cpu_contract_validation_7172.tar.gz`，以完全相同公开输入/独立oracle复算exact candidate7172数学条件：

```bash
python3 -s verify_and_reproduce.py --design-archive qualified_joint_timing_execution_design.tar.gz --receipt ARCHIVE_VALIDATION.json --math-archive cpu_contract_validation_7172.tar.gz
```

工具先核对归档SHA、所有source SHA和member manifest，只运行已知SHA的纯Fraction solver。应得到7172条件、2606可行、4566拒绝以及全部selected tick/objective和原独立oracle相同。复算分母保留全部infeasible条件；它不是新增native样本、训练过程或机器人成功率。

如需检查代码，可在个人空目录解包。`source_frozen/`是原131文件的逐字副本；任何再次native执行需相应外部资产与隔离SDK，并另立输出/源版本，不能覆盖本文已运行的case或修改已冻结版本。旧118/117源、旧失败、旧solver误拒与qualification logging限制全部保留。
''')
    members=sorted(p for p in PUBLIC.rglob('*') if p.is_file())
    roster={str(p.relative_to(PUBLIC)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in members}
    write_json(PUBLIC/'EXPORT_MANIFEST.json',dict(schema='paperb-frozen-source-design-export-manifest-v1',
        files=roster,source_release_sha256=RELEASE,frozen_source_files=131,source_and_native_raw_modified=False))
    members.append(PUBLIC/'EXPORT_MANIFEST.json')
    roster['EXPORT_MANIFEST.json']=dict(sha256=sha(members[-1]),bytes=members[-1].stat().st_size)
    archive=PUBLIC/'qualified_joint_timing_execution_design.tar.gz'
    with archive.open('xb') as output:
        with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as tar:
                for path in sorted(members):
                    if path.is_symlink():raise ValueError('no symlinks')
                    info=tar.gettarinfo(str(path),arcname=str(path.relative_to(PUBLIC)))
                    info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
                    with path.open('rb') as source:tar.addfile(info,source)
    seen=set()
    with tarfile.open(archive,'r:gz') as tar:
        for entry in tar.getmembers():
            if not entry.isfile() or entry.name.startswith('/') or '..' in Path(entry.name).parts or entry.name in seen:
                raise ValueError('archive path/member invalid')
            seen.add(entry.name);contents=tar.extractfile(entry).read();expected=roster[entry.name]
            if hashlib.sha256(contents).hexdigest()!=expected['sha256'] or len(contents)!=expected['bytes']:
                raise ValueError('reopen SHA/size differs')
    if seen!=set(roster):raise ValueError('member roster differs')
    frozen_check()
    receipt=dict(schema='paperb-frozen-design-archive-validation-v1',status='PASS_REOPEN_ALL_MEMBER_SHA256',
        archive=archive.name,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,members_total=len(seen),
        frozen_source_files=131,source_release_sha256=RELEASE,each_member_SHA_exact=True,safe_regular_members_only=True,
        source_and_native_raw_modified=False,actual_native_results_packaged=0,new_native_episodes_added_by_export=0)
    write_json(PUBLIC/'ARCHIVE_VALIDATION.json',receipt)
    print(json.dumps(receipt))


if __name__=='__main__':
    main()
