"""Freeze four raw calibration episodes after the independent auditor agrees."""
import argparse
import hashlib
import json
import os
from pathlib import Path
from expansion_protocol import calibration_model

ROOT=Path(__file__).parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--independent-audit',required=True)
    args=parser.parse_args()
    release=json.loads((ROOT/'EXECUTION_RELEASE.json').read_text())
    for rel,h in release['files'].items():
        if sha(ROOT/rel)!=h:raise ValueError('execution source changed: '+rel)
    protocol=json.loads((ROOT/'protocol.json').read_text())
    audit_path=Path(args.independent_audit).resolve()
    audit=json.loads(audit_path.read_text())
    expected=[c['id'] for c in protocol['cases'] if c['role']=='calibration']
    if audit['schema']!='paperb-independent-calibration-audit-v1' or audit['status']!='PASS_COMPONENT':
        raise ValueError('independent calibration audit must PASS_COMPONENT')
    if sorted(audit['complete_case_ids'])!=sorted(expected):
        raise ValueError('all four calibration episodes must enter the fit without filtering')
    expected_observations={(c,k) for c in expected for k in ('contact','release')}
    observed_keys=[(x['case_id'],x['kind']) for x in audit['observations']]
    if len(observed_keys)!=8 or set(observed_keys)!=expected_observations:
        raise ValueError('eight unique cell-specific mechanical intervals required; no averaging or imputation')
    if not audit.get('complete_active_controller_raw_pass',False):
        raise ValueError('new calibration requires independently recomputable complete controller RAW')
    if not audit.get('fresh_and_cached_preimages_pass',False):
        raise ValueError('new calibration requires independent before/after state preimage verification')
    required_raw={f'cases/{case_id}/{name}' for case_id in expected for name in (
        'CONTROLLER_BEFORE.json','CONTROLLER_AFTER.json','CONTROLLER_INSTALLATION.json',
        'task/ACTIVE_DRIVE_END.json','task/controller_origin.json','task/installed_properties_end.json')}
    if not required_raw.issubset(audit['raw_artifact_sha256']):
        raise ValueError('independent audit must bind complete controller RAW for all four cells')
    if audit['protocol_sha256']!=sha(ROOT/'protocol.json') or audit['execution_release_sha256']!=sha(ROOT/'EXECUTION_RELEASE.json'):
        raise ValueError('independent audit identity mismatch')
    for rel,h in audit['raw_artifact_sha256'].items():
        if Path(rel).is_absolute() or '..' in Path(rel).parts or sha(ROOT/rel)!=h:
            raise ValueError('independent audit raw artifact changed: '+rel)
    model=calibration_model(ROOT,protocol)
    if model['mechanical_latency_intervals_s']!=audit['mechanical_latency_intervals_s']:
        raise ValueError('executor and independent raw event latency intervals differ')
    own={(x['case_id'],x['kind']):x['mechanical_interval_s'] for x in model['observations']}
    other={(x['case_id'],x['kind']):x['mechanical_interval_s'] for x in audit['observations']}
    if own!=other:raise ValueError('per-episode independent calibration discrepancy')
    model.update(independent_audit_path=str(audit_path),independent_audit_sha256=sha(audit_path),
                 independent_auditor_release_sha256=audit['auditor_release_sha256'])
    with (ROOT/'CALIBRATION.json').open('x') as f:
        json.dump(model,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
    receipt=dict(schema='paperb-calibration-release-v2',calibration_sha256=sha(ROOT/'CALIBRATION.json'),
        execution_release_sha256=sha(ROOT/'EXECUTION_RELEASE.json'),protocol_sha256=sha(ROOT/'protocol.json'),
        independent_audit_sha256=sha(audit_path),fitted_episode_ids=expected,uses_test_outputs=False)
    with (ROOT/'CALIBRATION_RELEASE.json').open('x') as f:
        json.dump(receipt,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    print(json.dumps(receipt,sort_keys=True))

if __name__=='__main__':main()
