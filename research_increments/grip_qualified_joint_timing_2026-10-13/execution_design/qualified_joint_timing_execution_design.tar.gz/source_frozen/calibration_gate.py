"""Every test method waits for the same complete independent four-cell fit."""
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_frozen_calibration(root, protocol):
    root=Path(root)
    receipt=json.loads((root/'CALIBRATION_RELEASE.json').read_text())
    expected=[c['id'] for c in protocol['cases'] if c['role']=='calibration']
    if receipt['execution_release_sha256']!=sha(root/'EXECUTION_RELEASE.json') or receipt['protocol_sha256']!=sha(root/'protocol.json'):
        raise ValueError('frozen new calibration belongs to another source/protocol')
    digest=sha(root/'CALIBRATION.json')
    if receipt['calibration_sha256']!=digest or sorted(receipt['fitted_episode_ids'])!=sorted(expected):
        raise ValueError('new calibration receipt mismatch or incomplete four-cell fit')
    model=json.loads((root/'CALIBRATION.json').read_text())
    if model['status']!='FROZEN_CALIBRATION' or model['fitted_episode_ids']!=expected:
        raise ValueError('all four current calibration episodes required')
    audit_path=Path(model['independent_audit_path'])
    if sha(audit_path)!=model['independent_audit_sha256'] or receipt['independent_audit_sha256']!=model['independent_audit_sha256']:
        raise ValueError('independent calibration audit changed')
    audit=json.loads(audit_path.read_text())
    if audit['status']!='PASS_COMPONENT' or sorted(audit['complete_case_ids'])!=sorted(expected):
        raise ValueError('independent new calibration audit is not a complete PASS_COMPONENT')
    for name,digest0 in model['sources'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts or sha(root/name)!=digest0:
            raise ValueError('calibration RAW source changed: '+name)
    return model,digest
