"""Same three prior baselines/events, plus the separately audited exact solver.

The new joint method bypasses the old midpoint precheck. Inputs are only the
public contract/FIFO, fixed skill indices, and independent frozen calibration.
"""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
from exact_grid_solver import solve,ceilq,floorq
from legacy_timing_protocol import (score_gap,FixedDelayFIFO,sampled_operation_events,
    contact_features,confirm_event,upright_tilt_deg,finite,has_prefix,
    calibration_model as _legacy_calibration_model,dispatch_schedule as _legacy_dispatch_schedule)

METHODS=('nominal_prior','public_delay_prior','calibrated_interval','joint_exact_grid')


def solver_inputs(case, protocol, calibration):
    cfg=protocol['exact_grid_scheduler']; dt=F(cfg['dt_ratio'])
    eps=F(str(case['contact_tolerance_s']))
    if F(str(case['duration_tolerance_s']))!=eps or F(str(protocol['primary_score_definition']['release_tolerance_s']))!=eps:
        raise ValueError('this frozen exact candidate requires equal three contract tolerances')
    if float(dt)!=protocol['dt_s']:
        raise ValueError('nominal rational grid and protocol dt mismatch')
    close,cue,release=[protocol[k] for k in ('first_close_source_index','cue_source_index','first_open_source_index')]
    intervals=calibration['mechanical_latency_intervals_s']
    # Public decimal contract values and binary64 calibration endpoints have
    # explicitly distinct conventions, both logged as canonical ratios.
    return dict(dt_ratio=str(dt),public_delay_ticks=case['public_transport_delay_ticks'],
        contact_request_s=str(F(str(case['requested_contact_gap_s']))),
        duration_request_s=str(F(str(case['requested_contact_to_release_s']))),tolerance_s=str(eps),
        mechanical_contact_interval_s=[str(F(x)) for x in intervals['contact']],
        mechanical_release_interval_s=[str(F(x)) for x in intervals['release']],
        earliest_contact_dispatch_s=str((close-cue)*dt),min_skill_gap_s=str((release-close)*dt))


def exact_certificate(inputs, result):
    dt=F(inputs['dt_ratio']);delay=inputs['public_delay_ticks']*dt
    D,H,e=[F(inputs[k]) for k in ('contact_request_s','duration_request_s','tolerance_s')]
    a0,a1=[F(x)+delay for x in inputs['mechanical_contact_interval_s']]
    b0,b1=[F(x)+delay for x in inputs['mechanical_release_interval_s']]
    A=[D-e-a0,D+e-a1];B=[D+H-e-b0,D+H+e-b1]
    delta=[H-e-b0+a1,H+e-b1+a0]
    minimum=F(inputs['min_skill_gap_s']);earliest=F(inputs['earliest_contact_dispatch_s'])
    count=0
    for ai in range(max(ceilq(A[0]/dt),ceilq(earliest/dt)),floorq(A[1]/dt)+1):
        lo=max(ceilq(B[0]/dt),ceilq((ai*dt+minimum)/dt),ceilq((ai*dt+delta[0])/dt))
        hi=min(floorq(B[1]/dt),floorq((ai*dt+delta[1])/dt))
        count+=max(0,hi-lo+1)
    return dict(schema='paperb-joint-exact-grid-certificate-v1',solver_input=inputs,solver_result=result,
        contact_dispatch_bounds_ratio=[str(x) for x in A],release_dispatch_bounds_ratio=[str(x) for x in B],
        command_difference_bounds_ratio=[str(x) for x in delta],minimum_skill_gap_ratio=str(minimum),
        grid_feasible_candidates=count,refused=result['status']=='REFUSED',
        interval_scope='FOUR_CALIBRATION_EMPIRICAL_ENVELOPE; NO_TRUE_SUPPORT_OR_CONFIDENCE_GUARANTEE',
        nominal_grid_is_not_measured_native_clock=True,private_current_episode_truth_used=False)


def dispatch_schedule(case, protocol, calibration=None):
    if case['role']=='calibration':
        return _legacy_dispatch_schedule(case,protocol,None)
    method=case['method']
    if method not in METHODS:
        raise ValueError('unknown frozen method')
    if method!='joint_exact_grid':
        return _legacy_dispatch_schedule(case,protocol,calibration)
    if calibration is None or calibration['status']!='FROZEN_CALIBRATION':
        raise ValueError('joint_exact_grid requires frozen independent new calibration')
    inputs=solver_inputs(case,protocol,calibration);result=solve(inputs)
    certificate=exact_certificate(inputs,result)
    close,release,cue,total=[protocol[k] for k in ('first_close_source_index','first_open_source_index','cue_source_index','total_commands')]
    refused=result['status']=='REFUSED'
    if refused:
        close_extra=release_extra=0
    else:
        at,bt=result['selected_ticks'];close_extra=at-(close-cue)
        release_extra=bt-(release-cue)-close_extra
        if close_extra<0 or release_extra<0:
            raise ValueError('exact solver output violates immutable source skill timing')
    indices=list(range(close))+[close-1]*close_extra+list(range(close,release))+[release-1]*release_extra+list(range(release,total))
    def shift(index):
        return index+(close_extra if index>=close else 0)+(release_extra if index>=release else 0)
    stage_plan=[dict(id=s['id'],start_tick=shift(s['start_tick'])+case['public_transport_delay_ticks'],
        end_tick=shift(s['end_tick'])+case['public_transport_delay_ticks']) for s in protocol['stage_plan']]
    stage_plan[0]['start_tick']=0
    dt=protocol['dt_s'];delay=case['public_transport_delay_ticks']*dt
    intervals=calibration['mechanical_latency_intervals_s']
    return dict(source_indices=indices,stage_plan=stage_plan,
        hold_before_close_ticks=close_extra,hold_before_release_ticks=release_extra,
        planned_command_contact_gap_s=(close-cue+close_extra)*dt,
        planned_command_release_gap_s=(release-cue+close_extra+release_extra)*dt,
        expected_contact_transport_plus_mechanical_s=float(sum(map(F,intervals['contact']))/2)+delay,
        expected_release_transport_plus_mechanical_s=float(sum(map(F,intervals['release']))/2)+delay,
        uses_current_test_contact_labels=False,uses_test_mass=False,schedule_refused=refused,
        joint_interval_certificate=certificate,joint_exact_grid_certificate=certificate,
        available_public_transport_delay_ticks=case['public_transport_delay_ticks'])


def calibration_model(root, protocol):
    root=Path(root)
    model=_legacy_calibration_model(root,protocol)
    model['schema']='paperb-complete-raw-grip-qualified-timing-calibration-v1'
    expected=[c for c in protocol['cases'] if c['role']=='calibration']
    obs=model['observations']
    model['calibration_cells']=[dict(case_id=c['id'],mass_factor=c['mass_factor'],
        public_delay_ticks=c['public_transport_delay_ticks'],
        intervals={kind:next(o['mechanical_interval_s'] for o in obs if o['case_id']==c['id'] and o['kind']==kind)
                   for kind in ('contact','release')}) for c in expected]
    model['missing_cell_policy']='REFUSE_FIT; NO_FILTERING_OR_MEDIAN_IMPUTATION'
    model['variability_scope']='UNION_OF_ALL_EIGHT_RECORDED_MECHANICAL_INTERVALS; NOT_AVERAGE_OR_TRUE_SUPPORT'
    model['previous_qualification_or_failed_cohort_used_for_fit']=False
    model['all_four_common_actor_installations_required']=True
    for cell in expected:
        prefix='cases/'+cell['id']+'/'
        # These full arrays/preimages are part of the immutable fit dependency,
        # even though the timing actor consumes only the interval values.
        for name in ('CONTROLLER_BEFORE.json','CONTROLLER_AFTER.json','CONTROLLER_INSTALLATION.json',
                     'task/ACTIVE_DRIVE_END.json','task/controller_origin.json','task/installed_properties_end.json'):
            path=root/prefix/name
            model['sources'][prefix+name]=hashlib.sha256(path.read_bytes()).hexdigest()
    return model
