"""Visible-information-only scheduling labels, explicitly synthetic CPU demo.

No current robot outcome, contact, estimated mass, or fitted CALIBRATION file is
opened. These are planning targets, not a teacher robot trajectory dataset.
"""
import hashlib
import json
from pathlib import Path
from expansion_protocol import dispatch_schedule

ROOT=Path(__file__).parent


def main():
    protocol=json.loads((ROOT/'protocol.json').read_text())
    synthetic=dict(status='FROZEN_CALIBRATION',mechanical_latency_intervals_s={
        'contact':[.158,.162],'release':[.078,.082]})
    examples=[]
    for case in protocol['cases']:
        if case['role']!='test':
            continue
        schedule=dispatch_schedule(case,protocol,synthetic)
        close=protocol['first_close_source_index']+schedule['hold_before_close_ticks']
        release=protocol['first_open_source_index']+schedule['hold_before_close_ticks']+schedule['hold_before_release_ticks']
        examples.append(dict(case_id=case['id'],method=case['method'],
            public_contract={k:case[k] for k in ('requested_contact_gap_s','requested_contact_to_release_s',
                'contact_tolerance_s','duration_tolerance_s','public_transport_delay_ticks')},
            visible_information_available=['public contract and FIFO','fixed full skill indices',
                'old nominal prior','explicit synthetic mechanical interval fixture for calibrated methods'],
            mechanical_fixture_scope='CPU_SYNTHETIC_PUBLIC_DEMO_NOT_NATIVE_CALIBRATION',
            teacher_label_scope='CONTRACT_DISPATCH_AND_HOLD_TARGETS; NOT_VISUAL_STATE_LABELS_OR_ROBOT_TEACHER_ROLLOUTS',
            decision_targets=dict(close_submission_tick=close,release_submission_tick=release,
                close_cue_relative_tick=close-protocol['cue_source_index'],release_cue_relative_tick=release-protocol['cue_source_index'],
                hold_before_close_ticks=schedule['hold_before_close_ticks'],hold_before_release_ticks=schedule['hold_before_release_ticks'],
                schedule_refused=schedule['schedule_refused']),
            source_action_sequence_sha256=hashlib.sha256(json.dumps(schedule['source_indices']).encode()).hexdigest(),
            commands_submitted=len(schedule['source_indices']),FIFO_tail_flush_ticks=case['public_transport_delay_ticks'],
            joint_exact_grid_certificate=schedule.get('joint_exact_grid_certificate'),
            current_test_truth_read=False,current_mass_or_pose_used_for_decision=False,actual_robot_outcome=None))
    receipt=dict(schema='paperb-synthetic-visible-scheduling-decision-demo-v1',
        status='CPU_SYNTHETIC_DEMO_NO_NATIVE_OR_TRAINING_ADMISSION',
        public_synthetic_fixture=synthetic,examples=examples,examples_total=len(examples),
        new_native_episodes=0,new_test_outcomes=0,calibration_fit_executed=False,teacher_robot_rollouts=0,
        current_test_labels_read=False,protocol_sha256=hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest())
    with (ROOT/'DEMO_DECISIONS.json').open('x') as f:
        json.dump(receipt,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps(dict(status=receipt['status'],examples=len(examples))))


if __name__=='__main__':
    main()
