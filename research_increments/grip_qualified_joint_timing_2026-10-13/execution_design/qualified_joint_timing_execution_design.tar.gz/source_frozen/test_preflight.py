"""Focused CPU contracts; original native and qualified RAW are not fitted."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
import torch
from gain_installation import install, verify_end, canonical_sha
from expansion_protocol import dispatch_schedule,solver_inputs,exact_certificate,FixedDelayFIFO
from exact_grid_solver import solve
from legacy_timing_protocol import dispatch_schedule as legacy_schedule
from calibration_gate import load_frozen_calibration

ROOT=Path(__file__).parent
CPU=Path('/data/liyufeng/paperb_joint_scheduler_validation_20261013_v1')
EPOCH='CPU_FAKE_INTERFACE_NOT_NATIVE'
PROTOCOL=json.loads((ROOT/'protocol.json').read_text())
# Explicit synthetic mechanics, no native episode result used here.
CAL=dict(status='FROZEN_CALIBRATION',mechanical_latency_intervals_s={'contact':[.158,.162],'release':[.078,.082]})


class View:
    def __init__(self):
        self.k=torch.tensor([[60000.]*7+[800.,800.]])
        self.d=torch.tensor([[6000.]*7+[40.,40.]])
        self.e=torch.tensor([[87.]*4+[12.]*3+[100.,float('inf')]])
        self.root=torch.tensor([[0.,0.,0.,0.,0.,0.,1.]])
        self.q=torch.zeros(1,9)
    def get_dof_stiffnesses(self):return self.k
    def get_dof_dampings(self):return self.d
    def get_dof_max_forces(self):return self.e
    def get_transforms(self):return self.root
    def get_velocities(self):return torch.zeros(1,6)
    def get_root_transforms(self):return self.root
    def get_root_velocities(self):return self.get_velocities()
    def get_dof_positions(self):return self.q
    def get_dof_velocities(self):return torch.zeros(1,9)


def robot_scene():
    data=SimpleNamespace(joint_pos=torch.zeros(1,9),joint_vel=torch.zeros(1,9),root_pos_w=torch.zeros(1,3),
        root_quat_w=torch.tensor([[1.,0.,0.,0.]]),root_lin_vel_w=torch.zeros(1,3),root_ang_vel_w=torch.zeros(1,3))
    robot=SimpleNamespace(root_physx_view=View(),joint_names=[f'fr3_joint{i}' for i in range(1,8)]+['fr3_finger_joint1','fr3_finger_joint2'],
        num_joints=9,data=data,actuators={'hand':SimpleNamespace(stiffness=torch.tensor([[800.,800.]]))})
    def setter(value,joint_ids):robot.root_physx_view.k[:,joint_ids]=value
    robot.write_joint_stiffness_to_sim=setter
    scene=SimpleNamespace(rigid_objects={'bottle':SimpleNamespace(data=data,root_physx_view=View())},articulations={'fr3_A':robot})
    return robot,scene,SimpleNamespace(current_time=5.133333333),dict(count=1230)


class Tests(unittest.TestCase):
    def test_roster_preserves_4_new_cal_16_tests_and_25ms(self):
        cases=PROTOCOL['cases'];self.assertEqual(sum(c['role']=='calibration' for c in cases),4)
        self.assertEqual(sum(c['role']=='test' for c in cases),16)
        self.assertEqual(len({c['id'] for c in cases}),20)
        self.assertEqual({c['method'] for c in cases if c['role']=='test'},
            {'nominal_prior','public_delay_prior','calibrated_interval','joint_exact_grid'})
        for c in cases:self.assertEqual((c['contact_tolerance_s'],c['duration_tolerance_s']),(.025,.025))
        self.assertEqual(PROTOCOL['primary_score_definition']['shared_denominator'],16)
        self.assertEqual(PROTOCOL['common_actor_installation']['candidate'],1600.)
        self.assertFalse(PROTOCOL['split_contract']['old_qualification_labels_used_for_fit'])

    def test_all_pinned_inputs_and_mechanical_helper_exact(self):
        origin=json.loads((ROOT/'SOURCE_ORIGIN.json').read_text())
        for name,h in origin['copied_fixed_source_hashes'].items():
            self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),h,name)
        self.assertEqual(hashlib.sha256((ROOT/'exact_grid_solver.py').read_bytes()).hexdigest(),origin['exact_candidate_solver_sha256'])
        self.assertEqual(hashlib.sha256((ROOT/'legacy_timing_protocol.py').read_bytes()).hexdigest(),origin['legacy_three_baseline_and_event_helper_sha256'])

    def test_every_calibration_full_original_skill_no_holds(self):
        for c in PROTOCOL['cases']:
            if c['role']=='calibration':
                d=dispatch_schedule(c,PROTOCOL,None)
                self.assertEqual(d['source_indices'],list(range(13427)))

    def test_three_prior_baselines_exact_legacy_math(self):
        for c in PROTOCOL['cases']:
            if c['role']=='test' and c['method']!='joint_exact_grid':
                self.assertEqual(dispatch_schedule(c,PROTOCOL,CAL),legacy_schedule(c,PROTOCOL,CAL),c['id'])

    def test_missing_calibration_refuses_joint(self):
        c=next(c for c in PROTOCOL['cases'] if c['method']=='joint_exact_grid')
        with self.assertRaises(ValueError):dispatch_schedule(c,PROTOCOL,None)

    def test_known_false_refusal_bypassed_and_immutable_skill_minimum(self):
        p=copy.deepcopy(PROTOCOL);p['first_open_source_index']=7680
        c=copy.deepcopy(next(c for c in p['cases'] if c['method']=='joint_exact_grid'))
        c['requested_contact_to_release_s']=17.95
        cal=dict(status='FROZEN_CALIBRATION',mechanical_latency_intervals_s={'contact':['.158','.162'],'release':['.118','.122']})
        old=copy.deepcopy(c);old['method']='joint_interval_scheduler'
        old_cal=dict(status='FROZEN_CALIBRATION',mechanical_latency_intervals_s={k:list(map(float,v)) for k,v in cal['mechanical_latency_intervals_s'].items()})
        with self.assertRaisesRegex(ValueError,'precedes feasible source release stage'):legacy_schedule(old,p,old_cal)
        d=dispatch_schedule(c,p,cal)
        self.assertFalse(d['schedule_refused'])
        # The published1161/5481 counterexample is feasible; the independently
        # audited minimum-cost pair for that roster is1160/5480.
        self.assertEqual(d['joint_exact_grid_certificate']['solver_result']['selected_ticks'],[1160,5480])
        self.assertGreaterEqual(d['hold_before_close_ticks'],0);self.assertGreaterEqual(d['hold_before_release_ticks'],0)

    def test_wide_intervals_preserve_refusal_full_diagnostic_skill(self):
        c=next(c for c in PROTOCOL['cases'] if c['method']=='joint_exact_grid')
        cal=dict(status='FROZEN_CALIBRATION',mechanical_latency_intervals_s={'contact':[.10,.20],'release':[.05,.15]})
        d=dispatch_schedule(c,PROTOCOL,cal)
        self.assertTrue(d['schedule_refused']);self.assertEqual(d['source_indices'],list(range(13427)))
        self.assertEqual(d['joint_exact_grid_certificate']['grid_feasible_candidates'],0)

    def test_dispatch_ignores_private_mass_contact_pose_fields(self):
        c=copy.deepcopy(next(c for c in PROTOCOL['cases'] if c['method']=='joint_exact_grid'))
        expected=dispatch_schedule(c,PROTOCOL,CAL)
        c.update(mass_factor=999.,contacts='UNKNOWN_TEST_TRUTH',object_pose=[999.]*7,inferred_lag=.9)
        self.assertEqual(dispatch_schedule(c,PROTOCOL,CAL),expected)

    def test_unequal_tolerance_is_explicitly_unsupported(self):
        c=copy.deepcopy(next(c for c in PROTOCOL['cases'] if c['method']=='joint_exact_grid'));c['duration_tolerance_s']=.05
        with self.assertRaises(ValueError):dispatch_schedule(c,PROTOCOL,CAL)

    def test_exact_solver_historical_7172_independent_oracle_matches(self):
        count=0
        with (CPU/'ROSTER.jsonl').open() as roster,(CPU/'oracle_pairs.jsonl').open() as oracle:
            for line,truth in zip(roster,oracle):
                c=json.loads(line);o=json.loads(truth);result=solve(c)
                self.assertEqual(c['id'],o['case_id'])
                self.assertEqual(result['selected_ticks'],o['selected_ticks'],c['id'])
                self.assertEqual(result['objective_ratio'],o['objective_ratio'],c['id'])
                cert=exact_certificate(c,result)
                self.assertEqual(cert['grid_feasible_candidates'],o['feasible_pair_count'],c['id'])
                self.assertEqual(result['status']=='FEASIBLE',o['feasible_pair_count']>0,c['id'])
                count+=1
        self.assertEqual(count,7172)

    def test_complete_before_after_end_raw_roundtrip_hash_recomputation(self):
        r,s,sim,c=robot_scene();records={}
        receipt,expected=install(r,s,sim,c,dict(status='PASS'),EPOCH,recorder=lambda n,v:records.update({n:v}))
        end=verify_end(r,expected,s,sim,c,EPOCH,recorder=lambda n,v:records.update({n:v}))
        self.assertEqual(set(records),{'CONTROLLER_BEFORE.json','CONTROLLER_AFTER.json','task/ACTIVE_DRIVE_END.json'})
        for raw in records.values():
            decoded=json.loads(json.dumps(raw,allow_nan=False))
            self.assertEqual(set(decoded['active']),{'stiffness','damping','effort_limits'})
            self.assertEqual(decoded['native_epoch'],EPOCH)
            for scope in ('cached_scene_state','fresh_physics_view_state'):
                self.assertEqual(canonical_sha(decoded[scope+'_preimage']),decoded[scope+'_sha256'])
            self.assertEqual(decoded['active']['effort_limits'][0][-1],'POSITIVE_INFINITY')
        before,after=receipt['before'],receipt['after']
        self.assertEqual(before['active']['stiffness'][0][-2:],[800.,800.])
        self.assertEqual(after['active']['stiffness'][0][-2:],[1600.,1600.])
        self.assertEqual(before['active']['damping'],after['active']['damping'])
        self.assertEqual(before['active']['effort_limits'],after['active']['effort_limits'])
        self.assertEqual(before['fresh_physics_view_state_preimage'],after['fresh_physics_view_state_preimage'])
        self.assertEqual(end['actual'],after['active'])

    def test_old_qualification_cannot_satisfy_new_raw_contract(self):
        path=Path('/data/liyufeng/paperb_grip_stiffness_qualification_20261013_v1/gain_installation.py')
        spec=importlib.util.spec_from_file_location('frozen_old_gain_for_CPU_regression',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        r,s,sim,c=robot_scene();old,_=module.install(r,s,sim,c,dict(status='PASS'))
        self.assertNotIn('before',old);self.assertNotIn('fresh_physics_view_state_preimage',old)
        self.assertIn('fresh_physics_view_state_sha256_before',old)

    def test_before_raw_retained_when_baseline_denies_install(self):
        r,s,sim,c=robot_scene();records={}
        with self.assertRaises(ValueError):install(r,s,sim,c,dict(status='FAIL'),EPOCH,recorder=lambda n,v:records.update({n:v}))
        self.assertEqual(set(records),{'CONTROLLER_BEFORE.json'});self.assertEqual(r.root_physx_view.k[0,7].item(),800.)

    def test_fresh_or_cached_state_mutation_after_install_is_rejected_and_logged(self):
        for scope in ['fresh','cached']:
            r,s,sim,c=robot_scene();records={};setter=r.write_joint_stiffness_to_sim
            def wrong(value,joint_ids):
                setter(value,joint_ids)
                if scope=='fresh':s.rigid_objects['bottle'].root_physx_view.root[0,0]+=1.
                else:s.rigid_objects['bottle'].data.root_pos_w[0,0]+=1.
            r.write_joint_stiffness_to_sim=wrong
            with self.assertRaises(ValueError):install(r,s,sim,c,dict(status='PASS'),EPOCH,recorder=lambda n,v:records.update({n:v}))
            self.assertEqual(set(records),{'CONTROLLER_BEFORE.json','CONTROLLER_AFTER.json'})

    def test_damping_force_arm_or_clock_change_rejected_with_full_after(self):
        for field in ['damping','limit','arm','clock','callback']:
            r,s,sim,c=robot_scene();records={};setter=r.write_joint_stiffness_to_sim
            def wrong(value,joint_ids):
                setter(value,joint_ids)
                if field=='damping':r.root_physx_view.d[0,7]+=1.
                elif field=='limit':r.root_physx_view.e[0,7]+=1.
                elif field=='arm':r.root_physx_view.k[0,0]+=1.
                elif field=='clock':sim.current_time+=.1
                else:c['count']+=1
            r.write_joint_stiffness_to_sim=wrong
            with self.assertRaises(ValueError):install(r,s,sim,c,dict(status='PASS'),EPOCH,recorder=lambda n,v:records.update({n:v}))
            self.assertEqual(set(records),{'CONTROLLER_BEFORE.json','CONTROLLER_AFTER.json'})

    def test_end_drift_retains_full_failed_arrays_and_preimages(self):
        r,s,sim,c=robot_scene();_,expected=install(r,s,sim,c,dict(status='PASS'),EPOCH);r.root_physx_view.d[0,7]+=1.;records={}
        with self.assertRaises(ValueError):verify_end(r,expected,s,sim,c,EPOCH,recorder=lambda n,v:records.update({n:v}))
        end=records['task/ACTIVE_DRIVE_END.json'];self.assertEqual(end['status'],'FAIL_PARAMETER_DRIFT_RETAINED')
        self.assertIn('fresh_physics_view_state_preimage',end);self.assertEqual(end['actual']['damping'][0][7],41.)

    def test_all_test_entry_points_gate_calibration_and_actor_install_unconditional(self):
        native=(ROOT/'native_probe.py').read_text();worker=(ROOT/'run_worker.py').read_text()
        for src in (native,worker):self.assertIn("if case['role']=='test':",src);self.assertIn('load_frozen_calibration',src)
        tree=ast.parse(native);run=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='run_task')
        self.assertFalse([n for n in ast.walk(run) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr.startswith('write_joint_')])
        idx=native.index('installation,gain_expected=install_declared_gain');task=native.index('result=run_task()',idx)
        self.assertNotIn("case[",native[idx:task]);self.assertIn("protocol['common_actor_installation']",native[idx:task])
        self.assertIn("task_origin!=installation['after']['native_time_s']",native)
        self.assertIn('native_epoch=epochs',native[idx:task])

    def test_missing_new_four_cell_fit_denies_even_nominal(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileNotFoundError):load_frozen_calibration(tmp,PROTOCOL)

    def test_FIFO_tail_native_tick_mapping_unchanged(self):
        fifo=FixedDelayFIFO(12);applied=[]
        for tick in range(28):
            sub,actual=fifo.step(tick,tick if tick<16 else None,[float(tick)] if tick<16 else None)
            if actual is not None:applied.append((tick,actual.source_index,actual.target))
        self.assertEqual(applied,[(i+12,i,(float(i),)) for i in range(16)])
        self.assertFalse(fifo.pending);self.assertEqual(fifo.submitted,fifo.applied)


if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    if not result.wasSuccessful():raise SystemExit(1)
    if torch.cuda.is_initialized():raise RuntimeError('CPU preflight initialized CUDA')
    receipt=dict(schema='paperb-qualified-timing-cpu-preflight-v1',status='PASS_GPU_FREE_QUALIFIED_TIMING_PREFLIGHT',
        focused_tests=result.testsRun,historical_exact_math_conditions_rechecked=7172,new_native_episodes=0,
        new_test_outcomes=0,calibration_fit_executed=False,cuda_initialized=False,
        scope='Fake active interface, full RAW serialization, recorded historical independent math oracle, static lineage; no native success acceptance',
        test_contract_sha256=hashlib.sha256((ROOT/'test_contract.json').read_bytes()).hexdigest())
    with (ROOT/'CPU_PREFLIGHT.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
