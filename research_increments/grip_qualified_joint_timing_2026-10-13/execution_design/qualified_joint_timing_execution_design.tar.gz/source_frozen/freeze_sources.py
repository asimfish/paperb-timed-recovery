"""Root review may freeze this separate20-case release; never launches or fits."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    gate=json.loads((ROOT/'CPU_PREFLIGHT.json').read_text())
    if gate['status']!='PASS_GPU_FREE_QUALIFIED_TIMING_PREFLIGHT' or gate['new_native_episodes'] or gate['cuda_initialized']:
        raise ValueError('GPU-free CPU gate required')
    if any((ROOT/'cases').iterdir()) or (ROOT/'CALIBRATION.json').exists() or (ROOT/'CALIBRATION_RELEASE.json').exists():
        raise ValueError('source review/seal must precede any new native data or fit')
    origin=json.loads((ROOT/'SOURCE_ORIGIN.json').read_text())
    fixed=origin['copied_fixed_source_hashes']
    for name,h in fixed.items():
        if sha(ROOT/name)!=h:
            raise ValueError('unchanged source inputs/helpers differ: '+name)
    if sha(ROOT/'exact_grid_solver.py')!=origin['exact_candidate_solver_sha256']:
        raise ValueError('independently audited7172 candidate changed')
    if sha(ROOT/'legacy_timing_protocol.py')!=origin['legacy_three_baseline_and_event_helper_sha256']:
        raise ValueError('legacy three baseline/event helper changed')
    protocol=json.loads((ROOT/'protocol.json').read_text())
    roles=[c['role'] for c in protocol['cases']]
    if roles.count('calibration')!=4 or roles.count('test')!=16 or len(roles)!=20:
        raise ValueError('prospective4cal+16test roster changed')
    if protocol['common_actor_installation']['candidate']!=1600. or not protocol['common_actor_installation']['unconditional_for_all_20_episodes']:
        raise ValueError('common unconditional K1600 required')
    owned=['native_probe.py','legacy_timing_protocol.py','exact_grid_solver.py','expansion_protocol.py','gain_installation.py',
        'calibration_gate.py','fit_calibration.py','run_worker.py','gpu_mapping.py','launch_worker.sh','protocol.json',
        'SOURCE_ORIGIN.json','RAW_SCHEMA.json','test_contract.json','test_preflight.py','CPU_PREFLIGHT.json',
        'CPU_PREFLIGHT_ATTEMPT_1.json','CPU_PREFLIGHT_ATTEMPT_2.json','demo_decisions.py','DEMO_DECISIONS.json',
        'RUN_BUDGET.json','README_cn.md','freeze_sources.py','REGRESSION_EVIDENCE.json','SOURCE_REVIEW.json']
    files={name:sha(ROOT/name) for name in list(fixed)+owned}
    receipt=dict(schema='paperb-grip-qualified-joint-timing-execution-release-v1',files=files,
        calibration_cases=4,test_cases=16,qualification_cases=0,total_cases=20,
        common_unconditional_hand_stiffness=1600.,full_controller_arrays_and_state_preimages_required=True,
        strong_method='joint_exact_grid',exact_candidate_source_sha256=origin['exact_candidate_solver_sha256'],
        preserves_all_old_sources_raw_failures_and_qualification=True,new_test_outcomes_used_for_design=0,
        original_mechanical_thresholds_unchanged=True,maximum_owned_workers_per_gpu=1,
        minimum_free_gpu_mib=24576,max_worker_seconds=700,total_max_allocated_gpu_seconds=14000,
        no_learning_or_true_latency_support_guarantee=True,all_test_methods_require_new_independent_four_cell_fit=True)
    with (ROOT/'EXECUTION_RELEASE.json').open('x') as f:
        json.dump(receipt,f,indent=2);f.write('\n')
    print(json.dumps(dict(status='NEW_SOURCE_FROZEN_NO_GPU_OR_FIT',files=len(files),release_sha256=sha(ROOT/'EXECUTION_RELEASE.json'))))


if __name__=='__main__':
    main()
