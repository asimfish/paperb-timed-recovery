"""Uniform actor installation with complete, independently recomputable RAW.

No pose/joint-state/material/mass/D/maxForce setter is used. Before and after
snapshots are recorded before assertions, retaining evidence on every failure.
"""
import hashlib
import json
import math


def safe_list(tensor):
    def clean(value):
        if isinstance(value, list):
            return [clean(x) for x in value]
        if isinstance(value, float) and math.isinf(value):
            return 'POSITIVE_INFINITY' if value > 0 else 'NEGATIVE_INFINITY'
        if isinstance(value, float) and math.isnan(value):
            raise ValueError('NaN active parameter')
        return value
    return clean(tensor.tolist())


def active_drives(robot):
    return dict(stiffness=robot.root_physx_view.get_dof_stiffnesses().clone(),
                damping=robot.root_physx_view.get_dof_dampings().clone(),
                effort_limits=robot.root_physx_view.get_dof_max_forces().clone())


def canonical_sha(preimage):
    return hashlib.sha256(json.dumps(preimage, sort_keys=True, allow_nan=False).encode()).hexdigest()


def cached_state_preimage(scene):
    bodies={k:dict(pos=a.data.root_pos_w.tolist(), quat=a.data.root_quat_w.tolist(),
                   lin_vel=a.data.root_lin_vel_w.tolist(), ang_vel=a.data.root_ang_vel_w.tolist())
            for k,a in scene.rigid_objects.items()}
    arms={k:dict(q=a.data.joint_pos.tolist(), qd=a.data.joint_vel.tolist(),
                 pos=a.data.root_pos_w.tolist(), quat=a.data.root_quat_w.tolist())
          for k,a in scene.articulations.items()}
    return dict(bodies=bodies, arms=arms)


def fresh_state_preimage(scene):
    # Installed getter names are pinned in INSTALLED_API_READ_ONLY.json.
    bodies={k:dict(transforms=a.root_physx_view.get_transforms().clone().tolist(),
                   velocities=a.root_physx_view.get_velocities().clone().tolist())
            for k,a in scene.rigid_objects.items()}
    arms={k:dict(root_transforms=a.root_physx_view.get_root_transforms().clone().tolist(),
                 root_velocities=a.root_physx_view.get_root_velocities().clone().tolist(),
                 dof_positions=a.root_physx_view.get_dof_positions().clone().tolist(),
                 dof_velocities=a.root_physx_view.get_dof_velocities().clone().tolist())
          for k,a in scene.articulations.items()}
    return dict(bodies=bodies, arms=arms)


def installation_snapshot(robot, scene, sim, callbacks, native_epoch, phase):
    values=active_drives(robot)
    cached=cached_state_preimage(scene); fresh=fresh_state_preimage(scene)
    snapshot=dict(schema='paperb-complete-controller-observation-v2', phase=phase,
        native_epoch=native_epoch, native_time_s=float(sim.current_time), physics_callbacks=callbacks['count'],
        active={k:safe_list(v) for k,v in values.items()},
        active_tensor_metadata={k:dict(shape=list(v.shape), dtype=str(v.dtype)) for k,v in values.items()},
        cached_scene_state_preimage=cached, cached_scene_state_sha256=canonical_sha(cached),
        fresh_physics_view_state_preimage=fresh, fresh_physics_view_state_sha256=canonical_sha(fresh),
        cached_state_scope='ISAACLAB_SCENE_DATA_CACHED_TENSORS',
        fresh_state_scope='FRESH_RIGID_AND_ARTICULATION_PHYSX_VIEW_GETTERS',
        hash_serialization='json.dumps(preimage,sort_keys=True,allow_nan=False).encode()',
        hand_actuator_cache_stiffness=safe_list(robot.actuators['hand'].stiffness),
        parameters_authoritative_from='ACTIVE_PHYSX_VIEWS', object_state_writes=0, robot_state_writes=0)
    return snapshot, values


def install(robot, scene, sim, callbacks, baseline_verdict, native_epoch,
            baseline=800., candidate=1600., recorder=None):
    import torch
    before, before_values=installation_snapshot(robot,scene,sim,callbacks,native_epoch,'BEFORE_INSTALLATION')
    if recorder is not None:
        recorder('CONTROLLER_BEFORE.json',before)
    if baseline_verdict['status']!='PASS':
        raise ValueError('original baseline transient must pass before installation')
    ids=[robot.joint_names.index(n) for n in ('fr3_finger_joint1','fr3_finger_joint2')]
    others=[i for i in range(robot.num_joints) if i not in ids]
    if not torch.equal(before_values['stiffness'][:,ids],torch.full_like(before_values['stiffness'][:,ids],baseline)):
        raise ValueError('active baseline hand gain is not 800')
    if not torch.equal(before_values['damping'][:,ids],torch.full_like(before_values['damping'][:,ids],40.)):
        raise ValueError('active baseline hand damping is not 40')
    robot.write_joint_stiffness_to_sim(candidate,joint_ids=ids)
    # Mirror the same one declared K in the implicit actuator cache (#128 in
    # the pinned SDK writer). Physical D and maxForce are never written.
    robot.actuators['hand'].stiffness.fill_(candidate)
    after, after_values=installation_snapshot(robot,scene,sim,callbacks,native_epoch,'AFTER_INSTALLATION')
    if recorder is not None:
        recorder('CONTROLLER_AFTER.json',after)
    if not torch.equal(after_values['stiffness'][:,ids],torch.full_like(after_values['stiffness'][:,ids],candidate)):
        raise ValueError('active candidate hand K is not 1600')
    if not torch.equal(before_values['stiffness'][:,others],after_values['stiffness'][:,others]):
        raise ValueError('arm stiffness changed')
    for key in ('damping','effort_limits'):
        if not torch.equal(before_values[key],after_values[key]):
            raise ValueError(key+' changed')
    unchanged_fields=('native_epoch','native_time_s','physics_callbacks',
        'cached_scene_state_preimage','fresh_physics_view_state_preimage',
        'cached_scene_state_sha256','fresh_physics_view_state_sha256')
    if any(before[key]!=after[key] for key in unchanged_fields):
        raise ValueError('installation changed native state/time/epoch')
    receipt=dict(schema='paperb-complete-active-controller-installation-v2', status='PASS_COMPLETE_RAW_GAIN_INSTALLATION',
        original_baseline_transient_verdict=baseline_verdict, before=before, after=after,
        finger_joint_names=[robot.joint_names[i] for i in ids], finger_joint_indices=ids,
        baseline_stiffness_N_per_m=baseline, candidate_stiffness_N_per_m=candidate,
        only_stiffness_changed=True, same_unconditional_gain_for_all_methods=True,
        object_state_writes=0,robot_state_writes=0,
        parameter_installation_location='AFTER_ORIGINAL_BASELINE_ACCEPTANCE_BEFORE_TASK',
        original_failed_cohort_active_readback_available=False)
    return receipt,after_values


def verify_end(robot, expected, scene, sim, callbacks, native_epoch, recorder=None):
    import torch
    snapshot,actual=installation_snapshot(robot,scene,sim,callbacks,native_epoch,'END_TASK')
    unchanged=all(torch.equal(actual[k],expected[k]) for k in expected)
    receipt=dict(snapshot,schema='paperb-complete-controller-end-readback-v2',
        status='PASS_END_DRIVES_MATCH_AFTER' if unchanged else 'FAIL_PARAMETER_DRIFT_RETAINED',
        actual={k:safe_list(v) for k,v in actual.items()},
        endpoint_drives_equal=unchanged,
        parameter_observation_scope='FULL_BEFORE_AFTER_END_READBACKS_PLUS_PINNED_SOURCE_NO_FURTHER_PARAMETER_SETTERS; NOT_PER_TICK_ACTIVE_TELEMETRY')
    if recorder is not None:
        recorder('task/ACTIVE_DRIVE_END.json',receipt)
    if not unchanged:
        raise ValueError('active controller parameter changed during task; complete end RAW retained')
    return receipt
