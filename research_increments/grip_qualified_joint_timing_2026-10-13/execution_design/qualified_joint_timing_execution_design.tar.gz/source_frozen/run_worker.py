"""One owned worker on one explicitly admitted GPU. No foreign process signals."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
from calibration_gate import load_frozen_calibration
import signal
import subprocess
import time

ROOT=Path(__file__).parent
CAPSULE=Path('/tmp/chemrm-papera-v15/pilot/paperA/driver_library_isolation_v54_20261011/capsule_r2')

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write(p,value):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())

def prior_native_output_exists(root,case_id):
    root=Path(root)
    return (root/'cases'/case_id).exists() or (root/'logs'/(case_id+'.json')).exists()

def resource_refusal_path(root,case_id,attempt_id):
    return Path(root)/'resource_gate_attempts'/case_id/(attempt_id+'.json')

def verify_sources():
    release=json.loads((ROOT/'EXECUTION_RELEASE.json').read_text())
    for rel,h in release['files'].items():
        if Path(rel).is_absolute() or '..' in Path(rel).parts or sha(ROOT/rel)!=h:
            raise ValueError('frozen execution source changed: '+rel)
    return release

def live_group(pgid):
    values=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            if os.getpgid(int(p.name))==pgid and (p/'stat').read_text().split(') ',1)[1].split()[0]!='Z':values.append(int(p.name))
        except (FileNotFoundError,ProcessLookupError,PermissionError):pass
    return values

def main():
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('--case',required=True);p.add_argument('--gpu-uuid',required=True)
    p.add_argument('--verify-only',action='store_true');a=p.parse_args()
    release=verify_sources();protocol=json.loads((ROOT/'protocol.json').read_text())
    cases=[c for c in protocol['cases'] if c['id']==a.case]
    if len(cases)!=1:raise ValueError('unknown frozen case')
    case=cases[0]
    if a.verify_only:
        print(json.dumps(dict(status='SOURCE_VERIFIED_NO_GPU_ALLOCATION',case=a.case,files=len(release['files']))));return
    if prior_native_output_exists(ROOT,a.case):
        raise ValueError('prior output preserved; no overwrite/restart allowed')
    if case['role']=='test':
        # Scheduling ablations share the same four-cell collection/fit gate.
        # Prior methods intentionally ignore calibration values in their plan.
        load_frozen_calibration(ROOT,protocol)
    lock=open('/tmp/paperb-native-'+a.gpu_uuid+'.lock','a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    attempt_id=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'-'+str(os.getpid())
    env=dict(os.environ);env['LD_LIBRARY_PATH']=str(CAPSULE)
    # Read-only subprocess avoids importing incompatible NVML into this worker.
    try:
        admission=json.loads(subprocess.check_output(['python3',str(ROOT/'gpu_mapping.py'),'--uuid',a.gpu_uuid],env=env,text=True))
    except subprocess.CalledProcessError as e:
        write(resource_refusal_path(ROOT,a.case,attempt_id),dict(status='RESOURCE_GATE_REFUSED',exit_code=e.returncode,gpu_uuid=a.gpu_uuid,
              case_id=a.case,attempt_id=attempt_id,foreign_processes_signaled=False,gpu_work_started=False,
              formal_episode_started=False,retry_after_resource_change_allowed=True,
              allocated_gpu_hours_upper_bound=0,model_calls=0,training_gpu_hours=0));raise
    write(ROOT/'admission'/a.case/(attempt_id+'.json'),admission)
    child=None;start=time.monotonic();timed_out=False;code=None;remaining=[]
    try:
        log_path=ROOT/'launch_attempts'/a.case/(attempt_id+'.log')
        log_path.parent.mkdir(parents=True,exist_ok=True)
        with log_path.open('x') as log:
            child=subprocess.Popen(['bash',str(ROOT/'launch_worker.sh'),a.case,a.gpu_uuid],stdout=log,stderr=subprocess.STDOUT,
                                   env=env,start_new_session=True)
            write(ROOT/'running'/a.case/(attempt_id+'.json'),dict(case_id=a.case,attempt_id=attempt_id,pid=child.pid,pgid=child.pid,gpu_uuid=a.gpu_uuid,
                started_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),max_seconds=protocol['max_worker_seconds']))
            try:code=child.wait(timeout=protocol['max_worker_seconds'])
            except subprocess.TimeoutExpired:
                timed_out=True;os.killpg(child.pid,signal.SIGTERM)
                try:code=child.wait(timeout=15)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=15)
        remaining=live_group(child.pid)
        if remaining:
            # This process group was created by this worker only.
            os.killpg(child.pid,signal.SIGKILL);remaining=live_group(child.pid)
        verify_sources()
    finally:
        if child is not None:
            left=live_group(child.pid)
            if left:os.killpg(child.pid,signal.SIGKILL)
        wall=time.monotonic()-start
        native_output_exists=(ROOT/'cases'/a.case).exists()
        resource_refused=code==42 and not native_output_exists
        terminal_path=resource_refusal_path(ROOT,a.case,attempt_id) if resource_refused else ROOT/'logs'/(a.case+'.json')
        write(terminal_path,dict(status='RESOURCE_GATE_REFUSED' if resource_refused else 'COMPLETE' if code==0 and not remaining else 'FAILED_RETAINED',
            case_id=a.case,gpu_uuid=a.gpu_uuid,exit_code=code,timed_out=timed_out,wall_s=wall,
            attempt_id=attempt_id,launch_log=str(log_path.relative_to(ROOT)),native_output_exists=native_output_exists,
            formal_episode_started=native_output_exists,retry_after_resource_change_allowed=resource_refused,
            allocated_gpu_hours_upper_bound=0 if resource_refused else wall/3600,owned_process_group_empty=not remaining,
            cost_scope='OWNED_CHILD_ATTEMPT_WALL_UPPER_BOUND_INCLUDING_STARTUP_AND_FAILED_LAUNCHES; RESOURCE_REFUSAL_WITHOUT_NATIVE_ONLY_ZERO',
            model_calls=0,training_gpu_hours=0,foreign_processes_signaled=False,gpu_global_configuration_changes=False))
    print(json.dumps(dict(case_id=a.case,exit_code=code,timed_out=timed_out,wall_s=wall)))
    if code or remaining:raise SystemExit(code or 1)

if __name__=='__main__':main()
