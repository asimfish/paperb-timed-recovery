"""Verify public source bundle and optionally replay7172 exact CPU conditions.

No native app import, extraction, GPU allocation, fit, or source mutation.
Only exact known solver source is executed; archive paths are never executed.
"""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile
import types

RELEASE='0c3cff79148f20f6b5f212eb484ac205122b02e63fac98d657ad8e14db3041dd'
SOLVER='0dd7a0b422f183008d90d65ef97f9e93f244862989f8ef3f6ae575b9c7c4d3f0'
MATH_ARCHIVE='b093ac9582258e912729292091e28816d6d2f9addaa710ab8f851c62eed45d31'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_regular_members(path, maximum_uncompressed=64*1024*1024):
    result={};size=0
    with tarfile.open(path,'r:gz') as archive:
        for entry in archive.getmembers():
            if not entry.isfile() or entry.name.startswith('/') or '..' in Path(entry.name).parts or entry.name in result:
                raise ValueError('unsafe or duplicate archive member')
            size+=entry.size
            if size>maximum_uncompressed:
                raise ValueError('archive exceeds declared CPU evidence size bound')
            result[entry.name]=archive.extractfile(entry).read()
    return result


def main():
    parser=argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--design-archive',required=True)
    parser.add_argument('--receipt',required=True)
    parser.add_argument('--math-archive')
    args=parser.parse_args()
    path=Path(args.design_archive);receipt=json.loads(Path(args.receipt).read_text())
    if digest(path.read_bytes())!=receipt['archive_sha256']:
        raise ValueError('design archive SHA does not match published receipt')
    bundle=read_regular_members(path)
    if digest(bundle['EXECUTION_RELEASE.json'])!=RELEASE:
        raise ValueError('archive source release differs from reviewed131-file release')
    release=json.loads(bundle['EXECUTION_RELEASE.json'])
    for name,h in release['files'].items():
        if digest(bundle['source_frozen/'+name])!=h:
            raise ValueError('frozen source member differs: '+name)
    manifest=json.loads(bundle['EXPORT_MANIFEST.json'])
    if set(bundle)!=set(manifest['files'])|{'EXPORT_MANIFEST.json'}:
        raise ValueError('archive roster differs from export manifest')
    for name,item in manifest['files'].items():
        if digest(bundle[name])!=item['sha256'] or len(bundle[name])!=item['bytes']:
            raise ValueError('export member differs: '+name)
    result=dict(status='PASS_REOPEN_COMPLETE_FROZEN_SOURCE_BUNDLE',source_files=len(release['files']),
        archive_members=len(bundle),source_release_sha256=RELEASE,new_native_episodes=0,new_test_outcomes=0,
        physics_app_imported=False,calibration_fit=False,CPU_math_replay_conditions=0)
    if args.math_archive:
        mathpath=Path(args.math_archive)
        if digest(mathpath.read_bytes())!=MATH_ARCHIVE:
            raise ValueError('7172 math archive must match original independently audited public archive')
        mathbundle=read_regular_members(mathpath)
        source=bundle['source_frozen/exact_grid_solver.py']
        if digest(source)!=SOLVER:
            raise ValueError('solver source does not match pinned7172 candidate')
        # This reviewed exact source imports only standard-library Fraction.
        module=types.ModuleType('verified_exact_grid_CPU_only')
        exec(compile(source,'verified_exact_grid_solver.py','exec'),module.__dict__)
        roster=[json.loads(x) for x in mathbundle['cpu_methods/ROSTER.jsonl'].splitlines()]
        oracle=[json.loads(x) for x in mathbundle['cpu_methods/oracle_pairs.jsonl'].splitlines()]
        if len(roster)!=7172 or len(oracle)!=7172:
            raise ValueError('full7172 denominator required')
        feasible=refused=0
        for case,truth in zip(roster,oracle):
            actual=module.solve(case)
            if case['id']!=truth['case_id'] or actual['selected_ticks']!=truth['selected_ticks'] or actual['objective_ratio']!=truth['objective_ratio']:
                raise ValueError('candidate/oracle discrepancy: '+case['id'])
            feasible+=actual['status']=='FEASIBLE';refused+=actual['status']=='REFUSED'
        result.update(CPU_math_replay_conditions=7172,CPU_feasible=feasible,CPU_refused=refused,
            status='PASS_FROZEN_SOURCE_AND_HISTORICAL_7172_CPU_REPLAY',math_archive_sha256=MATH_ARCHIVE)
    print(json.dumps(result,sort_keys=True))


if __name__=='__main__':
    main()
