# K1600 公平定时小矩阵：新校准、新测试、完整原始读回

本版本独立于原4条校准和单条K1600资格轨迹。旧4条中重载2条机械失败保留，资格只有一条，不能替代任何校准或进入主测试分母。新实验仍为4calibration +16test，全部采用同一个无条件K1600 actor参数规则；原机械门槛、完整瓶体技能、质量/惯量安装规则与真实position-target FIFO均不变。

四个新校准条件是mass0.8/1.2 ×FIFO0/12tick，必须每格完整执行、原机械验收和接触/独立稳定release均通过，且原始控制参数与状态记录可独立复算。任一格缺失、失败或没有事件就拒绝拟合；不能删失败、以资格替代、用平均或中位数补缺。拟合逐格保存两事件的机械区间，采用所有格lower最小/upper最大包络，承认格间变异和未知支撑范围，不称统计置信保证或物理延迟全集。

测试固定为4方法×4条件，质量0.9/1.1是校准0.8/1.2之间的插值留出；D5/5.5秒、H18/18.5秒、FIFO0/12tick、contact/release/gap全部25ms。条件中mass与D、FIFO与H仍绑定，所以只比较同条件方法，不分别归因质量或合同，不称多随机seed泛化。新test outcome当前0，所有拒绝、失败和missing均保留16分母。

三条原名义、公开delay补偿和calibrated midpoint baseline的规划数学与旧源码完全相同。第四方法明确更名`joint_exact_grid`：逐字pin已7172数学条件独立审计的exact candidate，直接在nominal1/240格点求解两绝对效果窗口、gap及原技能最短17秒；绕开已知旧midpoint-precheck误拒。原旧代码与61条误拒记录保留，不称原算法本就无误。public合同以精确十进制Fraction表达，冻结机械区间以JSON binary64的精确Fraction表达，全部输入、约束、选中dispatch tick、objective、可行数量和refusal写certificate。这个条件数学规划并不替代实际native时钟或事后独立事件计分。

所有20条在原warmup1200、matched30-tick baseline PASS之后、task之前安装同一个双指K800→1600，D40、7armK、全部maxForce、物体参数及原指令目标不变。`CONTROLLER_BEFORE.json`/`CONTROLLER_AFTER.json`在assert之前保存完整K/D/limit数组、fresh/cached完整状态preimages、可重算hash与epoch/time/callback；receipt嵌入两snapshot。end同样保留完整参数、状态preimages、时钟并验证参数与after相同。taskorigin必须等于installation afterclock，禁止task物体/joint状态写入。旧资格没有这些全部before记录，本版本补齐，不能追写旧RAW。

接触和release维持原phase-independent raw定义，onset与confirmation分开。主joint为contact绝对窗口、release绝对窗口、durationgap、原机械任务和非拒绝；strict sampled bilateral hold另报，不能把两endpoint的gap改称持续hold。

`RAW_SCHEMA.json`是独立auditor接口，`test_contract.json`限定CPU证据能力。CPU fake active-view反例验证before/after/end原数组、状态/参数变化拒绝及失败保留，solver以历史独立exact oracle逐条件复验7172条；这些均非新增机器人episode或学习结果。`DEMO_DECISIONS.json`仅使用显式synthetic公开校准盒演示调度decision/teacher targets，不能作为当前native数据、fit或test outcome。

任何test方法（连原名义和公开delay）都必须先通过完整新4cal独立PASS并冻结CALIBRATION；只有两个calibrated方法消费其区间，prior方法刻意不消费区间。GPU执行由root负责，准备阶段不GPU/fit。资源准入保持24GiB空闲、UUID/minor/DRM核对、每GPU一owned worker与独立缓存；不抢占、不修改全局驱动，不信号foreign进程；未启动native的资源拒绝可在资源改变后重试。

最大worker预算700秒/条，20条累计硬上限14000秒即3.889 allocatedGPU小时（4cal0.778、16test3.111）；最近实测约5–8分钟/条，单合格GPU预计100–160分钟，两合格GPU约50–80分钟，实际受资源、初始化和RGB开销影响。代表FIFO12的四方法保留新6fps视频，所有条保留完整raw状态/contact/queue。

准备完成后先由root审查source/protocol、独立auditor冻结，再由root执行新cal。完整新4cal独立准入后才能fit/freeze；测试完成后才报告方法成绩。当前没有新native轨迹、没有权重更新或学习能力结论。
