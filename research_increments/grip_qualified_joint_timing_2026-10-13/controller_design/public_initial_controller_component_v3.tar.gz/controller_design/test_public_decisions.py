"""Pure CPU contract decisions, no simulator import/integration/test outcomes."""
import ast
import copy
from dataclasses import replace
import hashlib,json,math
from pathlib import Path
import unittest
from public_types import Packet,Ack,ObservedEvent,ReservedChannel,Reservation
from public_adapters import PublicContext,PublicDecisionAdapter,METHODS,conditional_original_event,powered_after_ACK,Budget

ROOT=Path(__file__).parent
MODEL={'inertia':.002,'damping':.006};DT=10_000_000


def packet_at(tick,lag=100_000_000):
    q=v=0.;decay=MODEL['inertia']/(MODEL['inertia']+.01*MODEL['damping'])
    for _ in range(tick):v=10+(v-10)*decay;q+=v*.01
    return Packet(tick*DT,tick*DT+lag,(q,q,q),(v,v,v),(.06,.06,.06))


def context(order=('C','A'),busy=450_000_000,D=2_800_000_000,slot=650_000_000,fine=True):
    old,new=packet_at(40),packet_at(45);coarse=ObservedEvent(400_000_000,450_000_000,550_000_000)
    reference,evidence=conditional_original_event(old,new,coarse,MODEL,DT)
    p={'D_C_ns':D,'eps_C_ns':150_000_000,'A_window_ns':[1_800_000_000,D],
        'graph_edges':[list(order)],'minimum_edge_gap_ns':40_000_000,'public_nominal_model':MODEL,
        'maximum_candidates_per_decision':1000,'maximum_candidates_epoch':10000,
        'max_requests_A_C':4,'max_requests_per_rotor':2,'calibrated_prediction_residual_ns':[0,0]}
    r={'capacity':1,'services_ns':{'A_stop':50_000_000,'C_stop':450_000_000},
        'B_reservation':{'tag':'B_reserved_drive_change','request_ns':0,'service_start_ns':slot,'service_end_ns':slot+busy}}
    return PublicContext(560_000_000,new,coarse,reference if fine else coarse,(),ReservedChannel(r).public_snapshot(),p,r),evidence


class Tests(unittest.TestCase):
    def test_private_native_imports_getters_absent(self):
        tree=ast.parse((ROOT/'public_adapters.py').read_text())
        names=[]
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):names.extend(x.name for x in node.names)
            elif isinstance(node,ast.ImportFrom):names.append(node.module)
        self.assertEqual(set(names),{'dataclasses','math','time','public_types'})
        self.assertFalse({'plant','mujoco','referee','NativePlant'}.intersection(names))

    def test_conditional_model_same_event_refinement_not_private_RAW(self):
        ctx,e=context();self.assertEqual((ctx.reference.lower_ns,ctx.reference.upper_ns),(440_000_000,450_000_000))
        self.assertEqual((ctx.original_B_coarse.lower_ns,ctx.original_B_coarse.upper_ns),(400_000_000,450_000_000))
        self.assertFalse(e['model_fitted']);self.assertLessEqual(max(e['residual']),1e-9)
        self.assertTrue(e['not_information_theoretic_lower_bound'])

    def test_model_mismatch_keeps_original_coarse(self):
        old,new=packet_at(40),packet_at(45);new=replace(new,positions=(new.positions[0],new.positions[1]+1e-4,new.positions[2]))
        coarse=ObservedEvent(400_000_000,450_000_000,550_000_000)
        ref,e=conditional_original_event(old,new,coarse,MODEL,DT);self.assertEqual(ref,coarse)

    def test_future_packet_rejected(self):
        ctx,_=context()
        with self.assertRaises(ValueError):replace(ctx,now_ns=540_000_000)

    def test_private_field_and_RAW_kind_rejected(self):
        ctx,_=context();p=copy.deepcopy(ctx.public);p['current_fault']='first_A_drop'
        with self.assertRaises(ValueError):replace(ctx,public=p)
        raw=replace(ctx.reference,kind='B_PRIVATE_NATIVE_RAW')
        with self.assertRaises(ValueError):replace(ctx,reference=raw)

    def test_no_nested_resource_getter_can_enter_actor(self):
        ctx,_=context()
        class ForbiddenGetter(dict):
            def __getitem__(self,k):raise AssertionError('private getter must never execute')
        r=copy.deepcopy(ctx.resource);r['services_ns']=ForbiddenGetter(r['services_ns'])
        with self.assertRaises(TypeError):replace(ctx,resource=r)

    def test_original_unreachable_slot_not_rescued_by_deadline_relabel(self):
        ctx,_=context(order=('A','C'),busy=450_000_000,D=2_800_000_000,slot=1_500_000_000)
        r=PublicDecisionAdapter(METHODS[0]).decide(ctx)
        self.assertIsNone(r['proposed_program'])
        stages=r['budget']['component_stage_counts']
        self.assertGreater(stages['resource_feasible_C_proposals'],0)
        self.assertEqual(stages['C_window_feasible_proposals'],0)
        self.assertFalse(r['physical_or_information_infeasibility_claim'])

    def test_later_reanchor_rejected(self):
        ctx,_=context();later=ObservedEvent(1_000_000_000,1_010_000_000,1_100_000_000)
        with self.assertRaises(ValueError):replace(ctx,reference=later)

    def test_ACK_does_not_say_effect_success_and_same_tick_capture_pre_ACK(self):
        ctx,_=context();ack=Ack(1,'A','A_stop',650_000_000);p=packet_at(65)
        c=replace(ctx,now_ns=800_000_000,latest=p,acks=(ack,))
        self.assertFalse(powered_after_ACK(c,'A'))
        c=replace(c,latest=packet_at(66));self.assertTrue(powered_after_ACK(c,'A'))
        p=replace(c.latest,torques=(0.,.06,.06));self.assertFalse(powered_after_ACK(replace(c,latest=p),'A'))

    def test_fixed_information_fault_indistinguishability(self):
        ctx,_=context()
        # No current fault exists in context. All methods receive exactly the
        # same public history under none/drop until causal feedback diverges.
        a=PublicDecisionAdapter(METHODS[0]).decide(ctx);b=PublicDecisionAdapter(METHODS[0]).decide(ctx)
        self.assertEqual(a['proposed_program'],b['proposed_program'])
        self.assertFalse(a['ACK_is_effect_success'])

    def test_common_two_tick_cost_all_actions_and_no_global_B_control(self):
        for method in METHODS:
            ctx,_=context();r=PublicDecisionAdapter(method).decide(ctx)
            self.assertEqual(r['charged_decision_ns'],2*DT)
            for action in r['proposed_program']['actions']:
                self.assertGreaterEqual(action['submit_ns'],ctx.now_ns+2*DT)
                self.assertIn(action['target'],('A','C'))
            self.assertEqual(sum(a['target']=='A' for a in r['proposed_program']['actions']),2)
            self.assertEqual(len(r['proposed_program']['actions']),3)

    def test_budget_before_evaluation_and_epoch_accounting(self):
        b=Budget(2,3);b.begin();self.assertTrue(b.consume());self.assertTrue(b.consume());self.assertFalse(b.consume())
        b.begin();self.assertTrue(b.consume());self.assertFalse(b.consume());self.assertEqual((b.current,b.epoch),(1,3))
        ctx,_=context();r=PublicDecisionAdapter(METHODS[0],per_decision=1).decide(ctx)
        self.assertEqual(r['budget']['candidate_evaluations'],1);self.assertTrue(r['budget']['budget_exhausted'])
        self.assertFalse(r['physical_or_information_infeasibility_claim'])

    def test_action_budget_refusal_not_more_than_allowed(self):
        ctx,_=context();p=copy.deepcopy(ctx.public);p['max_requests_A_C']=2
        r=PublicDecisionAdapter(METHODS[0]).decide(replace(ctx,public=p))
        self.assertIsNone(r['proposed_program']);self.assertTrue(r['budget']['action_budget_refused'])

    def test_existing_feedback_not_pretended_full_native_HSM_MPC(self):
        ctx,_=context();p=packet_at(66);ack=Ack(1,'A','A_stop',650_000_000)
        r=PublicDecisionAdapter(METHODS[1]).decide(replace(ctx,now_ns=800_000_000,latest=p,acks=(ack,)))
        self.assertEqual(r['status'],'INITIAL_DECISION_ADAPTER_ONLY_FEEDBACK_LIFECYCLE_SPEC_PENDING')
        self.assertIsNone(r['proposed_program']);self.assertFalse(r['full_stateful_HSM_EDF_MPC_native_arm_implemented'])

    def test_accepted_pending_A_C_requests_prevent_duplicate_initial_program(self):
        ctx,_=context()
        for method in METHODS:
            for target in ('A','C'):
                pending=(Reservation(1,target,target+'_stop',560_000_000,4_000_000_000,4_050_000_000),
                         Reservation(2,target,target+'_stop',560_000_000,4_050_000_000,4_100_000_000))
                r=PublicDecisionAdapter(method).decide(replace(ctx,reservations=ctx.reservations+pending))
                self.assertEqual(r['status'],'INITIAL_DECISION_ADAPTER_ONLY_FEEDBACK_LIFECYCLE_SPEC_PENDING')
                self.assertIsNone(r['proposed_program'])
                self.assertEqual(r['accepted_actor_requests'],2)
                self.assertEqual(r['pending_accepted_actor_requests'],2)
                self.assertEqual(r['lifecycle_guard'],'ACK_OR_ANY_ACCEPTED_NONEXTERNAL_A_C_RESERVATION')

    def test_completed_actor_reservation_without_ACK_also_prevents_reissue(self):
        ctx,_=context()
        r=Reservation(1,'A','A_stop',0,50_000_000,100_000_000)
        for method in METHODS:
            result=PublicDecisionAdapter(method).decide(replace(ctx,reservations=ctx.reservations+(r,)))
            self.assertIsNone(result['proposed_program'])
            self.assertEqual(result['accepted_actor_requests'],1)
            self.assertEqual(result['pending_accepted_actor_requests'],0)

    def test_external_B_reservation_remains_legal_initial_resource_input(self):
        ctx,_=context()
        self.assertEqual(len(ctx.reservations),1)
        self.assertTrue(ctx.reservations[0].external)
        for method in METHODS:
            result=PublicDecisionAdapter(method).decide(ctx)
            self.assertEqual(result['status'],'FEASIBLE_PUBLIC_CONDITIONAL_DECISION')
            self.assertEqual(len(result['proposed_program']['actions']),3)

    def test_four_methods_eight_synthetic_public_conditions(self):
        rows=[]
        for order in [('A','C'),('C','A')]:
            for busy in [50_000_000,450_000_000]:
                for D in [2_800_000_000,3_100_000_000]:
                    ctx,_=context(order,busy,D)
                    for method in METHODS:
                        r=PublicDecisionAdapter(method).decide(ctx)
                        self.assertIsNotNone(r['proposed_program'],(order,busy,D,method,r['budget']))
                        self.assertLessEqual(r['budget']['candidate_evaluations'],1000)
                        self.assertTrue(r['proposed_program']['blind_A_redundancy_available_to_all'])
                        rows.append(dict(graph=list(order),B_service_ns=busy,D_ns=D,method=method,
                            status=r['status'],budget=r['budget'],program=r['proposed_program'],
                            charged_decision_ns=r['charged_decision_ns'],measured_host_compute_ns=r['measured_host_compute_ns'],
                            conditional_public_model_only=True,new_native_episodes=0))
        self.assertEqual(len(rows),32)
        with (ROOT/'CPU_DECISIONS.json').open('x') as f:json.dump(dict(
            status='SYNTHETIC_PUBLIC_INITIAL_DECISIONS_NOT_FORMAL32_OR_NATIVE_WITNESSES',decisions=rows,
            shared_estimator_available_all_arms=True,synthetic_cases=8,method_decisions=32,
            initial_public_plans_feasible=32,new_native_episodes=0,formal_test_outcomes=0,fit_executed=False,
            all_strong_baselines_can_solve_this_initial_plan_family=True,
            not_evidence_of_agentic_or_query_necessity=True),f,indent=2);f.write('\n')


if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    if not result.wasSuccessful():raise SystemExit(1)
    with (ROOT/'CPU_PREFLIGHT.json').open('x') as f:json.dump(dict(
        status='PASS_PUBLIC_DECISION_CONTRACTS_NOT_STATEFUL_NATIVE_CONTROLLERS',focused_tests=result.testsRun,
        synthetic_public_initial_decisions=32,native_integrations=0,formal32_runs=0,fit=0,GPU=0,
        full_HSM_EDF_MPC_feedback_integration_pending=True),f,indent=2);f.write('\n')
