"""Read-only four-cell calibration report and frozen prospective test plans.

No test case directory is read, no fitter/worker/simulator is imported, no
native episode is produced. Curves are recorded states, not new scoring.
"""
import argparse
import csv
import hashlib
import json
import shutil
import sys
from pathlib import Path

SOURCE_RELEASE='0c3cff79148f20f6b5f212eb484ac205122b02e63fac98d657ad8e14db3041dd'


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def read(p):return json.loads(Path(p).read_text())


def main():
    parser=argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--root',required=True)
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    root=Path(args.root).resolve();out=Path(args.out).resolve()
    if out.exists() or out.is_relative_to(root):raise ValueError('new external output only')
    for name in ('paperb_scene_methods_expansion_20261013_v1','paperb_grip_stiffness_qualification_20261013_v1','paperb_joint_scheduler_validation_20261013_v1'):
        if out.is_relative_to(root.parent/name):raise ValueError('protected historical source/output')
    release=read(root/'EXECUTION_RELEASE.json')
    if sha(root/'EXECUTION_RELEASE.json')!=SOURCE_RELEASE:raise ValueError('source release mismatch')
    for rel,h in release['files'].items():
        if sha(root/rel)!=h:raise ValueError('frozen source changed: '+rel)
    protocol=read(root/'protocol.json');cal=read(root/'CALIBRATION.json');seal=read(root/'CALIBRATION_RELEASE.json')
    audit_path=Path(cal['independent_audit_path']);audit=read(audit_path)
    if seal['calibration_sha256']!=sha(root/'CALIBRATION.json') or seal['independent_audit_sha256']!=sha(audit_path):
        raise ValueError('calibration/audit binding mismatch')
    if seal['execution_release_sha256']!=SOURCE_RELEASE or seal['uses_test_outputs']:
        raise ValueError('unrecognized or test-dependent calibration')
    cases=[c for c in protocol['cases'] if c['role']=='calibration']
    test_roster=[c for c in protocol['cases'] if c['role']=='test']
    expected=[c['id'] for c in cases]
    if len(cases)!=4 or len(test_roster)!=16 or set(cal['fitted_episode_ids'])!=set(expected):raise ValueError('roster mismatch')
    if audit['status']!='PASS_COMPONENT' or sorted(audit['complete_case_ids'])!=sorted(expected):raise ValueError('all four independent calibration cells required')
    if not all(audit[k] for k in ('complete_active_controller_raw_pass','fresh_and_cached_preimages_pass')):
        raise ValueError('complete controller evidence required')
    observations={(x['case_id'],x['kind']):x for x in audit['observations']}
    if len(observations)!=8:raise ValueError('eight independently retained observation slots')
    # Import only frozen pure math and pose transform helpers, never execution.
    sys.path.insert(0,str(root))
    from expansion_protocol import dispatch_schedule,upright_tilt_deg
    bindings={str(p):sha(p) for p in [root/'protocol.json',root/'EXECUTION_RELEASE.json',root/'CALIBRATION.json',root/'CALIBRATION_RELEASE.json',audit_path]}
    cell_rows=[];curve_rows=[];cell_series=[]
    for case in cases:
        case_id=case['id'];folder=root/'cases'/case_id
        terminal=read(root/'logs'/f'{case_id}.json')
        if terminal['status']!='COMPLETE' or not terminal['owned_process_group_empty']:raise ValueError('nonterminal calibration')
        state_path=folder/'task/states.jsonl';cue_path=folder/'task/public_cue.json';cue=read(cue_path)
        for p in [state_path,cue_path,root/'logs'/f'{case_id}.json',folder/'case.json',folder/'RESULT.json']:
            bindings[str(p)]=sha(p)
        if audit['raw_artifact_sha256']['cases/'+case_id+'/task/states.jsonl']!=sha(state_path):raise ValueError('states differ from independent audit')
        rows=[json.loads(s) for s in state_path.open()]
        if any(r['command_index']!=i or r['native_epoch']!=cue['clock_id'] for i,r in enumerate(rows)):
            raise ValueError('raw tick coverage/epoch mismatch')
        first_t=cue['bounds_s'][0];series=[]
        for r in rows:
            row={'case_id':case_id,'command_index':r['command_index'],'applied_source_command_index':r['applied_source_command_index'],
                'native_before_s':r['native_before_s'],'native_after_s':r['native_after_s'],'time_since_cue_s':r['native_after_s']-first_t,
                'jaw_width_mm':r['jaw_width_m']*1000,'bottle_tilt_deg':upright_tilt_deg(r['object_pose'])}
            series.append(row);curve_rows.append(row)
        cell_series.append((case,series,first_t))
        for kind in ('contact','release'):
            obs=observations[case_id,kind];lo,hi=obs['mechanical_interval_s']
            cell_rows.append({'case_id':case_id,'mass_factor':case['mass_factor'],'public_FIFO_ticks':case['public_transport_delay_ticks'],
                'event':kind,'mechanical_response_lower_s':lo,'mechanical_response_upper_s':hi,
                'physical_onset_lower_since_cue_s':obs['effect_onset']['bounds_s'][0]-first_t,
                'physical_onset_upper_since_cue_s':obs['effect_onset']['bounds_s'][1]-first_t,
                'confirmation_since_cue_s':obs['confirmation_time_s']-first_t,'recorded_task_rows':len(rows),
                'independent_admission':'PASS_COMPONENT'})
    schedules=[]
    for case in test_roster:
        schedule=dispatch_schedule(case,protocol,cal)
        schedules.append((case,schedule))
    # Nothing above reads a test directory or label. Output is now write-once.
    out.mkdir(parents=True);(out/'planned_schedules').mkdir()
    for p in [root/'protocol.json',root/'EXECUTION_RELEASE.json',root/'CALIBRATION.json',root/'CALIBRATION_RELEASE.json',audit_path]:shutil.copy2(p,out/p.name)
    shutil.copy2(__file__,out/'export_report.py')
    for name,rows in [('calibration_cells.csv',cell_rows),('recorded_state_curves.csv',curve_rows)]:
        with (out/name).open('x',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    plan_rows=[]
    for case,schedule in schedules:
        # Exactly the executor's canonical schedule hash encoding.
        schedule_hash=hashlib.sha256(json.dumps(schedule,sort_keys=True).encode()).hexdigest()
        p=out/'planned_schedules'/f"{case['id']}.json"
        p.write_text(json.dumps({'case':case,'schedule':schedule,'executor_schedule_sha256':schedule_hash},indent=2,allow_nan=False)+'\n')
        certificate=schedule.get('joint_exact_grid_certificate') or {}
        plan_rows.append({'case_id':case['id'],'method':case['method'],'mass_factor':case['mass_factor'],
            'public_FIFO_ticks':case['public_transport_delay_ticks'],'contact_contract_s':case['requested_contact_gap_s'],
            'contact_to_stable_release_gap_contract_s':case['requested_contact_to_release_s'],
            'tolerance_s':case['contact_tolerance_s'],'command_contact_since_cue_s':schedule['planned_command_contact_gap_s'],
            'command_release_since_cue_s':schedule['planned_command_release_gap_s'],
            'hold_before_close_ticks':schedule['hold_before_close_ticks'],'hold_before_release_ticks':schedule['hold_before_release_ticks'],
            'source_submission_count':len(schedule['source_indices']),'schedule_refused':schedule['schedule_refused'],
            'exact_grid_feasible_candidates':certificate.get('grid_feasible_candidates','N/A'),
            'executor_schedule_sha256':schedule_hash,'observed_test_outcome':'NOT_READ'})
    with (out/'prospective_16_plans.csv').open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(plan_rows[0]));w.writeheader();w.writerows(plan_rows)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,2,figsize=(10,6.3),sharex=True)
    colors={'contact':'#247aa5','release':'#8466a8'}
    for axis,(case,series,cue) in zip(axes.flat,cell_series):
        t=[r['time_since_cue_s'] for r in series];jaw=[r['jaw_width_mm'] for r in series]
        axis.plot(t,jaw,color='#263f52',linewidth=.8,label='jaw width')
        twin=axis.twinx();twin.plot(t,[r['bottle_tilt_deg'] for r in series],color='#c37537',linewidth=.6,label='bottle tilt')
        for kind in ('contact','release'):
            obs=observations[case['id'],kind];bounds=[x-cue for x in obs['effect_onset']['bounds_s']]
            axis.axvspan(*bounds,color=colors[kind],alpha=.6)
            axis.axvline(obs['confirmation_time_s']-cue,color=colors[kind],linestyle=':',linewidth=.8)
        axis.set_title(f"mass {case['mass_factor']}, FIFO {case['public_transport_delay_ticks']} ticks",fontsize=10)
        axis.set_ylabel('Jaw width (mm)');twin.set_ylabel('Bottle tilt (deg)',color='#a55a27')
        axis.set_xlabel('Measured native time since cue (s)');axis.grid(alpha=.15);axis.set_xlim(2.5,26.5)
    fig.suptitle('Four independent calibration episodes, common hand stiffness 1600\nShaded physical onset brackets; dotted confirmation; no test outcomes',fontsize=11)
    fig.tight_layout()
    for ext in ('svg','pdf','png'):fig.savefig(out/f'four_calibration_states.{ext}',dpi=180)
    plt.close(fig)
    for p,h in bindings.items():
        if sha(p)!=h:raise ValueError('input changed during read-only export: '+p)
    report={'schema':'paperb-four-cell-calibration-and-prospective-plans-report-v1','status':'POSTHOC_CALIBRATION_REPORT_AND_FROZEN_PROSPECTIVE_PLANS',
        'calibration_cells':4,'independent_observation_slots':8,'recorded_task_rows':len(curve_rows),
        'calibration_mechanical_interval_cells_equal_in_this_recorded_cohort':all(len({(r['mechanical_response_lower_s'],r['mechanical_response_upper_s']) for r in cell_rows if r['event']==kind})==1 for kind in ('contact','release')),
        'empirical_envelope_s':cal['mechanical_latency_intervals_s'],'prospective_test_plans':16,'test_outcomes_accessed':0,
        'new_native_episodes':0,'fit_executed_here':False,'policy_or_frozen_source_changed':False,
        'does_not_prove_true_support_or_statistical_coverage':True,'fixed_scene_mass_interpolation_not_independent_random_episodes':True,
        'mass_and_contract_are_paired_not_separately_identified':True,'onset_and_confirmation_distinct':True,
        'gap_is_not_continuous_contact_hold':True,'raw_input_sha256':bindings,
        'source_release_sha256':SOURCE_RELEASE,'calibration_release_sha256':sha(root/'CALIBRATION_RELEASE.json'),
        'independent_audit_sha256':sha(audit_path),'formal_test_results_in_this_report':None}
    (out/'summary.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    (out/'README_cn.md').write_text('''本报告包含四条独立校准episode的8个机械响应区间、完整记录的夹指/瓶体曲线，以及通过冻结校准生成的16条未来测试计划。它不读取任何测试case目录或结果，不启动native/GPU，不执行fit，不更新策略或冻结源。

4格质量×FIFO校准全部由独立RAW审计准入。这个记录队列中，各格contact区间恰好相同，release区间也相同；这不证明载荷或延迟永远不影响机械响应，更不提供真实延迟support或统计覆盖保证。各格分别保留，不能把8个事件slot写成8个机器人episode。

prospective_16_plans.csv仅列合同、dispatch和hold决策。planned_schedules/保留完整source index映射及executor同编码SHA；它们不是测试成功率。16条测试是4方法×4固定配对条件，质量0.9/1.1在校准0.8/1.2之间插值，并与D5/5.5和gap18/18.5配对，不能独立归因质量和合同。

曲线横轴来自记录的native钟。蓝/紫阴影为独立审计的contact/verified stable release物理onset bracket，点线为confirmation，二者没有互换。contact→stable release的gap不是连续bilateral hold；正式joint与joint_with_hold分开计分。本图没有重新计分接触或机械验收。

CALIBRATION_AUDIT.json是独立准入依据，CALIBRATION_RELEASE.json绑定根执行源和fit产物。EXPORT_MANIFEST.json列导出成员SHA。export_report.py只导出已完成4cal及静态test roster，可重放到全新目录；不应覆盖旧输出。
''')
    hashes={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()}
    (out/'EXPORT_MANIFEST.json').write_text(json.dumps({'files':hashes,'member_count':len(hashes),'no_test_case_files_read':True},indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('status','calibration_cells','independent_observation_slots','recorded_task_rows','prospective_test_plans','test_outcomes_accessed')}))


if __name__=='__main__':main()
