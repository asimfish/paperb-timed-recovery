#!/usr/bin/env bash
# NA3 CPU rehearsals (stand-in physics, real P0 worker, real paced owner loop), one per declared case, a guard-stop case, then the reader.
set -u
cd "$(dirname "$0")"
PY=/home/liyufeng/miniforge3/envs/safeduo/bin/python
mkdir -p rehearsal
for c in na3_d050_naive na3_d050_comp na3_d150_naive na3_d150_comp; do
  $PY -B code/cpu_rehearsal.py --root "$PWD" --out rehearsal/r1_$c --case $c > rehearsal/r1_$c.log 2>&1; echo "exit=$?" >> rehearsal/r1_$c.log
  $PY -B reader/check_na3.py --case rehearsal/r1_$c --bridge code/async_bridge.py > rehearsal/r1_${c}_reader.log 2>&1; echo "exit=$?" >> rehearsal/r1_${c}_reader.log
done
$PY -B code/cpu_rehearsal.py --root "$PWD" --out rehearsal/r1_guard_stop --case na3_d050_comp --task-ticks 600 --unlawful-at 301 > rehearsal/r1_guard_stop.log 2>&1; echo "exit=$?" >> rehearsal/r1_guard_stop.log
$PY -B reader/check_na3.py --case rehearsal/r1_guard_stop --bridge code/async_bridge.py > rehearsal/r1_guard_stop_reader.log 2>&1; echo "exit=$?" >> rehearsal/r1_guard_stop_reader.log
echo done > rehearsal/ALL_DONE
