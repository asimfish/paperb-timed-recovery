"""Run the declared NA3 cases in fixed order: for each, poll GPU free memory read-only until the gate passes,
then run one gated attempt; a second attempt only if the first never started the native clock.

Never signals other processes or changes driver settings. Bounded waits; every poll is logged.
"""
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
POLL_S = 60
MAX_WAIT_S = 8 * 3600


def free_mib():
    rows = subprocess.check_output(['nvidia-smi', '--query-gpu=uuid,memory.free', '--format=csv,noheader,nounits'], text=True).strip().splitlines()
    return {r.split(',')[0].strip(): int(r.split(',')[1]) for r in rows}


def log(row):
    with (ROOT / 'logs' / 'gpu_wait.jsonl').open('a') as f:
        f.write(json.dumps(dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), **row)) + '\n')


def main():
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    gate = protocol['budget']['gpu_min_free_mib']
    (ROOT / 'logs').mkdir(exist_ok=True)
    start = time.monotonic()
    for case in protocol['budget']['case_order_fixed']:
        while True:
            while True:
                free = free_mib()
                passed = max(free.values()) >= gate
                log(dict(case=case, free_mib=free, gate_mib=gate, passed=passed))
                if passed:
                    break
                if time.monotonic() - start > MAX_WAIT_S:
                    log(dict(status='WAIT_BUDGET_EXHAUSTED_NOT_LAUNCHED', case=case))
                    return
                time.sleep(POLL_S)
            r = subprocess.run(['python3', str(ROOT / 'run_case.py'), '--case', case, '--execute'], capture_output=True, text=True)
            output = r.stdout + r.stderr
            log(dict(status='RUN_CASE_RETURNED', case=case, code=r.returncode, stdout=r.stdout[-3000:], stderr=r.stderr[-3000:]))
            if any((d / 'NATIVE_CLOCK_STARTED.json').exists() for d in (ROOT / 'cases').glob(case + '_a*')):
                break  # formal case recorded (whatever its outcome); never rerun
            if 'REFUSED_GPU_FREE_MEMORY_BELOW_GATE' in output:
                continue  # no attempt consumed; wait for the gate again
            if r.returncode != 0:
                log(dict(status='GATE_OR_BUDGET_STOP_SEQUENCE', case=case))
                return  # pin mismatch, order, or attempt budget exhausted
            # launched but the native clock never started: run_case enforces the attempt budget
    log(dict(status='ALL_DECLARED_CASES_ATTEMPTED'))


if __name__ == '__main__':
    main()
