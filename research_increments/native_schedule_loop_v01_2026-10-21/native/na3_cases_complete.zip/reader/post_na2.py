"""After all formal NA2 cases: reader per case, comparison figure, side-by-side native camera video, summary.

Reads only recorded files. Frames are composed (no interpolation, no duplication) into one
1920x440 strip per request tick of the full-length cases, labelled with the declared delay and
the native tick, and encoded at 10 fps = simulation real time (one frame per 24 ticks of
1/240 s). A case that stopped early (state guard) shows an explicit labelled panel instead of
frames it never recorded; its last real frame is never repeated.
"""
import json
from pathlib import Path
import subprocess
import sys

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
PY = '/home/liyufeng/miniforge3/envs/safeduo/bin/python'


def main():
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    order = protocol['budget']['case_order_fixed']
    cases = []
    for base in order:
        formal = [d for d in sorted((ROOT / 'cases').glob(base + '_a*')) if (d / 'NATIVE_CLOCK_STARTED.json').exists()]
        if len(formal) != 1:
            raise SystemExit('EXPECTED_ONE_FORMAL_CASE:' + base)
        cases.append(formal[0])
    out = ROOT / 'analysis'
    if out.exists():
        out.rename(ROOT / 'analysis_layout_v1')  # first post-processing pass retained (intersection-only video)
    out.mkdir(exist_ok=False)
    results = {c.name: json.loads((c / 'RESULT.json').read_text()) for c in cases}
    reports = {}
    for c in cases:
        subprocess.run([PY, '-B', str(ROOT / 'reader/check_na2.py'), '--case', str(c), '--bridge', str(ROOT / 'code/async_bridge.py')], check=True, stdout=subprocess.DEVNULL)
        reports[c.name] = json.loads((c / 'READER_REPORT.json').read_text())
    subprocess.run([PY, '-B', str(ROOT / 'reader/plot_na2.py'), '--cases', *map(str, cases), '--out', str(out / 'figures')], check=True)
    font_path = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
    font = ImageFont.truetype(font_path, 18) if Path(font_path).exists() else ImageFont.load_default()
    frame_sets = [sorted((c / 'frames').glob('*.jpg')) for c in cases]
    common = sorted(set.union(*[{f.name for f in fs} for fs in frame_sets]))
    strip_dir = out / 'video_strips'
    strip_dir.mkdir()
    for i, name in enumerate(common):
        tiles = [Image.open(c / 'frames' / name).convert('RGB') if (c / 'frames' / name).exists() else None for c in cases]
        w, h = next(t for t in tiles if t is not None).size
        strip = Image.new('RGB', (w * len(tiles), h + 40), (12, 20, 24))
        draw = ImageDraw.Draw(strip)
        for j, (c, tile) in enumerate(zip(cases, tiles)):
            delay = reports[c.name]['declared_return_delay_ms']
            if tile is not None:
                strip.paste(tile, (j * w, 40))
                draw.text((j * w + 12, 10), 'worker return delay %d ms   tick %d' % (delay, int(name[:-4])), fill=(240, 240, 236), font=font)
            else:
                r = results[c.name]
                draw.rectangle([j * w, 40, (j + 1) * w - 1, h + 39], fill=(40, 44, 48))
                draw.text((j * w + 12, 10), 'worker return delay %d ms' % delay, fill=(240, 240, 236), font=font)
                draw.text((j * w + 40, 40 + h // 2 - 30), 'case ended: %s at tick %s' % (r['stop_reason'], r['guard_stop_tick']), fill=(240, 240, 236), font=font)
                draw.text((j * w + 40, 40 + h // 2 + 5), 'no frames recorded after this tick', fill=(200, 200, 196), font=font)
        strip.save(strip_dir / ('%05d.png' % i))
    video = out / 'na2_side_by_side_10fps.mp4'
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-framerate', '10', '-i', str(strip_dir / '%05d.png'), '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
                    '-crf', '22', '-movflags', '+faststart', str(video)], check=True)
    probe = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'stream=width,height,nb_frames,duration', '-of', 'json', str(video)]))
    summary = dict(schema='PaperBNA2Summary/1', cases=[c.name for c in cases], video=dict(path=video.name, frames=len(common), probe=probe['streams'][0],
                                                                                         placeholder_panels={c.name: len(common) - len(fs) for c, fs in zip(cases, frame_sets)}),
                   stop={n: dict(stop_reason=r['stop_reason'], guard_stop_tick=r['guard_stop_tick'], final_tick=r['final_tick']) for n, r in results.items()},
                   per_case={n: {k: r[k] for k in ('status', 'declared_return_delay_ms', 'tickets', 'elapsed_ticks', 'elapsed_ticks_histogram', 'dispositions',
                                                   'channel_results', 'stale_fraction', 'worker_compute_ms', 'worker_held_ms', 'in_flight_wall_ms_per_elapsed_tick',
                                                   'tickets_with_step_lag_over_one_period_in_flight', 'lag_ms', 'ticks_lag_within_one_period',
                                                   'step_interval_ms_excluding_sense', 'step_wall_ms', 'sense_anchor_shift_ms', 'journal_bytes', 'censored')}
                             | {'checks_passed': sum(r['checks'].values()), 'checks_total': len(r['checks'])} for n, r in reports.items()})
    (out / 'NA2_SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({n: (v['status'], v['checks_passed'], v['elapsed_ticks_histogram'], v['dispositions'], v['channel_results']) for n, v in summary['per_case'].items()}, indent=1))
    print('video', summary['video'])


if __name__ == '__main__':
    sys.exit(main())
