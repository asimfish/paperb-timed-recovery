"""NA2 comparison figure from recorded files only (journal, TICKETS.json, CASE_CONFIG.json per case).

A: physical ticks elapsed between request and accepted return, every ticket, per declared delay.
B: what happened to the 8 planned slots of every ticket (STALE / APPLIED at original tick /
   REJECTED outside joint limits), as shares of all slots, labelled directly.
Palette: reference slots blue/aqua/orange (validated light mode; aqua below 3:1 -> direct labels).
"""
import argparse
import json
from pathlib import Path
import random

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

INK, INK2, GRID, SURFACE = '#0b0b0b', '#52514e', '#e4e3df', '#fcfcfb'
STALE, APPLIED, REJECTED = '#2a78d6', '#1baf7a', '#eb6834'


def load(case):
    events = [json.loads(x) for x in (case / 'ASYNC_JOURNAL.jsonl').read_bytes().splitlines()]
    cfg = json.loads((case / 'CASE_CONFIG.json').read_text())
    starts = {e['body']['ticket_id']: e['clock'][0] for e in events if e['kind'] == 'INFERENCE_START'}
    returns = {e['body']['ticket_id']: e['clock'][0] for e in events if e['kind'] == 'INFERENCE_RETURN'}
    status = {e['body']['command_id']: e['body']['status'] for e in events if e['kind'] == 'CHANNEL_RESULT'}
    slots = dict(STALE=0, APPLIED=0, REJECTED=0, DROPPED=0, OTHER=0)
    for e in events:
        if e['kind'] == 'SLOT_DISPOSITION':
            pr = e['body']['prepared']
            if pr['disposition'] == 'STALE':
                slots['STALE'] += 1
            elif pr['disposition'] == 'SUBMIT' and status.get(pr['command_id']) in ('APPLIED', 'REJECTED', 'DROPPED'):
                slots[status[pr['command_id']]] += 1
            else:
                slots['OTHER'] += 1
    result = json.loads((case / 'RESULT.json').read_text())
    return dict(delay=cfg['case']['return_delay_ms'], period_ms=cfg['period_ns'] / 1e6, elapsed=[returns[t] - starts[t] for t in returns], slots=slots,
                stop=result['stop_reason'], stop_tick=result['guard_stop_tick'])


def main():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--cases', nargs='+', required=True)
    p.add_argument('--out', required=True)
    a = p.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=False)
    data = sorted((load(Path(c)) for c in a.cases), key=lambda d: d['delay'])
    plt.rcParams.update({'font.size': 9, 'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2,
                         'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'DejaVu Sans', 'figure.facecolor': SURFACE, 'axes.facecolor': SURFACE})
    fig, (ax, bx) = plt.subplots(1, 2, figsize=(10.5, 5.0), gridspec_kw={'width_ratios': [1, 1.25]})
    fig.subplots_adjust(left=0.075, right=0.98, top=0.86, bottom=0.27, wspace=0.42)
    rng = random.Random(0)
    labels = ['%d ms\nn=%d%s' % (d['delay'], len(d['elapsed']), '' if d['stop'] == 'TASK_TICKS_COMPLETED' else '\nguard stop t%s' % d['stop_tick']) for d in data]
    for i, d in enumerate(data):
        xs = [i + rng.uniform(-0.18, 0.18) for _ in d['elapsed']]
        ax.scatter(xs, d['elapsed'], s=12, color=STALE, alpha=0.55, linewidths=0, zorder=3)
        med = sorted(d['elapsed'])[len(d['elapsed']) // 2]
        ax.plot([i - 0.3, i + 0.3], [med, med], color=INK, lw=2, zorder=4, solid_capstyle='round')
        ax.text(i + 0.33, med, 'median %d' % med, va='center', fontsize=8, color=INK)
    ax.axhline(8, color=INK2, lw=1, ls='--', zorder=2)
    ax.text(-0.45, 8.25, 'chunk horizon: all 8 planned ticks passed', fontsize=8, color=INK2, va='bottom')
    ax.set_xticks(range(len(data)), labels)
    ax.set_xlim(-0.5, len(data) - 0.2)
    ax.set_ylim(0, max(max(d['elapsed']) for d in data) + 2)
    ax.set_xlabel('declared worker return delay')
    ax.set_ylabel('physical ticks elapsed (request to return)')
    ax.grid(axis='y', color=GRID, lw=0.8)
    ax.set_title('A  Latency consumes physical time', loc='left', fontsize=10, fontweight='bold', color=INK)
    for i, d in enumerate(data):
        total = sum(d['slots'].values())
        left = 0.0
        for key, color in (('STALE', STALE), ('APPLIED', APPLIED), ('REJECTED', REJECTED), ('DROPPED', SURFACE)):
            share = d['slots'][key] / total
            if share > 0:
                hatch = '////' if key == 'DROPPED' else None
                bx.barh(i, share, left=left, height=0.56, color=color, edgecolor=INK2 if key == 'DROPPED' else SURFACE, linewidth=1 if key == 'DROPPED' else 2, hatch=hatch)
                if share >= 0.06:
                    bx.text(left + share / 2, i, '%.0f%%' % (100 * share), ha='center', va='center', fontsize=8.5, color='white' if key in ('STALE', 'REJECTED') else INK, fontweight='bold')
                elif key == 'DROPPED':
                    bx.annotate('%.0f%% dropped at guard stop' % (100 * share), xy=(left + share / 2, i + 0.28), xytext=(0.64, i + 0.5), fontsize=8, color=INK2, va='center',
                                arrowprops=dict(arrowstyle='-', color=INK2, lw=0.8))
            left += share
        assert d['slots']['OTHER'] == 0
    bx.set_yticks(range(len(data)), labels)
    bx.invert_yaxis()
    bx.set_xlim(0, 1)
    bx.set_xticks([0, 0.25, 0.5, 0.75, 1.0], ['0', '25%', '50%', '75%', '100%'])
    bx.set_xlabel('share of all planned slots (8 per ticket)')
    bx.grid(axis='x', color=GRID, lw=0.8)
    bx.set_title('B  Fate of every planned action slot', loc='left', fontsize=10, fontweight='bold', color=INK)
    handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in (STALE, APPLIED, REJECTED)] + [plt.Rectangle((0, 0), 1, 1, facecolor=SURFACE, edgecolor=INK2, hatch='////')]
    fig.legend(handles, ['STALE: planned tick already passed at return', 'APPLIED exactly at planned tick', 'REJECTED: outside joint limits (not clipped)', 'DROPPED: pending when the state guard stopped the case'],
               loc='lower left', bbox_to_anchor=(0.505, 0.0), ncol=1, frameon=False, fontsize=8)
    fig.suptitle('NA2: paced native loop, one physics tick per %.2f ms of wall time' % data[0]['period_ms'], x=0.07, ha='left', y=0.975, fontsize=11.5, fontweight='bold', color=INK)
    for ext in ('svg', 'pdf', 'png'):
        fig.savefig(out / ('na2_latency_slack.' + ext), dpi=160)
    rows = [dict(delay_ms=d['delay'], tickets=len(d['elapsed']), elapsed_ticks=sorted(d['elapsed']), slots=d['slots']) for d in data]
    (out / 'FIGURE_INPUTS.json').write_text(json.dumps(dict(cases=[str(c) for c in a.cases], rows=rows, data_windowed=False), indent=1) + '\n')


if __name__ == '__main__':
    main()
