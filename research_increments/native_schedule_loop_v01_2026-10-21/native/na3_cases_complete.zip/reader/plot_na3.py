"""NA3 comparison figure from recorded files only (journal, TICKETS.json, CASE_CONFIG.json, RESULT.json per case).

A: slack at return = planned offset - physical ticks elapsed, every ticket (>= 0: whole chunk still
   ahead; < 0: that many leading slots already passed), naive vs compensated per declared delay.
B: fate of every planned slot (STALE / APPLIED at planned tick / REJECTED outside joint limits / DROPPED at a guard stop).
Palette: reference slots blue/aqua/orange (validated light mode; aqua below 3:1 -> direct labels).
"""
import argparse
import json
from pathlib import Path
import random

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

INK, INK2, GRID, SURFACE = '#0b0b0b', '#52514e', '#e4e3df', '#fcfcfb'
STALE, APPLIED, REJECTED = '#2a78d6', '#1baf7a', '#eb6834'


def load(case):
    events = [json.loads(x) for x in (case / 'ASYNC_JOURNAL.jsonl').read_bytes().splitlines()]
    cfg = json.loads((case / 'CASE_CONFIG.json').read_text())
    tickets = json.loads((case / 'TICKETS.json').read_text())
    result = json.loads((case / 'RESULT.json').read_text())
    status = {e['body']['command_id']: e['body']['status'] for e in events if e['kind'] == 'CHANNEL_RESULT'}
    slots = dict(STALE=0, APPLIED=0, REJECTED=0, DROPPED=0, OTHER=0)
    for e in events:
        if e['kind'] == 'SLOT_DISPOSITION':
            pr = e['body']['prepared']
            if pr['disposition'] == 'STALE':
                slots['STALE'] += 1
            elif pr['disposition'] == 'SUBMIT' and status.get(pr['command_id']) in ('APPLIED', 'REJECTED', 'DROPPED'):
                slots[status[pr['command_id']]] += 1
            else:
                slots['OTHER'] += 1
    slack = [t['planned_offset_ticks'] - (t['return_tick'] - t['start_tick']) for t in tickets.values() if 'return_tick' in t]
    return dict(delay=cfg['case']['return_delay_ms'], schedule=cfg['case']['schedule'], period_ms=cfg['period_ns'] / 1e6, slack=slack, slots=slots,
                stop=result['stop_reason'], stop_tick=result['guard_stop_tick'])


def main():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--cases', nargs='+', required=True)
    p.add_argument('--out', required=True)
    a = p.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=False)
    data = [load(Path(c)) for c in a.cases]
    data.sort(key=lambda d: (d['delay'], d['schedule'] != 'naive'))
    plt.rcParams.update({'font.size': 9, 'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2,
                         'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'DejaVu Sans', 'figure.facecolor': SURFACE, 'axes.facecolor': SURFACE})
    fig, (ax, bx) = plt.subplots(1, 2, figsize=(11, 5.0), gridspec_kw={'width_ratios': [1, 1.2]})
    fig.subplots_adjust(left=0.075, right=0.98, top=0.86, bottom=0.27, wspace=0.42)
    rng = random.Random(0)
    labels = ['%d ms\n%s\nn=%d%s' % (d['delay'], d['schedule'], len(d['slack']), '' if d['stop'] == 'TASK_TICKS_COMPLETED' else '\nguard stop t%s' % d['stop_tick']) for d in data]
    for i, d in enumerate(data):
        xs = [i + rng.uniform(-0.18, 0.18) for _ in d['slack']]
        ax.scatter(xs, d['slack'], s=12, color=STALE, alpha=0.55, linewidths=0, zorder=3)
        med = sorted(d['slack'])[len(d['slack']) // 2]
        ax.plot([i - 0.3, i + 0.3], [med, med], color=INK, lw=2, zorder=4, solid_capstyle='round')
        ax.text(i + 0.33, med, 'median %d' % med, va='center', fontsize=8, color=INK)
    ax.axhline(0, color=INK2, lw=1, ls='--', zorder=2)
    ax.text(1.55, -0.6, '0 = chunk starts\nat the next tick', fontsize=8, color=INK2, va='top')
    ax.set_xticks(range(len(data)), labels)
    ax.set_xlim(-0.5, len(data) - 0.2)
    ax.set_ylabel('slack at return (planned offset - elapsed ticks)')
    ax.grid(axis='y', color=GRID, lw=0.8)
    ax.set_title('A  Slack left when the chunk arrives', loc='left', fontsize=10, fontweight='bold', color=INK)
    for i, d in enumerate(data):
        total = sum(d['slots'].values())
        left = 0.0
        for key, color in (('STALE', STALE), ('APPLIED', APPLIED), ('REJECTED', REJECTED), ('DROPPED', SURFACE)):
            share = d['slots'][key] / total if total else 0
            if share > 0:
                bx.barh(i, share, left=left, height=0.56, color=color, edgecolor=INK2 if key == 'DROPPED' else SURFACE, linewidth=1 if key == 'DROPPED' else 2,
                        hatch='////' if key == 'DROPPED' else None)
                if share >= 0.06:
                    bx.text(left + share / 2, i, '%.0f%%' % (100 * share), ha='center', va='center', fontsize=8.5, color='white' if key in ('STALE', 'REJECTED') else INK, fontweight='bold')
                elif key == 'STALE':
                    bx.text(left, i - 0.33, '%.0f%% STALE (%d slots)' % (100 * share, d['slots'][key]), ha='left', va='bottom', fontsize=7.5, color=INK2)
            left += share
        assert d['slots']['OTHER'] == 0
    bx.set_yticks(range(len(data)), ['%d ms %s' % (d['delay'], d['schedule']) for d in data])
    bx.invert_yaxis()
    bx.set_xlim(0, 1)
    bx.set_xticks([0, 0.25, 0.5, 0.75, 1.0], ['0', '25%', '50%', '75%', '100%'])
    bx.set_xlabel('share of all planned slots (8 per ticket)')
    bx.grid(axis='x', color=GRID, lw=0.8)
    bx.set_title('B  Fate of every planned action slot', loc='left', fontsize=10, fontweight='bold', color=INK)
    handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in (STALE, APPLIED, REJECTED)]
    names = ['STALE: planned tick already passed at return', 'APPLIED exactly at planned tick', 'REJECTED: outside joint limits (not clipped)']
    if any(d['slots']['DROPPED'] for d in data):
        handles.append(plt.Rectangle((0, 0), 1, 1, facecolor=SURFACE, edgecolor=INK2, hatch='////'))
        names.append('DROPPED: pending when the state guard stopped the case')
    fig.legend(handles, names,
               loc='lower left', bbox_to_anchor=(0.52, 0.0), ncol=1, frameon=False, fontsize=8)
    fig.suptitle('NA3: naive vs latency-compensated schedule, one physics tick per %.2f ms of wall time' % data[0]['period_ms'], x=0.075, ha='left', y=0.975, fontsize=11.5, fontweight='bold', color=INK)
    for ext in ('svg', 'pdf', 'png'):
        fig.savefig(out / ('na3_schedule_slack.' + ext), dpi=160)
    rows = [dict(delay_ms=d['delay'], schedule=d['schedule'], tickets=len(d['slack']), slack_ticks=sorted(d['slack']), slots=d['slots'], stop=d['stop']) for d in data]
    (out / 'FIGURE_INPUTS.json').write_text(json.dumps(dict(cases=[str(c) for c in a.cases], rows=rows, data_windowed=False), indent=1) + '\n')


if __name__ == '__main__':
    main()
