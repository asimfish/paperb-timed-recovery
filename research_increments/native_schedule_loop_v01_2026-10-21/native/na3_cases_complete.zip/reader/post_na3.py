"""After all formal NA3 cases: 2x2 native-camera grid video (rows: delay; columns: naive / compensated) and summary.

Reads only recorded frames and reader reports. One grid per request tick present in every case
(all four cases are full length); 10 fps = simulation real time; no interpolation or repetition.
"""
import json
from pathlib import Path
import subprocess

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]


def main():
    order = json.loads((ROOT / 'protocol.json').read_text())['budget']['case_order_fixed']
    cases = []
    for base in order:
        formal = [d for d in sorted((ROOT / 'cases').glob(base + '_a*')) if (d / 'NATIVE_CLOCK_STARTED.json').exists()]
        assert len(formal) == 1, base
        cases.append(formal[0])
    reports = {c.name: json.loads((c / 'READER_REPORT.json').read_text()) for c in cases}
    out = ROOT / 'analysis'
    strips = out / 'video_strips'
    strips.mkdir(parents=True, exist_ok=False)
    font_path = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
    font = ImageFont.truetype(font_path, 18) if Path(font_path).exists() else ImageFont.load_default()
    common = sorted(set.intersection(*[{f.name for f in (c / 'frames').glob('*.jpg')} for c in cases]))
    grid = [[cases[0], cases[1]], [cases[2], cases[3]]]  # d050 naive, d050 comp / d150 naive, d150 comp
    for i, name in enumerate(common):
        tiles = [[Image.open(c / 'frames' / name).convert('RGB') for c in row] for row in grid]
        w, h = tiles[0][0].size
        canvas = Image.new('RGB', (2 * w, 2 * (h + 36)), (12, 20, 24))
        draw = ImageDraw.Draw(canvas)
        for r, row in enumerate(grid):
            for col, c in enumerate(row):
                x, y = col * w, r * (h + 36)
                canvas.paste(tiles[r][col], (x, y + 36))
                rep = reports[c.name]
                draw.text((x + 10, y + 8), 'delay %d ms  %s  tick %d' % (rep['declared_return_delay_ms'], rep['schedule'], int(name[:-4])), fill=(240, 240, 236), font=font)
        canvas.save(strips / ('%05d.png' % i))
    video = out / 'na3_grid_10fps.mp4'
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-framerate', '10', '-i', str(strips / '%05d.png'), '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
                    '-crf', '22', '-movflags', '+faststart', str(video)], check=True)
    probe = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'stream=width,height,nb_frames,duration', '-of', 'json', str(video)]))
    keys = ('status', 'declared_return_delay_ms', 'schedule', 'tickets', 'elapsed_ticks_histogram', 'planned_offset_ticks', 'slack_ticks_at_return', 'dispositions',
            'channel_results', 'stale_fraction', 'worker_compute_ms', 'worker_held_ms', 'in_flight_wall_ms_per_elapsed_tick', 'tickets_with_step_lag_over_one_period_in_flight',
            'lag_ms', 'ticks_lag_within_one_period', 'step_interval_ms_excluding_sense', 'stop_reason', 'guard_stop_tick', 'journal_bytes', 'censored')
    summary = dict(schema='PaperBNA3Summary/1', cases=[c.name for c in cases], video=dict(path=video.name, frames=len(common), probe=probe['streams'][0]),
                   per_case={n: {k: r.get(k) for k in keys} | {'checks_passed': sum(r['checks'].values()), 'checks_total': len(r['checks'])} for n, r in reports.items()})
    (out / 'NA3_SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary['video']))


if __name__ == '__main__':
    main()
