"""CPU rehearsal of the NA2 paced owner loop with the real P0 worker and a stand-in physics adapter.

The adapter is a first-order joint tracker whose step and render sleep for declared wall
costs similar to the native case (default 4 ms / 60 ms). It exercises pacing and wiring
only; it is not native physics. Native joint limits from M1 are used for target admission.
"""
import argparse
import json
import os
from pathlib import Path
import sys
import time

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from async_bridge import AsyncBridge, fixture_header, canonical
from owner_loop import WorkerClient, run_paced_loop

LIMITS = [[-2.743699789047241, 2.743699789047241], [-1.7836999893188477, 1.7836999893188477], [-2.9006998538970947, 2.9006998538970947],
          [-3.042099952697754, -0.1517999917268753], [-2.80649995803833, 2.80649995803833], [0.544499933719635, 4.516899585723877],
          [-3.015899658203125, 3.015899658203125], [0.0, 0.03999999910593033], [0.0, 0.03999999910593033]]


class StandInAdapter:
    def __init__(self, q0, dt_ns, step_s, render_s, images, unlawful_at=None):
        self.k, self.q, self.qd = 0, np.asarray(q0, float), np.zeros(9)
        self.limits, self.dt_ns, self.step_s, self.render_s, self.unlawful_at = np.asarray(LIMITS, float), dt_ns, step_s, render_s, unlawful_at
        self.q0, self.images = list(q0), images

    def initial_target(self):
        return self.q0

    def state(self):
        lawful = self.unlawful_at is None or self.k < self.unlawful_at
        violations = [] if lawful else [dict(joint='synthetic', kind='synthetic_unlawful_at', value=self.k, bound=self.unlawful_at)]
        return dict(tick=self.k, time_ns=self.k * self.dt_ns, q=self.q.tolist(), qd=self.qd.tolist(), lawful=lawful, violations=violations)

    def target_admissible(self, target):
        t = np.asarray(target, float)
        return bool(t.shape == (9,) and np.isfinite(t).all() and np.all(t >= self.limits[:, 0]) and np.all(t <= self.limits[:, 1]))

    def render(self):
        time.sleep(self.render_s)
        small = self.images[min(self.k // 80, len(self.images) - 1)].transpose(1, 2, 0)
        return np.ascontiguousarray(small.repeat(10, axis=0).repeat(10, axis=1))

    def step(self, target):
        new = self.q + 0.08 * (np.asarray(target, float) - self.q)
        self.qd = (new - self.q) / (self.dt_ns * 1e-9)
        self.q = new
        self.k += 1
        time.sleep(self.step_s)


def main():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument('--root', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--case', required=True, help='declared protocol case id (selects return delay)')
    p.add_argument('--task-ticks', type=int, default=None)
    p.add_argument('--step-s', type=float, default=0.004)
    p.add_argument('--render-s', type=float, default=0.06)
    p.add_argument('--unlawful-at', type=int, default=None)
    a = p.parse_args()
    root, out = Path(a.root).resolve(), Path(a.out)
    out.mkdir(parents=True, exist_ok=False)
    protocol = json.loads((root / 'protocol.json').read_text())
    case = [c for c in protocol['cases'] if c['id'] == a.case][0]
    task_ticks = a.task_ticks or protocol['task_ticks']
    dt = protocol['dt_s']
    data = np.load(root / 'inputs/p0_dataset.npz')
    adapter = StandInAdapter(data['proprio'][0][:9].tolist(), int(round(dt * 1e9)), a.step_s, a.render_s, data['images'], a.unlawful_at)
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='')
    worker = WorkerClient([sys.executable, '-B', str(root / 'code/p0_service_worker.py'), '--root', str(root), '--return-delay-ms', str(case['return_delay_ms'])],
                          env, out / 'RAW_WORKER_CHANNEL.jsonl', out / 'worker_stderr.log')
    ready = worker.wait_message(120)
    assert len(ready) == 1 and ready[0]['kind'] == 'READY' and not ready[0]['cuda_initialized'], ready
    header = fixture_header()
    header.update(mode='CPU_FIXTURE', attempt_id='na3-cpu-rehearsal-' + a.case, failure_root_id='cpu-rehearsal-no-task', native_epoch='cpu-stand-in-adapter',
                  original_deadline_ns=int(round(task_ticks * dt * 1e9)), deadline_clock_id='stand-in-time-since-origin', graph_id='na3-cpu-rehearsal')
    header['actors'] = [dict(actor_id='p0_student', role='STUDENT', actor_source_sha256='a' * 64, weights_sha256='b' * 64, input_adapter_sha256='c' * 64)]
    header['initial_actor_id'] = 'p0_student'
    header['channel']['latency_ticks'] = protocol['channel_latency_ticks']
    (out / 'EXPECTED_HEADER.json').write_bytes(canonical(header) + b'\n')
    bridge = AsyncBridge(out / 'ASYNC_JOURNAL.jsonl', header, expected_header=json.loads(canonical(header)))
    period_ns = int(round(protocol['pace_factor'] * dt * 1e9))
    (out / 'CASE_CONFIG.json').write_text(json.dumps(dict(case=case, period_ns=period_ns, pace_factor=protocol['pace_factor'], dt_s=dt)) + '\n')
    t0 = time.monotonic()
    summary = run_paced_loop(adapter, bridge, worker, out, task_ticks=task_ticks, request_period=protocol['request_period_ticks'], period_ns=period_ns,
                             return_wait_s=protocol['return_wait_s'], actor_id='p0_student', dt_s=dt, schedule=case['schedule'], latency_window=protocol['latency_window'])
    code, tail = worker.stop()
    result = dict(status='CPU_REHEARSAL_FINISHED', case=case, period_ns=period_ns, **summary, worker_exit_code=code, worker_tail=tail,
                  wall_s=time.monotonic() - t0, native_physics=False, task_ticks=task_ticks)
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('censored', 'worker_tail')}))


if __name__ == '__main__':
    main()
